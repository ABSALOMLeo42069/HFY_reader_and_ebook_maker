# HFY NEKROCODEXXX — APK Build Instructions

## Option 1: Install as PWA (Easiest — No APK needed)
On your Android phone:
1. Open Chrome and go to the app URL
2. Tap the menu (⋮) → "Add to Home screen" or "Install app"
3. The app installs with an icon — opens fullscreen like a native app

## Option 2: Build APK with Bubblewrap (Recommended for real APK)
Requires: Node.js 18+, JDK 17 (NOT 21)

```bash
# Install Bubblewrap
npm install -g @bubblewrap/cli

# Initialize from the PWA manifest
bubblewrap init --manifest="https://preview-65099b6c-322b-41be-9418-f063ffa98116.space-z.ai/manifest.json" \
  --name="HFY NEKROCODEXXX" \
  --packageId="com.nekro.hfycyberdeck" \
  --appVersionName="1.0.0" \
  --appVersionCode=1

# Answer prompts:
# - Install JDK? → N (use your own JDK 17)
# - JDK 17 path → /path/to/your/jdk-17

# Download the Android project template
bubblewrap update

# Build the APK
bubblewrap build

# APK will be at: app-release-signed.apk
```

## Option 3: Build APK with Capacitor (Already set up in this project)
Requires: Android Studio or Android SDK + JDK 17

```bash
# Extract the zip
unzip hfy-nekrocodexxx.zip
cd hfy-nekrocodexxx

# Install dependencies
bun install
bun add @capacitor/android @capacitor/cli

# Set up Android SDK path
echo "sdk.dir=/path/to/Android/SDK" > android/local.properties

# Sync the web assets
npx cap sync android

# Build the APK
cd android
./gradlew assembleDebug

# APK will be at: app/build/outputs/apk/debug/app-debug.apk
```

## Option 4: Use Android Studio
1. Extract the zip
2. Open Android Studio
3. Open the `android/` folder as a project
4. Click "Build → Build Bundle(s) / APK(s) → Build APK(s)"
5. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

## Installing the APK on Android
1. Transfer the .apk file to your phone
2. Settings → Security → Enable "Install from unknown sources"
3. Open the .apk file with your file manager
4. Tap "Install"

## Signing for Release
For a release-signed APK:
```bash
keytool -genkey -v -keystore hfy.keystore -alias hfy_key \
  -keyalg RSA -keysize 2048 -validity 10000

# Then in android/app/build.gradle, add signingConfig
# Or use: ./gradlew assembleRelease
```
