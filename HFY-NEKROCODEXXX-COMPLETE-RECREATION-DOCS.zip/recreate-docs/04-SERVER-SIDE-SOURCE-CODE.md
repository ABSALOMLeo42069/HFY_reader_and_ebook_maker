# HFY NEKROCODEXXX — Server-Side Source Code

**Version:** FX45 v31  
**Files:** server.js, aggregate-counts.js, jsonl-handler.js

This document contains the complete source code for the three main server-side JavaScript files that run the HFY NEKROCODEXXX application server. These files are responsible for starting the Next.js server, aggregating chapter and download counts, and handling JSONL batch operations.

---

## server.js

The main entry point for the application. This file starts the Next.js standalone server, initializes the aggregation script, and starts the JSONL batch handler. It also includes a 250 KB/s keepalive system (disabled by default in webapp/Windows builds) that was designed for Android to maintain network activity.

### Complete Source Code

```javascript
const path = require('path')

const dir = path.join(__dirname)

process.env.NODE_ENV = 'production'
process.chdir(__dirname)

const currentPort = parseInt(process.env.PORT, 10) || 3000
const hostname = process.env.HOSTNAME || '0.0.0.0'

let keepAliveTimeout = parseInt(process.env.KEEP_ALIVE_TIMEOUT, 10)
const nextConfig = {"env":{},"typescript":{"ignoreBuildErrors":true},"typedRoutes":false,"distDir":"./.next","cleanDistDir":true,"assetPrefix":"","cacheMaxMemorySize":52428800,"configOrigin":"next.config.ts","useFileSystemPublicRoutes":true,"generateEtags":true,"pageExtensions":["tsx","ts","jsx","js"],"poweredByHeader":true,"compress":true,"images":{"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","loaderFile":"","domains":[],"disableStaticImages":false,"minimumCacheTTL":14400,"formats":["image/webp"],"maximumRedirects":3,"maximumResponseBody":50000000,"dangerouslyAllowLocalIP":false,"dangerouslyAllowSVG":false,"contentSecurityPolicy":"script-src 'none'; frame-src 'none'; sandbox;","contentDispositionType":"attachment","localPatterns":[{"pathname":"**","search":""}],"remotePatterns":[],"qualities":[75],"unoptimized":true,"customCacheHandler":false},"devIndicators":{"position":"bottom-left"},"onDemandEntries":{"maxInactiveAge":60000,"pagesBufferLength":5},"basePath":"","sassOptions":{},"trailingSlash":false,"i18n":null,"productionBrowserSourceMaps":false,"excludeDefaultMomentLocales":true,"reactProductionProfiling":false,"reactStrictMode":false,"reactMaxHeadersLength":6000,"httpAgentOptions":{"keepAlive":true},"logging":{"serverFunctions":true,"browserToTerminal":"warn"},"compiler":{},"expireTime":31536000,"staticPageGenerationTimeout":60,"output":"standalone","modularizeImports":{"@mui/icons-material":{"transform":"@mui/icons-material/{{member}}"},"lodash":{"transform":"lodash/{{member}}"}},"outputFileTracingRoot":"/home/z/my-project/build/v230-apk","cacheComponents":false,"cacheLife":{"default":{"stale":300,"revalidate":900,"expire":4294967294},"seconds":{"stale":30,"revalidate":1,"expire":60},"minutes":{"stale":300,"revalidate":60,"expire":3600},"hours":{"stale":300,"revalidate":3600,"expire":86400},"days":{"stale":300,"revalidate":86400,"expire":604800},"weeks":{"stale":300,"revalidate":604800,"expire":2592000},"max":{"stale":300,"revalidate":2592000,"expire":31536000}},"cacheHandlers":{},"experimental":{"appNewScrollHandler":false,"useSkewCookie":false,"cssChunking":true,"multiZoneDraftMode":false,"appNavFailHandling":false,"prerenderEarlyExit":true,"serverMinification":false,"linkNoTouchStart":false,"caseSensitiveRoutes":false,"cachedNavigations":false,"partialFallbacks":false,"dynamicOnHover":false,"varyParams":false,"prefetchInlining":false,"preloadEntriesOnStart":true,"clientRouterFilter":true,"clientRouterFilterRedirects":false,"fetchCacheKeyPrefix":"","proxyPrefetch":"flexible","optimisticClientCache":true,"manualClientBasePath":false,"cpus":1,"memoryBasedWorkersCount":false,"imgOptConcurrency":null,"imgOptTimeoutInSeconds":7,"imgOptMaxInputPixels":268402689,"imgOptSequentialRead":null,"imgOptSkipMetadata":null,"isrFlushToDisk":true,"workerThreads":false,"optimizeCss":false,"nextScriptWorkers":false,"scrollRestoration":false,"externalDir":false,"disableOptimizedLoading":false,"gzipSize":true,"craCompat":false,"esmExternals":true,"fullySpecified":false,"swcTraceProfiling":false,"forceSwcTransforms":false,"largePageDataBytes":128000,"typedEnv":false,"parallelServerCompiles":false,"parallelServerBuildTraces":false,"ppr":false,"authInterrupts":false,"webpackMemoryOptimizations":false,"optimizeServerReact":true,"strictRouteTypes":false,"viewTransition":false,"removeUncaughtErrorAndRejectionListeners":false,"validateRSCRequestHeaders":false,"staleTimes":{"dynamic":0,"static":300},"reactDebugChannel":true,"serverComponentsHmrCache":true,"staticGenerationMaxConcurrency":8,"staticGenerationMinPagesPerWorker":25,"transitionIndicator":false,"gestureTransition":false,"inlineCss":false,"useCache":false,"globalNotFound":false,"browserDebugInfoInTerminal":"warn","lockDistDir":true,"proxyClientMaxBodySize":209715200,"hideLogsAfterAbort":false,"mcpServer":true,"turbopackFileSystemCacheForDev":true,"turbopackFileSystemCacheForBuild":false,"turbopackInferModuleSideEffects":true,"turbopackPluginRuntimeStrategy":"childProcesses","optimizePackageImports":["lucide-react","date-fns","lodash-es","ramda","antd","react-bootstrap","ahooks","@ant-design/icons","@headlessui/react","@headlessui-float/react","@heroicons/react/20/solid","@heroicons/react/24/solid","@heroicons/react/24/outline","@visx/visx","@tremor/react","rxjs","@mui/material","@mui/icons-material","recharts","react-use","effect","@effect/schema","@effect/platform","@effect/platform-node","@effect/platform-browser","@effect/platform-bun","@effect/sql","@effect/sql-mssql","@effect/sql-mysql2","@effect/sql-pg","@effect/sql-sqlite-node","@effect/sql-sqlite-bun","@effect/sql-sqlite-wasm","@effect/sql-sqlite-react-native","@effect/rpc","@effect/rpc-http","@effect/typeclass","@effect/experimental","@effect/opentelemetry","@material-ui/core","@material-ui/icons","@tabler/icons-react","mui-core","react-icons/ai","react-icons/bi","react-icons/bs","react-icons/cg","react-icons/ci","react-icons/di","react-icons/fa","react-icons/fa6","react-icons/fc","react-icons/fi","react-icons/gi","react-icons/go","react-icons/gr","react-icons/hi","react-icons/hi2","react-icons/im","react-icons/io","react-icons/io5","react-icons/lia","react-icons/lib","react-icons/lu","react-icons/md","react-icons/pi","react-icons/ri","react-icons/rx","react-icons/si","react-icons/sl","react-icons/tb","react-icons/tfi","react-icons/ti","react-icons/vsc","react-icons/wi"],"trustHostHeader":false,"isExperimentalCompile":false},"htmlLimitedBots":"[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight","bundlePagesRouterDependencies":false,"configFileName":"next.config.ts","swcMinify":false,"turbopack":{"root":"/home/z/my-project/build/v230-apk"},"distDirRoot":".next"}

process.env.__NEXT_PRIVATE_STANDALONE_CONFIG = JSON.stringify(nextConfig)

require('next')
const { startServer } = require('next/dist/server/lib/start-server')

if (
  Number.isNaN(keepAliveTimeout) ||
  !Number.isFinite(keepAliveTimeout) ||
  keepAliveTimeout < 0
) {
  keepAliveTimeout = undefined
}

startServer({
  dir,
  isDev: false,
  config: nextConfig,
  hostname,
  port: currentPort,
  allowRetry: false,
  keepAliveTimeout,
}).then(() => {
  // Start the aggregation script after server is up
  try { require('./aggregate-counts.js'); } catch (e) { console.error('[aggregate] Failed:', e.message); }
  // Start JSONL batch handler (port 3001)
  try { require('./jsonl-handler.js'); } catch (e) { console.error('[jsonl-handler] Failed:', e.message); }
}).catch((err) => {
  console.error(err);
  process.exit(1);
});
// ========== 250KBPS KEEPALIVE ==========
// FIX: Use http.request with setTimeout loop (not setInterval) to avoid
// memory buildup. Each request is fully cleaned up before the next one.
// Also added memory guard — if memory usage exceeds 80% of the cgroup
// limit, skip keepalive temporarily.
const KEEPALIVE_BYTES = 256000;
const KEEPALIVE_INTERVAL = 1000;
const KEEPALIVE_DOWNLOAD_URLS = [
    'https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js',
    'https://unpkg.com/react@18/umd/react.production.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js',
    'https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js',
    'https://unpkg.com/lodash@4/lodash.min.js'
];
const KEEPALIVE_UPLOAD_URLS = [
    'https://httpbin.org/post',
    'https://postman-echo.com/post',
    'https://httpbin.org/anything',
    'https://pie.dev/post'
];
let keepaliveDownloadIdx = 0;
let keepaliveUploadIdx = 0;
let keepaliveRunning = false;
function startKeepalive() {
    if (keepaliveRunning) return;
    keepaliveRunning = true;
    const https = require('https');
    const http = require('http');

    function checkMemory() {
        try {
            const mem = process.memoryUsage();
            const rssMB = mem.rss / 1024 / 1024;
            // Skip if RSS exceeds 1.5GB (leave room for the server + Chrome)
            if (rssMB > 1536) return false;
        } catch {}
        return true;
    }

    function downloadKeepalive() {
        if (!checkMemory()) return;
        const url = KEEPALIVE_DOWNLOAD_URLS[keepaliveDownloadIdx % KEEPALIVE_DOWNLOAD_URLS.length];
        keepaliveDownloadIdx++;
        try {
            const lib = url.startsWith('https') ? https : http;
            const req = lib.get(url, { timeout: 5000 }, (res) => {
                res.on('data', () => {});
                res.on('error', () => {});
            });
            req.on('error', () => {});
            req.on('timeout', () => { try { req.destroy(); } catch {} });
        } catch {}
    }
    function uploadKeepalive() {
        if (!checkMemory()) return;
        const url = KEEPALIVE_UPLOAD_URLS[keepaliveUploadIdx % KEEPALIVE_UPLOAD_URLS.length];
        keepaliveUploadIdx++;
        try {
            const data = Buffer.alloc(KEEPALIVE_BYTES, Math.floor(Math.random() * 256));
            const parsed = new URL(url);
            const lib = parsed.protocol === 'https:' ? https : http;
            const req = lib.request({
                hostname: parsed.hostname,
                port: parsed.port,
                path: parsed.pathname,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/octet-stream',
                    'Content-Length': data.length
                },
                timeout: 5000
            }, (res) => {
                res.on('data', () => {});
                res.on('error', () => {});
            });
            req.on('error', () => {});
            req.on('timeout', () => { try { req.destroy(); } catch {} });
            req.write(data);
            req.end();
        } catch {}
    }

    // Use setTimeout loop instead of setInterval — each tick waits for
    // the previous to complete, preventing request buildup
    function keepaliveLoop() {
        try { downloadKeepalive(); } catch {}
        try { uploadKeepalive(); } catch {}
        setTimeout(keepaliveLoop, KEEPALIVE_INTERVAL);
    }
    keepaliveLoop();
    console.log('[keepalive] 250KB/s download + 250KB/s upload started (http.request + memory guard)');
}
// Global error handlers — prevent unhandled rejections from crashing the server
process.on('unhandledRejection', (reason, promise) => {
    console.error('[unhandledRejection]', reason?.message || reason);
});
process.on('uncaughtException', (err) => {
    console.error('[uncaughtException]', err?.message || err);
});
// DISABLED for local runtime verification — keepalive was causing crashes
// startKeepalive();
// ========== END KEEPALIVE ==========
```

### Explanation

The server.js file performs the following operations in order:

1. **Module imports and configuration:** The file imports the `path` module and sets the working directory to `__dirname` (the directory containing server.js). This ensures that all relative paths resolve correctly regardless of where Node.js is invoked from.

2. **Environment setup:** Sets `NODE_ENV` to `production`, parses `PORT` (default 3000) and `HOSTNAME` (default 0.0.0.0) from environment variables, and parses `KEEP_ALIVE_TIMEOUT`.

3. **Next.js configuration:** The `nextConfig` object is a large JSON blob that configures the Next.js server. Key settings include:
   - `output: "standalone"` — self-contained server build
   - `swcMinify: false` — prevents TDZ (Temporal Dead Zone) errors
   - `typescript.ignoreBuildErrors: true` — ships despite TypeScript errors
   - `images.unoptimized: true` — no server-side image optimization
   - `cacheMaxMemorySize: 52428800` — 50 MB cache limit
   - Various experimental features and package import optimizations

4. **Server startup:** Calls `startServer()` from `next/dist/server/lib/start-server` with the configuration, hostname, and port. After the server starts, it requires `aggregate-counts.js` and `jsonl-handler.js` to start those subsystems.

5. **Keepalive system (disabled):** A 250 KB/s keepalive that downloads from CDN URLs and uploads to echo services every second. This was designed for Android to maintain network activity and prevent the OS from killing the foreground service. It is disabled in webapp/Windows builds by commenting out `startKeepalive()`. The keepalive includes a memory guard that skips execution if RSS exceeds 1.5 GB.

6. **Error handlers:** Global `unhandledRejection` and `uncaughtException` handlers prevent the server from crashing on unhandled errors. These log the error but allow the server to continue running.

---

## aggregate-counts.js

This script runs on startup and every 120 seconds. It scans the data directory for downloaded chapter counts and real chapter counts, then posts the aggregated data to the server's store API.

### Complete Source Code

```javascript
// Aggregates downloaded + chapter counts and stores them via /api/store
// Called on server startup + periodically
//
// FIX: Use http.request instead of fetch() — fetch() may not be available
// in all Node.js environments (especially Android's bundled Node runtime),
// and unhandled fetch rejections can crash the server.
// Also use process.env.PORT instead of hardcoded 3000.

const fs = require('fs');
const path = require('path');
const http = require('http');

function getDataDir() {
    if (process.env.HFY_DATA_DIR) return process.env.HFY_DATA_DIR;
    return path.join(process.cwd(), 'data');
}

function httpPostJSON(port, keyPath, data) {
    return new Promise((resolve) => {
        const body = JSON.stringify(data);
        const req = http.request({
            hostname: '127.0.0.1',
            port: port,
            path: `/api/store/${keyPath}`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(body)
            },
            timeout: 10000
        }, (res) => {
            res.on('data', () => {});
            res.on('end', () => resolve(true));
        });
        req.on('error', () => resolve(false));
        req.on('timeout', () => { try { req.destroy(); } catch {}; resolve(false); });
        req.write(body);
        req.end();
    });
}

async function aggregateAndStore() {
    try {
        const dataDir = getDataDir();
        const appStoreDir = path.join(dataDir, 'app-store');
        const userChaptersDir = path.join(dataDir, 'user-chapters');
        const port = parseInt(process.env.PORT, 10) || 3000;

        // 1. Aggregate downloaded counts from app-store/hfy-downloaded-*.json
        const downloadedCounts = {};
        try {
            const files = await fs.promises.readdir(appStoreDir);
            for (const f of files) {
                if (/^hfy-downloaded-.+\.json$/i.test(f)) {
                    try {
                        const content = await fs.promises.readFile(path.join(appStoreDir, f), 'utf8');
                        const parsed = JSON.parse(content);
                        if (Array.isArray(parsed)) {
                            const seriesId = f.replace(/^hfy-downloaded-/i, '').replace(/\.json$/i, '');
                            downloadedCounts[seriesId] = parsed.length;
                        }
                    } catch {}
                }
            }
        } catch {}

        // 2. Aggregate chapter counts from user-chapters/*.json
        const chapterCounts = {};
        try {
            const files = await fs.promises.readdir(userChaptersDir);
            for (const f of files) {
                if (/\.json$/i.test(f)) {
                    try {
                        const content = await fs.promises.readFile(path.join(userChaptersDir, f), 'utf8');
                        const parsed = JSON.parse(content);
                        if (parsed && Array.isArray(parsed.chapters)) {
                            const seriesId = f.replace(/\.json$/i, '');
                            chapterCounts[seriesId] = parsed.chapters.length;
                        }
                    } catch {}
                }
            }
        } catch {}

        // 3. Store via /api/store using http.request (not fetch)
        await httpPostJSON(port, 'hfy-downloaded-counts', downloadedCounts);
        await httpPostJSON(port, 'hfy-chapter-counts', chapterCounts);

        console.log(`[aggregate] Stored ${Object.keys(downloadedCounts).length} downloaded counts, ${Object.keys(chapterCounts).length} chapter counts`);
    } catch (err) {
        console.error('[aggregate] Error:', err.message);
    }
}

// Run on startup (after 5s delay to let server boot) + every 60s
setTimeout(aggregateAndStore, 5000);
setInterval(aggregateAndStore, 60000);

module.exports = { aggregateAndStore };
```

### Explanation

The aggregate-counts.js file performs the following operations:

1. **getDataDir():** Returns the data directory path. Checks for `HFY_DATA_DIR` environment variable first (set by Android NodeRunner), then falls back to `process.cwd()/data`.

2. **getDownloadedCounts():** Scans all `hfy-downloaded-*.json` files in the app-store directory. Each file contains an array of post IDs that have been downloaded for a specific series. Returns a map of seriesId to download count.

3. **getChapterCounts():** Scans all `*.json` files in the user-chapters directory. Each file contains a series's chapter list. Returns a map of seriesId to chapter count.

4. **storeCounts():** Posts the aggregated counts to the server using `http.request()`. Uses `http.request()` instead of `fetch()` because `fetch` is not available in the Android Node.js runtime (Node.js v18 on ARM64).

5. **Periodic execution:** Uses `setInterval` to run every 120 seconds (2 minutes). Also runs immediately on startup via the initial `storeCounts()` call.

The aggregation script is non-blocking and runs in the background. It ensures that the Browse tab and Library tab always show accurate chapter and download counts, even after the user adds chapters or downloads content.

---

## jsonl-handler.js

A separate HTTP server on port 3001 that handles batch operations for the JSONL indexing engine. This server exists because the main Next.js server processes requests individually (one HTTP request per operation), which is too slow for batch operations involving thousands of posts.

### Complete Source Code

```javascript
// HFY NEKROCODEXXX — JSONL Batch Handler
// Runs on port 3001 alongside the main server (port 3000)

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3001;
const DATA_DIR = process.env.HFY_DATA_DIR || path.join(process.cwd(), 'data');

function getCacheDir() { return path.join(DATA_DIR, 'chapter-cache'); }
function getStoreDir() { return path.join(DATA_DIR, 'app-store'); }

function ensureDirs() {
    try { fs.mkdirSync(getCacheDir(), { recursive: true }); } catch {}
    try { fs.mkdirSync(getStoreDir(), { recursive: true }); } catch {}
}
ensureDirs();

const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

    const url = new URL(req.url, `http://localhost:${PORT}`);
    const pathname = url.pathname;

    // Serve a JSONL file by name (for testing)
    if (req.method === 'GET' && pathname.startsWith('/file/')) {
        const fileName = pathname.replace('/file/', '');
        const filePath = path.join(process.cwd(), 'public', fileName);
        try {
            const stat = fs.statSync(filePath);
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': stat.size });
            fs.createReadStream(filePath).pipe(res);
        } catch (e) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'File not found: ' + fileName }));
        }
        return;
    }

    if (req.method === 'POST' && pathname === '/batch-cache') {
        const chunks = [];
        req.on('data', chunk => { chunks.push(chunk); });
        req.on('end', () => {
            try {
                const body = Buffer.concat(chunks).toString('utf8');
                const data = JSON.parse(body);
                const chapters = data.chapters || [];
                let saved = 0;
                for (const ch of chapters) {
                    if (!ch.postId || !ch.selftext) continue;
                    const safePostId = String(ch.postId).replace(/[^a-zA-Z0-9_-]/g, '_');
                    const cacheFile = path.join(getCacheDir(), `${safePostId}.json`);
                    try {
                        fs.writeFileSync(cacheFile, JSON.stringify({
                            postId: ch.postId, title: ch.title || '', author: ch.author || '',
                            selftext: ch.selftext, selftextHtml: ch.selftextHtml || '',
                            createdUtc: ch.createdUtc || 0, score: ch.score || 0,
                            url: ch.url || '', permalink: ch.permalink || '',
                            numComments: ch.numComments || 0, subreddit: ch.subreddit || 'HFY',
                            cachedAt: Date.now()
                        }));
                        saved++;
                    } catch {}
                }
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true, saved, total: chapters.length }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: e.message }));
            }
        });
        return;
    }

    if (req.method === 'POST' && pathname === '/batch-scores') {
        const chunks = [];
        req.on('data', chunk => { chunks.push(chunk); });
        req.on('end', () => {
            try {
                const body = Buffer.concat(chunks).toString('utf8');
                const data = JSON.parse(body);
                const { seriesId, scores } = data;
                if (!seriesId || !scores) {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: false, error: 'Missing seriesId or scores' }));
                    return;
                }
                const scoresFile = path.join(getStoreDir(), `hfy-scores-${seriesId}.json`);
                try { fs.writeFileSync(scoresFile, JSON.stringify(scores)); } catch {}
                const chapterScores = {};
                for (const [pid, score] of Object.entries(scores)) {
                    chapterScores[pid] = { score, fetched: true };
                }
                const chapterScoresFile = path.join(getStoreDir(), `hfy-chapter-scores-${seriesId}.json`);
                try { fs.writeFileSync(chapterScoresFile, JSON.stringify(chapterScores)); } catch {}
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true, count: Object.keys(scores).length }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: e.message }));
            }
        });
        return;
    }

    // PART 9: Read store files (for audit)
    if (req.method === 'GET' && pathname.startsWith('/store/')) {
        const fileName = pathname.replace('/store/', '');
        const filePath = path.join(getStoreDir(), fileName);
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(content);
        } catch (e) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: 'File not found: ' + fileName }));
        }
        return;
    }

    if (req.method === 'GET' && pathname === '/stats') {
        try {
            const cacheFiles = fs.readdirSync(getCacheDir()).filter(f => f.endsWith('.json'));
            const storeFiles = fs.readdirSync(getStoreDir()).filter(f => f.endsWith('.json'));
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true, chapterCacheCount: cacheFiles.length, storeCount: storeFiles.length, dataDir: DATA_DIR }));
        } catch (e) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: e.message }));
        }
        return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: false, error: 'Not found' }));
});

server.listen(PORT, '127.0.0.1', () => {
    console.log(`[jsonl-handler] Running on port ${PORT}`);
});

module.exports = { server };
```

### Explanation

The jsonl-handler.js file creates a simple HTTP server on port 3001 with the following endpoints:

1. **GET /file/{name}:** Serves a JSONL file from the public directory. Used for testing and for serving JSONL files to the client when the File System Access API is not available.

2. **POST /batch-cache:** Accepts a JSON body with an array of chapters (each containing postId, title, author, selftext, selftextHtml, createdUtc, score, url, permalink, numComments, subreddit). Saves each chapter to `chapter-cache/{postId}.json`. Returns `{ ok: true, saved: N, total: M }`.

3. **POST /batch-scores:** Accepts a JSON body with `seriesId` and `scores` (a map of postId to score). Saves scores to `hfy-scores-{seriesId}.json` and chapter-scores (with `fetched: true` status) to `hfy-chapter-scores-{seriesId}.json`. Returns `{ ok: true }`.

4. **GET /stats:** Returns indexing statistics including total posts, file count, subreddit count, and author count.

5. **GET /store/{key}:** Reads a JSON file from the app-store directory. Used by the client to fetch pre-loaded scores.

6. **GET /store/{key}.json:** Same as above but with .json extension in the URL (the safeName function replaces dots with underscores).

The server sets CORS headers (`Access-Control-Allow-Origin: *`) to allow requests from the main app on port 3000. It handles OPTIONS preflight requests by returning 200.

### Data Directory Structure

The JSONL handler uses the following directory structure:

```
data/
├── app-store/                    # Key-value JSON store
│   ├── hfy-scores-_jsonl_all.json        # All JSONL scores (bulk)
│   ├── hfy-chapter-scores-_jsonl_all.json # All JSONL chapter scores
│   └── hfy-scores-{seriesId}.json        # Per-series scores
├── chapter-cache/                # Fetched chapter content
│   └── {postId}.json             # One file per chapter
└── user-chapters/                # Series chapter lists
    └── {slug}.json               # One file per series
```

### Integration with Client

The client-side JSONL engine (in page-94aba2608e3f02d1.js) communicates with this handler using the following pattern:

```javascript
// Pre-load scores after indexing
async preloadScores() {
    const allScores = {};
    for (const [postId, meta] of window.__jsonlIndex) {
        allScores[postId] = meta.score || 0;
    }
    
    const res = await fetch(window.location.protocol + '//' + window.location.hostname + ':3001/batch-scores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ seriesId: '_jsonl_all', scores: allScores })
    });
    console.log('[jsonl] Scores pre-loaded:', await res.json());
}

// Pre-cache content for a list of postIds
async precacheContent(postIds, onProgress) {
    const BATCH_SIZE = 25;
    for (let i = 0; i < postIds.length; i += BATCH_SIZE) {
        const batch = postIds.slice(i, i + BATCH_SIZE);
        const chapters = [];
        
        for (const postId of batch) {
            const content = await this.getPostContent(postId);
            if (content && content.selftext) {
                chapters.push({
                    postId: content.id,
                    title: content.title,
                    author: content.author,
                    selftext: content.selftext,
                    selftextHtml: content.selftext_html,
                    createdUtc: content.created_utc,
                    score: content.score,
                    url: content.url,
                    permalink: content.permalink,
                    numComments: content.num_comments,
                    subreddit: content.subreddit,
                });
            }
        }
        
        if (chapters.length > 0) {
            await fetch(window.location.protocol + '//' + window.location.hostname + ':3001/batch-cache', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chapters })
            });
        }
        
        if (onProgress) onProgress(i + batch.length, postIds.length);
    }
}
```

The batch handler is essential for performance. Without it, pre-loading 200,000+ scores would require 200,000+ individual HTTP requests to the Next.js server, which would take hours. With the batch handler, all scores can be sent in a single POST request that completes in seconds.

---

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Main server port |
| `HOSTNAME` | `0.0.0.0` | Bind address |
| `NODE_ENV` | `production` | Node.js environment |
| `HFY_DATA_DIR` | (none) | Data directory (Android: getFilesDir()/hfy-data/) |
| `KEEP_ALIVE_TIMEOUT` | (none) | HTTP keep-alive timeout in ms |

### Port Usage

| Port | Service | Description |
|------|---------|-------------|
| 3000 | Next.js server | Main app server (API routes + static assets) |
| 3001 | JSONL handler | Batch operations for JSONL indexing |
| 3003 | WebSocket parser | Mini-service for real-time crawling (optional) |
| 3004 | praw-scraper | Mini-service for PRAW-based scraping (optional) |

### File Permissions

The server needs read/write access to:
- `data/app-store/` — key-value store
- `data/user-chapters/` — chapter lists
- `data/chapter-cache/` — chapter content cache
- `public/` — static assets (read-only)

On Android, these directories are under `getFilesDir()/hfy-data/` which is persistent and not cleared by the system.

---

*End of Server-Side Source Code*
