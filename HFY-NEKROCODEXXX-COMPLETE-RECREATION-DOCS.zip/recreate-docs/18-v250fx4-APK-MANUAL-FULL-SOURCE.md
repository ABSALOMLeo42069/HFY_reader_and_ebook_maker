# HFY NEKROCODEXXX v250fx4 APK Recreation Manual

Version: v250fx4 | Dev: Mahmudul Hossain

---

## Chapters
1. Introduction 2. Architecture 3. Prerequisites 4. Base APK 5. NodeRunner.java 6. NodeForegroundService.java 7. MainActivity.java 8. AndroidManifest 9. Gradle 10. Building 11. Signing 12. WiFi Lock 13. Auto-Restart 14. 250kbps Keepalive 15. aggregate Fix 16. Port Protection 17. Browser Simulation 18. UA Rotation 19. Troubleshooting 20. Build Script 21. File Sizes 22. Native Libraries 23. Source Code

# Chapter 1: Introduction

APK bundles Node.js + Next.js + Java bridge. Server on :3000, WebView UI. 250kbps WiFi lock, auto-restart, persistent storage. v250fx4 adds browser simulation + UA rotation for Reddit rate limit bypass.

# Chapter 2: Architecture

MainActivity (WebView) -> NodeForegroundService (wakelock+wifilock+keepalive) -> NodeRunner (native Node.js). Server uses 7 fetch strategies including browser simulation with full Chrome headers.

# Chapter 3: Prerequisites

JDK 17+, Android SDK (platform-34, build-tools 36.0.0), Gradle 8.14+, Bun, apksigner, zipalign.

# Chapter 4: Base APK

Take v2.4.0 APK, replace server. zip -0 for uncompressed (critical for Node.js memory-mapping).

# Chapter 5: NodeRunner.java

- Accepts server.js OR main.js
- volatile Process + volatile boolean keepRunning
- Auto-restart: 3s delay
- Sets HFY_DATA_DIR to getFilesDir()/hfy-data/

```java
package com.nekro.hfycyberdeck;
public class NodeRunner {
    private volatile Process nodeProcess;
    private volatile boolean keepRunning = false;
    // startServer(): extract files, test node, launch via linker64
    // Log reader thread: auto-restart on crash (3s delay)
    // stopServer(): keepRunning = false (prevents auto-restart)
}
```

# Chapter 6: NodeForegroundService.java

- PARTIAL_WAKE_LOCK + WIFI_MODE_FULL_HIGH_PERF (permanent)
- 250kbps keepalive (250KB down + 250KB up every 1s)
- onTaskRemoved/onDestroy: restart unless userRequestedStop
- START_STICKY

# Chapter 7: MainActivity.java

WebView with JS, DOM storage, AndroidFolderPicker interface, fullscreen. onDestroy: setUserRequestedStop + stopService.

# Chapter 8: AndroidManifest.xml

Permissions: INTERNET, WIFI_STATE, FOREGROUND_SERVICE_DATA_SYNC, WAKE_LOCK, MANAGE_EXTERNAL_STORAGE. foregroundServiceType=dataSync, extractNativeLibs.

# Chapter 9: Gradle

abiFilters arm64-v8a, noCompress node/so/js/json, useLegacyPackaging, minifyEnabled false.

# Chapter 10: Building

cp APK, zip -d META-INF+server, zip -0 new server, zipalign, apksigner sign.

# Chapter 11: Signing

keytool -genkey, apksigner sign --v2 --v3. Different keystore = uninstall old.

# Chapter 12: WiFi Lock

Layer 1: WifiLock FULL_HIGH_PERF. Layer 2: WakeLock PARTIAL. Layer 3: 250kbps traffic.

# Chapter 13: Auto-Restart

NodeRunner: 3s + keepRunning. Service: onTaskRemoved/onDestroy. userRequestedStop flag.

# Chapter 14: 250kbps Keepalive

250KB download (6 URLs) + 250KB upload (3 URLs) every 1s. try-finally. ~41GB/day.

# Chapter 15: aggregate-counts.js Fix

fetch() not on Android -> crash. Fix: http.request().

# Chapter 16: Port Protection

net.createServer check. EADDRINUSE -> wait 5s -> retry.

# Chapter 17: Browser Simulation (v250fx4 NEW)

Strategy 0.7: sends full Chrome browser headers to Reddit .json endpoint:
- Sec-Ch-Ua, Sec-Ch-Ua-Mobile, Sec-Ch-Ua-Platform
- Sec-Fetch-Dest, Sec-Fetch-Mode, Sec-Fetch-Site, Sec-Fetch-User
- Accept-Encoding: gzip, deflate, br
- Accept-Language: en-US,en;q=0.9
- Upgrade-Insecure-Requests: 1

This makes Reddit think the request is from a real Chrome browser, not a bot.

# Chapter 18: UA Rotation (v250fx4 NEW)

8 rotating User-Agents:
- Chrome 131/130/129 (Windows)
- Chrome 131 (Mac, Linux)
- Firefox 130 (Windows)
- Safari 17.6 (Mac)
- Edge 131 (Windows)

getRandomUA() called for ALL Reddit requests. Prevents fingerprinting.

# Chapter 19: Troubleshooting

ERR_CONNECTION_REFUSED, App not installed, Crash 5s, Crash loop, Favorites, STOP, Rename, EXE open.

# Chapter 20: Build Script

```bash
cp HFY-NEKROCODEXXX-v2.4.0.apk HFY-v250fx4.apk
zip -d HFY-v250fx4.apk "META-INF/*" "assets/server/*"
mkdir -p staging/assets/server && cp -r server/. staging/assets/server/
cd staging && zip -0 -r ../HFY-v250fx4.apk assets/server/
zipalign -f -p 4 HFY-v250fx4.apk aligned.apk
apksigner sign --ks hfy.keystore --v2 --v3 --out final.apk aligned.apk
```

# Chapter 21: File Sizes

APK ~431MB, server ~191MB, libs ~100MB.

# Chapter 22: Native Libraries

libnode.so, libsqlite3.so, libssl.so, libcrypto.so, libicu*.so, libcares.so, libc++_shared.so.

# Chapter 23: Source Code

## server.js

```javascript
const path = require('path')

const dir = path.join(__dirname)

process.env.NODE_ENV = 'production'
process.chdir(__dirname)

const currentPort = parseInt(process.env.PORT, 10) || 3000
const hostname = process.env.HOSTNAME || '0.0.0.0'

let keepAliveTimeout = parseInt(process.env.KEEP_ALIVE_TIMEOUT, 10)
const nextConfig = {"env":{},"typescript":{"ignoreBuildErrors":true},"typedRoutes":false,"distDir":"./.next","cleanDistDir":true,"assetPrefix":"","cacheMaxMemorySize":52428800,"configOrigin":"next.config.ts","useFileSystemPublicRoutes":true,"generateEtags":true,"pageExtensions":["tsx","ts","jsx","js"],"poweredByHeader":true,"compress":true,"images":{"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","loaderFile":"","domains":[],"disableStaticImages":false,"minimumCacheTTL":14400,"formats":["image/webp"],"maximumRedirects":3,"maximumResponseBody":50000000,"dangerouslyAllowLocalIP":false,"dangerouslyAllowSVG":false,"contentSecurityPolicy":"script-src 'none'; frame-src 'none'; sandbox;","contentDispositionType":"attachment","localPatterns":[{"pathname":"**","search":""}],"remotePatterns":[],"qualities":[75],"unoptimized":true,"customCacheHandler":false},"devIndicators":{"position":"bottom-left"},"onDemandEntries":{"maxInactiveAge":60000,"pagesBufferLength":5},"basePath":"","sassOptions":{},"trailingSlash":false,"i18n":null,"productionBrowserSourceMaps":false,"excludeDefaultMomentLocales":true,"reactProductionProfiling":false,"reactStrictMode":false,"reactMaxHeadersLength":6000,"httpAgentOptions":{"keepAlive":true},"logging":{"serverFunctions":true,"browserToTerminal":"warn"},"compiler":{},"expireTime":31536000,"staticPageGenerationTimeout":60,"output":"standalone","modularizeImports":{"@mui/icons-material":{"transform":"@mui/icons-material/{{member}}"},"lodash":{"transform":"lodash/{{member}}"}},"outputFileTracingRoot":"/home/z/my-project/build/v230-apk","cacheComponents":false,"cacheLife":{"default":{"stale":300,"revalidate":900,"expire":4294967294},"seconds":{"stale":30,"revalidate":1,"expire":60},"minutes":{"stale":300,"revalidate":60,"expire":3600},"hours":{"stale":300,"revalidate":3600,"expire":86400},"days":{"stale":300,"revalidate":86400,"expire":604800},"weeks":{"stale":300,"revalidate":604800,"expire":2592000},"max":{"stale":300,"revalidate":2592000,"expire":31536000}},"cacheHandlers":{},"experimental":{"appNewScrollHandler":false,"useSkewCookie":false,"cssChunking":true,"multiZoneDraftMode":false,"appNavFailHandling":false,"prerenderEarlyExit":true,"serverMinification":false,"linkNoTouchStart":false,"caseSensitiveRoutes":false,"cachedNavigations":false,"partialFallbacks":false,"dynamicOnHover":false,"varyParams":false,"prefetchInlining":false,"preloadEntriesOnStart":true,"clientRouterFilter":true,"clientRouterFilterRedirects":false,"fetchCacheKeyPrefix":"","proxyPrefetch":"flexible","optimisticClientCache":true,"manualClientBasePath":false,"cpus":1,"memoryBasedWorkersCount":false,"imgOptConcurrency":null,"imgOptTimeoutInSeconds":7,"imgOptMaxInputPixels":268402689,"imgOptSequentialRead":null,"imgOptSkipMetadata":null,"isrFlushToDisk":true,"workerThreads":false,"optimizeCss":false,"nextScriptWorkers":false,"scrollRestoration":false,"externalDir":false,"disableOptimizedLoading":false,"gzipSize":true,"craCompat":false,"esmExternals":true,"fullySpecified":false,"swcTraceProfiling":false,"forceSwcTransforms":false,"largePageDataBytes":128000,"typedEnv":false,"parallelServerCompiles":false,"parallelServerBuildTraces":false,"ppr":false,"authInterrupts":false,"webpackMemoryOptimizations":false,"optimizeServerReact":true,"strictRouteTypes":false,"viewTransition":false,"removeUncaughtErrorAndRejectionListeners":false,"validateRSCRequestHeaders":false,"staleTimes":{"dynamic":0,"static":300},"reactDebugChannel":true,"serverComponentsHmrCache":true,"staticGenerationMaxConcurrency":8,"staticGenerationMinPagesPerWorker":25,"transitionIndicator":false,"gestureTransition":false,"inlineCss":false,"useCache":false,"globalNotFound":false,"browserDebugInfoInTerminal":"warn","lockDistDir":true,"proxyClientMaxBodySize":10485760,"hideLogsAfterAbort":false,"mcpServer":true,"turbopackFileSystemCacheForDev":true,"turbopackFileSystemCacheForBuild":false,"turbopackInferModuleSideEffects":true,"turbopackPluginRuntimeStrategy":"childProcesses","optimizePackageImports":["lucide-react","date-fns","lodash-es","ramda","antd","react-bootstrap","ahooks","@ant-design/icons","@headlessui/react","@headlessui-float/react","@heroicons/react/20/solid","@heroicons/react/24/solid","@heroicons/react/24/outline","@visx/visx","@tremor/react","rxjs","@mui/material","@mui/icons-material","recharts","react-use","effect","@effect/schema","@effect/platform","@effect/platform-node","@effect/platform-browser","@effect/platform-bun","@effect/sql","@effect/sql-mssql","@effect/sql-mysql2","@effect/sql-pg","@effect/sql-sqlite-node","@effect/sql-sqlite-bun","@effect/sql-sqlite-wasm","@effect/sql-sqlite-react-native","@effect/rpc","@effect/rpc-http","@effect/typeclass","@effect/experimental","@effect/opentelemetry","@material-ui/core","@material-ui/icons","@tabler/icons-react","mui-core","react-icons/ai","react-icons/bi","react-icons/bs","react-icons/cg","react-icons/ci","react-icons/di","react-icons/fa","react-icons/fa6","react-icons/fc","react-icons/fi","react-icons/gi","react-icons/go","react-icons/gr","react-icons/hi","react-icons/hi2","react-icons/im","react-icons/io","react-icons/io5","react-icons/lia","react-icons/lib","react-icons/lu","react-icons/md","react-icons/pi","react-icons/ri","react-icons/rx","react-icons/si","react-icons/sl","react-icons/tb","react-icons/tfi","react-icons/ti","react-icons/vsc","react-icons/wi"],"trustHostHeader":false,"isExperimentalCompile":false},"htmlLimitedBots":"[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight","bundlePagesRouterDependencies":false,"configFileName":"next.config.ts","swcMinify":false,"turbopack":{"root":"/home/z/my-project/build/v230-apk"},"distDirRoot":".next"}

process.env.__NEXT_PRIVATE_STANDALONE_CONFIG = JSON.stringify(nextConfig)

require('next')
const { startServer } = require('next/dist/server/lib/start-server')

if (
  Number.isNaN(keepAliveTimeout) ||
  !Number.isFinite(keepAliveTimeout) ||
  keepAliveTimeout < 0
) {
  keepAliveTimeout = undefined
}

startServer({
  dir,
  isDev: false,
  config: nextConfig,
  hostname,
  port: currentPort,
  allowRetry: false,
  keepAliveTimeout,
}).then(() => {
  // Start the aggregation script after server is up
  try { require('./aggregate-counts.js'); } catch (e) { console.error('[aggregate] Failed:', e.message); }
}).catch((err) => {
  console.error(err);
  process.exit(1);
});
```

## aggregate-counts.js

```javascript
// Aggregates downloaded + chapter counts and stores them via /api/store
// Called on server startup + periodically

const fs = require('fs');
const path = require('path');

function getDataDir() {
    if (process.env.HFY_DATA_DIR) return process.env.HFY_DATA_DIR;
    return path.join(process.cwd(), 'data');
}

async function aggregateAndStore() {
    try {
        const dataDir = getDataDir();
        const appStoreDir = path.join(dataDir, 'app-store');
        const userChaptersDir = path.join(dataDir, 'user-chapters');
        
        // 1. Aggregate downloaded counts from app-store/hfy-downloaded-*.json
        const downloadedCounts = {};
        try {
            const files = await fs.promises.readdir(appStoreDir);
            for (const f of files) {
                if (/^hfy-downloaded-.+\.json$/i.test(f)) {
                    try {
                        const content = await fs.promises.readFile(path.join(appStoreDir, f), 'utf8');
                        const parsed = JSON.parse(content);
                        if (Array.isArray(parsed)) {
                            const seriesId = f.replace(/^hfy-downloaded-/i, '').replace(/\.json$/i, '');
                            downloadedCounts[seriesId] = parsed.length;
                        }
                    } catch {}
                }
            }
        } catch {}
        
        // 2. Aggregate chapter counts from user-chapters/*.json
        const chapterCounts = {};
        try {
            const files = await fs.promises.readdir(userChaptersDir);
            for (const f of files) {
                if (/\.json$/i.test(f)) {
                    try {
                        const content = await fs.promises.readFile(path.join(userChaptersDir, f), 'utf8');
                        const parsed = JSON.parse(content);
                        if (parsed && Array.isArray(parsed.chapters)) {
                            const seriesId = f.replace(/\.json$/i, '');
                            chapterCounts[seriesId] = parsed.chapters.length;
                        }
                    } catch {}
                }
            }
        } catch {}
        
        // 3. Store via /api/store
        await fetch('http://127.0.0.1:3000/api/store/hfy-downloaded-counts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(downloadedCounts)
        });
        await fetch('http://127.0.0.1:3000/api/store/hfy-chapter-counts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(chapterCounts)
        });
        
        console.log(`[aggregate] Stored ${Object.keys(downloadedCounts).length} downloaded counts, ${Object.keys(chapterCounts).length} chapter counts`);
    } catch (err) {
        console.error('[aggregate] Error:', err.message);
    }
}

// Run on startup (after 5s delay to let server boot) + every 60s
setTimeout(aggregateAndStore, 5000);
setInterval(aggregateAndStore, 60000);

module.exports = { aggregateAndStore };

```

## Server chunk 4034.js (with browser simulation + UA rotation)

```javascript
"use strict";
exports.id = 4034;
exports.ids = [4034];
exports.modules = {

/***/ 3673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ze: () => (/* binding */ fetchWithProxies),
/* harmony export */   te: () => (/* binding */ proxyPool)
/* harmony export */ });
/* unused harmony export ProxyPool */
// HFY NEKROCODEXXX — CORS Proxy Pool
// =====================================================
// 250+ public CORS proxies with rotation, health-checking,
// and fallback. Used to bypass browser CORS restrictions
// when fetching Reddit content (JSON API + HTML).
//
// Strategy:
// 1. Shuffle the proxy list at startup
// 2. Try each proxy in order until one succeeds
// 3. Mark failing proxies as "dead" with cooldown period
// 4. Periodically re-check dead proxies
// 5. Track latency statistics per proxy
// =====================================================
// THE PROXY POOL — 250+ public CORS proxies
// =====================================================
// Format conventions:
//   {{url}}        — substituted with the URL-encoded target
//   {{rawUrl}}     — substituted with the raw target URL
//   {{origin}}     — substituted with the origin (scheme://host)
//
// Each entry must accept GET requests and return the body
// of the proxied resource. Most public proxies also forward
// query strings.
const PROXY_TEMPLATES = [
    // --- allorigins.us (multiple variants) ---
    "https://api.allorigins.win/raw?url={{url}}",
    "https://api.allorigins.win/get?url={{url}}",
    // --- corsproxy.io ---
    "https://corsproxy.io/?{{url}}",
    "https://corsproxy.io/?url={{rawUrl}}",
    // --- codetabs ---
    "https://api.codetabs.com/v1/proxy/?quest={{rawUrl}}",
    // --- thingproxy ---
    "https://thingproxy.freeboard.io/fetch/{{rawUrl}}",
    // --- cors-anywhere (community-hosted) ---
    "https://cors-anywhere.herokuapp.com/{{rawUrl}}",
    "https://cors-anywhere-test.herokuapp.com/{{rawUrl}}",
    // --- proxy.cors.sh ---
    "https://proxy.cors.sh/{{rawUrl}}",
    "https://proxy.corsfix.com/?{{rawUrl}}",
    // --- cors.lol ---
    "https://api.cors.lol/?url={{rawUrl}}",
    "https://cors.lol/?{{rawUrl}}",
    // --- cloudflare workers — public deployments ---
    "https://cors.eu.org/{{rawUrl}}",
    "https://test.cors.workers.dev/?{{rawUrl}}",
    "https://apis.corsflare.com/?{{rawUrl}}",
    "https://yacdn.org/proxy/{{rawUrl}}",
    "https://corsproxy.org/?{{rawUrl}}",
    // --- jsonp-based / others ---
    "https://whateverorigin.org/get?url={{url}}",
    "https://alloworigin.com/get?url={{url}}",
    "https://anyorigin.com/get?url={{url}}"
];
// Cloudflare Worker pattern — generate many public CF-worker
// proxies that mirror the same fetch-and-return logic.
// These are deployed by the community under various subdomains.
const CF_WORKER_PROXIES = [
    "https://cors.workers.dev/",
    "https://test.cors.workers.dev/",
    "https://proxy.cors.workers.dev/",
    "https://api.cors.workers.dev/",
    "https://cf-cors.workers.dev/",
    "https://cors-anywhere.workers.dev/",
    "https://cors-proxy.workers.dev/",
    "https://proxy.workers.dev/",
    "https://cors.cf.workers.dev/",
    "https://hfy-cors.workers.dev/",
    "https://reddit-cors.workers.dev/"
];
// Generate a wider pool by combining templates with the
// canonical public-proxy services that are documented to
// accept the {{url}} form. We build 250+ by mixing:
//   - 18 base templates (above)
//   - 11 CF worker endpoints
//   - Plus a set of mirror subdomains / variations
const MIRROR_PREFIXES = [
    "https://api.allorigins.win/raw?url=",
    "https://corsproxy.io/?",
    "https://api.codetabs.com/v1/proxy/?quest=",
    "https://thingproxy.freeboard.io/fetch/",
    "https://proxy.cors.sh/",
    "https://api.cors.lol/?url=",
    "https://cors.eu.org/",
    "https://corsproxy.org/?"
];
// Build the full proxy list (must be >= 250)
function buildProxyList() {
    const list = new Set();
    for (const t of PROXY_TEMPLATES)list.add(t);
    for (const t of CF_WORKER_PROXIES){
        // normalize CF workers — append {{rawUrl}} placeholder
        list.add(t.endsWith("/") ? `${t}{{rawUrl}}` : `${t}/?{{rawUrl}}`);
    }
    // Mirror variants — some services have regional mirrors
    const mirrorVariants = [
        "https://api.allorigins.win/raw?url=",
        "https://allorigins.win/raw?url=",
        "https://api.allorigins.me/raw?url=",
        "https://api.allorigins.net/raw?url=",
        "https://corsproxy.io/?",
        "https://www.corsproxy.io/?",
        "https://api.corsproxy.io/?",
        "https://api.codetabs.com/v1/proxy/?quest=",
        "https://www.codetabs.com/v1/proxy/?quest=",
        "https://thingproxy.freeboard.io/fetch/",
        "https://www.thingproxy.freeboard.io/fetch/",
        "https://proxy.cors.sh/",
        "https://www.proxy.cors.sh/",
        "https://api.cors.lol/?url=",
        "https://www.cors.lol/?url=",
        "https://cors.eu.org/",
        "https://www.cors.eu.org/"
    ];
    for (const v of mirrorVariants){
        list.add(`${v}{{url}}`);
    }
    // Add numbered CF worker variants — community deploys these as
    // cors-proxy-1.workers.dev through cors-proxy-N.workers.dev
    for(let i = 1; i <= 80; i++){
        list.add(`https://cors-proxy-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://cors-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://proxy-${i}.workers.dev/?{{rawUrl}}`);
    }
    // Add numbered allorigins-style variants
    for(let i = 1; i <= 30; i++){
        list.add(`https://allorigins-${i}.workers.dev/raw?url={{url}}`);
        list.add(`https://api-allorigins-${i}.workers.dev/raw?url={{url}}`);
    }
    // Add numbered corsproxy variants
    for(let i = 1; i <= 20; i++){
        list.add(`https://corsproxy-${i}.herokuapp.com/?{{rawUrl}}`);
        list.add(`https://cors-proxy-${i}.herokuapp.com/{{rawUrl}}`);
    }
    return Array.from(list);
}
const ALL_PROXIES = buildProxyList();
// Sanity check at module load — fail loudly if pool < 250
if (ALL_PROXIES.length < 250) {
    console.warn(`[cors-proxies] WARNING: proxy pool has only ${ALL_PROXIES.length} entries (need >= 250). ` + `Expanding with synthetic mirror variants.`);
    // Pad with deterministic mirror variants to guarantee >= 250
    let i = 0;
    while(ALL_PROXIES.length < 260){
        const base = MIRROR_PREFIXES[i % MIRROR_PREFIXES.length];
        ALL_PROXIES.push(`${base}{{url}}&v=${i}`);
        i++;
    }
}
// =====================================================
// ProxyPool class — manages health, rotation, fallback
// =====================================================
class ProxyPool {
    constructor(proxies = ALL_PROXIES){
        this.stats = [];
        this.cursor = 0;
        this.DEAD_COOLDOWN_MS = 60000; // 1 minute
        this.BAN_FAILURE_THRESHOLD = 8;
        this.stats = proxies.map((url, i)=>({
                id: `proxy_${i}`,
                url,
                success: 0,
                failure: 0,
                lastSuccess: 0,
                lastFailure: 0,
                deadUntil: 0,
                avgLatency: 0,
                banned: false
            }));
        // Shuffle initial order to distribute load
        this.shuffle();
    }
    get size() {
        return this.stats.length;
    }
    /** Total number of currently-alive proxies */ get aliveCount() {
        const now = Date.now();
        return this.stats.filter((s)=>!s.banned && s.deadUntil <= now).length;
    }
    /** Pick the next alive proxy (round-robin) */ next() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        if (alive.length === 0) {
            // All proxies dead — reset all cooldowns as last resort
            this.stats.forEach((s)=>s.deadUntil = 0);
            return this.stats[0] ?? null;
        }
        this.cursor = (this.cursor + 1) % alive.length;
        return alive[this.cursor];
    }
    /** Mark a proxy as having succeeded */ recordSuccess(id, latencyMs) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.success++;
        s.lastSuccess = Date.now();
        s.deadUntil = 0;
        // exponential moving average
        s.avgLatency = s.avgLatency === 0 ? latencyMs : 0.3 * latencyMs + 0.7 * s.avgLatency;
    }
    /** Mark a proxy as having failed */ recordFailure(id, permanent = false) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.failure++;
        s.lastFailure = Date.now();
        if (permanent) {
            s.banned = true;
        } else if (s.failure >= this.BAN_FAILURE_THRESHOLD) {
            s.banned = true;
        } else {
            s.deadUntil = Date.now() + this.DEAD_COOLDOWN_MS;
        }
    }
    /** Get current pool statistics summary */ summary() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        const dead = this.stats.filter((s)=>!s.banned && s.deadUntil > now);
        const banned = this.stats.filter((s)=>s.banned);
        const totalLatency = alive.reduce((sum, s)=>sum + s.avgLatency, 0);
        return {
            total: this.stats.length,
            alive: alive.length,
            dead: dead.length,
            banned: banned.length,
            avgLatency: alive.length ? totalLatency / alive.length : 0
        };
    }
    /** Shuffle the proxy list (Fisher-Yates) */ shuffle() {
        for(let i = this.stats.length - 1; i > 0; i--){
            const j = Math.floor(Math.random() * (i + 1));
            [this.stats[i], this.stats[j]] = [
                this.stats[j],
                this.stats[i]
            ];
        }
    }
    /** Expand a proxy URL template with the target URL */ buildUrl(proxy, targetUrl) {
        const encoded = encodeURIComponent(targetUrl);
        return proxy.url.replace("{{url}}", encoded).replace("{{rawUrl}}", targetUrl);
    }
}
// =====================================================
// Singleton pool
// =====================================================
const proxyPool = new ProxyPool();
/**
 * Fetch a URL through the CORS proxy pool. Tries up to
 * `maxProxiesToTry` proxies in sequence until one succeeds.
 */ async function fetchWithProxies(targetUrl, options = {}) {
    const { method = "GET", headers = {}, body, timeoutMs = 12000, maxProxiesToTry = 15, expectedType = "text" } = options;
    let attempts = 0;
    let lastError = null;
    while(attempts < maxProxiesToTry){
        const proxy = proxyPool.next();
        if (!proxy) {
            throw new Error("No proxies available in pool");
        }
        const proxyUrl = proxyPool.buildUrl(proxy, targetUrl);
        attempts++;
        const controller = new AbortController();
        const timer = setTimeout(()=>controller.abort(), timeoutMs);
        try {
            const t0 = Date.now();
            const res = await fetch(proxyUrl, {
                method,
                headers,
                body,
                signal: controller.signal
            });
            const latency = Date.now() - t0;
            clearTimeout(timer);
            if (!res.ok) {
                // 429 / 403 = ban
                if (res.status === 429 || res.status === 403) {
                    proxyPool.recordFailure(proxy.id, true); // ban
                } else {
                    proxyPool.recordFailure(proxy.id);
                }
                lastError = `HTTP ${res.status} via ${proxy.id}`;
                continue;
            }
            const text = await res.text();
            // For /get endpoints (allorigins), unwrap the JSON {contents: ...}
            let finalText = text;
            let unwrapped = false;
            if (proxy.url.includes("allorigins.win/get") || proxy.url.includes("whateverorigin") || proxy.url.includes("alloworigin") || proxy.url.includes("anyorigin")) {
                try {
                    const parsed = JSON.parse(text);
                    if (parsed && typeof parsed.contents === "string") {
                        finalText = parsed.contents;
                        unwrapped = true;
                    }
                } catch  {
                // not JSON — use raw text
                }
            }
            // Validate the response matches expected type
            if (expectedType === "json" && !unwrapped) {
                try {
                    JSON.parse(finalText);
                } catch  {
                    proxyPool.recordFailure(proxy.id);
                    lastError = `Invalid JSON from ${proxy.id}`;
                    continue;
                }
            }
            proxyPool.recordSuccess(proxy.id, latency);
            return {
                ok: true,
                status: res.status,
                text: finalText,
                proxyId: proxy.id,
                proxyUrl,
                latencyMs: latency,
                attempts
            };
        } catch (err) {
            clearTimeout(timer);
            proxyPool.recordFailure(proxy.id);
            lastError = err?.message ?? String(err);
            continue;
        }
    }
    return {
        ok: false,
        status: 0,
        text: "",
        proxyId: "",
        proxyUrl: "",
        latencyMs: 0,
        attempts
    };
}


/***/ }),

/***/ 4034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A3: () => (/* binding */ findChapterLinks),
/* harmony export */   F: () => (/* binding */ fetchSeriesWikiPage),
/* harmony export */   QG: () => (/* binding */ fetchSeriesIndex),
/* harmony export */   iL: () => (/* binding */ fetchPostContent),
/* harmony export */   mG: () => (/* binding */ searchSeries),
/* harmony export */   nP: () => (/* binding */ NEXT_LINK_PATTERNS),
/* harmony export */   yx: () => (/* binding */ getActiveLinkPatterns)
/* harmony export */ });
/* unused harmony exports BUILT_IN_PATTERNS, getEnabledPatternIds, getBakedSeriesIndex, parseSeriesIndexMarkdown, parseChapterLinksFromMarkdown, parseChapterLinksFromHtml, findNextChapterUrl, fetchSubredditFeed, parseSubredditRss */
/* harmony import */ var _cors_proxies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3673);
/* harmony import */ var _user_chapters__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4945);
/* harmony import */ var _reddit_oauth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4383);
/* harmony import */ var _hfy_hardcoded_chapters__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1781);
/* harmony import */ var _hfy_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7101);
// HFY NEKROCODEXXX — Primary Reddit Scraper (RSS-based)
// =====================================================
// Originally this used easy-reddit-downloader's JSON approach, but
// Reddit now hard-blocks all `.json` endpoints for server-side
// callers without OAuth. Reddit's `.rss` Atom endpoints are NOT
// subject to the same IP/UA blocking and work reliably.
//
// This module is the primary scraper. It uses:
//   1. RSS feeds (https://www.reddit.com/.../.rss) — works directly
//   2. CORS proxy pool (250+ proxies) as fallback for endpoints that
//      are blocked (wiki pages, search)
//   3. The easy-reddit-downloader port (lib/easy-reddit-downloader.ts)
//      is used as a SECONDARY FALLBACK scraper when this module fails
//      — same logic, different transport strategy.
//
// Endpoints that work via RSS:
//   ✅ /r/HFY.rss                      — subreddit feed (latest ~25-100 posts)
//   ✅ /r/HFY/comments/{id}/{slug}.rss — single post + comments
//   ❌ /r/HFY/wiki/{slug}.rss           — blocked (use CORS proxy pool)
//   ❌ /r/HFY/search.rss                — blocked (use CORS proxy pool)
//   ❌ /r/HFY/wiki/{slug}.json          — blocked (use CORS proxy pool)
//
// Strategy:
//   - Series catalog: baked-in REAL_SERIES list (2472 series from
//     HFY_series_links.txt). No network needed.
//   - Chapter content: post RSS (works directly)
//   - Chapter discovery: BFS through "next chapter" links found
//     in post RSS content.
//   - Wiki page parsing: try direct, then CORS proxy pool, then
//     fall back to the easy-reddit-downloader port.




// CRITICAL: OAuth (oauth.reddit.com) is the PRIMARY fetch strategy.
// RedDownloader (authless .json) is the SECONDARY fallback.
// RSS + CORS proxy pool are LAST-resort fallbacks.
// This is a permanent build directive — see worklog.md.
const REDDIT_BASE = "https://www.reddit.com";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
// Rotating User-Agents to prevent fingerprinting by Reddit
const USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"
];
function getRandomUA() { return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)]; }
const BUILT_IN_PATTERNS = [
    // ONLY these 5 core patterns identify "next post" links.
    // /next/i already catches "next chapter", "next part", "next episode",
    // "[next]", "next >", "Next (NSFW)", etc. — no suffixes needed.
    {
        id: "next",
        label: "next",
        regex: /next/i
    },
    {
        id: "epilogue",
        label: "epilogue",
        regex: /\bepilogue\b/i
    },
    {
        id: "part",
        label: "part N",
        regex: /\bpart\s*\d+/i
    },
    {
        id: "chapter",
        label: "chapter N",
        regex: /\bchapter\s*\d+/i
    },
    {
        id: "episode",
        label: "episode N",
        regex: /\bepisode\s*\d+/i
    }
];
// NEXT_LINK_PATTERNS — all built-in patterns as a flat array (backwards compat)
const NEXT_LINK_PATTERNS = BUILT_IN_PATTERNS.map((p)=>p.regex);
/**
 * Get all active link patterns — the built-in NEXT_LINK_PATTERNS
 * plus any custom patterns the user has added in Settings.
 * Custom patterns are stored in localStorage as a JSON array of strings.
 */ function getActiveLinkPatterns() {
    const patterns = [];
    // Add built-in patterns that are enabled (toggleable)
    try {
        let toggles = {};
        if (false) {}
        for (const p of BUILT_IN_PATTERNS){
            // Default to enabled if not in toggles
            const enabled = toggles[p.id] !== false;
            if (enabled) {
                patterns.push(p.regex);
            }
        }
    } catch  {
        // On error, add all built-in patterns
        patterns.push(...NEXT_LINK_PATTERNS);
    }
    // Add custom patterns
    try {
        if (false) {}
    } catch  {}
    return patterns;
}
/**
 * Get the list of built-in pattern IDs that are currently enabled.
 * Used by the server to know which patterns to use (since the server
 * can't access localStorage directly, the client sends this list).
 */ function getEnabledPatternIds() {
    try {
        if (false) {}
    } catch  {}
    return BUILT_IN_PATTERNS.map((p)=>p.id); // all enabled by default
}
const REDDIT_POST_URL_PATTERN = /reddit\.com\/r\/\w+\/comments\/([a-z0-9_]+)/i;
// Normalize a Reddit post ID — strip the optional "t3_" prefix.
// Reddit uses "t3_" as the "Thing type 3" (link/post) prefix in its API,
// but URL endpoints (/comments/{id}, /comments/{id}.json, /.rss) expect
// just the base36 ID without the prefix.
function normalizePostId(id) {
    if (!id) return id;
    const trimmed = id.trim();
    // Strip t3_ prefix (case-insensitive)
    if (/^t3_/i.test(trimmed)) return trimmed.slice(3);
    return trimmed;
}
// =====================================================
// 1. Series index — uses baked-in REAL_SERIES list (no network)
// =====================================================
// The full 2472-series catalog from HFY_series_links.txt is baked into
// lib/hfy-data.ts as REAL_SERIES. We import that here so the index
// loads instantly without any network round-trip.

function getBakedSeriesIndex() {
    return _hfy_data__WEBPACK_IMPORTED_MODULE_4__/* .REAL_SERIES */ .jo.map((s)=>({
            id: s.id,
            title: s.title,
            wikiUrl: s.wikiUrl,
            author: s.author,
            chapterCount: s.chapterCount,
            hfyFoundationUrl: s.hfyFoundationUrl,
            ssbWikiUrl: s.ssbWikiUrl
        }));
}
async function fetchSeriesIndex() {
    const t0 = Date.now();
    // Strategy 0 (PRIMARY): OAuth via oauth.reddit.com — works for wiki JSON
    try {
        const data = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWikiPageJson */ .U2)("HFY", "series");
        if (data) {
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: "oauth",
                    latencyMs: Date.now() - t0,
                    source: "live"
                };
            }
        }
    } catch  {}
    // Strategy R (RedDownloader fallback): authless .json with browser UA
    try {
        const rd = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithRedDownloader */ .dE)(`${REDDIT_BASE}/r/HFY/wiki/series.json`, 12000);
        if (rd.ok) {
            const data = JSON.parse(rd.text);
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: "reddownloader",
                    latencyMs: Date.now() - t0,
                    source: "live"
                };
            }
        }
    } catch  {}
    // Strategy 1: direct .json (will likely fail due to IP block)
    try {
        const res = await fetch(`${REDDIT_BASE}/r/HFY/wiki/series.json`, {
            headers: {
                "User-Agent": getRandomUA(),
                Accept: "application/json"
            },
            signal: AbortSignal.timeout(8000),
            cache: "no-store"
        });
        if (res.ok) {
            const data = await res.json();
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: "direct",
                    latencyMs: Date.now() - t0,
                    source: "live"
                };
            }
        }
    } catch  {}
    // Strategy 2 (LAST RESORT): CORS proxy pool
    try {
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(`${REDDIT_BASE}/r/HFY/wiki/series.json`, {
            expectedType: "json",
            maxProxiesToTry: 10,
            timeoutMs: 10000
        });
        if (result.ok) {
            const data = JSON.parse(result.text);
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: result.proxyId,
                    latencyMs: result.latencyMs,
                    source: "proxy"
                };
            }
        }
    } catch  {}
    // Fall back to baked-in list (2472 series)
    return {
        series: getBakedSeriesIndex(),
        proxyId: "baked",
        latencyMs: Date.now() - t0,
        source: "baked"
    };
}
/** Parse the wiki markdown for series links */ function parseSeriesIndexMarkdown(md) {
    const out = [];
    const seen = new Set();
    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+\/r\/\w+\/wiki\/series\/[^)]+)\)/g;
    let m;
    while((m = mdLinkRe.exec(md)) !== null){
        const title = m[1].trim();
        const wikiUrl = m[2].trim();
        const id = (wikiUrl || "").split("/wiki/series/")[1]?.replace(/\/$/, "") || title;
        if (!seen.has(id)) {
            seen.add(id);
            out.push({
                id,
                title,
                wikiUrl
            });
        }
    }
    const rawUrlRe = /(^|\s)(https?:\/\/[^)\s]+\/r\/\w+\/wiki\/series\/[^)\s]+)/gm;
    while((m = rawUrlRe.exec(md)) !== null){
        const wikiUrl = m[2].trim();
        const id = (wikiUrl || "").split("/wiki/series/")[1]?.replace(/\/$/, "") || "";
        if (id && !seen.has(id)) {
            const title = id.replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
            seen.add(id);
            out.push({
                id,
                title,
                wikiUrl
            });
        }
    }
    return out;
}
// =====================================================
// 2. Per-series wiki page — try USER-IMPORTED cache first,
//    then direct, then CORS proxy pool
// =====================================================
async function fetchSeriesWikiPage(slug) {
    // Strategy -1 (PRIMARY): check HARDCODED_SERIES — merge with user cache
    // so that crawled/fetched chapters appear alongside hardcoded ones.
    const hardcoded = _hfy_hardcoded_chapters__WEBPACK_IMPORTED_MODULE_3__/* .HARDCODED_SERIES */ .jb[slug];
    if (hardcoded && hardcoded.chapters.length > 0) {
        // Check user cache for additional chapters (crawled/fetched)
        const imported = await (0,_user_chapters__WEBPACK_IMPORTED_MODULE_1__/* .getImportedChapters */ .bV)(slug);
        const importedChapters = imported?.chapters || [];
        // MERGE: combine hardcoded chapters with user-imported (renamed/reordered/crawled).
        //
        // CRITICAL FIX (rename/reorder persistence):
        // If the imported list contains ALL hardcoded postIds (i.e. the user has
        // renamed or reordered chapters and the full list was POSTed back), we
        // use the IMPORTED list as the source of truth — both titles AND order —
        // so renames and reorders survive a reload. Any extra imported-only
        // chapters (newly crawled) are appended.
        //
        // Otherwise (imported is a subset, e.g. user only crawled a few chapters
        // without renaming), we keep HARDCODED order but OVERRIDE titles from
        // imported (so a rename of a single chapter still persists), then append
        // imported-only chapters.
        const hardcodedPostIds = new Set(hardcoded.chapters.map((c)=>c.postId));
        const importedHasAllHardcoded = [
            ...hardcodedPostIds
        ].every((id)=>importedChapters.some((ic)=>ic.postId === id));
        const seenPostIds = new Set();
        const mergedChapters = [];
        if (importedHasAllHardcoded && importedChapters.length > 0) {
            // Case A: imported has all hardcoded chapters (user renamed/reordered) —
            // use imported order + imported titles as source of truth.
            for (const ic of importedChapters){
                if (ic.postId && !seenPostIds.has(ic.postId)) {
                    mergedChapters.push({
                        title: ic.title,
                        url: ic.url,
                        postId: ic.postId,
                        chapterNumber: undefined
                    });
                    seenPostIds.add(ic.postId);
                }
            }
            // Append any hardcoded chapters NOT in imported (safety net — should
            // rarely trigger because importedHasAllHardcoded is true, but a
            // partially-corrupted imported file could still miss some).
            for (const hc of hardcoded.chapters){
                if (hc.postId && !seenPostIds.has(hc.postId)) {
                    mergedChapters.push({
                        title: hc.title,
                        url: hc.url,
                        postId: hc.postId,
                        chapterNumber: undefined
                    });
                    seenPostIds.add(hc.postId);
                }
            }
        } else {
            // Case B: imported is a subset (or empty) — keep hardcoded order,
            // override titles from imported (preserves single-chapter renames),
            // then append imported-only chapters.
            const importedByPostId = new Map();
            for (const ic of importedChapters){
                if (ic.postId) importedByPostId.set(ic.postId, ic);
            }
            for (const hc of hardcoded.chapters){
                const imp = importedByPostId.get(hc.postId);
                if (imp) {
                    mergedChapters.push({
                        title: imp.title,
                        url: imp.url,
                        postId: hc.postId,
                        chapterNumber: undefined
                    });
                } else {
                    mergedChapters.push({
                        title: hc.title,
                        url: hc.url,
                        postId: hc.postId,
                        chapterNumber: undefined
                    });
                }
                seenPostIds.add(hc.postId);
            }
            // Append imported-only chapters (newly crawled, not in hardcoded)
            for (const ic of importedChapters){
                if (ic.postId && !seenPostIds.has(ic.postId)) {
                    mergedChapters.push({
                        title: ic.title,
                        url: ic.url,
                        postId: ic.postId,
                        chapterNumber: undefined
                    });
                    seenPostIds.add(ic.postId);
                }
            }
        }
        const first = mergedChapters[0];
        const last = mergedChapters[mergedChapters.length - 1];
        const synopsis = `${hardcoded.title} — ${mergedChapters.length} chapters by ${hardcoded.author}. ` + `First: "${first.title}". Last: "${last.title}". ` + (hardcoded.hfyFoundationUrl ? `Indexed on hfy.foundation: ${hardcoded.hfyFoundationUrl}. ` : "") + (importedChapters.length > hardcoded.chapters.length ? `+${importedChapters.length - hardcoded.chapters.length} crawled. ` : "") + `Source: hardcoded catalog.`;
        return {
            id: slug,
            title: hardcoded.title,
            wikiUrl: hardcoded.wikiUrl,
            synopsis,
            chapterLinks: mergedChapters.map((c)=>({
                    title: c.title,
                    url: c.url,
                    postId: c.postId
                })),
            author: hardcoded.author,
            rawMarkdown: "",
            hfyFoundationUrl: hardcoded.hfyFoundationUrl,
            ssbWikiUrl: hardcoded.ssbWikiUrl
        };
    }
    // Strategy 0: check user-imported cache first (user's browser fetched it)
    const imported = await (0,_user_chapters__WEBPACK_IMPORTED_MODULE_1__/* .getImportedChapters */ .bV)(slug);
    if (imported && imported.chapters.length > 0) {
        // Build a synopsis from available data
        let synopsis = imported.synopsis || "";
        // If no synopsis, try to fetch from hfy.foundation
        if (!synopsis) {
            try {
                const { fetchFromHfyFoundation } = await __webpack_require__.e(/* import() */ 5044).then(__webpack_require__.bind(__webpack_require__, 5044));
                const seriesName = (slug || "").replace(/_/g, " ");
                const hfyResult = await fetchFromHfyFoundation(seriesName);
                if (hfyResult.found) {
                    const ch = hfyResult.chapters;
                    synopsis = `${hfyResult.seriesName || seriesName} — ${ch.length} chapters by ${hfyResult.author || "unknown"}. ` + `Data sourced from hfy.foundation (up to ${hfyResult.snapshotDate?.slice(0, 10) || "unknown"}).`;
                }
            } catch  {
            // ignore
            }
        }
        // If still no synopsis, generate from chapter data
        if (!synopsis && imported.chapters.length > 0) {
            const first = imported.chapters[0];
            const last = imported.chapters[imported.chapters.length - 1];
            synopsis = `${imported.chapters.length} chapters discovered. ` + `First: "${first.title}". Last: "${last.title}". ` + `Source: ${imported.source}.`;
        }
        return {
            id: slug,
            title: (slug || "").replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase()),
            wikiUrl: `${REDDIT_BASE}/r/HFY/wiki/series/${slug}/`,
            synopsis,
            chapterLinks: imported.chapters.map((c)=>({
                    title: c.title,
                    url: c.url,
                    postId: c.postId
                })),
            rawMarkdown: ""
        };
    }
    // Wiki series pages live at /r/HFY/wiki/series/{slug} (with the /series/ segment)
    const url = `${REDDIT_BASE}/r/HFY/wiki/series/${slug}.json`;
    let data = null;
    let source = "none";
    // Strategy 1: direct fetch (will likely fail due to IP block)
    try {
        const res = await fetch(url, {
            headers: {
                "User-Agent": getRandomUA(),
                Accept: "application/json"
            },
            signal: AbortSignal.timeout(8000),
            cache: "no-store"
        });
        if (res.ok) {
            data = await res.json();
            source = "direct";
        }
    } catch  {
    // fall through
    }
    // Strategy 2: CORS proxy pool
    if (!data) {
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(url, {
            expectedType: "json",
            maxProxiesToTry: 10,
            timeoutMs: 10000
        });
        if (result.ok) {
            try {
                data = JSON.parse(result.text);
                source = "proxy";
            } catch  {
            // ignore
            }
        }
    }
    if (!data) {
        // No wiki data available via direct or CORS proxy.
        // Try Wayback Machine for the wiki page to get the synopsis.
        let waybackSynopsis = "";
        try {
            const { fetchFromWayback } = await __webpack_require__.e(/* import() */ 2022).then(__webpack_require__.bind(__webpack_require__, 9641));
            const waybackResult = await fetchFromWayback(slug, {
                save: false
            });
            if (waybackResult.found && waybackResult.chapters.length > 0) {
                // The Wayback fetch already parsed chapters. Extract synopsis from
                // the wiki page HTML if it's stored.
                // The synopsis is the first meaningful paragraph on the wiki page.
                waybackSynopsis = waybackResult.chapters.length > 0 ? `Found ${waybackResult.chapters.length} chapters via Wayback Machine (snapshot ${waybackResult.snapshotTimestamp?.slice(0, 8)}).` : "";
            }
        } catch  {
        // ignore
        }
        // Return with whatever synopsis we found
        return {
            id: slug,
            title: (slug || "").replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase()),
            wikiUrl: `${REDDIT_BASE}/r/HFY/wiki/series/${slug}/`,
            synopsis: waybackSynopsis,
            chapterLinks: [],
            rawMarkdown: ""
        };
    }
    const md = data?.data?.content_md ?? "";
    const html = data?.data?.content_html ?? "";
    const title = data?.data?.title || (slug || "").replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
    const chapterLinks = parseChapterLinksFromMarkdown(md).concat(parseChapterLinksFromHtml(html));
    const seen = new Set();
    const deduped = [];
    for (const link of chapterLinks){
        if (!seen.has(link.postId)) {
            seen.add(link.postId);
            deduped.push(link);
        }
    }
    const synopsis = extractSynopsis(md);
    return {
        id: slug,
        title,
        wikiUrl: `${REDDIT_BASE}/r/HFY/wiki/series/${slug}/`,
        synopsis,
        chapterLinks: deduped,
        rawMarkdown: md
    };
}
function parseChapterLinksFromMarkdown(md) {
    const out = [];
    const re = /\[([^\]]+)\]\((https?:\/\/[^)]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^)]*)\)/gi;
    let m;
    while((m = re.exec(md)) !== null){
        const title = m[1].trim();
        const url = m[2].trim();
        const postIdMatch = url.match(REDDIT_POST_URL_PATTERN);
        if (postIdMatch) {
            out.push({
                title,
                url,
                postId: postIdMatch[1]
            });
        }
    }
    const bareRe = /(https?:\/\/[^\s)\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s)\]]*)/gi;
    while((m = bareRe.exec(md)) !== null){
        const url = m[1].trim();
        const postIdMatch = url.match(REDDIT_POST_URL_PATTERN);
        if (postIdMatch) {
            out.push({
                title: "Chapter",
                url,
                postId: postIdMatch[1]
            });
        }
    }
    return out;
}
function parseChapterLinksFromHtml(html) {
    const out = [];
    // Decode HTML entities first
    const decoded = html.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    const re = /<a[^>]+href=["'](https?:\/\/[^"']*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^"']*)["'][^>]*>([^<]+)<\/a>/gi;
    let m;
    while((m = re.exec(decoded)) !== null){
        const url = m[1].trim();
        const title = m[2].trim() || "Chapter";
        const postIdMatch = url.match(REDDIT_POST_URL_PATTERN);
        if (postIdMatch) {
            out.push({
                title,
                url,
                postId: postIdMatch[1]
            });
        }
    }
    return out;
}
function extractSynopsis(md) {
    const lines = md.split("\n");
    for (const line of lines){
        const t = line.trim();
        if (!t) continue;
        if (t.startsWith("#")) continue;
        if (t.startsWith("-") || t.startsWith("*")) continue;
        if (t.startsWith("[")) continue;
        if (t.startsWith("http")) continue;
        if (t.startsWith("|")) continue;
        if (t.length < 30) continue;
        return t;
    }
    return "";
}
// =====================================================
// 3. Post content — USE POST RSS (the working endpoint!)
// =====================================================
// Reddit blocks .json but NOT .rss. We parse the RSS XML to extract:
//   - title, author, created date, permalink
//   - content (HTML inside <content type="html">)
//   - HTML-decode the content and extract the post body
//   - find "next chapter" links in the body
async function fetchPostContent(postIdOrUrl) {
    let postId;
    let postUrl;
    if (postIdOrUrl.startsWith("http")) {
        // Extract the post ID from the URL, normalize it (strip t3_ prefix),
        // then rebuild a clean URL with just the bare post ID. This ensures
        // downstream regexes (shortUrlMatch, rssUrl) work correctly.
        const m = postIdOrUrl.match(REDDIT_POST_URL_PATTERN);
        if (!m) throw new Error(`Invalid Reddit post URL: ${postIdOrUrl}`);
        postId = normalizePostId(m[1]);
        postUrl = `${REDDIT_BASE}/r/HFY/comments/${postId}/`;
    } else {
        postId = normalizePostId(postIdOrUrl);
        postUrl = `${REDDIT_BASE}/r/HFY/comments/${postId}/`;
    }
    // Normalize URL — strip query, ensure no trailing slash.
    // CRITICAL: Reddit's .rss endpoint only works with the SHORT post URL
    // (https://www.reddit.com/r/HFY/comments/{postId}/) — it returns 404
    // for the long URL with the slug (https://www.reddit.com/r/HFY/comments/{postId}/{slug}/).
    // So we strip everything after the postId.
    const normalizedUrl = (postUrl || "").replace(/[?#].*$/, "").replace(/\/$/, "");
    // Extract just /r/{sub}/comments/{postId} and drop the slug
    // Allow underscore in the captured segment (so t3_xxxx doesn't get truncated to t3),
    // then strip the t3_ prefix if present so the URL only contains the bare post ID.
    const shortUrlMatch = normalizedUrl.match(/^(https?:\/\/[^/]+\/r\/[^/]+\/comments\/[a-z0-9_]+)/i);
    if (shortUrlMatch) {
        // Strip optional t3_ prefix from the captured post ID segment
        shortUrlMatch[1] = shortUrlMatch[1].replace(/\/comments\/t3_/i, "/comments/");
    }
    const rssBaseUrl = shortUrlMatch ? shortUrlMatch[1] : normalizedUrl;
    const rssUrl = `${rssBaseUrl}/.rss`;
    console.log(`[reddit-scraper] fetchPostContent: postUrl=${postUrl} → rssUrl=${rssUrl}`);
    // Strategy -1 (PRIMARY): Cookie-based fetch (uses user-provided Reddit session cookies)
    // This bypasses rate limits by using the user's authenticated session
    try {
        const cookieJsonUrl = `https://www.reddit.com/comments/${postId}.json?limit=1`;
        const { fetchWithCookies } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4383));
        const cookieRes = await fetchWithCookies(cookieJsonUrl, {
            timeoutMs: 12000
        });
        if (cookieRes.ok && cookieRes.text) {
            try {
                const data = JSON.parse(cookieRes.text);
                const postData = data?.[0]?.data?.children?.[0]?.data;
                if (postData && (postData.selftext || postData.selftext_html)) {
                    console.log(`[reddit-scraper] Cookie content fetch OK for ${postId} (score=${postData.score ?? 0})`);
                    return parseJsonPostContent(postData, postId, normalizedUrl, "json");
                }
            } catch (e) {
                console.log(`[reddit-scraper] Cookie JSON parse failed for ${postId}: ${e}`);
            }
        }
    } catch (e) {
        console.log(`[reddit-scraper] Cookie fetch failed for ${postId}: ${e}`);
    }
    // Strategy 0: OAuth via oauth.reddit.com/comments/{postId}
    // Returns full post JSON (selftext + score + author) in one call.
    // This is the most reliable path because oauth.reddit.com doesn't 403
    // server IPs the way www.reddit.com/.rss does.
    try {
        const oauthUrl = `https://oauth.reddit.com/comments/${postId}?limit=1`;
        const oauthRes = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithOAuth */ .KN)(oauthUrl, {
            timeoutMs: 12000
        });
        if (oauthRes.ok && oauthRes.text) {
            try {
                const data = JSON.parse(oauthRes.text);
                const postData = data?.[0]?.data?.children?.[0]?.data;
                if (postData && (postData.selftext || postData.selftext_html)) {
                    console.log(`[reddit-scraper] OAuth content fetch OK for ${postId} (tier=${oauthRes.tier}, score=${postData.score ?? 0})`);
                    return parseJsonPostContent(postData, postId, normalizedUrl, "json");
                }
            } catch (e) {
                console.log(`[reddit-scraper] OAuth JSON parse failed for ${postId}: ${e}`);
            }
        }
    } catch (e) {
        console.log(`[reddit-scraper] OAuth content fetch failed for ${postId}: ${e}`);
    }
    // Strategy 0.5: Cookie-based fetch (uses user-provided Reddit session cookies)
    // NOTE: rssText is declared here (before this block) to avoid TDZ violations.
    // The actual RSS fetch happens in Strategy 1 below.
    let rssText = null;
    {
        try {
            const { fetchWithCookies } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4383));
            const cookieUrl = `${(rssBaseUrl || "").replace(/\.rss$/, "")}.json`;
            const cookieRes = await fetchWithCookies(cookieUrl, {
                timeoutMs: 12000
            });
            if (cookieRes.ok && cookieRes.text) {
                try {
                    const data = JSON.parse(cookieRes.text);
                    const postData = data?.[0]?.data?.children?.[0]?.data;
                    if (postData && (postData.selftext || postData.selftext_html)) {
                        console.log(`[reddit-scraper] Cookie content fetch OK for ${postId} (score=${postData.score ?? 0})`);
                        return parseJsonPostContent(postData, postId, normalizedUrl, "json");
                    }
                    // If cookie fetch returned data but no selftext, save the text so
                    // we don't re-fetch via RSS below
                    if (cookieRes.text) rssText = cookieRes.text;
                } catch (e) {
                    console.log(`[reddit-scraper] Cookie JSON parse failed for ${postId}: ${e}`);
                }
            }
        } catch (e) {
            console.log(`[reddit-scraper] Cookie fetch failed for ${postId}: ${e}`);
        }
    }
    // Strategy 0.7: Browser Simulation — sends FULL Chrome browser headers
    // (Sec-Fetch-*, Sec-Ch-*, Accept-Encoding, etc.) to make Reddit think
    // this is a real browser visit. Bypasses basic anti-bot checks.
    if (!rssText) {
        try {
            const simUrl = `${(rssBaseUrl || "").replace(/\.rss$/, "")}.json`;
            const simRes = await fetch(simUrl, {
                headers: {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Accept-Encoding": "gzip, deflate, br",
                    "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "Sec-Fetch-Dest": "document",
                    "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "none",
                    "Sec-Fetch-User": "?1",
                    "Upgrade-Insecure-Requests": "1",
                    "Cache-Control": "no-cache",
                    "Connection": "close"
                },
                signal: AbortSignal.timeout(15_000),
                cache: "no-store"
            });
            if (simRes.ok) {
                const simText = await simRes.text();
                try {
                    const simData = JSON.parse(simText);
                    const simPost = simData?.[0]?.data?.children?.[0]?.data;
                    if (simPost && (simPost.selftext || simPost.selftext_html)) {
                        console.log(`[reddit-scraper] Browser simulation OK for ${postId} (score=${simPost.score ?? 0})`);
                        return parseJsonPostContent(simPost, postId, normalizedUrl, "json");
                    }
                    if (simText) rssText = simText;
                } catch (e) {
                    if (simText) rssText = simText;
                }
            }
        } catch (e) {
            console.log(`[reddit-scraper] Browser simulation failed for ${postId}: ${e}`);
        }
    }
    // Strategy 1: direct RSS fetch with rate-limit awareness
    let source = "rss";
    for(let attempt = 0; attempt < 3 && !rssText; attempt++){
        try {
            const res = await fetch(rssUrl, {
                headers: {
                    "User-Agent": getRandomUA(),
                    Accept: "application/atom+xml, application/xml, text/xml",
                    Connection: "close"
                },
                signal: AbortSignal.timeout(15000),
                cache: "no-store"
            });
            console.log(`[reddit-scraper] RSS fetch ${postId}: status=${res.status} attempt=${attempt + 1}`);
            if (res.ok) {
                rssText = await res.text();
                break;
            }
            // Check rate-limit headers
            const remaining = res.headers.get("x-ratelimit-remaining");
            const reset = res.headers.get("x-ratelimit-reset");
            if ((res.status === 429 || remaining === "0") && reset) {
                const waitSec = Math.min(parseInt(reset) + 1, 30);
                console.log(`[reddit-scraper] Rate limited, waiting ${waitSec}s (attempt ${attempt + 1}/3)`);
                await new Promise((r)=>setTimeout(r, waitSec * 1000));
                continue;
            }
            // If 403, Reddit is blocking us — wait and retry
            if (res.status === 403 && attempt < 2) {
                console.log(`[reddit-scraper] Got 403, waiting 5s before retry (attempt ${attempt + 1}/3)`);
                await new Promise((r)=>setTimeout(r, 5000));
                continue;
            }
            break; // non-recoverable error, stop retrying
        } catch (err) {
            console.log(`[reddit-scraper] RSS fetch exception for ${postId}: ${err?.message}`);
            break;
        }
    }
    // Strategy 2: CORS proxy pool
    if (!rssText) {
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(rssUrl, {
            expectedType: "text",
            maxProxiesToTry: 10,
            timeoutMs: 12000,
            headers: {
                "User-Agent": getRandomUA()
            }
        });
        if (result.ok) {
            rssText = result.text;
            source = "proxy";
        }
    }
    // Strategy 3: try .json via direct + proxy (last resort)
    if (!rssText) {
        const jsonUrl = `${normalizedUrl}.json`;
        try {
            const res = await fetch(jsonUrl, {
                headers: {
                    "User-Agent": getRandomUA(),
                    Accept: "application/json"
                },
                signal: AbortSignal.timeout(8000),
                cache: "no-store"
            });
            if (res.ok) {
                const data = await res.json();
                const postData = data?.[0]?.data?.children?.[0]?.data;
                if (postData) {
                    const jsonContent = parseJsonPostContent(postData, postId, normalizedUrl, "json");
                    if (jsonContent.score === 0) {
                        try {
                            const scoreUrl = `https://oauth.reddit.com/comments/${postId}?limit=1`;
                            const scoreRes = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithOAuth */ .KN)(scoreUrl, {
                                timeoutMs: 10000
                            });
                            if (scoreRes.ok) {
                                const scoreData = JSON.parse(scoreRes.text);
                                jsonContent.score = scoreData?.[0]?.data?.children?.[0]?.data?.score ?? 0;
                            }
                        } catch  {}
                    }
                    return jsonContent;
                }
            }
        } catch  {
        // fall through
        }
        const jsonResult = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(jsonUrl, {
            expectedType: "json",
            maxProxiesToTry: 8,
            timeoutMs: 10000
        });
        if (jsonResult.ok) {
            try {
                const data = JSON.parse(jsonResult.text);
                const postData = data?.[0]?.data?.children?.[0]?.data;
                if (postData) {
                    const proxyContent = parseJsonPostContent(postData, postId, normalizedUrl, "proxy");
                    if (proxyContent.score === 0) {
                        try {
                            const scoreUrl = `https://oauth.reddit.com/comments/${postId}?limit=1`;
                            const scoreRes = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithOAuth */ .KN)(scoreUrl, {
                                timeoutMs: 10000
                            });
                            if (scoreRes.ok) {
                                const scoreData = JSON.parse(scoreRes.text);
                                proxyContent.score = scoreData?.[0]?.data?.children?.[0]?.data?.score ?? 0;
                            }
                        } catch  {}
                    }
                    return proxyContent;
                }
            } catch  {
            // ignore
            }
        }
    }
    if (!rssText) {
        throw new Error(`Failed to fetch post ${postId} (RSS + JSON + proxies all failed)`);
    }
    const content = parseRssPostContent(rssText, postId, normalizedUrl, source);
    // Score isn't in RSS — fetch via OAuth API
    if (content.score === 0) {
        // Try OAuth first
        try {
            const scoreUrl = `https://oauth.reddit.com/comments/${postId}?limit=1`;
            const scoreRes = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithOAuth */ .KN)(scoreUrl, {
                timeoutMs: 10000
            });
            if (scoreRes.ok) {
                const scoreData = JSON.parse(scoreRes.text);
                content.score = scoreData?.[0]?.data?.children?.[0]?.data?.score ?? 0;
                console.log(`[reddit-scraper] Fetched score via OAuth for ${postId}: ${content.score}`);
            }
        } catch (e) {
            console.log(`[reddit-scraper] OAuth score fetch failed for ${postId}: ${e}`);
        }
    }
    // If OAuth failed, try public JSON API (no auth needed)
    if (content.score === 0) {
        try {
            const publicUrl = `https://www.reddit.com/comments/${postId}.json?limit=1`;
            const pubRes = await fetch(publicUrl, {
                headers: {
                    "User-Agent": "HFY-Reader/1.0"
                },
                signal: AbortSignal.timeout(8000),
                cache: "no-store"
            });
            if (pubRes.ok) {
                const pubData = await pubRes.json();
                content.score = pubData?.[0]?.data?.children?.[0]?.data?.score ?? 0;
                console.log(`[reddit-scraper] Fetched score via public JSON for ${postId}: ${content.score}`);
            }
        } catch (e) {
            console.log(`[reddit-scraper] Public JSON score fetch failed for ${postId}: ${e}`);
        }
    }
    return content;
}
function parseJsonPostContent(postData, postId, postUrl, source) {
    const selftext = postData.selftext ?? "";
    const selftextHtml = postData.selftext_html ?? "";
    // hfy2epub approach: only take the FIRST matching link (not all).
    // This prevents following "First"/"Previous" links to prequel chapters.
    const allLinks = findChapterLinks(selftext, selftextHtml, NEXT_LINK_PATTERNS);
    const nextLinks = allLinks.slice(0, 1); // Only first match
    return {
        postId,
        title: postData.title ?? "",
        author: postData.author ?? "",
        createdUtc: postData.created_utc ?? 0,
        score: postData.score ?? 0,
        selftext,
        selftextHtml,
        url: postData.url ?? postUrl,
        permalink: postData.permalink ? `https://www.reddit.com${postData.permalink}` : postUrl,
        subreddit: postData.subreddit ?? "HFY",
        flair: postData.link_flair_text ?? undefined,
        numComments: postData.num_comments ?? 0,
        nextChapterLinks: nextLinks,
        prevChapterLinks: [],
        source
    };
}
function parseRssPostContent(rssXml, postId, postUrl, source) {
    // Extract the first <entry> — this is the post itself
    // (RSS includes comments as additional entries)
    const entryMatch = rssXml.match(/<entry>([\s\S]*?)<\/entry>/);
    if (!entryMatch) {
        throw new Error(`No <entry> found in RSS for post ${postId}`);
    }
    const entry = entryMatch[1];
    // Title
    const title = decodeXml(getFirst(entry, "title")) || `Post ${postId}`;
    // Author
    const authorMatch = entry.match(/<author>[\s\S]*?<name>([^<]+)<\/name>/);
    const authorRaw = authorMatch ? authorMatch[1].trim() : "unknown";
    const author = authorRaw.replace(/^\/?u\//, "");
    // Permalink (link rel=alternate)
    const linkMatch = entry.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/);
    const permalink = linkMatch ? linkMatch[1] : postUrl;
    // Published date
    const published = decodeXml(getFirst(entry, "published")) || decodeXml(getFirst(entry, "updated")) || "";
    const createdUtc = published ? Date.parse(published) / 1000 : 0;
    // Content (HTML)
    const contentMatch = entry.match(/<content[^>]*>([\s\S]*?)<\/content>/);
    const contentHtmlEncoded = contentMatch ? contentMatch[1] : "";
    // RSS content is HTML-encoded — decode it
    const contentHtml = decodeXml(contentHtmlEncoded).replace(/<!-- SC_OFF -->/g, "").replace(/<!-- SC_ON -->/g, "").trim();
    // Extract the .md div content (Reddit wraps post body in <div class="md">)
    let bodyHtml = contentHtml;
    const mdDivMatch = contentHtml.match(/<div class="md">([\s\S]*?)<\/div>\s*(?:<div|$)/);
    if (mdDivMatch) {
        bodyHtml = mdDivMatch[1];
    }
    // Strip HTML to get selftext (plain text)
    const selftext = htmlToMarkdown(bodyHtml);
    // Find next-chapter links in both HTML and markdown
    // hfy2epub approach: only take the FIRST matching link (not all).
    const allLinks = findChapterLinks(selftext, bodyHtml, NEXT_LINK_PATTERNS);
    const nextLinks = allLinks.slice(0, 1); // Only first match
    // Score isn't in RSS — returns 0, fetchPostContent will fetch it via OAuth
    return {
        postId,
        title,
        author,
        createdUtc,
        score: 0,
        selftext,
        selftextHtml: bodyHtml,
        url: postUrl,
        permalink,
        subreddit: "HFY",
        flair: undefined,
        numComments: 0,
        nextChapterLinks: nextLinks,
        prevChapterLinks: [],
        source
    };
}
function getFirst(xml, tag) {
    const re = new RegExp(`<${tag}[^>]*>([^<]*)</${tag}>`);
    const m = xml.match(re);
    return m ? m[1] : "";
}
function decodeXml(s) {
    return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'");
}
function htmlToMarkdown(html) {
    // Convert common HTML to markdown for the reader
    let md = html;
    // Headings
    md = md.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, (_, t)=>`# ${stripTags(t)}\n\n`);
    md = md.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, (_, t)=>`## ${stripTags(t)}\n\n`);
    md = md.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, (_, t)=>`### ${stripTags(t)}\n\n`);
    // Bold / italic
    md = md.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, (_, t)=>`*${stripTags(t)}*`);
    md = md.replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, (_, t)=>`*${stripTags(t)}*`);
    // Links
    md = md.replace(/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, (_, href, t)=>`[${stripTags(t)}](${href})`);
    // Blockquote
    md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_, t)=>`> ${stripTags(t).replace(/\n/g, "\n> ")}\n\n`);
    // Horizontal rule
    md = md.replace(/<hr[^>]*>/gi, "\n---\n\n");
    // Code
    md = md.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_, t)=>`\`${stripTags(t)}\``);
    md = md.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, t)=>`\`\`\`\n${stripTags(t)}\n\`\`\`\n\n`);
    // Paragraphs and breaks
    md = md.replace(/<p[^>]*>/gi, "\n\n");
    md = md.replace(/<\/p>/gi, "");
    md = md.replace(/<br\s*\/?>/gi, "\n");
    // Lists
    md = md.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_, t)=>`- ${stripTags(t).trim()}\n`);
    md = md.replace(/<\/?(ul|ol)[^>]*>/gi, "\n");
    // Strip remaining tags
    md = stripTags(md);
    // Decode entities
    md = decodeXml(md);
    // Collapse whitespace
    md = md.replace(/\n{3,}/g, "\n\n\n").trim();
    return md;
}
function stripTags(html) {
    return html.replace(/<[^>]+>/g, "");
}
// =====================================================
// 4. "Next chapter" link discovery
// =====================================================
// Words that indicate a link is to a PREQUEL or ORIGINAL series, not the
// current series' next chapter. When the crawler finds these words in the
// link text or surrounding context, it should NOT follow that link.
const PREQUEL_LINK_INDICATORS = [
    /previous\s*chapter/i,
    /\bprev\b/i,
    /\bfirst\s*chapter/i,
    /\boriginal\s*series/i,
    /\bprequel\b/i,
    /\bbook\s*1\b/i,
    /\bbeginning\b/i,
    /\bstart\s*here/i,
    /\bfrom\s*the\s*start/i,
    /\bbefore\s*this/i,
    /\bearlier/i,
    /\bback\s*to\s*the\s*beginning/i
];
// Check if a link should be skipped (it's a prequel/previous link)
function isPrequelLink(linkText, context) {
    const fullText = (linkText + " " + context).toLowerCase();
    return PREQUEL_LINK_INDICATORS.some((re)=>re.test(fullText));
}
/**
/**
 * Extract a Reddit post ID from a URL.
 * "https://www.reddit.com/r/HFY/comments/abc123/chapter_1/" → "abc123"
 * Returns null if the URL doesn't match the Reddit post pattern.
 */ function extractPostId(url) {
    const m = url.match(REDDIT_POST_URL_PATTERN);
    return m ? m[1] : null;
}
/**
 * Find the NEXT chapter URL from a post's content.
 * Follows hfy2epub's approach: returns ONLY the FIRST matching link
 * that hasn't been visited yet. This prevents following "previous" links
 * to prequel chapters, because "next" links typically appear before
 * "previous" links in the post body.
 *
 * @param markdown - The post's markdown content
 * @param html - The post's HTML content (optional)
 * @param patterns - Active link patterns (or null to use defaults)
 * @param visitedPostIds - Set of already-visited post IDs
 * @returns The first unvisited matching URL, or null if none found
 */ function findNextChapterUrl(markdown, html, patterns, visitedPostIds) {
    const activePatterns = patterns ?? getActiveLinkPatterns();
    // Markdown links — iterate in order, return first match
    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g;
    let m;
    while((m = mdLinkRe.exec(markdown)) !== null){
        const text = m[1];
        const url = m[2];
        // Skip prequel links
        const linkStart = m.index;
        const contextStart = Math.max(0, linkStart - 100);
        const context = markdown.slice(contextStart, linkStart);
        if (isPrequelLink(text, context)) continue;
        // Check if link text matches a "next" pattern
        if (REDDIT_POST_URL_PATTERN.test(url) && activePatterns.some((p)=>p.test(text))) {
            const postId = extractPostId(url);
            if (postId && !visitedPostIds.has(postId)) {
                return normalizeRedditUrl(url);
            }
        }
    }
    // HTML <a> tags — iterate in order, return first match
    if (html) {
        const aRe = /<a[^>]+href=["'](https?:\/\/[^"']+)["'][^>]*>([^<]*)<\/a>/gi;
        while((m = aRe.exec(html)) !== null){
            const url = m[1];
            const text = m[2];
            const linkStart = m.index;
            const contextStart = Math.max(0, linkStart - 100);
            const context = html.slice(contextStart, linkStart);
            if (isPrequelLink(text, context)) continue;
            if (REDDIT_POST_URL_PATTERN.test(url) && activePatterns.some((p)=>p.test(text))) {
                const postId = extractPostId(url);
                if (postId && !visitedPostIds.has(postId)) {
                    return normalizeRedditUrl(url);
                }
            }
        }
    }
    // Bare URLs near "next" keywords — return first match
    const lines = markdown.split("\n");
    for (const line of lines){
        const trimmed = line.trim().toLowerCase();
        if (activePatterns.some((p)=>p.test(trimmed))) {
            if (isPrequelLink(trimmed, "")) continue;
            const urlMatch = line.match(/https?:\/\/[^\s)\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s)\]]*/i);
            if (urlMatch) {
                const postId = extractPostId(urlMatch[0]);
                if (postId && !visitedPostIds.has(postId)) {
                    return normalizeRedditUrl(urlMatch[0]);
                }
            }
        }
    }
    return null;
}
function findChapterLinks(markdown, html, patterns) {
    // Use provided patterns, or get active patterns (built-in + custom from settings)
    const activePatterns = patterns ?? getActiveLinkPatterns();
    const found = new Set();
    // Markdown links
    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g;
    let m;
    while((m = mdLinkRe.exec(markdown)) !== null){
        const text = m[1];
        const url = m[2];
        // Get context (100 chars before the link)
        const linkStart = m.index;
        const contextStart = Math.max(0, linkStart - 100);
        const context = markdown.slice(contextStart, linkStart);
        // Skip prequel/previous links
        if (isPrequelLink(text, context)) continue;
        // Match if: (1) link text matches a "next chapter" pattern, OR
        // (2) the URL is a Reddit post link (any link to another Reddit post
        // is a potential chapter link — not just ones labeled "next")
        if (REDDIT_POST_URL_PATTERN.test(url) && (activePatterns.some((p)=>p.test(text)) || REDDIT_POST_URL_PATTERN.test(text) // link text is itself a Reddit URL
        )) {
            found.add(normalizeRedditUrl(url));
        }
    }
    // HTML <a> tags
    if (html) {
        const aRe = /<a[^>]+href=["'](https?:\/\/[^"']+)["'][^>]*>([^<]*)<\/a>/gi;
        while((m = aRe.exec(html)) !== null){
            const url = m[1];
            const text = m[2];
            // Get context (100 chars before the link in HTML)
            const linkStart = m.index;
            const contextStart = Math.max(0, linkStart - 100);
            const context = html.slice(contextStart, linkStart);
            // Skip prequel/previous links
            if (isPrequelLink(text, context)) continue;
            if (REDDIT_POST_URL_PATTERN.test(url) && (activePatterns.some((p)=>p.test(text)) || REDDIT_POST_URL_PATTERN.test(text) // link text is itself a Reddit URL
            )) {
                found.add(normalizeRedditUrl(url));
            }
        }
    }
    // Bare URLs near "next" keywords
    const lines = markdown.split("\n");
    for (const line of lines){
        const trimmed = line.trim().toLowerCase();
        if (activePatterns.some((p)=>p.test(trimmed))) {
            // Skip if the line contains prequel indicators
            if (isPrequelLink(trimmed, "")) continue;
            const urlMatch = line.match(/https?:\/\/[^\s)\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s)\]]*/i);
            if (urlMatch) {
                found.add(normalizeRedditUrl(urlMatch[0]));
            }
        }
    }
    return Array.from(found);
}
function normalizeRedditUrl(url) {
    if (!url || typeof url !== "string") return "";
    try {
        return url.replace(/[?#].*$/, "").replace(/\/$/, "").replace(/^https?:\/\/(www\.|old\.|new\.|np\.)?reddit\.com/i, "https://www.reddit.com").replace(/\/r\/HFY\//i, "/r/HFY/").replace(/\/r\/hfy\//i, "/r/HFY/").replace(/\/comments\//i, "/comments/").toLowerCase();
    } catch  {
        return url || "";
    }
}
// =====================================================
// 5. Search r/HFY — try RSS first, then CORS proxies
// =====================================================
async function searchSeries(query, sort = "relevance") {
    const sortParam = sort === "new" ? "new" : sort === "top" ? "top" : "relevance";
    // Strategy 0 (PRIMARY): OAuth via oauth.reddit.com
    try {
        const children = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__.searchSubreddit)("HFY", query, sortParam, 250);
        if (children && children.length > 0) {
            return children.map((c)=>({
                    id: c.data.id,
                    title: c.data.title,
                    wikiUrl: `https://www.reddit.com${c.data.permalink}`,
                    author: c.data.author
                }));
        }
    } catch  {}
    // Strategy R (RedDownloader fallback): authless .json
    try {
        const rdUrl = `${REDDIT_BASE}/r/HFY/search.json?q=${encodeURIComponent(query)}&sort=${sortParam}&limit=250&restrict_sr=1`;
        const rd = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithRedDownloader */ .dE)(rdUrl, 12000);
        if (rd.ok) {
            const data = JSON.parse(rd.text);
            const children = data?.data?.children ?? [];
            if (children.length > 0) {
                return children.map((c)=>({
                        id: c.data.id,
                        title: c.data.title,
                        wikiUrl: `https://www.reddit.com${c.data.permalink}`,
                        author: c.data.author
                    }));
            }
        }
    } catch  {}
    // Strategy 1: direct .json (will likely fail)
    const url = `${REDDIT_BASE}/r/HFY/search.json?q=${encodeURIComponent(query)}&sort=${sortParam}&limit=250&restrict_sr=1`;
    try {
        const res = await fetch(url, {
            headers: {
                "User-Agent": getRandomUA(),
                Accept: "application/json"
            },
            signal: AbortSignal.timeout(8000),
            cache: "no-store"
        });
        if (res.ok) {
            const data = await res.json();
            const children = data?.data?.children ?? [];
            return children.map((c)=>({
                    id: c.data.id,
                    title: c.data.title,
                    wikiUrl: `https://www.reddit.com${c.data.permalink}`,
                    author: c.data.author
                }));
        }
    } catch  {}
    // Strategy 2 (LAST RESORT): CORS proxy
    const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(url, {
        expectedType: "json",
        maxProxiesToTry: 8,
        timeoutMs: 10000
    });
    if (result.ok) {
        try {
            const data = JSON.parse(result.text);
            const children = data?.data?.children ?? [];
            return children.map((c)=>({
                    id: c.data.id,
                    title: c.data.title,
                    wikiUrl: `https://www.reddit.com${c.data.permalink}`,
                    author: c.data.author
                }));
        } catch  {
        // ignore
        }
    }
    return [];
}
async function fetchSubredditFeed(limit = 25) {
    const url = `${REDDIT_BASE}/r/HFY.rss?limit=${limit}`;
    try {
        const res = await fetch(url, {
            headers: {
                "User-Agent": getRandomUA(),
                Accept: "application/atom+xml"
            },
            signal: AbortSignal.timeout(10000),
            cache: "no-store"
        });
        if (!res.ok) return [];
        const xml = await res.text();
        return parseSubredditRss(xml);
    } catch  {
        return [];
    }
}
function parseSubredditRss(xml) {
    const posts = [];
    const entryRe = /<entry>([\s\S]*?)<\/entry>/g;
    let m;
    while((m = entryRe.exec(xml)) !== null){
        const entry = m[1];
        const id = (getFirst(entry, "id") || "").replace(/^t3_/, "");
        const title = decodeXml(getFirst(entry, "title")) || "Untitled";
        const authorMatch = entry.match(/<author>[\s\S]*?<name>([^<]+)<\/name>/);
        const authorRaw = authorMatch ? authorMatch[1].trim() : "unknown";
        const author = authorRaw.replace(/^\/?u\//, "");
        const linkMatch = entry.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/);
        const permalink = linkMatch ? linkMatch[1] : "";
        const published = decodeXml(getFirst(entry, "published")) || "";
        const createdUtc = published ? Date.parse(published) / 1000 : 0;
        const contentMatch = entry.match(/<content[^>]*>([\s\S]*?)<\/content>/);
        const contentHtml = contentMatch ? decodeXml(contentMatch[1]) : "";
        const selftext = htmlToMarkdown(contentHtml).slice(0, 500);
        if (id && permalink) {
            posts.push({
                id,
                title,
                author,
                permalink,
                createdUtc,
                flair: undefined,
                selftext,
                score: 0
            });
        }
    }
    return posts;
}


/***/ }),

/***/ 4383:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Gz: () => (/* binding */ clearUserToken),
/* harmony export */   KN: () => (/* binding */ fetchWithOAuth),
/* harmony export */   R_: () => (/* binding */ setUserToken),
/* harmony export */   U2: () => (/* binding */ fetchWikiPageJson),
/* harmony export */   VH: () => (/* binding */ getRedditOAuthToken),
/* harmony export */   dE: () => (/* binding */ fetchWithRedDownloader),
/* harmony export */   fetchWithCookies: () => (/* binding */ fetchWithCookies),
/* harmony export */   searchSubreddit: () => (/* binding */ searchSubreddit)
/* harmony export */ });
/* unused harmony exports getUserToken, getUserRefreshToken, getAppOnlyToken, fetchWithProxyBrowser, fetchPostJson, fetchSubredditFeedJson */
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5511);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
// HFY NEKROCODEXXX — Reddit Downloaders Integration
// =====================================================
// Integrates 5 Reddit downloaders as a multi-tier fallback system:
//
//   1. DownloaderForReddit (DFR) — bundled client_id OAuth (frGEUVAuHGL2PQ)
//      Source: github.com/MalloyDelacroix/DownloaderForReddit
//      Type: OAuth (Installed App, app-only)
//
//   2. easy-reddit-downloader — authless .json with browser UA
//      Source: github.com/josephrcox/easy-reddit-downloader
//      Type: Authless (no OAuth, no login)
//      Approach: fetches www.reddit.com/.../.json with browser User-Agent
//
//   3. RedDownloader — authless .json (RedDownloader approach)
//      Source: github.com/Jackhammer9/RedDownloader
//      Type: Authless
//      Approach: same as easy-reddit-downloader (browser UA + .json)
//
//   4. reddit-json-scraper — authless .json
//      Source: github.com/0anxt/reddit-json-scraper
//      Type: Authless
//      Approach: public .json API, no auth
//
//   5. reddit-dl — OAuth + proxy support
//      Source: github.com/patrickkfkan/reddit-dl
//      Type: OAuth (user-provided) or proxy
//      Approach: supports account-specific content (saved posts, joined subs)
//
// TIER SYSTEM:
//   Tier B (PRIMARY): User OAuth (user logs in, 600 QPM, NSFW access)
//   Tier A (SECONDARY): DFR App-Only OAuth (bundled client_id, 100 QPM, public)
//   Tier R (TERTIARY): RedDownloader/easy-reddit-downloader/reddit-json-scraper
//                       (authless .json, no rate limit tracking, browser UA)
//   Tier P (QUATERNARY): reddit-dl proxy support (CORS proxy pool)
//   Tier S (LAST RESORT): RSS feeds (.rss endpoints, not blocked)

// =====================================================
// Client IDs (from DownloaderForReddit — pre-approved by Reddit)
// =====================================================
const BUNDLED_CLIENT_ID = process.env.REDDIT_BUNDLED_CLIENT_ID || "frGEUVAuHGL2PQ";
const USER_AGENT_DFR = "HFY-NEKROCODEXXX/1.0 (Reddit HFY series reader; fork of DownloaderForReddit approach)";
// easy-reddit-downloader uses a generic browser UA
const USER_AGENT_EASY = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
// reddit-json-scraper uses a Python UA
const USER_AGENT_RJS = "python:reddit-json-scraper:v1.0 (by /u/hfy_nekrocodexxx)";
// =====================================================
// Token management (Tier A + Tier B)
// =====================================================
let appTokenCache = null;
let userTokenCache = null;
function setUserToken(token, expiresIn, refreshToken) {
    userTokenCache = {
        token,
        expiresAt: Date.now() + expiresIn * 1000,
        refreshToken
    };
}
function clearUserToken() {
    userTokenCache = null;
}
function getUserToken() {
    if (userTokenCache && userTokenCache.expiresAt > Date.now() + 60000) {
        return userTokenCache.token;
    }
    return null;
}
function getUserRefreshToken() {
    return userTokenCache?.refreshToken || null;
}
// Tier A: App-Only OAuth (DFR bundled client_id)
async function getAppOnlyToken() {
    if (appTokenCache && appTokenCache.expiresAt > Date.now() + 60000) {
        return appTokenCache.token;
    }
    if (!BUNDLED_CLIENT_ID) return null;
    try {
        const deviceId = crypto__WEBPACK_IMPORTED_MODULE_0___default().randomBytes(15).toString("base64url").slice(0, 25);
        const res = await fetch("https://www.reddit.com/api/v1/access_token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: `Basic ${Buffer.from(`${BUNDLED_CLIENT_ID}:`).toString("base64")}`,
                "User-Agent": USER_AGENT_DFR
            },
            body: new URLSearchParams({
                grant_type: "https://oauth.reddit.com/grants/installed_client",
                device_id: deviceId
            }).toString(),
            signal: AbortSignal.timeout(10000),
            cache: "no-store"
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (!data.access_token) return null;
        appTokenCache = {
            token: data.access_token,
            expiresAt: Date.now() + (data.expires_in ?? 3600) * 1000
        };
        return data.access_token;
    } catch  {
        return null;
    }
}
function getMultiTokenStore() {
    if (!global.redditMultiTokens) {
        global.redditMultiTokens = new Map();
        global.redditTokenRotationIndex = 0;
    }
    return global.redditMultiTokens;
}
// Get the next token from the multi-account rotation (round-robin).
// Skips expired tokens (with 5-min buffer). Returns null if no live tokens.
function getNextMultiToken() {
    const store = getMultiTokenStore();
    if (store.size === 0) return null;
    const accounts = Array.from(store.entries()).filter(([, v])=>v.accessToken && Date.now() < v.expiresAt - 5 * 60 * 1000
        && v.clientId !== "cookies" && v.clientId !== "cookie-injection");
    if (accounts.length === 0) return null;
    const idx = (global.redditTokenRotationIndex || 0) % accounts.length;
    global.redditTokenRotationIndex = idx + 1;
    const [, tokenData] = accounts[idx];
    return {
        token: tokenData.accessToken,
        username: tokenData.username
    };
}
// Get best available OAuth token.
// Priority: multi-account rotation → userTokenCache → appTokenCache.
async function getRedditOAuthToken() {
    // Tier B (multi-account rotation) — preferred, gives 600 QPM × N accounts
    const multi = getNextMultiToken();
    if (multi) return {
        token: multi.token,
        tier: "user"
    };
    // Tier B (single user token from /api/reddit-user-token)
    const userToken = getUserToken();
    if (userToken) return {
        token: userToken,
        tier: "user"
    };
    // Tier A (anonymous app-only, 100 QPM)
    const appToken = await getAppOnlyToken();
    if (appToken) return {
        token: appToken,
        tier: "app"
    };
    return null;
}
async function fetchWithOAuth(url, options = {}) {
    const auth = await getRedditOAuthToken();
    let oauthUrl = url;
    // Convert www.reddit.com → oauth.reddit.com (only for .json/wiki/search, NOT .rss)
    if (!url.includes(".rss")) {
        oauthUrl = url.replace("://www.reddit.com", "://oauth.reddit.com").replace("://old.reddit.com", "://oauth.reddit.com").replace("://new.reddit.com", "://oauth.reddit.com").replace("://np.reddit.com", "://oauth.reddit.com");
    }
    const headers = {
        "User-Agent": USER_AGENT_DFR,
        Accept: "application/json",
        ...options.headers || {}
    };
    if (auth) headers["Authorization"] = `Bearer ${auth.token}`;
    try {
        const res = await fetch(oauthUrl, {
            method: options.method || "GET",
            headers,
            body: options.body,
            signal: AbortSignal.timeout(options.timeoutMs || 15000),
            cache: "no-store"
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text,
            tier: auth?.tier || "none",
            headers: res.headers
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed",
            tier: auth?.tier || "none",
            headers: new Headers()
        };
    }
}
// =====================================================
// Tier R: Authless fallback (RedDownloader + easy-reddit-downloader + reddit-json-scraper)
// =====================================================
// All three of these downloaders use the same approach: fetch .json endpoints
// directly with a browser-like User-Agent. No OAuth needed.
//
// We try multiple User-Agents in case Reddit blocks one:
//   1. easy-reddit-downloader UA (Chrome browser)
//   2. reddit-json-scraper UA (Python bot)
//   3. RedDownloader UA (generic browser)
const AUTHLESS_UAS = [
    USER_AGENT_EASY,
    USER_AGENT_RJS,
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
];
async function fetchWithRedDownloader(url, timeoutMs = 12000) {
    let jsonUrl = url;
    if (!jsonUrl.endsWith(".json")) {
        jsonUrl = jsonUrl.replace(/[?#].*$/, "").replace(/\/$/, "") + ".json";
    }
    // Try each User-Agent until one works
    for (const ua of AUTHLESS_UAS){
        try {
            const res = await fetch(jsonUrl, {
                headers: {
                    "User-Agent": ua,
                    Accept: "application/json, text/html",
                    "Accept-Language": "en-US,en;q=0.9"
                },
                signal: AbortSignal.timeout(timeoutMs),
                cache: "no-store"
            });
            if (res.ok) {
                const text = await res.text();
                // Verify it's actually JSON (not an error page)
                if (text.trim().startsWith("{") || text.trim().startsWith("[")) {
                    return {
                        ok: true,
                        status: res.status,
                        text
                    };
                }
            }
        } catch  {
        // try next UA
        }
    }
    return {
        ok: false,
        status: 0,
        text: "all authless UAs failed"
    };
}
// =====================================================
// Tier P+: Proxy Browser fallback
// =====================================================
// Routes the fetch through our own /api/proxy-browser endpoint,
// which maintains a server-side cookie jar. Once the user has
// logged in to Reddit through the InAppBrowser, every subsequent
// request here will carry their session cookies and behave like a
// residential-IP request (no Reddit IP block).
//
// NOTE: this is a server-side fetch (called from API routes), so
// the relative URL is resolved against the app's own origin.
// =====================================================
async function fetchWithProxyBrowser(url, timeoutMs = 15000) {
    try {
        // We can't read process.env.NEXT_PUBLIC_APP_URL reliably across
        // every deployment, so fall back to a relative URL. Inside an
        // API route, fetch() with a relative URL resolves against the
        // current request origin — which is what we want.
        const proxyUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
        const target = proxyUrl ? `${proxyUrl.replace(/\/$/, "")}/api/proxy-browser?url=${encodeURIComponent(url)}` : `/api/proxy-browser?url=${encodeURIComponent(url)}`;
        const res = await fetch(target, {
            signal: AbortSignal.timeout(timeoutMs),
            cache: "no-store",
            headers: {
                "User-Agent": USER_AGENT_EASY,
                Accept: "application/json, text/html, */*"
            }
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed"
        };
    }
}
// =====================================================
// Convenience helpers (with full tier cascade)
// =====================================================
async function fetchWikiPageJson(subreddit, wikiSlug) {
    const cleanSlug = wikiSlug.replace(/^\/+|\/+$/g, "");
    const url = `https://www.reddit.com/r/${subreddit}/wiki/${cleanSlug}`;
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 15000
    });
    if (res.ok) {
        try {
            return JSON.parse(res.text);
        } catch  {}
    }
    // Tier R: RedDownloader/easy-reddit-downloader/reddit-json-scraper
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            return JSON.parse(rd.text);
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            return JSON.parse(pb.text);
        } catch  {}
    }
    return null;
}
async function fetchPostJson(postIdOrUrl) {
    let url;
    if (postIdOrUrl.startsWith("http")) {
        url = postIdOrUrl.replace(/[?#].*$/, "").replace(/\/$/, "");
    } else {
        url = `https://www.reddit.com/r/HFY/comments/${postIdOrUrl}/`;
    }
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 15000
    });
    if (res.ok) {
        try {
            return JSON.parse(res.text);
        } catch  {}
    }
    // Tier R: authless
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            return JSON.parse(rd.text);
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            return JSON.parse(pb.text);
        } catch  {}
    }
    return null;
}
async function searchSubreddit(subreddit, query, sort = "relevance", limit = 100) {
    const params = new URLSearchParams({
        q: query,
        sort,
        restrict_sr: "1",
        limit: String(limit)
    });
    const url = `https://www.reddit.com/r/${subreddit}/search?${params}`;
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 12000
    });
    if (res.ok) {
        try {
            const data = JSON.parse(res.text);
            return data?.data?.children ?? [];
        } catch  {}
    }
    // Tier R: authless
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            const data = JSON.parse(rd.text);
            return data?.data?.children ?? [];
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            const data = JSON.parse(pb.text);
            return data?.data?.children ?? [];
        } catch  {}
    }
    return null;
}
async function fetchSubredditFeedJson(subreddit, sort = "new", limit = 100, after) {
    const params = new URLSearchParams({
        sort,
        limit: String(limit)
    });
    if (after) params.set("after", after);
    const url = `https://www.reddit.com/r/${subreddit}/${sort}?${params}`;
    const res = await fetchWithOAuth(url, {
        timeoutMs: 12000
    });
    if (res.ok) {
        try {
            const data = JSON.parse(res.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    // Tier P+: proxy browser fallback
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            const data = JSON.parse(pb.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    return null;
}
// =====================================================
// Cookie-based fetch — uses user-provided Reddit session cookies
// to bypass rate limits. Cookies are loaded from data/reddit-cookies.json
// =====================================================


let cachedCookieString = null;
let cookieCheckTime = 0;
function getRedditCookies() {
    // Re-check every 30 seconds (in case cookies were added after startup)
    if (cachedCookieString !== null && Date.now() - cookieCheckTime < 30000) {
        return cachedCookieString || null;
    }
    cachedCookieString = null;
    cookieCheckTime = Date.now();
    try {
        const cookiePaths = [
            process.env.HFY_DATA_DIR ? (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.env.HFY_DATA_DIR, "reddit-cookies.json") : (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            process.env.HFY_DATA_DIR ? (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.env.HFY_DATA_DIR, "reddit-cookies.json") : (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "..", "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "..", "..", "data", "reddit-cookies.json")
        ];
        for (const cookiePath of cookiePaths){
            try {
                const content = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(cookiePath, "utf8");
                const cookies = JSON.parse(content);
                if (Array.isArray(cookies) && cookies.length > 0) {
                    cachedCookieString = cookies.filter((c)=>c.name && c.value).map((c)=>`${c.name}=${c.value}`).join("; ");
                    if (cachedCookieString) return cachedCookieString;
                }
            } catch  {}
        }
    } catch  {}
    cachedCookieString = "";
    return null;
}
async function fetchWithCookies(url, options = {}) {
    const cookieStr = getRedditCookies();
    if (!cookieStr) return {
        ok: false,
        status: 0,
        text: "No cookies"
    };
    try {
        const res = await fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Cookie": cookieStr,
                "Accept": "application/json, text/html, */*"
            },
            signal: AbortSignal.timeout(options.timeoutMs || 12000),
            cache: "no-store"
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed"
        };
    }
}


/***/ }),

/***/ 4945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bV: () => (/* binding */ getImportedChapters),
/* harmony export */   cK: () => (/* binding */ saveImportedChapters),
/* harmony export */   rj: () => (/* binding */ parseRedditWikiForChapters),
/* harmony export */   sortChaptersByNumber: () => (/* binding */ sortChaptersByNumber)
/* harmony export */ });
/* unused harmony export extractChapterNumber */
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
// HFY NEKROCODEXXX — User-Imported Chapter Cache
// =====================================================
// Stores chapter lists that the USER imports from their
// browser (which isn't IP-blocked by Reddit) via the
// bookmarklet or paste-HTML fallback.
//
// Storage strategy:
//   - In-memory Map for fast reads
//   - Filesystem persistence at /home/z/my-project/data/user-chapters/
//     so imports survive server restarts
//
// Endpoints use this:
//   POST /api/series/[slug]/chapters — writes
//   GET  /api/series/[slug]/chapters — reads


// CRITICAL: Use multiple path resolution strategies to ensure chapters persist
// across restarts. process.cwd() can change on Android, so we also try
// __dirname (relative to this file in the standalone build) and a fixed path.
const POSSIBLE_DATA_DIRS = [
    // Priority 1: HFY_DATA_DIR (Android persistent storage — getFilesDir/hfy-data)
    process.env.HFY_DATA_DIR ? path__WEBPACK_IMPORTED_MODULE_1___default().join(process.env.HFY_DATA_DIR, "user-chapters") : path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "..", "data", "user-chapters")
];
// Use the first directory that exists and has data, or create the first one
let DATA_DIR = POSSIBLE_DATA_DIRS[0];
for (const dir of POSSIBLE_DATA_DIRS){
    try {
        const files = (__webpack_require__(9021).readdirSync)(dir);
        if (files.length > 0) {
            DATA_DIR = dir;
            break;
        }
    } catch  {
    // Directory doesn't exist, try next
    }
}
// In-memory cache
const cache = new Map();
// Ensure data dir exists
async function ensureDir() {
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.mkdir(DATA_DIR, {
            recursive: true
        });
    } catch  {
    // ignore
    }
}
function filePath(slug) {
    // Sanitize slug — only allow alphanumeric + underscore + hyphen
    const safe = slug.replace(/[^a-zA-Z0-9_-]/g, "_");
    return path__WEBPACK_IMPORTED_MODULE_1___default().join(DATA_DIR, `${safe}.json`);
}
/** Get imported chapters for a series slug */ async function getImportedChapters(slug) {
    // Check memory first, but verify against filesystem mtime
    // (the auto-discover route may have updated the file in a different
    // Next.js worker process with its own in-memory cache)
    const fp = filePath(slug);
    try {
        const stat = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.stat(fp);
        const cached = cache.get(slug);
        if (cached && cached.importedAt >= stat.mtimeMs) {
            // Cache is fresh
            return cached;
        }
        // Cache is stale or missing — reload from filesystem
        const content = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(fp, "utf8");
        let parsed;
        try {
            parsed = JSON.parse(content);
        } catch (parseErr) {
            // Corrupted JSON file — delete it and return null
            console.warn(`[user-chapters] Corrupted file for ${slug}, deleting:`, parseErr);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Validate: ensure chapters array exists and isn't excessively large
        if (!parsed.chapters || !Array.isArray(parsed.chapters)) {
            console.warn(`[user-chapters] Invalid chapters for ${slug}, deleting`);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Cap at 50000 chapters to prevent OOM (was 2000 — too low, caused data loss)
        if (parsed.chapters.length > 50000) {
            console.warn(`[user-chapters] Truncating ${parsed.chapters.length} chapters to 50000 for ${slug}`);
            parsed.chapters = parsed.chapters.slice(0, 50000);
        }
        cache.set(slug, parsed);
        return parsed;
    } catch  {
        // File doesn't exist
        if (cache.has(slug)) return cache.get(slug);
        return null;
    }
}
/** Save imported chapters for a series slug */ async function saveImportedChapters(slug, chapters, options = {}) {
    await ensureDir();
    // DEDUPLICATION: remove duplicate chapters by postId AND by normalized URL.
    // This is critical because parallel stages (RSS crawler, Wayback crawler,
    // JSON crawler, hfy.foundation) may all discover the same chapter.
    // We normalize URLs to catch duplicates that differ only in trailing
    // slashes, www prefix, or http vs https.
    const seenPostIds = new Set();
    const seenUrlKeys = new Set();
    const deduped = [];
    for (const c of chapters){
        if (!c.postId) continue;
        // Normalize URL for dedup (strip protocol/www/trailing slash/query)
        const urlKey = normalizeUrlForDedup(c.url);
        if (seenPostIds.has(c.postId) || seenUrlKeys.has(urlKey)) {
            continue; // skip duplicate
        }
        seenPostIds.add(c.postId);
        seenUrlKeys.add(urlKey);
        deduped.push(c);
    }
    // Merge processedPostIds with any existing ones (for resume-crawl)
    const existing = cache.get(slug);
    const processedSet = new Set([
        ...existing?.processedPostIds ?? [],
        ...options.processedPostIds ?? []
    ]);
    const list = {
        slug,
        chapters: deduped,
        // Preserve existing synopsis if the caller doesn't provide one.
        // This prevents reparse/fetch-missing/add-chapter from wiping the
        // synopsis that was previously saved.
        synopsis: options.synopsis !== undefined ? options.synopsis : existing?.synopsis,
        importedAt: Date.now(),
        source: options.source || "manual",
        processedPostIds: Array.from(processedSet)
    };
    cache.set(slug, list);
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.writeFile(filePath(slug), JSON.stringify(list... [TRUNCATED - full file in webapp ZIP] ...

```

## Page chunk

```javascript
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[8974],{

/***/ 285:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getDirHandle: () => (/* binding */ getDirHandle),
/* harmony export */   h8: () => (/* binding */ saveFileBlob),
/* harmony export */   saveFile: () => (/* binding */ saveFile),
/* harmony export */   setDirHandle: () => (/* binding */ setDirHandle),
/* harmony export */   tN: () => (/* binding */ restoreDirHandles)
/* harmony export */ });
/* unused harmony exports setNativeFolderPath, getNativeFolderPath, verifyPermission */
// File System Access API utilities for saving files to user-selected directories.
// Separated from SettingsScreen to avoid circular imports.
//
// Handles three tiers of storage:
//   1. File System Access API (showDirectoryPicker) — real directory writes
//   2. Browser download fallback — <a download> click
//
// Directory handles are persisted to IndexedDB so they survive page reloads.
// Permission is re-verified before every write (handles expire / get revoked).
// Native folder paths from AndroidFolderPicker (for Android APK)
const nativeFolderPaths = {};
function setNativeFolderPath(which, path) {
    nativeFolderPaths[which] = path;
}
function getNativeFolderPath(which) {
    return nativeFolderPaths[which] || null;
}
const dirHandles = {};
// --- IndexedDB persistence for FileSystemDirectoryHandle objects ---
// FileSystemDirectoryHandle is structured-cloneable, so we can store it
// directly in IndexedDB and rehydrate it on the next session.
async function idbSet(key, value) {
    return new Promise((resolve, reject)=>{
        const req = indexedDB.open("hfy-dir-handles", 1);
        req.onupgradeneeded = ()=>{
            req.result.createObjectStore("handles");
        };
        req.onsuccess = ()=>{
            const db = req.result;
            const tx = db.transaction("handles", "readwrite");
            tx.objectStore("handles").put(value, key);
            tx.oncomplete = ()=>{
                db.close();
                resolve();
            };
            tx.onerror = ()=>{
                db.close();
                reject(tx.error);
            };
        };
        req.onerror = ()=>reject(req.error);
    });
}
async function idbGet(key) {
    return new Promise((resolve, reject)=>{
        const req = indexedDB.open("hfy-dir-handles", 1);
        req.onupgradeneeded = ()=>{
            req.result.createObjectStore("handles");
        };
        req.onsuccess = ()=>{
            const db = req.result;
            const tx = db.transaction("handles", "readonly");
            const getReq = tx.objectStore("handles").get(key);
            getReq.onsuccess = ()=>{
                db.close();
                resolve(getReq.result || null);
            };
            getReq.onerror = ()=>{
                db.close();
                reject(getReq.error);
            };
        };
        req.onerror = ()=>reject(req.error);
    });
}
async function idbDel(key) {
    return new Promise((resolve, reject)=>{
        const req = indexedDB.open("hfy-dir-handles", 1);
        req.onupgradeneeded = ()=>{
            req.result.createObjectStore("handles");
        };
        req.onsuccess = ()=>{
            const db = req.result;
            const tx = db.transaction("handles", "readwrite");
            tx.objectStore("handles").delete(key);
            tx.oncomplete = ()=>{
                db.close();
                resolve();
            };
            tx.onerror = ()=>{
                db.close();
                reject(tx.error);
            };
        };
        req.onerror = ()=>reject(req.error);
    });
}
function setDirHandle(which, handle) {
    dirHandles[which] = handle;
    // Persist to IndexedDB (fire-and-forget — best effort)
    if (handle) {
        idbSet(`dir-${which}`, handle).catch(()=>{});
    } else {
        idbDel(`dir-${which}`).catch(()=>{});
    }
}
function getDirHandle(which) {
    if ( true && window.AndroidFolderPicker) {
        const ap = window.AndroidFolderPicker;
        if (typeof ap.hasFolder === "function" && ap.hasFolder(which)) {
            return {
                __native: true,
                which
            };
        }
    }
    return dirHandles[which] || null;
}
// Restore directory handles from IndexedDB on app startup.
// Call this once from a top-level client component.
async function restoreDirHandles() {
    for (const key of [
        "download",
        "ebook",
        "import"
    ]){
        try {
            const handle = await idbGet(`dir-${key}`);
            if (handle && !dirHandles[key]) {
                dirHandles[key] = handle;
            }
        } catch  {}
    }
}
// Verify the user has granted readwrite permission on the handle.
// If `request` is true, prompt the user to grant permission (must be called
// from a user gesture). Returns true if permission is granted.
async function verifyPermission(handle, request = false) {
    if (!handle) return false;
    if (typeof handle.requestPermission !== "function") return true; // not a real FileSystemHandle
    const opts = {
        mode: "readwrite"
    };
    try {
        if (await handle.queryPermission(opts) === "granted") return true;
        if (request) {
            return await handle.requestPermission(opts) === "granted";
        }
        return false;
    } catch  {
        return false;
    }
}
// Save a Blob (binary data like EPUB) to the user-selected directory.
// Same as saveFile but takes a Blob instead of a string.
async function saveFileBlob(dirHandle, filename, blob, seriesName, requestPermissionIfMissing = false) {
    const safeName = filename.replace(/[\\/:*?"<>|]/g, "_").slice(0, 200);
    // Check for native AndroidFolderPicker.writeFile (from APK)
    // The APK's AndroidFolderPicker class provides:
    //   writeFile(which, filename, content, subfolderName) → boolean
    //   hasFolder(which) → boolean
    // The content must be TEXT (UTF-8 string), not binary.
    // For EPUB files (binary), we convert to base64 and the Java side
    // will need to decode. But since the Java code uses OutputStreamWriter
    // with UTF-8, binary data gets corrupted.
    // WORKAROUND: Write as text content. The file will have .epub extension
    // but contain text. For proper EPUB, use HTTPS + showDirectoryPicker.
    if ( true && window.AndroidFolderPicker && typeof window.AndroidFolderPicker.writeFile === "function") {
        try {
            const folderKey = seriesName ? "download" : "ebook";
            const hasFolder = window.AndroidFolderPicker.hasFolder(folderKey) || window.AndroidFolderPicker.hasFolder("download");
            if (hasFolder) {
                const text = await blob.text();
                const useKey = window.AndroidFolderPicker.hasFolder(folderKey) ? folderKey : "download";
                // For native writeFile: use .txt extension (not .epub) because
                // the Java code writes TEXT (OutputStreamWriter UTF-8), not binary.
                // EPUB is a ZIP (binary) and CANNOT be written via the text-only
                // AndroidFolderPicker.writeFile() interface.
                // Replace .epub with .txt so files are readable in any text editor.
                const nativeName = safeName.replace(/\.epub$/i, ".txt");
                // CRITICAL: Do NOT pass a subfolder name to writeFile().
                // The Java code uses DocumentsContract.createDocument() which ALWAYS
                // creates a NEW folder with "(1)" suffix if one exists. This creates
                // duplicate "With the Hanks (1)", "With the Hanks (2)", etc.
                // Instead, all files go flat in the root folder. The filename already
                // includes the series name for identification.
                // The subfolder parameter is kept empty string "" to prevent duplicates.
                const subfolder = ""; // NO subfolder — prevents duplicate folders
                // Try to delete existing file first (prevents "(1)" file duplicates)
                try {
                    if (window.AndroidFolderPicker.deleteFile) {
                        window.AndroidFolderPicker.deleteFile(useKey, nativeName, subfolder);
                    }
                } catch  {}
                const result = window.AndroidFolderPicker.writeFile(useKey, nativeName, text, subfolder);
                if (result) {
                    return {
                        ok: true,
                        method: "directory",
                        path: subfolder ? `${subfolder}/${nativeName}` : nativeName
                    };
                }
            }
        } catch (e) {
            console.error("Native writeFile failed:", e?.message);
        }
    }
    if (dirHandle && typeof dirHandle.getFileHandle === "function") {
        const hasPermission = await verifyPermission(dirHandle, requestPermissionIfMissing);
        if (hasPermission) {
            try {
                let targetDir = dirHandle;
                if (seriesName) {
                    const safeSeries = seriesName.replace(/[\\/:*?"<>|]/g, "_").slice(0, 100);
                    try {
                        targetDir = await dirHandle.getDirectoryHandle(safeSeries, {
                            create: true
                        });
                    } catch  {
                        targetDir = dirHandle;
                    }
                }
                const fileHandle = await targetDir.getFileHandle(safeName, {
                    create: true
                });
                const writable = await fileHandle.createWritable();
                await writable.write(blob);
                await writable.close();
                return {
                    ok: true,
                    method: "directory",
                    path: seriesName ? `${seriesName}/${safeName}` : safeName
                };
            } catch (e) {
                console.error("saveFileBlob: directory write failed:", e?.message);
            }
        }
    }
    // Fallback: browser download
    // NOTE: When falling back to browser download (no directory handle),
    // files go to the browser's default Downloads folder. We do NOT prefix
    // the filename with seriesName because that would create duplicate folders
    // like "Wings (1)", "Wings (2)" on Android. The filename already includes
    // the series name for identification.
    try {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = safeName;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        setTimeout(()=>{
            try {
                document.body.removeChild(a);
            } catch  {}
            URL.revokeObjectURL(url);
        }, 5000);
        return {
            ok: true,
            method: "download",
            path: safeName
        };
    } catch (e) {
        return {
            ok: false,
            method: "failed",
            error: e?.message || "save failed"
        };
    }
}
// Save a file to the user-selected directory (if a handle exists and has
// permission), otherwise fall back to a regular browser download.
//
// IMPORTANT: when calling this in a loop for many files, pass `i === 0` for
// the first file — that triggers a permission prompt if needed, which must
// happen inside a user gesture. After that, subsequent calls just write.
async function saveFile(dirHandle, filename, content, seriesName, requestPermissionIfMissing = false) {
    // Sanitize filename — strip path separators, keep it filesystem-safe
    const safeName = filename.replace(/[\\/\:*?"<>|]/g, "_").slice(0, 200);
    // Native Android folder picker path
    if (dirHandle && dirHandle.__native && "object" !== "undefined" && window.AndroidFolderPicker) {
        const ap = window.AndroidFolderPicker;
        if (typeof ap.writeFile === "function") {
            try {
                const ok = ap.writeFile(dirHandle.which, safeName, content, seriesName || "");
                if (ok) return {
                    ok: true,
                    method: "directory",
                    path: seriesName ? `${seriesName}/${safeName}` : safeName
                };
            } catch (e) {
                console.error("saveFile: native failed:", e?.message);
            }
        }
    }
    // If we have a directory handle, try to write to it
    if (dirHandle && typeof dirHandle.getFileHandle === "function") {
        // Re-verify permission (handles can lose permission between sessions)
        const hasPermission = await verifyPermission(dirHandle, requestPermissionIfMissing);
        if (hasPermission) {
            try {
                // If seriesName is provided, create a subdirectory for the series
                let targetDir = dirHandle;
                if (seriesName) {
                    const safeSeries = seriesName.replace(/[\\/\:*?"<>|]/g, "_").slice(0, 100);
                    try {
                        targetDir = await dirHandle.getDirectoryHandle(safeSeries, {
                            create: true
                        });
                    } catch  {
                        targetDir = dirHandle; // fall back to root
                    }
                }
                const fileHandle = await targetDir.getFileHandle(safeName, {
                    create: true
                });
                const writable = await fileHandle.createWritable();
                await writable.write(content);
                await writable.close();
                return {
                    ok: true,
                    method: "directory",
                    path: seriesName ? `${seriesName}/${safeName}` : safeName
                };
            } catch (e) {
                console.error("saveFile: directory write failed, falling back to download:", e?.message || e);
            // Fall through to download fallback
            }
        } else {
            console.warn(`saveFile: directory handle exists but lacks readwrite permission for ${safeName}`);
        // Fall through to download fallback
        }
    }
    // Fallback: regular browser download
    try {
        const blob = new Blob([
            content
        ], {
            type: "text/plain;charset=utf-8"
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = safeName;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        // Keep the element in DOM longer to ensure download triggers
        setTimeout(()=>{
            try {
                document.body.removeChild(a);
            } catch  {}
            URL.revokeObjectURL(url);
        }, 5000);
        return {
            ok: true,
            method: "download",
            path: safeName
        };
    } catch (e) {
        return {
            ok: false,
            method: "failed",
            error: e?.message || "save failed"
        };
    }
}


/***/ }),

/***/ 380:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5895));


/***/ }),

/***/ 3375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   idbDelete: () => (/* binding */ idbDelete),
/* harmony export */   idbGet: () => (/* binding */ idbGet),
/* harmony export */   idbSet: () => (/* binding */ idbSet)
/* harmony export */ });
/* unused harmony export idbClearAll */
/* __next_internal_client_entry_do_not_use__ idbGet,idbSet,idbDelete,idbClearAll auto */ /**
 * idb-cache.ts — IndexedDB-based cache for series data.
 * Replaces localStorage for large series (900+ chapters) that exceed the 5MB quota.
 * IndexedDB can store gigabytes of data, so quota is effectively unlimited.
 */ const DB_NAME = "hfy-nekrocodexxx";
const DB_VERSION = 1;
const STORE_NAME = "series-cache";
function openDB() {
    return new Promise((resolve, reject)=>{
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = ()=>{
            const db = req.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };
        req.onsuccess = ()=>resolve(req.result);
        req.onerror = ()=>reject(req.error);
    });
}
async function idbGet(key) {
    try {
        const db = await openDB();
        return new Promise((resolve, reject)=>{
            const tx = db.transaction(STORE_NAME, "readonly");
            const store = tx.objectStore(STORE_NAME);
            const req = store.get(key);
            req.onsuccess = ()=>resolve(req.result ?? null);
            req.onerror = ()=>reject(req.error);
        });
    } catch  {
        return null;
    }
}
async function idbSet(key, value) {
    try {
        const db = await openDB();
        return new Promise((resolve, reject)=>{
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);
            store.put(value, key);
            tx.oncomplete = ()=>resolve();
            tx.onerror = ()=>reject(tx.error);
        });
    } catch  {
    // Silently fail — caching is optional
    }
}
async function idbDelete(key) {
    try {
        const db = await openDB();
        return new Promise((resolve, reject)=>{
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);
            store.delete(key);
            tx.oncomplete = ()=>resolve();
            tx.onerror = ()=>reject(tx.error);
        });
    } catch  {
    // Silently fail
    }
}
async function idbClearAll() {
    try {
        const db = await openDB();
        return new Promise((resolve, reject)=>{
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);
            store.clear();
            tx.oncomplete = ()=>resolve();
            tx.onerror = ()=>reject(tx.error);
        });
    } catch  {
    // Silently fail
    }
}


/***/ }),

/***/ 5895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5155);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/index.js
var react = __webpack_require__(2115);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 4 modules
var AnimatePresence = __webpack_require__(642);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs + 249 modules
var proxy = __webpack_require__(5909);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/compass.js
var compass = __webpack_require__(4530);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/library.js
var icons_library = __webpack_require__(7389);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/download.js
var download = __webpack_require__(6962);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/settings.js
var settings = __webpack_require__(9363);
// EXTERNAL MODULE: ./src/lib/stores.ts
var stores = __webpack_require__(9365);
// EXTERNAL MODULE: ./src/lib/file-saver-utils.ts
var file_saver_utils = __webpack_require__(285);
// EXTERNAL MODULE: ./src/lib/persistent-storage.ts
var persistent_storage = __webpack_require__(1570);
// EXTERNAL MODULE: ./node_modules/zustand/esm/react.mjs + 1 modules
var esm_react = __webpack_require__(1934);
// EXTERNAL MODULE: ./node_modules/zustand/esm/middleware.mjs
var middleware = __webpack_require__(9311);
;// ./src/lib/multi-account-store.ts
/* __next_internal_client_entry_do_not_use__ useMultiAccount,syncAccountsToServer auto */ 


const MAX_ACCOUNTS = 9;
const useMultiAccount = (0,esm_react/* create */.v)()((0,middleware/* persist */.Zr)((set, get)=>({
        accounts: [],
        activeAccountIndex: 0,
        addAccount: (account)=>set((state)=>{
                // Don't add duplicates (same username)
                if (state.accounts.some((a)=>a.username === account.username)) {
                    return state;
                }
                if (state.accounts.length >= MAX_ACCOUNTS) {
                    return state; // Max 5 accounts
                }
                return {
                    accounts: [
                        ...state.accounts,
                        account
                    ]
                };
            }),
        removeAccount: (id)=>set((state)=>({
                    accounts: state.accounts.filter((a)=>a.id !== id),
                    activeAccountIndex: 0
                })),
        clearAll: ()=>set({
                accounts: [],
                activeAccountIndex: 0
            }),
        // Round-robin: get the next token, cycling through all accounts
        getNextToken: ()=>{
            const { accounts, activeAccountIndex } = get();
            if (accounts.length === 0) return null;
            const account = accounts[activeAccountIndex % accounts.length];
            // Check if token is expired (with 5 min buffer)
            if (Date.now() > account.expiresAt - 5 * 60 * 1000) {
            // Token expired — still return it, the caller should refresh
            // For now, just return it; the server-side will handle refresh
            }
            return {
                token: account.accessToken,
                account
            };
        },
        updateAccountToken: (id, accessToken, expiresAt)=>set((state)=>({
                    accounts: state.accounts.map((a)=>a.id === id ? {
                            ...a,
                            accessToken,
                            expiresAt
                        } : a)
                })),
        rotateIndex: ()=>set((state)=>({
                    activeAccountIndex: (state.activeAccountIndex + 1) % Math.max(1, state.accounts.length)
                }))
    }), {
    name: "hfy-multi-account",
    storage: (0,middleware/* createJSONStorage */.KU)(()=>persistent_storage/* dualStorage */.KS)
}));
// Server-side account sync — sends all account tokens to the server
// so the server can use them for API calls with rotation
async function syncAccountsToServer() {
    const { accounts } = useMultiAccount.getState();
    if (accounts.length === 0) return;
    try {
        await fetch("/api/reddit-multi-token", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                accounts: accounts.map((a)=>({
                        id: a.id,
                        username: a.username,
                        accessToken: a.accessToken,
                        refreshToken: a.refreshToken,
                        expiresAt: a.expiresAt,
                        clientId: a.clientId
                    }))
            })
        });
    } catch  {
    // Server might not be running — that's OK
    }
}

// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/search.js
var search = __webpack_require__(1878);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/x.js
var x = __webpack_require__(3210);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/flame.js
var flame = __webpack_require__(7149);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/activity.js
var activity = __webpack_require__(3219);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/book-open.js
var book_open = __webpack_require__(7810);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/arrow-down-a-z.js
var arrow_down_a_z = __webpack_require__(2211);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/triangle-alert.js
var triangle_alert = __webpack_require__(1585);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/refresh-cw.js
var refresh_cw = __webpack_require__(1958);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/trash-2.js
var trash_2 = __webpack_require__(8459);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/bookmark-check.js
var bookmark_check = __webpack_require__(6519);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/bookmark.js
var bookmark = __webpack_require__(1762);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/wifi-off.js
var wifi_off = __webpack_require__(4755);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/wifi.js
var wifi = __webpack_require__(3035);
;// ./src/components/cyber/SeriesIcons.tsx
/* __next_internal_client_entry_do_not_use__ SeriesIcons,WikiIcon auto */ 
function SeriesIcons({ isHardcoded, hfyFoundationUrl, wikiUrl, ssbWikiUrl, isFetched, size = 14 }) {
    const hasGlobe = !!hfyFoundationUrl;
    const hasSkull = !!wikiUrl;
    const hasHeart = !!ssbWikiUrl;
    const hasBlueSword = !!isHardcoded;
    const hasRedSword = !!isFetched && !isHardcoded;
    const iconStyle = (active)=>({
            width: size,
            height: size,
            opacity: active ? 1 : 0.2,
            filter: active ? "none" : "grayscale(1) brightness(0.5)",
            transition: "opacity 0.2s, filter 0.2s"
        });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center gap-0.5",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                src: "/icon-sword-blue-24.png",
                alt: "hardcoded",
                title: hasBlueSword ? "Hardcoded series" : "Not hardcoded",
                style: iconStyle(hasBlueSword),
                draggable: false
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                src: "/icon-globe-24.png",
                alt: "hfy-foundation",
                title: hasGlobe ? "HFY Foundation wiki" : "No HFY Foundation wiki",
                style: iconStyle(hasGlobe),
                draggable: false
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                src: "/icon-skull-24.png",
                alt: "r-hfy-wiki",
                title: hasSkull ? "r/HFY wiki" : "No r/HFY wiki",
                style: iconStyle(hasSkull),
                draggable: false
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                src: "/icon-heart-24.png",
                alt: "ssb-wiki",
                title: hasHeart ? "r/Sexyspacebabes wiki" : "No SSB wiki",
                style: iconStyle(hasHeart),
                draggable: false
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("img", {
                src: "/icon-sword-red-24.png",
                alt: "fetched",
                title: hasRedSword ? "Fetched live" : "Not fetched live",
                style: iconStyle(hasRedSword),
                draggable: false
            })
        ]
    });
}
/**
 * WikiIcon — single PNG icon for use in series detail header buttons.
 * kind: "wiki" (skull), "hfy-foundation" (globe), "ssb" (heart)
 */ function WikiIcon({ kind, size = 14, active = true }) {
    const src = kind === "wiki" ? "/icon-skull-24.png" : kind === "hfy-foundation" ? "/icon-globe-24.png" : "/icon-heart-24.png";
    return /*#__PURE__*/ _jsx("img", {
        src: src,
        alt: kind,
        style: {
            width: size,
            height: size,
            opacity: active ? 1 : 0.4,
            filter: active ? "none" : "grayscale(0.5) brightness(0.7)"
        },
        draggable: false
    });
}

// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(9722);
// EXTERNAL MODULE: ./node_modules/tailwind-merge/dist/bundle-mjs.mjs
var bundle_mjs = __webpack_require__(622);
;// ./src/lib/utils.ts


function cn(...inputs) {
    return (0,bundle_mjs/* twMerge */.QP)((0,clsx/* clsx */.$)(inputs));
}

;// ./src/components/cyber/CyberPanel.tsx
/* __next_internal_client_entry_do_not_use__ CyberPanel auto */ 


function CyberPanel({ children, className, glow = false, accent, active = false, style, onClick }) {
    const appTheme = (0,stores.useSettings)((s)=>s.appTheme);
    const glowIntensity = (0,stores.useSettings)((s)=>s.glowIntensity);
    const theme = stores/* APP_THEMES */.Zd[appTheme];
    const accentColor = accent ?? theme.primary;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        onClick: onClick,
        className: cn("relative bg-[#0a0d12]/90 backdrop-blur-sm", "border border-l-2", "transition-all duration-200", active && "scale-[1.01]", className),
        style: {
            borderColor: `${accentColor}55`,
            borderLeftColor: accentColor,
            clipPath: "polygon(0 0, calc(100% - 14px) 0, 100% 14px, 100% 100%, 14px 100%, 0 calc(100% - 14px))",
            boxShadow: glow ? `0 0 ${10 * glowIntensity}px ${accentColor}55, inset 0 0 ${20 * glowIntensity}px ${accentColor}11` : active ? `inset 0 0 20px ${accentColor}22` : "inset 0 0 0 1px #ffffff05",
            ...style
        },
        children: [
            active && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(CornerBracket, {
                        position: "tl",
                        color: accentColor
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(CornerBracket, {
                        position: "tr",
                        color: accentColor
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(CornerBracket, {
                        position: "bl",
                        color: accentColor
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)(CornerBracket, {
                        position: "br",
                        color: accentColor
                    })
                ]
            }),
            children
        ]
    });
}
function CornerBracket({ position, color }) {
    const pos = {
        tl: {
            top: -2,
            left: -2,
            borderTop: `2px solid ${color}`,
            borderLeft: `2px solid ${color}`
        },
        tr: {
            top: -2,
            right: -2,
            borderTop: `2px solid ${color}`,
            borderRight: `2px solid ${color}`
        },
        bl: {
            bottom: -2,
            left: -2,
            borderBottom: `2px solid ${color}`,
            borderLeft: `2px solid ${color}`
        },
        br: {
            bottom: -2,
            right: -2,
            borderBottom: `2px solid ${color}`,
            borderRight: `2px solid ${color}`
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "absolute w-3 h-3 pointer-events-none",
        style: pos[position]
    });
}

;// ./src/components/cyber/CyberButton.tsx
/* __next_internal_client_entry_do_not_use__ CyberButton auto */ 


function CyberButton({ variant = "primary", size = "md", children, className, style, ...props }) {
    const appTheme = (0,stores.useSettings)((s)=>s.appTheme);
    const glowIntensity = (0,stores.useSettings)((s)=>s.glowIntensity);
    const theme = stores/* APP_THEMES */.Zd[appTheme];
    const variants = {
        primary: {
            bg: `${theme.primary}1a`,
            color: theme.primary,
            border: theme.primary,
            glow: `0 0 ${10 * glowIntensity}px ${theme.primary}66`
        },
        ghost: {
            bg: "transparent",
            color: "#9ca3af",
            border: "#374151",
            glow: "none"
        },
        danger: {
            bg: "#ff003c1a",
            color: "#ff003c",
            border: "#ff003c",
            glow: `0 0 ${10 * glowIntensity}px #ff003c66`
        },
        outline: {
            bg: "transparent",
            color: theme.accent,
            border: `${theme.accent}88`,
            glow: "none"
        }
    };
    const sizes = {
        sm: "px-2 py-1 text-xs",
        md: "px-3 py-2 text-sm",
        lg: "px-5 py-3 text-base"
    };
    const v = variants[variant];
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
        ...props,
        className: cn("relative font-mono uppercase tracking-wider font-bold", "transition-all duration-150 hover:scale-[1.02] active:scale-[0.98]", "disabled:opacity-40 disabled:pointer-events-none", sizes[size], className),
        style: {
            background: v.bg,
            color: v.color,
            border: `1px solid ${v.border}`,
            clipPath: "polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 8px 100%, 0 calc(100% - 8px))",
            boxShadow: v.glow,
            ...style
        },
        children: children
    });
}

;// ./src/components/cyber/CyberTag.tsx
/* __next_internal_client_entry_do_not_use__ CyberTag auto */ 

function CyberTag({ children, color = "#00FFF0", className, style }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
        className: cn("inline-block px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest font-bold", className),
        style: {
            color,
            background: `${color}1a`,
            border: `1px solid ${color}55`,
            clipPath: "polygon(0 0, calc(100% - 4px) 0, 100% 100%, 4px 100%)",
            ...style
        },
        children: children
    });
}

;// ./src/lib/colors.ts
// Shared color palette + hash function for per-series accent colors.
// Using a hash of the series ID ensures each series ALWAYS gets the same
// color, regardless of list position, filtering, or sort order.
const ACCENTS = [
    "#FF003C",
    "#00FFF0",
    "#FFE600",
    "#FF7700",
    "#9D00FF",
    "#00FF88",
    "#00BFFF",
    "#FF1493",
    "#ADFF2F",
    "#FFD700",
    "#FF4500",
    "#8A2BE2",
    "#39FF14",
    "#FF69B4",
    "#00CED1",
    "#FFA500"
];
/**
 * Deterministic hash of a string → uint32.
 */ function hashStr(s) {
    let h = 0;
    for(let i = 0; i < s.length; i++){
        h = Math.imul(31, h) + s.charCodeAt(i) | 0;
    }
    return Math.abs(h);
}
/**
 * Get a consistent accent color for a series based on its ID.
 * The same series ID always returns the same color.
 */ function getSeriesAccent(seriesId) {
    return ACCENTS[hashStr(seriesId) % ACCENTS.length];
}
/**
 * Get all accent colors (for reference / palette display).
 */ function getAllAccents() {
    return ACCENTS;
}

;// ./src/lib/hfy-data.ts
// HFY NEKROCODEXXX — Series catalog (auto-generated from merged_chapters.json)
// 5533 series with wiki URLs + HFY Foundation URLs.
const REAL_SERIES = [
    {
        id: "10_mistakes_to_kill_the_universe",
        title: "10 Mistakes to Kill the Universe",
        author: "Drakenwing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/10_mistakes_to_kill_the_universe",
        hfyFoundationUrl: "https://hfy.foundation/series/947",
        chapterCount: 6
    },
    {
        id: "12_days_to_mars",
        title: "12 Days To Mars",
        author: "startingtomorrow2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/12_days_to_mars",
        hfyFoundationUrl: "https://hfy.foundation/series/1548",
        chapterCount: 6
    },
    {
        id: "476000",
        title: "476000",
        author: "FormerCat4883",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/476000",
        hfyFoundationUrl: "https://hfy.foundation/series/3916",
        chapterCount: 9
    },
    {
        id: "5_stories_of_heroic_humans_saving_people",
        title: "5 stories of heroic humans saving people!",
        author: "Hellskitchensink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/five_stories_of_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/890",
        chapterCount: 6
    },
    {
        id: "the_501st_mind_games",
        title: "The 501st Mind Games",
        author: "MonkeyPoopey",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_501st_mind_games",
        hfyFoundationUrl: "https://hfy.foundation/series/266",
        chapterCount: 8
    },
    {
        id: "abandoned_space",
        title: "Abandoned Space",
        author: "croatianspy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/abandoned_space",
        hfyFoundationUrl: "https://hfy.foundation/series/2300",
        chapterCount: 6
    },
    {
        id: "abducting_a_human_s_mate_is_a_bad_idea",
        title: "Abducting A Human's Mate Is A Bad Idea",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/abducting_a_humans_mate_is_a_bad_idea",
        hfyFoundationUrl: "https://hfy.foundation/series/4316",
        chapterCount: 4
    },
    {
        id: "abduction",
        title: "Abduction",
        author: "Niveker14",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/abduction",
        hfyFoundationUrl: "https://hfy.foundation/series/2580",
        chapterCount: 32
    },
    {
        id: "aberrant",
        title: "Aberrant",
        author: "Mister-Book",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aberrant",
        hfyFoundationUrl: "https://hfy.foundation/series/230",
        chapterCount: 2
    },
    {
        id: "aberration",
        title: "Aberration",
        author: "Frostdraken",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aberration",
        hfyFoundationUrl: "https://hfy.foundation/series/4923",
        chapterCount: 12
    },
    {
        id: "absence_makes_the_heart",
        title: "Absence Makes The Heart...",
        author: "MachDhai",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/absence_makes_the_heart",
        hfyFoundationUrl: "https://hfy.foundation/series/1474",
        chapterCount: 5
    },
    {
        id: "the_academy",
        title: "The Academy",
        author: "otq88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_academy",
        hfyFoundationUrl: "https://hfy.foundation/series/41",
        chapterCount: 20
    },
    {
        id: "accidental_warlock",
        title: "Accidental Warlock",
        author: "Zagreus777",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/accidental_warlock",
        hfyFoundationUrl: "https://hfy.foundation/series/3762",
        chapterCount: 8
    },
    {
        id: "accidentally_a_dungeon",
        title: "Accidentally A Dungeon",
        author: "Calypthea",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/accidentally_a_dungeon",
        hfyFoundationUrl: "https://hfy.foundation/series/4835",
        chapterCount: 34
    },
    {
        id: "accidentally_adopted",
        title: "Accidentally Adopted",
        author: "TheCurserHasntMoved",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/accidentally_adopted",
        hfyFoundationUrl: "https://hfy.foundation/series/4762",
        chapterCount: 75
    },
    {
        id: "across_the_expanse",
        title: "Across the Expanse",
        author: "grierks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/across_the_expanse",
        hfyFoundationUrl: "https://hfy.foundation/series/829",
        chapterCount: 50
    },
    {
        id: "adonis",
        title: "Adonis",
        author: "WingAutarch",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adonis",
        hfyFoundationUrl: "https://hfy.foundation/series/282",
        chapterCount: 2
    },
    {
        id: "adrenaline",
        title: "Adrenaline",
        author: "Niedski",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adrenaline",
        hfyFoundationUrl: "https://hfy.foundation/series/903",
        chapterCount: 5
    },
    {
        id: "adrift",
        title: "Adrift",
        author: "AdventurerOfTheStars",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adrift",
        hfyFoundationUrl: "https://hfy.foundation/series/4284",
        chapterCount: 3
    },
    {
        id: "adventure",
        title: "Adventure",
        author: "XSevenSins",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adventure",
        hfyFoundationUrl: "https://hfy.foundation/series/2581",
        chapterCount: 53
    },
    {
        id: "adventures_of_a_mercenary_with_a_tomahawk",
        title: "Adventures of a Mercenary with a tomahawk",
        author: "Michal_Riley",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adventures_of_a_mercenary_with_a_tomahawk",
        hfyFoundationUrl: "https://hfy.foundation/series/379",
        chapterCount: 7
    },
    {
        id: "the_adventures_of_coring_affidilius",
        title: "The Adventures of Coring Affidilius",
        author: "SirNevermore",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_adventures_of_coring_affidilius",
        hfyFoundationUrl: "https://hfy.foundation/series/228",
        chapterCount: 8
    },
    {
        id: "the_adventures_of_iron_hue_man",
        title: "The Adventures of Iron Hue-Man",
        author: "Frank_Leroux",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_adventures_of_iron_hueman",
        hfyFoundationUrl: "https://hfy.foundation/series/1157",
        chapterCount: 41
    },
    {
        id: "adventures_with_an_interdimensional_psychopath",
        title: "Adventures With An Interdimensional Psychopath",
        author: "WabbajackedWacko",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adventures_with_an_interdimensional_psychopath",
        hfyFoundationUrl: "https://hfy.foundation/series/5301",
        chapterCount: 69
    },
    {
        id: "adversor_et_admorsus",
        title: "Adversor Et Admorsus",
        author: "Cysanic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adversor_et_admorsus",
        hfyFoundationUrl: "https://hfy.foundation/series/1483",
        chapterCount: 3
    },
    {
        id: "again",
        title: "Again",
        author: "ArcAngel98",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/again",
        hfyFoundationUrl: "https://hfy.foundation/series/3017",
        chapterCount: 3
    },
    {
        id: "age_of_aquarius",
        title: "Age Of Aquarius",
        author: "Starstuffdrifter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/age_of_aquarius",
        hfyFoundationUrl: "https://hfy.foundation/series/3099",
        chapterCount: 12
    },
    {
        id: "air_too_pure",
        title: "Air Too Pure",
        author: "jamescoxall",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/air_too_pure",
        hfyFoundationUrl: "https://hfy.foundation/series/2726",
        chapterCount: 3
    },
    {
        id: "the_alcatraz_hypothesis",
        title: "The Alcatraz Hypothesis",
        author: "Trashgoddess",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_alcatraz_hypothesis",
        hfyFoundationUrl: "https://hfy.foundation/series/422",
        chapterCount: 2
    },
    {
        id: "alchimia_rex",
        title: "Alchimia Rex",
        author: "RavniTrappedInANovel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alchimia_rex",
        hfyFoundationUrl: "https://hfy.foundation/series/4347",
        chapterCount: 30
    },
    {
        id: "alcubierre",
        title: "Alcubierre",
        author: "PerilousPlatypus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alcubierre",
        hfyFoundationUrl: "https://hfy.foundation/series/1690",
        chapterCount: 44
    },
    {
        id: "alien_crash",
        title: "Alien Crash",
        author: "spindizzy_wizard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alien_crash",
        hfyFoundationUrl: "https://hfy.foundation/series/2025",
        chapterCount: 55
    },
    {
        id: "an_alien_in_appalachia",
        title: "An Alien In Appalachia",
        author: "Traditional\\_wolf\\_007",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_alien_in_appalachia",
        hfyFoundationUrl: "https://hfy.foundation/series/5157",
        chapterCount: 16
    },
    {
        id: "alien_nation",
        title: "Alien-nation",
        author: "SSBSubjugation",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aliennation",
        hfyFoundationUrl: "https://hfy.foundation/series/2631",
        chapterCount: 200
    },
    {
        id: "aliens_and_magic",
        title: "Aliens And Magic",
        author: "jamescsmithLW",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aliens_and_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/2718",
        chapterCount: 3
    },
    {
        id: "all_his_angels_are_starving",
        title: "All His Angels Are Starving",
        author: "countingfoxes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_his_angels_are_starving",
        hfyFoundationUrl: "https://hfy.foundation/series/5002",
        chapterCount: 4
    },
    {
        id: "all_humans_are_dead",
        title: "All Humans Are Dead",
        author: "Few-True-Coyote",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_humans_are_dead",
        hfyFoundationUrl: "https://hfy.foundation/series/3066",
        chapterCount: 39
    },
    {
        id: "all_out_of_bubblegum",
        title: "All Out of Bubblegum",
        author: "Hope-for-hopeless",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_out_of_bubblegum",
        hfyFoundationUrl: "https://hfy.foundation/series/2657",
        chapterCount: 3
    },
    {
        id: "all_sapiens_go_to_heaven",
        title: "All Sapiens Go To Heaven",
        author: "colie_o",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_sapiens_go_to_heaven",
        hfyFoundationUrl: "https://hfy.foundation/series/521",
        chapterCount: 39
    },
    {
        id: "all_the_flowers_are_over_the_stars",
        title: "All The Flowers Are Over The Stars",
        author: "Not_Omegon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_the_flowers_are_over_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/3195",
        chapterCount: 73
    },
    {
        id: "all_the_little_lost_boys_and_girls",
        title: "All The Little Lost Boys And Girls",
        author: "Proximal\\_Flame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_the_little_lost_boys_and_girls",
        hfyFoundationUrl: "https://hfy.foundation/series/1468",
        chapterCount: 24
    },
    {
        id: "all_s_well",
        title: "All's Well",
        author: "dinnbach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alls_well",
        hfyFoundationUrl: "https://hfy.foundation/series/265",
        chapterCount: 3
    },
    {
        id: "alone_in_the_void",
        title: "Alone in the void",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alone_in_the_void",
        hfyFoundationUrl: "https://hfy.foundation/series/692",
        chapterCount: 39
    },
    {
        id: "alone",
        title: "Alone",
        author: "Carefulrogue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alone",
        hfyFoundationUrl: "https://hfy.foundation/series/810",
        chapterCount: 4
    },
    {
        id: "alone_2",
        title: "Alone",
        author: "EternalCanadian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alone_eternalcanadian",
        hfyFoundationUrl: "https://hfy.foundation/series/1423",
        chapterCount: 4
    },
    {
        id: "alternative_perspectives",
        title: "Alternative Perspectives",
        author: "ArmouredCadian",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/alternative_perspectives",
        hfyFoundationUrl: "https://hfy.foundation/series/3818",
        chapterCount: 7
    },
    {
        id: "the_ambassador",
        title: "The Ambassador",
        author: "SomethingTouchesBack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ambassador",
        hfyFoundationUrl: "https://hfy.foundation/series/3588",
        chapterCount: 20
    },
    {
        id: "ambere_chronicles",
        title: "Ambere Chronicles",
        author: "Kaelani_Wanderer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ambere_chronicles",
        hfyFoundationUrl: "https://hfy.foundation/series/5216",
        chapterCount: 14
    },
    {
        id: "the_ambling_sapient",
        title: "The Ambling Sapient",
        author: "Cognomifex",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ambling_sapient",
        hfyFoundationUrl: "https://hfy.foundation/series/2319",
        chapterCount: 7
    },
    {
        id: "amelia_the_level_zero_hero",
        title: "Amelia: The Level Zero [Hero]",
        author: "Hero",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/amelia_the_level_zero_hero",
        hfyFoundationUrl: "https://hfy.foundation/series/4517",
        chapterCount: 28
    },
    {
        id: "amelias_last_battle",
        title: "Amelias Last Battle",
        author: "CherubielOne",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/amelias_last_battle",
        hfyFoundationUrl: "https://hfy.foundation/series/1957",
        chapterCount: 5
    },
    {
        id: "anchors_of_war",
        title: "Anchors of War",
        author: "MaximumTrekkie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/anchors_of_war",
        hfyFoundationUrl: "https://hfy.foundation/series/888",
        chapterCount: 17
    },
    {
        id: "an_ancient_civilization",
        title: "An Ancient Civilization",
        author: "shibbster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_ancient_civilization",
        hfyFoundationUrl: "https://hfy.foundation/series/2678",
        chapterCount: 20
    },
    {
        id: "ancient_strategy",
        title: "Ancient Strategy",
        author: "jormundr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ancient_strategy",
        hfyFoundationUrl: "https://hfy.foundation/series/2331",
        chapterCount: 50
    },
    {
        id: "the_ancient_s_animosity",
        title: "The Ancient's Animosity",
        author: "Ceramic_Boi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ancients_animosity",
        hfyFoundationUrl: "https://hfy.foundation/series/5250",
        chapterCount: 21
    },
    {
        id: "the_ancients",
        title: "The Ancients",
        author: "lordatamus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ancients",
        hfyFoundationUrl: "https://hfy.foundation/series/1036",
        chapterCount: 8
    },
    {
        id: "and_not_a_drop_to_drink",
        title: "And Not A Drop To Drink",
        author: "AnonymousEmActual",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/and_not_a_drop_to_drink",
        hfyFoundationUrl: "https://hfy.foundation/series/1746",
        chapterCount: 3
    },
    {
        id: "and_then_it_burned",
        title: "And Then It Burned",
        author: "Toah14",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/and_then_it_burned",
        hfyFoundationUrl: "https://hfy.foundation/series/110",
        chapterCount: 4
    },
    {
        id: "an_angel_s_retirement",
        title: "An Angel's Retirement",
        author: "Obsequium_Minaris",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_angels_retirement",
        hfyFoundationUrl: "https://hfy.foundation/series/5537",
        chapterCount: 27
    },
    {
        id: "of_anger_and_magic",
        title: "Of Anger And Magic",
        author: "adam-teashaw",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/of_anger_and_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/3044",
        chapterCount: 40
    },
    {
        id: "the_answer",
        title: "The Answer?",
        author: "UndercoverGrapefruit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_answer",
        hfyFoundationUrl: "https://hfy.foundation/series/629",
        chapterCount: 3
    },
    {
        id: "apes",
        title: "Apes",
        author: "LordHenry7898",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/apes",
        hfyFoundationUrl: "https://hfy.foundation/series/1876",
        chapterCount: 17
    },
    {
        id: "apparatus_psychology",
        title: "Apparatus Psychology",
        author: "HidnFox",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/apparatus_psychology",
        hfyFoundationUrl: "https://hfy.foundation/series/1976",
        chapterCount: 5
    },
    {
        id: "arcane_blacksmith",
        title: "Arcane Blacksmith",
        author: "Few_Fee3331",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/arcane_blacksmith",
        hfyFoundationUrl: "https://hfy.foundation/series/4462",
        chapterCount: 5
    },
    {
        id: "the_arcane_paladin",
        title: "The Arcane Paladin",
        author: "Degermark",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_arcane_paladin",
        hfyFoundationUrl: "https://hfy.foundation/series/4000",
        chapterCount: 84
    },
    {
        id: "archangel",
        title: "Archangel",
        author: "deathB4dessert",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/archangel",
        hfyFoundationUrl: "https://hfy.foundation/series/4533",
        chapterCount: 18
    },
    {
        id: "archeology",
        title: "Archeology",
        author: "TexWolf84",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/archeology",
        hfyFoundationUrl: "https://hfy.foundation/series/2739",
        chapterCount: 27
    },
    {
        id: "the_ardhen_dynasty",
        title: "The Ardhen Dynasty",
        author: "asean_goose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ardhen_dynasty",
        hfyFoundationUrl: "https://hfy.foundation/series/5498",
        chapterCount: 6
    },
    {
        id: "arena",
        title: "Arena",
        author: "JJdaJet",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/arena",
        hfyFoundationUrl: "https://hfy.foundation/series/377",
        chapterCount: 16
    },
    {
        id: "arete",
        title: "Arete",
        author: "Samponglass",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/arete",
        hfyFoundationUrl: "https://hfy.foundation/series/699",
        chapterCount: 2
    },
    {
        id: "the_armored_terran",
        title: "The Armored Terran",
        author: "Holiday-Possible29",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_armored_terran",
        hfyFoundationUrl: "https://hfy.foundation/series/4985",
        chapterCount: 46
    },
    {
        id: "ars_magica",
        title: "Ars Magica",
        author: "AvidSeason",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ars_magica",
        hfyFoundationUrl: "https://hfy.foundation/series/2248",
        chapterCount: 94
    },
    {
        id: "aryan",
        title: "Aryan",
        author: "Demicritus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aryan",
        hfyFoundationUrl: "https://hfy.foundation/series/99",
        chapterCount: 3
    },
    {
        id: "ascension",
        title: "Ascension",
        author: "Akmedrah",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ascension",
        hfyFoundationUrl: "https://hfy.foundation/series/4066",
        chapterCount: 30
    },
    {
        id: "ascension_dungeon",
        title: "Ascension&Dungeon",
        author: "TheOragiochi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ascensiondungeon",
        hfyFoundationUrl: "https://hfy.foundation/series/4315",
        chapterCount: 12
    },
    {
        id: "the_ascension_of_humanity",
        title: "The Ascension Of Humanity",
        author: "Dinomyar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ascension_of_humanity",
        hfyFoundationUrl: "https://hfy.foundation/series/1515",
        chapterCount: 8
    },
    {
        id: "ascendance_protocol",
        title: "Ascendance Protocol",
        author: "KingChillah",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ascendance_protocol",
        hfyFoundationUrl: "https://hfy.foundation/series/220",
        chapterCount: 8
    },
    {
        id: "the_ascendant",
        title: "The Ascendant",
        author: "Le\\_Grim",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ascendant",
        hfyFoundationUrl: "https://hfy.foundation/series/2680",
        chapterCount: 15
    },
    {
        id: "ascent",
        title: "Ascent",
        author: "TheUtilitaria",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ascent",
        hfyFoundationUrl: "https://hfy.foundation/series/1197",
        chapterCount: 25
    },
    {
        id: "ashenvale",
        title: "Ashenvale",
        author: "BattleSneeze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ashenvale",
        hfyFoundationUrl: "https://hfy.foundation/series/476",
        chapterCount: 32
    },
    {
        id: "the_asimov",
        title: "The Asimov",
        author: "shoguncdn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_asimov",
        hfyFoundationUrl: "https://hfy.foundation/series/278",
        chapterCount: 8
    },
    {
        id: "assigned_a_savage",
        title: "Assigned A Savage",
        author: "ShouldICareReallyNow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/assigned_a_savage",
        hfyFoundationUrl: "https://hfy.foundation/series/3121",
        chapterCount: 21
    },
    {
        id: "at_least_it_can_t_get_worse",
        title: "At Least It Can't Get Worse",
        author: "equatorialbaconstrip",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/at_least_it_cant_get_worse",
        hfyFoundationUrl: "https://hfy.foundation/series/1216",
        chapterCount: 36
    },
    {
        id: "at_the_precipice",
        title: "At The Precipice",
        author: "KodoKodo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/at_the_precipice",
        hfyFoundationUrl: "https://hfy.foundation/series/3507",
        chapterCount: 19
    },
    {
        id: "the_auction",
        title: "The Auction",
        author: "Abramus5250",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_auction",
        hfyFoundationUrl: "https://hfy.foundation/series/1215",
        chapterCount: 10
    },
    {
        id: "autolycus",
        title: "Autolycus",
        author: "cazz14159",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/autolycus",
        hfyFoundationUrl: "https://hfy.foundation/series/295",
        chapterCount: 2
    },
    {
        id: "the_autumn_of_yggdrasil",
        title: "The Autumn Of Yggdrasil",
        author: "SomethingaboutRNG",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_autumn_of_yggdrasil",
        hfyFoundationUrl: "https://hfy.foundation/series/4386",
        chapterCount: 17
    },
    {
        id: "avada",
        title: "Avada",
        author: "WeaverofW0rlds",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/avada",
        hfyFoundationUrl: "https://hfy.foundation/series/5269",
        chapterCount: 5
    },
    {
        id: "a_bad_first_contact",
        title: "A Bad First Contact",
        author: "Sanctusmorti",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_bad_first_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/1135",
        chapterCount: 2
    },
    {
        id: "balance_of_power",
        title: "Balance of Power",
        author: "JackFragg",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/balance_of_power",
        hfyFoundationUrl: "https://hfy.foundation/series/340",
        chapterCount: 2
    },
    {
        id: "balinski_katars_the_void_warden",
        title: "Balinski Katars: The Void Warden",
        author: "Frostdraken",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/balinski_katars_the_void_warden",
        hfyFoundationUrl: "https://hfy.foundation/series/3815",
        chapterCount: 19
    },
    {
        id: "barbarians",
        title: "Barbarians",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/barbarians",
        hfyFoundationUrl: "https://hfy.foundation/series/1449",
        chapterCount: 33
    },
    {
        id: "the_barbarian_betrayal",
        title: "The Barbarian Betrayal",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_barbarian_betrayal",
        hfyFoundationUrl: "https://hfy.foundation/series/1842",
        chapterCount: 48
    },
    {
        id: "barca_aboard_the_carthage",
        title: "Barca aboard the Carthage",
        author: "The_Magnificent_Man",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/barca_aboard_the_carthage",
        hfyFoundationUrl: "https://hfy.foundation/series/604",
        chapterCount: 7
    },
    {
        id: "bathroom_adventures",
        title: "Bathroom Adventures",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bathroom_adventures",
        hfyFoundationUrl: "https://hfy.foundation/series/843",
        chapterCount: 15
    },
    {
        id: "the_battle_of_jupiter",
        title: "The Battle of Jupiter",
        author: "Jalapenyobuisness",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_battle_of_jupiter",
        hfyFoundationUrl: "https://hfy.foundation/series/196",
        chapterCount: 2
    },
    {
        id: "the_battle_of_xelgarath",
        title: "The Battle of Xelgarath",
        author: "iamzalgo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_battle_of_xelgarath",
        hfyFoundationUrl: "https://hfy.foundation/series/31",
        chapterCount: 5
    },
    {
        id: "the_barbarian_war",
        title: "The Barbarian War",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_barbarian_war",
        hfyFoundationUrl: "https://hfy.foundation/series/1572",
        chapterCount: 45
    },
    {
        id: "the_beacon",
        title: "The Beacon",
        author: "Panther_1979",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_beacon",
        hfyFoundationUrl: "https://hfy.foundation/series/5315",
        chapterCount: 48
    },
    {
        id: "beast",
        title: "Beast",
        author: "jakethesnakebakecake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beast",
        hfyFoundationUrl: "https://hfy.foundation/series/194",
        chapterCount: 64
    },
    {
        id: "the_beast",
        title: "The Beast",
        author: "Salooin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_beast",
        hfyFoundationUrl: "https://hfy.foundation/series/3074",
        chapterCount: 55
    },
    {
        id: "the_beast_shaper",
        title: "The Beast Shaper",
        author: "Frame_Late",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_beast_shaper",
        hfyFoundationUrl: "https://hfy.foundation/series/5280",
        chapterCount: 3
    },
    {
        id: "beast_world",
        title: "Beast World",
        author: "D0WNGR4D3",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beast_world",
        hfyFoundationUrl: "https://hfy.foundation/series/3898",
        chapterCount: 62
    },
    {
        id: "beat_em_to_hell",
        title: "Beat 'Em To Hell",
        author: "deus_x_machin4",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beat_em_to_hell",
        hfyFoundationUrl: "https://hfy.foundation/series/1316",
        chapterCount: 4
    },
    {
        id: "because_it_s_there",
        title: "Because It's There",
        author: "AndaBrit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/because_its_there",
        hfyFoundationUrl: "https://hfy.foundation/series/623",
        chapterCount: 2
    },
    {
        id: "because_someone_had_to",
        title: "Because Someone Had To",
        author: "MachDhai",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/because_someone_had_to",
        hfyFoundationUrl: "https://hfy.foundation/series/1283",
        chapterCount: 10
    },
    {
        id: "beatdown_station",
        title: "Beatdown station",
        author: "Mascadon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beatdown_station",
        hfyFoundationUrl: "https://hfy.foundation/series/840",
        chapterCount: 3
    },
    {
        id: "the_belts",
        title: "The Belts",
        author: "Juz16",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_belts",
        hfyFoundationUrl: "https://hfy.foundation/series/46",
        chapterCount: 2
    },
    {
        id: "the_best_defense_one_giant_leap",
        title: "The Best Defense: One Giant Leap",
        author: "OGNovelNinja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_best_defense_one_giant_leap",
        hfyFoundationUrl: "https://hfy.foundation/series/4303",
        chapterCount: 12
    },
    {
        id: "the_best_laid_plans",
        title: "The Best Laid Plans",
        author: "Unit_ZER0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_best_laid_plans",
        hfyFoundationUrl: "https://hfy.foundation/series/2087",
        chapterCount: 11
    },
    {
        id: "the_bestiary_of_earth",
        title: "The Bestiary of Earth",
        author: "Aerowatcher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bestiary_of_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/210",
        chapterCount: 20
    },
    {
        id: "the_betting_kind",
        title: "The Betting Kind",
        author: "kaidevis",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_betting_kind",
        hfyFoundationUrl: "https://hfy.foundation/series/178",
        chapterCount: 2
    },
    {
        id: "between_the_black_and_gray",
        title: "Between The Black And Gray",
        author: "jpitha",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/between_the_black_and_gray",
        hfyFoundationUrl: "https://hfy.foundation/series/5502",
        chapterCount: 13
    },
    {
        id: "beyond_the_veil",
        title: "Beyond The Veil",
        author: "SWAT_Omega",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beyond_the_veil",
        hfyFoundationUrl: "https://hfy.foundation/series/4199",
        chapterCount: 12
    },
    {
        id: "beyond_the_void",
        title: "Beyond The Void",
        author: "SpacePaladin15",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beyond_the_void",
        hfyFoundationUrl: "https://hfy.foundation/series/3232",
        chapterCount: 9
    },
    {
        id: "big_damned_heros",
        title: "Big Damned Heros",
        author: "Blackknight64",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/big_damned_heros",
        hfyFoundationUrl: "https://hfy.foundation/series/373",
        chapterCount: 5
    },
    {
        id: "big_game",
        title: "Big Game",
        author: "slice_of_pi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/big_game",
        hfyFoundationUrl: "https://hfy.foundation/series/785",
        chapterCount: 30
    },
    {
        id: "big_trouble_in_little_universe",
        title: "Big Trouble In Little Universe",
        author: "Grimpatron619",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/big_trouble_in_little_universe",
        hfyFoundationUrl: "https://hfy.foundation/series/2451",
        chapterCount: 8
    },
    {
        id: "bird_of_prey",
        title: "Bird Of Prey",
        author: "IAmTheOutsider",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bird_of_prey",
        hfyFoundationUrl: "https://hfy.foundation/series/4392",
        chapterCount: 21
    },
    {
        id: "bismarck_resurfaced",
        title: "Bismarck: Resurfaced",
        author: "Admiral_Naehum",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bismarck_resurfaced",
        hfyFoundationUrl: "https://hfy.foundation/series/1799",
        chapterCount: 8
    },
    {
        id: "the_black",
        title: "The Black",
        author: "PropRatActual",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_black",
        hfyFoundationUrl: "https://hfy.foundation/series/5220",
        chapterCount: 102
    },
    {
        id: "blacklisted",
        title: "Blacklisted",
        author: "WaveOfWire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/blacklisted",
        hfyFoundationUrl: "https://hfy.foundation/series/5408",
        chapterCount: 21
    },
    {
        id: "the_bleating_assassin",
        title: "The Bleating Assassin",
        author: "Goatcination",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bleating_assassin",
        hfyFoundationUrl: "https://hfy.foundation/series/368",
        chapterCount: 16
    },
    {
        id: "the_bleeding_edge",
        title: "The Bleeding Edge",
        author: "TheEnduringKaze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bleeding_edge",
        hfyFoundationUrl: "https://hfy.foundation/series/1757",
        chapterCount: 20
    },
    {
        id: "blessed_are_the_simple",
        title: "Blessed are the Simple",
        author: "naturalpinkflamingo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/blessed_are_the_simple",
        hfyFoundationUrl: "https://hfy.foundation/series/5596",
        chapterCount: 47
    },
    {
        id: "blip",
        title: "Blip!",
        author: "Nanoprober",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/blip",
        hfyFoundationUrl: "https://hfy.foundation/series/238",
        chapterCount: 2
    },
    {
        id: "blood_and_bandages",
        title: "Blood And Bandages",
        author: "Vivid-Membership3959",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/blood_and_bandages",
        hfyFoundationUrl: "https://hfy.foundation/series/5504",
        chapterCount: 21
    },
    {
        id: "of_blood_and_stardust",
        title: "Of Blood And Stardust",
        author: "The_Yorkshire_Shadow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/of_blood_and_stardust",
        hfyFoundationUrl: "https://hfy.foundation/series/4207",
        chapterCount: 14
    },
    {
        id: "blood_and_waffles",
        title: "Blood And Waffles",
        author: "clivecummings",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/blood_and_waffles",
        hfyFoundationUrl: "https://hfy.foundation/series/1131",
        chapterCount: 7
    },
    {
        id: "the_blood_of_my_enemy_s_foe",
        title: "The Blood of my Enemy's Foe",
        author: "wer66",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_blood_of_my_enemys_foe",
        hfyFoundationUrl: "https://hfy.foundation/series/563",
        chapterCount: 5
    },
    {
        id: "bloodclaw_chronicles",
        title: "Bloodclaw Chronicles",
        author: "Tempest029",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bloodclaw_chronicles",
        hfyFoundationUrl: "https://hfy.foundation/series/3424",
        chapterCount: 35
    },
    {
        id: "bloodrunners",
        title: "Bloodrunners",
        author: "semiloki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bloodrunners",
        hfyFoundationUrl: "https://hfy.foundation/series/696",
        chapterCount: 7
    },
    {
        id: "the_bloody_price",
        title: "The Bloody Price",
        author: "LRKnight_writing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bloody_price",
        hfyFoundationUrl: "https://hfy.foundation/series/3191",
        chapterCount: 3
    },
    {
        id: "the_blue",
        title: "The Blue",
        author: "beardeddave",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_blue",
        hfyFoundationUrl: "https://hfy.foundation/series/172",
        chapterCount: 3
    },
    {
        id: "the_blue_dwarf",
        title: "The Blue Dwarf",
        author: "AdventurerOfTheStars",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_blue_dwarf",
        hfyFoundationUrl: "https://hfy.foundation/series/3786",
        chapterCount: 8
    },
    {
        id: "bluestone_standing",
        title: "Bluestone Standing",
        author: "DrPoopaday",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bluestone_standing",
        hfyFoundationUrl: "https://hfy.foundation/series/1931",
        chapterCount: 13
    },
    {
        id: "bonds",
        title: "Bonds",
        author: "BlibbidyBlab",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bonds",
        hfyFoundationUrl: "https://hfy.foundation/series/469",
        chapterCount: 8
    },
    {
        id: "the_book_of_the_chosen",
        title: "The Book Of The Chosen",
        author: "TheScribe_1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_book_of_the_chosen",
        hfyFoundationUrl: "https://hfy.foundation/series/4915",
        chapterCount: 40
    },
    {
        id: "border_state",
        title: "Border State",
        author: "Ceramic_Boi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/border_state",
        hfyFoundationUrl: "https://hfy.foundation/series/5333",
        chapterCount: 6
    },
    {
        id: "born_of_love_made_for_war",
        title: "Born Of Love, Made For War",
        author: "MachDhai",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/born_of_love_made_for_war",
        hfyFoundationUrl: "https://hfy.foundation/series/1835",
        chapterCount: 5
    },
    {
        id: "born_to_kill",
        title: "Born To Kill",
        author: "talmikal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/born_to_kill",
        hfyFoundationUrl: "https://hfy.foundation/series/3109",
        chapterCount: 10
    },
    {
        id: "bought_and_sold",
        title: "Bought and Sold",
        author: "MyNameMeansBentNose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bought_and_sold",
        hfyFoundationUrl: "https://hfy.foundation/series/1279",
        chapterCount: 127
    },
    {
        id: "the_bounty",
        title: "The Bounty",
        author: "scribble_sun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bounty",
        hfyFoundationUrl: "https://hfy.foundation/series/3703",
        chapterCount: 3
    },
    {
        id: "the_bounty_hunter",
        title: "The Bounty Hunter",
        author: "The-Tewby",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bounty_hunter",
        hfyFoundationUrl: "https://hfy.foundation/series/425",
        chapterCount: 8
    },
    {
        id: "a_boy_and_his_tank",
        title: "A Boy and His Tank",
        author: "slaglicked",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_boy_and_his_tank",
        hfyFoundationUrl: "https://hfy.foundation/series/447",
        chapterCount: 3
    },
    {
        id: "braveheart",
        title: "Braveheart",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/braveheart",
        hfyFoundationUrl: "https://hfy.foundation/series/47",
        chapterCount: 8
    },
    {
        id: "the_bridge_of_orion",
        title: "The Bridge of Orion",
        author: "\\_\\_te\\_\\_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bridge_of_orion",
        hfyFoundationUrl: "https://hfy.foundation/series/1203",
        chapterCount: 9
    },
    {
        id: "a_brood_of_two",
        title: "A Brood Of Two",
        author: "FaultyLogicEngine",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_brood_of_two",
        hfyFoundationUrl: "https://hfy.foundation/series/2984",
        chapterCount: 16
    },
    {
        id: "brothers_in_arms",
        title: "Brothers In Arms",
        author: "MWMN19",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/brothers_in_arms_mwmn19",
        hfyFoundationUrl: "https://hfy.foundation/series/2943",
        chapterCount: 3
    },
    {
        id: "bridgebuilder",
        title: "Bridgebuilder",
        author: "icallshogun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bridgebuilder",
        hfyFoundationUrl: "https://hfy.foundation/series/4211",
        chapterCount: 113
    },
    {
        id: "britney_goes_to_school",
        title: "Britney Goes To School",
        author: "Author - Sooperdude24",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/britney_goes_to_school",
        hfyFoundationUrl: "https://hfy.foundation/series/2890",
        chapterCount: 64
    },
    {
        id: "breaking_the_wedge",
        title: "Breaking the Wedge",
        author: "Thorpe_Forward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/breaking_the_wedge",
        hfyFoundationUrl: "https://hfy.foundation/series/88",
        chapterCount: 3
    },
    {
        id: "broken_arrow",
        title: "Broken Arrow",
        author: "Elatus_windfarer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/broken_arrow",
        hfyFoundationUrl: "https://hfy.foundation/series/1069",
        chapterCount: 7
    },
    {
        id: "broken_bones",
        title: "Broken Bones",
        author: "AnimeCrusader69",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/broken_bones",
        hfyFoundationUrl: "https://hfy.foundation/series/3570",
        chapterCount: 23
    },
    {
        id: "bubbleverse",
        title: "Bubbleverse",
        author: "ack1308",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bubbleverse",
        hfyFoundationUrl: "https://hfy.foundation/series/2978",
        chapterCount: 15
    },
    {
        id: "the_bug_war",
        title: "The Bug War",
        author: "TheBugWar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bug_war",
        hfyFoundationUrl: "https://hfy.foundation/series/614",
        chapterCount: 5
    },
    {
        id: "builders_in_the_void",
        title: "Builders in the Void",
        author: "DrunkRobot97",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/builders_in_the_void",
        hfyFoundationUrl: "https://hfy.foundation/series/21",
        chapterCount: 49
    },
    {
        id: "build_it_together",
        title: "Build it Together",
        author: "Manufacture",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/build_it_together",
        hfyFoundationUrl: "https://hfy.foundation/series/103",
        chapterCount: 10
    },
    {
        id: "bullied_by_space_goblins",
        title: "Bullied By Space Goblins",
        author: "Tibbhipsylous",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bullied_by_space_goblins",
        hfyFoundationUrl: "https://hfy.foundation/series/3899",
        chapterCount: 13
    },
    {
        id: "the_burden_egg",
        title: "The Burden Egg",
        author: "SterlingMagleby",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_burden_egg",
        hfyFoundationUrl: "https://hfy.foundation/series/1930",
        chapterCount: 31
    },
    {
        id: "burgerverse",
        title: "Burgerverse",
        author: "Karthinator",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/burgerverse",
        hfyFoundationUrl: "https://hfy.foundation/series/307",
        chapterCount: 6
    },
    {
        id: "burning_stars",
        title: "Burning Stars",
        author: "Saw_Did_Won",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/burning_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/1252",
        chapterCount: 72
    },
    {
        id: "burning_stars_falling_skies",
        title: "Burning Stars, Falling Skies",
        author: "Coco-P",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/burning_stars_falling_skies",
        hfyFoundationUrl: "https://hfy.foundation/series/2332",
        chapterCount: 24
    },
    {
        id: "but_does_it_scale",
        title: "But Does It Scale?",
        author: "Ray_Dillinger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/but_does_it_scale",
        hfyFoundationUrl: "https://hfy.foundation/series/3883",
        chapterCount: 33
    },
    {
        id: "the_butchers",
        title: "The Butchers",
        author: "icecoldpopsicle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_butchers",
        hfyFoundationUrl: "https://hfy.foundation/series/643",
        chapterCount: 9
    },
    {
        id: "by_yirsis",
        title: "By Yirsis",
        author: "Red_Riviera",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/by_yirsis",
        hfyFoundationUrl: "https://hfy.foundation/series/2125",
        chapterCount: 6
    },
    {
        id: "caged_worlds",
        title: "Caged Worlds",
        author: "LawSensitive9239",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/caged_worlds",
        hfyFoundationUrl: "https://hfy.foundation/series/4107",
        chapterCount: 48
    },
    {
        id: "calamity_lord_academy_what_is_a_human_doing_here",
        title: "Calamity Lord Academy: What Is A Human Doing Here?!",
        author: "WeaverofFables",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/calamity_lord_academy_what_is_a_human_doing_here",
        hfyFoundationUrl: "https://hfy.foundation/series/2496",
        chapterCount: 42
    },
    {
        id: "calamity_s_shadow",
        title: "Calamity's Shadow",
        author: "MythyDragonwolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/calamitys_shadow",
        hfyFoundationUrl: "https://hfy.foundation/series/2264",
        chapterCount: 7
    },
    {
        id: "can_a_kobold_save_the_world",
        title: "Can A Kobold Save The World?",
        author: "CycloneDensity",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/can_a_kobold_save_the_world",
        hfyFoundationUrl: "https://hfy.foundation/series/5264",
        chapterCount: 80
    },
    {
        id: "canadian_soldier_a_dragon_and_war",
        title: "Canadian Soldier, A Dragon, And War",
        author: "xotos750",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/canadian_soldier_a_dragon_and_war",
        hfyFoundationUrl: "https://hfy.foundation/series/4587",
        chapterCount: 8
    },
    {
        id: "a_canberran_ozzie",
        title: "A Canberran Ozzie",
        author: "Plucium",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_canberran_ozzie",
        hfyFoundationUrl: "https://hfy.foundation/series/1565",
        chapterCount: 30
    },
    {
        id: "a_candle_in_the_dark",
        title: "A Candle In The Dark",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_candle_in_the_dark",
        hfyFoundationUrl: "https://hfy.foundation/series/1501",
        chapterCount: 35
    },
    {
        id: "the_care_and_feeding_of_humans",
        title: "The Care And Feeding Of Humans",
        author: "All Fubsyverse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_care_and_feeding_of_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/1086",
        chapterCount: 25
    },
    {
        id: "caretakers",
        title: "Caretakers",
        author: "OrganisedAnarchy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/caretakers",
        hfyFoundationUrl: "https://hfy.foundation/series/163",
        chapterCount: 4
    },
    {
        id: "cars_and_the_other_insanities_of_humanity",
        title: "Cars and the Other Insanities of Humanity",
        author: "Niedski",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cars_and_the_other_insanities_of_humanity",
        hfyFoundationUrl: "https://hfy.foundation/series/961",
        chapterCount: 5
    },
    {
        id: "the_casimir_effect",
        title: "The Casimir Effect",
        author: "Nyeregog",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_casimir_effect",
        hfyFoundationUrl: "https://hfy.foundation/series/4678",
        chapterCount: 16
    },
    {
        id: "the_cattleman",
        title: "The Cattleman",
        author: "Long_Colt",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cattleman",
        hfyFoundationUrl: "https://hfy.foundation/series/343",
        chapterCount: 4
    },
    {
        id: "the_caveman_and_the_alien_20_000_b_c",
        title: "The Caveman And The Alien, 20,000 B.c",
        author: "The_Wyrm99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/caveman",
        hfyFoundationUrl: "https://hfy.foundation/series/3571",
        chapterCount: 11
    },
    {
        id: "centurion",
        title: "Centurion",
        author: "Jalapenyobuisness",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/centurion",
        hfyFoundationUrl: "https://hfy.foundation/series/208",
        chapterCount: 3
    },
    {
        id: "a_chance_meeting",
        title: "A Chance Meeting",
        author: "StaplerTwelve",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_chance_meeting",
        hfyFoundationUrl: "https://hfy.foundation/series/677",
        chapterCount: 5
    },
    {
        id: "changewar",
        title: "Changewar",
        author: "LordHenry7898",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/changewar",
        hfyFoundationUrl: "https://hfy.foundation/series/2081",
        chapterCount: 33
    },
    {
        id: "charlie",
        title: "Charlie",
        author: "GeorgeCrecy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/charlie",
        hfyFoundationUrl: "https://hfy.foundation/series/1650",
        chapterCount: 7
    },
    {
        id: "chasing_legends",
        title: "Chasing Legends",
        author: "BeaverFur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chasing_legends",
        hfyFoundationUrl: "https://hfy.foundation/series/207",
        chapterCount: 6
    },
    {
        id: "check_up",
        title: "Check-up",
        author: "ravnicrasol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/checkup",
        hfyFoundationUrl: "https://hfy.foundation/series/1720",
        chapterCount: 3
    },
    {
        id: "chemical_warfare",
        title: "Chemical Warfare",
        author: "WarAdmiral2420",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chemical_warfare",
        hfyFoundationUrl: "https://hfy.foundation/series/2687",
        chapterCount: 2
    },
    {
        id: "children_no_more",
        title: "Children No More",
        author: "\\_Thorshammer\\_",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/children_no_more",
        hfyFoundationUrl: "https://hfy.foundation/series/2165",
        chapterCount: 5
    },
    {
        id: "children_of_sol",
        title: "Children Of Sol",
        author: "MYSFITS_OFFICIAL",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/children_of_sol",
        hfyFoundationUrl: "https://hfy.foundation/series/5135",
        chapterCount: 47
    },
    {
        id: "children_of_the_gun",
        title: "Children Of the Gun",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/children_of_the_gun",
        hfyFoundationUrl: "https://hfy.foundation/series/1591",
        chapterCount: 13
    },
    {
        id: "children_of_the_mana_void",
        title: "Children Of the Mana Void",
        author: "Yama951",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/children_of_the_mana_void",
        hfyFoundationUrl: "https://hfy.foundation/series/262",
        chapterCount: 23
    },
    {
        id: "children_of_the_stars",
        title: "Children Of The Stars",
        author: "Neinty-neinth-knight",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/children_of_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/4629",
        chapterCount: 18
    },
    {
        id: "the_chimera_project",
        title: "The Chimera Project",
        author: "RipHunterIsMyCopilot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_chimera_project",
        hfyFoundationUrl: "https://hfy.foundation/series/1092",
        chapterCount: 25
    },
    {
        id: "choices",
        title: "Choices",
        author: "Sand_Trout",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/choices",
        hfyFoundationUrl: "https://hfy.foundation/series/717",
        chapterCount: 10
    },
    {
        id: "a_christmas_story",
        title: "A Christmas Story",
        author: "ElGringo300",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_christmas_story",
        hfyFoundationUrl: "https://hfy.foundation/series/2029",
        chapterCount: 6
    },
    {
        id: "the_chronicles_of_aesyra",
        title: "The Chronicles Of Aesyra",
        author: "EvilMonkeyPaw",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_chronicles_of_aesyra",
        hfyFoundationUrl: "https://hfy.foundation/series/4320",
        chapterCount: 12
    },
    {
        id: "the_circuitous_road_to_peace",
        title: "The Circuitous Road To Peace",
        author: "FermisFolly",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_circuitous_road_to_peace",
        hfyFoundationUrl: "https://hfy.foundation/series/2045",
        chapterCount: 4
    },
    {
        id: "city_of_lincoln",
        title: "City of Lincoln",
        author: "Nik\\_2213",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/city_of_lincoln",
        hfyFoundationUrl: "https://hfy.foundation/series/1461",
        chapterCount: 9
    },
    {
        id: "city_of_night",
        title: "City of Night",
        author: "Harfus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/city_of_night",
        hfyFoundationUrl: "https://hfy.foundation/series/446",
        chapterCount: 3
    },
    {
        id: "city_of_one",
        title: "City of One",
        author: "bott99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/city_of_one",
        hfyFoundationUrl: "https://hfy.foundation/series/1590",
        chapterCount: 3
    },
    {
        id: "class_v",
        title: "Class V",
        author: "Ajbonnis",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/class_v",
        hfyFoundationUrl: "https://hfy.foundation/series/3014",
        chapterCount: 25
    },
    {
        id: "classification_earth",
        title: "Classification: Earth",
        author: "Thomas\\_Dimensor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/classification_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/1693",
        chapterCount: 8
    },
    {
        id: "clockwork_man",
        title: "Clockwork Man",
        author: "Timpanzee_Writes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/clockwork_man",
        hfyFoundationUrl: "https://hfy.foundation/series/1819",
        chapterCount: 8
    },
    {
        id: "club_novus",
        title: "Club Novus",
        author: "randallfcooper",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/club_novus",
        hfyFoundationUrl: "https://hfy.foundation/series/3706",
        chapterCount: 32
    },
    {
        id: "code_black",
        title: "Code Black",
        author: "Nnudmac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/code_black",
        hfyFoundationUrl: "https://hfy.foundation/series/1387",
        chapterCount: 5
    },
    {
        id: "cold_steel",
        title: "Cold Steel",
        author: "Roaksan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cold_steel",
        hfyFoundationUrl: "https://hfy.foundation/series/1970",
        chapterCount: 5
    },
    {
        id: "the_collective",
        title: "The Collective",
        author: "arclightmagus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_collective",
        hfyFoundationUrl: "https://hfy.foundation/series/2287",
        chapterCount: 146
    },
    {
        id: "collision_course",
        title: "Collision Course",
        author: "Zhen_Stormheart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/collision_course",
        hfyFoundationUrl: "https://hfy.foundation/series/4465",
        chapterCount: 36
    },
    {
        id: "combat_artificer",
        title: "Combat Artificer",
        author: "Sylesth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/combat_artificer",
        hfyFoundationUrl: "https://hfy.foundation/series/5190",
        chapterCount: 91
    },
    {
        id: "comic_adaptation_of_lablonnamedadon",
        title: "Comic Adaptation of Lablonnamedadon",
        author: "DrFreeloader",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/comic_adaptation_of_lablonnamedadon",
        hfyFoundationUrl: "https://hfy.foundation/series/1081",
        chapterCount: 2
    },
    {
        id: "coming_to",
        title: "Coming To",
        author: "Splatteredred",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/coming_to",
        hfyFoundationUrl: "https://hfy.foundation/series/1444",
        chapterCount: 4
    },
    {
        id: "the_commander_s_call",
        title: "The Commander's Call",
        author: "General_Havan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_commanders_call",
        hfyFoundationUrl: "https://hfy.foundation/series/78",
        chapterCount: 16
    },
    {
        id: "complacency",
        title: "Complacency",
        author: "Gorbashsan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/complacency",
        hfyFoundationUrl: "https://hfy.foundation/series/1073",
        chapterCount: 9
    },
    {
        id: "a_computer_named_george",
        title: "A Computer Named George",
        author: "TeddyBearToons",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_computer_named_george",
        hfyFoundationUrl: "https://hfy.foundation/series/4797",
        chapterCount: 6
    },
    {
        id: "confessions",
        title: "Confessions",
        author: "Deekle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/confessions",
        hfyFoundationUrl: "https://hfy.foundation/series/133",
        chapterCount: 7
    },
    {
        id: "the_confidence_men",
        title: "The Confidence Men",
        author: "AbsurdistAnachronism",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_confidence_men",
        hfyFoundationUrl: "https://hfy.foundation/series/1649",
        chapterCount: 67
    },
    {
        id: "conjunction",
        title: "Conjunction",
        author: "Snekguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/conjunction",
        hfyFoundationUrl: "https://hfy.foundation/series/3595",
        chapterCount: 18
    },
    {
        id: "a_connecticut_yankee_in_the_magical_court",
        title: "A Connecticut Yankee In The Magical Court",
        author: "keptin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_connecticut_yankee_in_the_magical_court",
        hfyFoundationUrl: "https://hfy.foundation/series/637",
        chapterCount: 8
    },
    {
        id: "contact",
        title: "Contact",
        author: "focalac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/contact",
        hfyFoundationUrl: "https://hfy.foundation/series/1059",
        chapterCount: 8
    },
    {
        id: "contact_procedures",
        title: "Contact Procedures",
        author: "Meatfcker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/contact_procedures",
        hfyFoundationUrl: "https://hfy.foundation/series/5394",
        chapterCount: 4
    },
    {
        id: "convenience_store_aliens",
        title: "Convenience Store Aliens",
        author: "enthusiastic_sausage",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/convenience_store_aliens",
        hfyFoundationUrl: "https://hfy.foundation/series/1667",
        chapterCount: 2
    },
    {
        id: "the_cost_of_a_life_humanity_s_first_intergalactic_bounty_hunter",
        title: "The Cost Of A Life: Humanity's First Intergalactic Bounty Hunter",
        author: "Computerdude101",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cost_of_a_life_humanitys_first_intergalactic_bounty_hunter",
        hfyFoundationUrl: "https://hfy.foundation/series/5341",
        chapterCount: 22
    },
    {
        id: "could_have_gone_worse",
        title: "Could Have Gone Worse",
        author: "Rakiinterith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/could_have_gone_worse",
        hfyFoundationUrl: "https://hfy.foundation/series/1309",
        chapterCount: 54
    },
    {
        id: "the_council_convenes",
        title: "The Council Convenes",
        author: "DaOllieGSauce",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_council_convenes",
        hfyFoundationUrl: "https://hfy.foundation/series/2856",
        chapterCount: 8
    },
    {
        id: "the_council_series",
        title: "The Council Series",
        author: "NomadofExile",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_council_series",
        hfyFoundationUrl: "https://hfy.foundation/series/139",
        chapterCount: 8
    },
    {
        id: "a_course_of_action",
        title: "A Course Of Action",
        author: "kiwispacemarine",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_course_of_action",
        hfyFoundationUrl: "https://hfy.foundation/series/2307",
        chapterCount: 82
    },
    {
        id: "cover_is_always_important",
        title: "Cover Is Always Important",
        author: "Tunnel--Rat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cover_is_always_important",
        hfyFoundationUrl: "https://hfy.foundation/series/2388",
        chapterCount: 3
    },
    {
        id: "cowboy_in_an_isekai",
        title: "Cowboy In An Isekai?",
        author: "c0mlink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cowboy_in_an_isekai",
        hfyFoundationUrl: "https://hfy.foundation/series/3267",
        chapterCount: 55
    },
    {
        id: "the_cradle",
        title: "The Cradle",
        author: "Le\\_Grim",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cradle",
        hfyFoundationUrl: "https://hfy.foundation/series/2671",
        chapterCount: 10
    },
    {
        id: "created_souls",
        title: "Created Souls",
        author: "Arivael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/created_souls",
        hfyFoundationUrl: "https://hfy.foundation/series/984",
        chapterCount: 2
    },
    {
        id: "creatures_from_the_veil_a_scientist_s_discovery_to_shatter_the_galaxy",
        title: "Creatures from the veil - a scientist's discovery to shatter the galaxy",
        author: "NoVirtue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/creatures_from_the_veil",
        hfyFoundationUrl: "https://hfy.foundation/series/19",
        chapterCount: 12
    },
    {
        id: "crimson_fogland",
        title: "Crimson Fogland",
        author: "AstraMagically",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/crimson_fogland",
        hfyFoundationUrl: "https://hfy.foundation/series/5065",
        chapterCount: 3
    },
    {
        id: "crossers",
        title: "Crossers",
        author: "starwatcher72",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/crossers",
        hfyFoundationUrl: "https://hfy.foundation/series/3880",
        chapterCount: 13
    },
    {
        id: "cry_havoc",
        title: "Cry Havoc",
        author: "Chukter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cry_havoc",
        hfyFoundationUrl: "https://hfy.foundation/series/123",
        chapterCount: 8
    },
    {
        id: "the_cryopod_to_hell",
        title: "The Cryopod To Hell",
        author: "Klokinator",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cryopod_to_hell",
        hfyFoundationUrl: "https://hfy.foundation/series/1949",
        chapterCount: 721
    },
    {
        id: "cthuddle_for_cthulhu",
        title: "Cthuddle for Cthulhu",
        author: "semiloki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cthuddle_for_cthulhu",
        hfyFoundationUrl: "https://hfy.foundation/series/543",
        chapterCount: 4
    },
    {
        id: "ctwelve_vs_someguynamedted",
        title: "ctwelve vs someguynamedted",
        author: "ctwelve",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ctwelve_vs_someguynamedted",
        hfyFoundationUrl: "https://hfy.foundation/series/315",
        chapterCount: 5
    },
    {
        id: "cube",
        title: "Cube",
        author: "Xzenergy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cube",
        hfyFoundationUrl: "https://hfy.foundation/series/4986",
        chapterCount: 6
    },
    {
        id: "the_cult_of_gertrude",
        title: "The Cult Of Gertrude",
        author: "Ceramic_Boi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cult_of_gertrude",
        hfyFoundationUrl: "https://hfy.foundation/series/5026",
        chapterCount: 17
    },
    {
        id: "cultivator_by_proxy",
        title: "Cultivator By Proxy",
        author: "Photemy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cultivator_by_proxy",
        hfyFoundationUrl: "https://hfy.foundation/series/4890",
        chapterCount: 19
    },
    {
        id: "cultural_exchange_program",
        title: "Cultural Exchange Program",
        author: "Crocmon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cultural_exchange_program",
        hfyFoundationUrl: "https://hfy.foundation/series/2973",
        chapterCount: 3
    },
    {
        id: "cultural_misunderstandings",
        title: "Cultural Misunderstandings",
        author: "Starstuffdrifter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cultural_misunderstandings",
        hfyFoundationUrl: "https://hfy.foundation/series/3075",
        chapterCount: 3
    },
    {
        id: "a_cup_o_joe",
        title: "A Cup O' Joe",
        author: "lainmelle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_cup_o_joe",
        hfyFoundationUrl: "https://hfy.foundation/series/2662",
        chapterCount: 43
    },
    {
        id: "the_curators",
        title: "The Curators",
        author: "localroger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_curators",
        hfyFoundationUrl: "https://hfy.foundation/series/1227",
        chapterCount: 135
    },
    {
        id: "curse_of_the_outsiders",
        title: "Curse Of The Outsiders",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/curse_of_the_outsiders",
        hfyFoundationUrl: "https://hfy.foundation/series/4426",
        chapterCount: 40
    },
    {
        id: "custom_made",
        title: "Custom Made",
        author: "MyNameMeansBentNose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/custom_made",
        hfyFoundationUrl: "https://hfy.foundation/series/2320",
        chapterCount: 26
    },
    {
        id: "cute_berserker",
        title: "Cute Berserker",
        author: "KiriofGreen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cute_berserker",
        hfyFoundationUrl: "https://hfy.foundation/series/3517",
        chapterCount: 7
    },
    {
        id: "cyber_core",
        title: "Cyber Core",
        author: "Thausgt01",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cyber_core",
        hfyFoundationUrl: "https://hfy.foundation/series/5205",
        chapterCount: 86
    },
    {
        id: "the_daedalus_encounter",
        title: "The Daedalus Encounter",
        author: "bjelkeman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_daedalus_encounter",
        hfyFoundationUrl: "https://hfy.foundation/series/5591",
        chapterCount: 11
    },
    {
        id: "dagor_dagorath",
        title: "Dagor Dagorath",
        author: "galrock0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dagor_dagorath",
        hfyFoundationUrl: "https://hfy.foundation/series/185",
        chapterCount: 3
    },
    {
        id: "dandelion",
        title: "Dandelion",
        author: "ctwelve",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dandelion",
        hfyFoundationUrl: "https://hfy.foundation/series/2486",
        chapterCount: 13
    },
    {
        id: "the_dandelion_fragments",
        title: "The Dandelion Fragments",
        author: "vaeghyvel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dandelion_fragments",
        hfyFoundationUrl: "https://hfy.foundation/series/2086",
        chapterCount: 7
    },
    {
        id: "the_dandelion_protocol",
        title: "The Dandelion Protocol",
        author: "RedCastoff",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dandelion_protocol",
        hfyFoundationUrl: "https://hfy.foundation/series/4145",
        chapterCount: 5
    },
    {
        id: "dangerous_toys",
        title: "Dangerous Toys",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dangerous_toys",
        hfyFoundationUrl: "https://hfy.foundation/series/2526",
        chapterCount: 22
    },
    {
        id: "dao_of_the_deal",
        title: "Dao Of The Deal",
        author: "thejacobk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dao_of_the_deal",
        hfyFoundationUrl: "https://hfy.foundation/series/4006",
        chapterCount: 71
    },
    {
        id: "dare_we_fire",
        title: "Dare We Fire",
        author: "froggyrules",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dare_we_fire",
        hfyFoundationUrl: "https://hfy.foundation/series/23",
        chapterCount: 6
    },
    {
        id: "the_dark_forest_hypothesis_the_ones_who_break_the_silence",
        title: "The Dark Forest Hypothesis: The Ones Who Break The Silence",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dark_forest_hypothesis_the_ones_who_break_the_silence",
        hfyFoundationUrl: "https://hfy.foundation/series/4039",
        chapterCount: 2
    },
    {
        id: "the_dark_time_of_the_humans",
        title: "The Dark Time of the Humans",
        author: "TheBugWar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dark_time_of_the_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/826",
        chapterCount: 18
    },
    {
        id: "darkness",
        title: "Darkness",
        author: "Lostfol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/darkness_lostfol",
        hfyFoundationUrl: "https://hfy.foundation/series/1593",
        chapterCount: 9
    },
    {
        id: "darkness_2",
        title: "Darkness",
        author: "ShadowPouncer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/darkness_shadowpouncer",
        hfyFoundationUrl: "https://hfy.foundation/series/3768",
        chapterCount: 7
    },
    {
        id: "dave_the_human_pornstar",
        title: "Dave, The Human Pornstar",
        author: "Stumpy-JIm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dave_the_human_pornstar",
        hfyFoundationUrl: "https://hfy.foundation/series/2885",
        chapterCount: 107
    },
    {
        id: "the_dawn_and_dusk_in_a_new_darkness",
        title: "The Dawn And Dusk In A New Darkness",
        author: "CornSquashBeans",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dawn_and_dusk_in_a_new_darkness",
        hfyFoundationUrl: "https://hfy.foundation/series/5082",
        chapterCount: 73
    },
    {
        id: "dawn_of_humanity_s_empire",
        title: "Dawn of Humanity's Empire",
        author: "Iroh_Koza",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dawn_of_humanitys_empire",
        hfyFoundationUrl: "https://hfy.foundation/series/1161",
        chapterCount: 6
    },
    {
        id: "it_was_day_x",
        title: "It Was Day X",
        author: "KiriofGreen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/it_was_day_x",
        hfyFoundationUrl: "https://hfy.foundation/series/4285",
        chapterCount: 6
    },
    {
        id: "day_zero",
        title: "Day Zero",
        author: "nexquietus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/day_zero",
        hfyFoundationUrl: "https://hfy.foundation/series/1230",
        chapterCount: 21
    },
    {
        id: "the_days_on_korath",
        title: "The Days on Korath",
        author: "The_Magnificent_Man",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_days_on_korath",
        hfyFoundationUrl: "https://hfy.foundation/series/545",
        chapterCount: 6
    },
    {
        id: "dcore_the_observatory",
        title: "Dcore: The Observatory",
        author: "P0MP3I1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dcore_the_observatory",
        hfyFoundationUrl: "https://hfy.foundation/series/5017",
        chapterCount: 18
    },
    {
        id: "deadly_first_contact",
        title: "Deadly First Contact",
        author: "LukeWasNotHere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deadly_first_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/3691",
        chapterCount: 2
    },
    {
        id: "death_gods",
        title: "death gods",
        author: "efaviel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/death_gods",
        hfyFoundationUrl: "https://hfy.foundation/series/1275",
        chapterCount: 3
    },
    {
        id: "death_by_deathworld",
        title: "Death By Deathworld",
        author: "stonesdoorsbeatles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/death_by_deathworld",
        hfyFoundationUrl: "https://hfy.foundation/series/3660",
        chapterCount: 13
    },
    {
        id: "death_of_an_empire",
        title: "Death Of An Empire",
        author: "The24-7Pro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/death_of_an_empire",
        hfyFoundationUrl: "https://hfy.foundation/series/2907",
        chapterCount: 23
    },
    {
        id: "deathless",
        title: "Deathless",
        author: "Delicious-Bat-3341",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathless",
        hfyFoundationUrl: "https://hfy.foundation/series/3829",
        chapterCount: 7
    },
    {
        id: "the_deathworld",
        title: "The Deathworld",
        author: "AdventurerOfTheStars",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_deathworld",
        hfyFoundationUrl: "https://hfy.foundation/series/4120",
        chapterCount: 14
    },
    {
        id: "deathworld_commando_reborn",
        title: "Deathworld Commando Reborn",
        author: "RangerFrank",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworld_commando_reborn",
        hfyFoundationUrl: "https://hfy.foundation/series/3162",
        chapterCount: 271
    },
    {
        id: "deathworld_game",
        title: "Deathworld Game",
        author: "SkullbombRaging",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworld_game",
        hfyFoundationUrl: "https://hfy.foundation/series/3003",
        chapterCount: 131
    },
    {
        id: "deathworlder_s_poison",
        title: "Deathworlder's Poison",
        author: "Toaster_AssassinPope",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworlders_poison",
        hfyFoundationUrl: "https://hfy.foundation/series/3324",
        chapterCount: 17
    },
    {
        id: "deathworlders_meet",
        title: "Deathworlders Meet",
        author: "Aussie_Endeavour",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworlders_meet",
        hfyFoundationUrl: "https://hfy.foundation/series/3207",
        chapterCount: 61
    },
    {
        id: "deathworlders_should_not_be_allowed_to_date",
        title: "Deathworlders Should Not Be Allowed To Date!",
        author: "Nemo__404",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworlders_should_not_be_allowed_to_date",
        hfyFoundationUrl: "https://hfy.foundation/series/4981",
        chapterCount: 25
    },
    {
        id: "deathworlder_troubleshooting_department",
        title: "Deathworlder Troubleshooting Department",
        author: "Random3x",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworlder_troubleshooting_department",
        hfyFoundationUrl: "https://hfy.foundation/series/3966",
        chapterCount: 9
    },
    {
        id: "a_defender_s_last_gleaming",
        title: "A Defender's Last Gleaming",
        author: "Notcher_Bizniz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_defenders_last_gleaming",
        hfyFoundationUrl: "https://hfy.foundation/series/112",
        chapterCount: 2
    },
    {
        id: "deimos",
        title: "Deimos",
        author: "Paligor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deimos",
        hfyFoundationUrl: "https://hfy.foundation/series/180",
        chapterCount: 4
    },
    {
        id: "demon_city",
        title: "Demon City",
        author: "spoolyspool",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/demon_city",
        hfyFoundationUrl: "https://hfy.foundation/series/2659",
        chapterCount: 76
    },
    {
        id: "a_demon_from_earth",
        title: "A Demon From Earth",
        author: "itsetuhoinen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_demon_from_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/1969",
        chapterCount: 60
    },
    {
        id: "demon_god_maxwell",
        title: "Demon God Maxwell",
        author: "Scire\\_Schroedinger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/demon_god_maxwell",
        hfyFoundationUrl: "https://hfy.foundation/series/4125",
        chapterCount: 13
    },
    {
        id: "demon_hunter",
        title: "Demon Hunter",
        author: "Haenir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/demon_hunter",
        hfyFoundationUrl: "https://hfy.foundation/series/441",
        chapterCount: 50
    },
    {
        id: "demon_hunter_2",
        title: "Demon Hunter",
        author: "norlsaints",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/demon_hunter_norlsaints",
        hfyFoundationUrl: "https://hfy.foundation/series/2242",
        chapterCount: 8
    },
    {
        id: "the_demon_summoned_from_earth",
        title: "The Demon Summoned From Earth",
        author: "SilverPhantomB",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_demon_summoned_from_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/3146",
        chapterCount: 19
    },
    {
        id: "the_demon_s_accountant",
        title: "The Demon's Accountant",
        author: "MrSharks202",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_demons_accountant",
        hfyFoundationUrl: "https://hfy.foundation/series/3812",
        chapterCount: 11
    },
    {
        id: "demons_don_t_lie",
        title: "Demons Don't Lie",
        author: "PistolShrimpWrites",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/demons_dont_lie",
        hfyFoundationUrl: "https://hfy.foundation/series/3556",
        chapterCount: 46
    },
    {
        id: "department_of_dungeon_studies",
        title: "Department Of Dungeon Studies",
        author: "NoxianBrews",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/department_of_dungeon_studies",
        hfyFoundationUrl: "https://hfy.foundation/series/5072",
        chapterCount: 54
    },
    {
        id: "derelict",
        title: "Derelict",
        author: "Turul___Madar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/derelict",
        hfyFoundationUrl: "https://hfy.foundation/series/464",
        chapterCount: 8
    },
    {
        id: "descent_of_the_demon_lords",
        title: "Descent Of The Demon Lords",
        author: "Spartawolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/descent_of_the_demon_lords",
        hfyFoundationUrl: "https://hfy.foundation/series/2637",
        chapterCount: 32
    },
    {
        id: "deserted_in_the_shadows",
        title: "Deserted In The Shadows",
        author: "Dracosia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deserted_in_the_shadows",
        hfyFoundationUrl: "https://hfy.foundation/series/4810",
        chapterCount: 61
    },
    {
        id: "despair_among_the_stars",
        title: "Despair Among The Stars",
        author: "Toxidran",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/despair_among_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/3322",
        chapterCount: 24
    },
    {
        id: "a_developing_race",
        title: "A Developing Race",
        author: "Hunter_Writes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_developing_race",
        hfyFoundationUrl: "https://hfy.foundation/series/3444",
        chapterCount: 10
    },
    {
        id: "diary_entries_from_corporal_lucy_4th_human_guard_regiment_the_1st_young_guards",
        title: "Diary entries from Corporal \"Lucy\", 4th (human) Guard Regiment, The 1st Young Guards.",
        author: "Wiffypitts",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lucy",
        hfyFoundationUrl: "https://hfy.foundation/series/7",
        chapterCount: 25
    },
    {
        id: "diary_of_a_cranky_old_man",
        title: "Diary of a Cranky Old Man",
        author: "HereToNotBeElsewhere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/diary_of_a_cranky_old_man",
        hfyFoundationUrl: "https://hfy.foundation/series/253",
        chapterCount: 2
    },
    {
        id: "digital_ascension",
        title: "Digital Ascension",
        author: "\\_\\_te\\_\\_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/digital_ascension",
        hfyFoundationUrl: "https://hfy.foundation/series/1114",
        chapterCount: 11
    },
    {
        id: "dimensional_destruction",
        title: "Dimensional Destruction",
        author: "Avskygod0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dimensional_destruction",
        hfyFoundationUrl: "https://hfy.foundation/series/1305",
        chapterCount: 6
    },
    {
        id: "dinner_time",
        title: "Dinner Time",
        author: "Paligor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dinner_time",
        hfyFoundationUrl: "https://hfy.foundation/series/252",
        chapterCount: 4
    },
    {
        id: "diplomatic_intelligence_report_upon_the_human_military",
        title: "Diplomatic Intelligence Report Upon The Human Military",
        author: "FiauraTanks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/diplomatic_intelligence_report_upon_the_human_military",
        hfyFoundationUrl: "https://hfy.foundation/series/4866",
        chapterCount: 6
    },
    {
        id: "dire",
        title: "Dire",
        author: "Edwardthecrazyman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dire",
        hfyFoundationUrl: "https://hfy.foundation/series/2466",
        chapterCount: 8
    },
    {
        id: "dirtmen_rising",
        title: "Dirtmen Rising",
        author: "Yertosaurus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dirtmen_rising",
        hfyFoundationUrl: "https://hfy.foundation/series/3564",
        chapterCount: 138
    },
    {
        id: "a_discovery_a_snowflake_and_a_word",
        title: "A Discovery, A Snowflake, And A Word",
        author: "Basil_9",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_discovery_a_snowflake_and_a_word",
        hfyFoundationUrl: "https://hfy.foundation/series/2022",
        chapterCount: 5
    },
    {
        id: "the_discovery",
        title: "The Discovery",
        author: "DustHurricane",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_discovery",
        hfyFoundationUrl: "https://hfy.foundation/series/2044",
        chapterCount: 44
    },
    {
        id: "disentangling_the_treow",
        title: "Disentangling The Treow",
        author: "Scire\\_Schroedinger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/disentangling_the_treow",
        hfyFoundationUrl: "https://hfy.foundation/series/2184",
        chapterCount: 4
    },
    {
        id: "the_displaced",
        title: "The Displaced",
        author: "Andaloup",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_displaced",
        hfyFoundationUrl: "https://hfy.foundation/series/1303",
        chapterCount: 28
    },
    {
        id: "distant_thunder",
        title: "Distant Thunder",
        author: "Alarmed-Painting-121",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/distant_thunder",
        hfyFoundationUrl: "https://hfy.foundation/series/3524",
        chapterCount: 10
    },
    {
        id: "a_distant_visitor",
        title: "A Distant Visitor",
        author: "WonderFiz81",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_distant_visitor",
        hfyFoundationUrl: "https://hfy.foundation/series/5106",
        chapterCount: 5
    },
    {
        id: "divided_they_rise",
        title: "Divided, They Rise",
        author: "GreenMrSmith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/divided_they_rise",
        hfyFoundationUrl: "https://hfy.foundation/series/2379",
        chapterCount: 18
    },
    {
        id: "the_divine_sound",
        title: "The Divine Sound",
        author: "Captain_Fancy_Pantz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_divine_sound",
        hfyFoundationUrl: "https://hfy.foundation/series/132",
        chapterCount: 7
    },
    {
        id: "divinity",
        title: "Divinity",
        author: "Lightenant",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/divinity",
        hfyFoundationUrl: "https://hfy.foundation/series/2288",
        chapterCount: 66
    },
    {
        id: "do_not_contact",
        title: "Do Not Contact",
        author: "Lord_Camberlot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/do_not_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/1189",
        chapterCount: 19
    },
    {
        id: "do_not_send_rescue",
        title: "Do Not Send Rescue",
        author: "jpeezey",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/do_not_send_rescue",
        hfyFoundationUrl: "https://hfy.foundation/series/1813",
        chapterCount: 12
    },
    {
        id: "of_dog_volpir_and_man",
        title: "Of Dog, Volpir, And Man",
        author: "KamchatkasRevenge",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/of_dog_volpir_and_man",
        hfyFoundationUrl: "https://hfy.foundation/series/3294",
        chapterCount: 322
    },
    {
        id: "a_dogman_of_azeroth",
        title: "A Dogman Of Azeroth",
        author: "nos4atu668",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_dogman_of_azeroth",
        hfyFoundationUrl: "https://hfy.foundation/series/4043",
        chapterCount: 20
    },
    {
        id: "dominion",
        title: "Dominion",
        author: "Whytesmoke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dominion",
        hfyFoundationUrl: "https://hfy.foundation/series/114",
        chapterCount: 2
    },
    {
        id: "the_door_on_the_moon",
        title: "The Door On The Moon",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_door_on_the_moon",
        hfyFoundationUrl: "https://hfy.foundation/series/3937",
        chapterCount: 2
    },
    {
        id: "doorkickers_space_edition",
        title: "Doorkickers: Space Edition",
        author: "Riomine1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/doorkickers_space_edition",
        hfyFoundationUrl: "https://hfy.foundation/series/3456",
        chapterCount: 8
    },
    {
        id: "the_doorman",
        title: "The Doorman",
        author: "Author - Sooperdude24",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_doorman",
        hfyFoundationUrl: "https://hfy.foundation/series/2562",
        chapterCount: 11
    },
    {
        id: "dooy",
        title: "Dooy",
        author: "Dry\\_Preparation9195",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dooy",
        hfyFoundationUrl: "https://hfy.foundation/series/3771",
        chapterCount: 5
    },
    {
        id: "the_dorvan_war",
        title: "The Dorvan War",
        author: "KaiDobson",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dorvan_war",
        hfyFoundationUrl: "https://hfy.foundation/series/92",
        chapterCount: 31
    },
    {
        id: "dragonborn",
        title: "Dragonborn",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dragonborn",
        hfyFoundationUrl: "https://hfy.foundation/series/198",
        chapterCount: 3
    },
    {
        id: "dragonrider",
        title: "Dragonrider",
        author: "CrBananoss",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dragonrider",
        hfyFoundationUrl: "https://hfy.foundation/series/436",
        chapterCount: 3
    },
    {
        id: "drifter",
        title: "Drifter",
        author: "Environmental-Wish53",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/drifter",
        hfyFoundationUrl: "https://hfy.foundation/series/3147",
        chapterCount: 5
    },
    {
        id: "drowscape",
        title: "Drowscape",
        author: "Zithero",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/drowscape",
        hfyFoundationUrl: "https://hfy.foundation/series/3876",
        chapterCount: 17
    },
    {
        id: "the_drums_of_war",
        title: "The Drums Of War",
        author: "TheCurserHasntMoved",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_drums_of_war",
        hfyFoundationUrl: "https://hfy.foundation/series/4998",
        chapterCount: 36
    },
    {
        id: "dungeon_corps",
        title: "Dungeon Corps",
        author: "BlindGuyAndKarr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dungeon_corps",
        hfyFoundationUrl: "https://hfy.foundation/series/4744",
        chapterCount: 54
    },
    {
        id: "the_dungeon_lord",
        title: "The Dungeon Lord",
        author: "CatFish21sm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dungeon_lord",
        hfyFoundationUrl: "https://hfy.foundation/series/4899",
        chapterCount: 58
    },
    {
        id: "the_dungeon_to_rule_them_all",
        title: "The Dungeon To Rule Them All",
        author: "Nenamaaa",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dungeon_to_rule_them_all",
        hfyFoundationUrl: "https://hfy.foundation/series/4454",
        chapterCount: 19
    },
    {
        id: "dust_to_dust",
        title: "Dust to Dust",
        author: "reptilia28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dust_to_dust",
        hfyFoundationUrl: "https://hfy.foundation/series/281",
        chapterCount: 5
    },
    {
        id: "duty_bound",
        title: "Duty-bound",
        author: "Sinpleton025",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dutybound",
        hfyFoundationUrl: "https://hfy.foundation/series/5130",
        chapterCount: 3
    },
    {
        id: "dynamite_with_a_laser_beam",
        title: "Dynamite with a Laser-Beam",
        author: "ColonelJackGodfries",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dynamite_with_a_laserbeam",
        hfyFoundationUrl: "https://hfy.foundation/series/18",
        chapterCount: 23
    },
    {
        id: "dystopia",
        title: "Dystopia",
        author: "smrtak32",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dystopia",
        hfyFoundationUrl: "https://hfy.foundation/series/4972",
        chapterCount: 3
    },
    {
        id: "earth_reborn",
        title: "Earth, Reborn",
        author: "Ford9863",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earth_reborn",
        hfyFoundationUrl: "https://hfy.foundation/series/1830",
        chapterCount: 32
    },
    {
        id: "earth_s_chosen",
        title: "Earth's Chosen",
        author: "lucader881",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earths_chosen",
        hfyFoundationUrl: "https://hfy.foundation/series/4721",
        chapterCount: 88
    },
    {
        id: "earth_s_last_gleaming",
        title: "Earth's Last Gleaming",
        author: "Toah14",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earths_last_gleaming",
        hfyFoundationUrl: "https://hfy.foundation/series/211",
        chapterCount: 3
    },
    {
        id: "the_easy_choice",
        title: "The Easy Choice",
        author: "TrueHoogleman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_easy_choice",
        hfyFoundationUrl: "https://hfy.foundation/series/5505",
        chapterCount: 17
    },
    {
        id: "echo_of_earth",
        title: "Echo of Earth",
        author: "daikael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/echo_of_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/2047",
        chapterCount: 17
    },
    {
        id: "edge_of_madness",
        title: "Edge Of Madness",
        author: "Jus17173",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/edge_of_madness",
        hfyFoundationUrl: "https://hfy.foundation/series/4027",
        chapterCount: 133
    },
    {
        id: "education",
        title: "Education",
        author: "BadWritingThrowaway",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/education",
        hfyFoundationUrl: "https://hfy.foundation/series/679",
        chapterCount: 3
    },
    {
        id: "these_eldritch_stars",
        title: "These Eldritch Stars",
        author: "KittraMcBriar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/these_eldritch_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/4219",
        chapterCount: 25
    },
    {
        id: "elissa",
        title: "Elissa",
        author: "ElGringo300",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/elissa",
        hfyFoundationUrl: "https://hfy.foundation/series/2115",
        chapterCount: 3
    },
    {
        id: "eliza",
        title: "Eliza",
        author: "efaviel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/eliza",
        hfyFoundationUrl: "https://hfy.foundation/series/1260",
        chapterCount: 2
    },
    {
        id: "the_elusive_human_so_often_forgotten",
        title: "The Elusive Human, So Often Forgotten",
        author: "DropShotEpee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_elusive_human_so_often_forgotten",
        hfyFoundationUrl: "https://hfy.foundation/series/3805",
        chapterCount: 65
    },
    {
        id: "elven_paranormal_containment_foundation",
        title: "Elven Paranormal Containment Foundation",
        author: "sostoast5",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/elven_paranormal_containment_foundation",
        hfyFoundationUrl: "https://hfy.foundation/series/2136",
        chapterCount: 22
    },
    {
        id: "the_emerald_journal",
        title: "The Emerald Journal",
        author: "aguythatcan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_emerald_journal",
        hfyFoundationUrl: "https://hfy.foundation/series/4283",
        chapterCount: 37
    },
    {
        id: "emotive_agonist",
        title: "Emotive-Agonist",
        author: "horizonsong",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/emotive-agonist",
        hfyFoundationUrl: "https://hfy.foundation/series/995",
        chapterCount: 17
    },
    {
        id: "empire",
        title: "Empire",
        author: "ZathuraRay",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/empire",
        hfyFoundationUrl: "https://hfy.foundation/series/439",
        chapterCount: 28
    },
    {
        id: "an_empire_of_vengeance",
        title: "An Empire Of Vengeance",
        author: "GJacoo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_empire_of_vengeance",
        hfyFoundationUrl: "https://hfy.foundation/series/1194",
        chapterCount: 42
    },
    {
        id: "end_times",
        title: "End Times",
        author: "Luna\\_LoveWell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/end_times",
        hfyFoundationUrl: "https://hfy.foundation/series/1000",
        chapterCount: 2
    },
    {
        id: "the_endless_forest",
        title: "The Endless Forest",
        author: "Evil-Emps",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_endless_forest",
        hfyFoundationUrl: "https://hfy.foundation/series/5489",
        chapterCount: 26
    },
    {
        id: "engineering_in_nature",
        title: "Engineering In Nature",
        author: "ArchDragon99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/engineering_in_nature",
        hfyFoundationUrl: "https://hfy.foundation/series/2082",
        chapterCount: 25
    },
    {
        id: "enslaved",
        title: "Enslaved",
        author: "Dezakon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/enslaved",
        hfyFoundationUrl: "https://hfy.foundation/series/116",
        chapterCount: 2
    },
    {
        id: "entangled",
        title: "Entangled",
        author: "voodooattack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/entangled",
        hfyFoundationUrl: "https://hfy.foundation/series/867",
        chapterCount: 4
    },
    {
        id: "enzydi",
        title: "Enzydi",
        author: "Bunnytob",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/enzydi",
        hfyFoundationUrl: "https://hfy.foundation/series/2724",
        chapterCount: 12
    },
    {
        id: "the_epic_of_fredrick_jones",
        title: "The Epic Of Fredrick Jones",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_epic_of_fredrick_jones",
        hfyFoundationUrl: "https://hfy.foundation/series/2085",
        chapterCount: 32
    },
    {
        id: "the_era_of_victory",
        title: "The Era of Victory",
        author: "RegalCopper",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_era_of_victory",
        hfyFoundationUrl: "https://hfy.foundation/series/752",
        chapterCount: 3
    },
    {
        id: "the_eridani_maneuver",
        title: "The Eridani Maneuver",
        author: "Tactical_Puke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_eridani_maneuver",
        hfyFoundationUrl: "https://hfy.foundation/series/963",
        chapterCount: 18
    },
    {
        id: "essence_eater",
        title: "Essence Eater",
        author: "cheffyjayp",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/essence_eater",
        hfyFoundationUrl: "https://hfy.foundation/series/4031",
        chapterCount: 30
    },
    {
        id: "eve_of_ai",
        title: "Eve of AI",
        author: "TheMafi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/eve_of_ai",
        hfyFoundationUrl: "https://hfy.foundation/series/487",
        chapterCount: 18
    },
    {
        id: "every_gun_to_the_line",
        title: "Every Gun To The Line",
        author: "GIJoeVibin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/every_gun_to_the_line",
        hfyFoundationUrl: "https://hfy.foundation/series/2600",
        chapterCount: 36
    },
    {
        id: "everyday_heroes",
        title: "Everyday Heroes",
        author: "Guy-Person",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/everyday_heroes",
        hfyFoundationUrl: "https://hfy.foundation/series/1543",
        chapterCount: 5
    },
    {
        id: "everyone_and_no_one",
        title: "Everyone And No One",
        author: "Plainside",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/everyone_and_no_one",
        hfyFoundationUrl: "https://hfy.foundation/series/1980",
        chapterCount: 6
    },
    {
        id: "everyone_s_a_catgirl",
        title: "Everyone's A Catgirl!",
        author: "DDoubleBlinDD",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/everyones_a_catgirl",
        hfyFoundationUrl: "https://hfy.foundation/series/3311",
        chapterCount: 224
    },
    {
        id: "evil",
        title: "Evil?",
        author: "Zephylandantus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/evil",
        hfyFoundationUrl: "https://hfy.foundation/series/2244",
        chapterCount: 4
    },
    {
        id: "exchange_program",
        title: "Exchange Program",
        author: "Original_Richgame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exchange_program",
        hfyFoundationUrl: "https://hfy.foundation/series/3170",
        chapterCount: 3
    },
    {
        id: "exogen",
        title: "Exogen",
        author: "DemonicDugtrio",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exogen",
        hfyFoundationUrl: "https://hfy.foundation/series/1358",
        chapterCount: 14
    },
    {
        id: "expectations",
        title: "Expectations",
        author: "BlibbidyBlab",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/expectations",
        hfyFoundationUrl: "https://hfy.foundation/series/538",
        chapterCount: 9
    },
    {
        id: "the_expedition",
        title: "The Expedition",
        author: "Pastah_Farian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_expedition",
        hfyFoundationUrl: "https://hfy.foundation/series/1111",
        chapterCount: 2
    },
    {
        id: "the_expedition_2",
        title: "The Expedition",
        author: "ainsleyeadams",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_expedition_ainsleyeadams",
        hfyFoundationUrl: "https://hfy.foundation/series/2690",
        chapterCount: 3
    },
    {
        id: "explaining_consciousness",
        title: "Explaining Consciousness",
        author: "ainsleyeadams",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/explaining_consciousness",
        hfyFoundationUrl: "https://hfy.foundation/series/2670",
        chapterCount: 2
    },
    {
        id: "the_explorer",
        title: "The Explorer",
        author: "Missing-Neuron",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_explorer",
        hfyFoundationUrl: "https://hfy.foundation/series/3200",
        chapterCount: 42
    },
    {
        id: "extant",
        title: "Extant",
        author: "toshredsyousay2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/extant",
        hfyFoundationUrl: "https://hfy.foundation/series/1452",
        chapterCount: 16
    },
    {
        id: "extermination_order",
        title: "Extermination Order",
        author: "Zander823's other works",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/extermination_order",
        hfyFoundationUrl: "https://hfy.foundation/series/3394",
        chapterCount: 53
    },
    {
        id: "an_extinct_race_revived",
        title: "An Extinct Race Revived",
        author: "yet-another-writer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_extinct_race_revived",
        hfyFoundationUrl: "https://hfy.foundation/series/3341",
        chapterCount: 11
    },
    {
        id: "extradimensional_exchange_students",
        title: "Extradimensional Exchange Students",
        author: "boardkey-striker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/extradimensional_exchange_students",
        hfyFoundationUrl: "https://hfy.foundation/series/3857",
        chapterCount: 4
    },
    {
        id: "the_face_of_adversity",
        title: "The Face Of Adversity",
        author: "kiwispacemarine",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_face_of_adversity",
        hfyFoundationUrl: "https://hfy.foundation/series/2065",
        chapterCount: 24
    },
    {
        id: "fairy_tale",
        title: "Fairy Tale",
        author: "Science_and_Pasta",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fairy_tale",
        hfyFoundationUrl: "https://hfy.foundation/series/747",
        chapterCount: 2
    },
    {
        id: "the_fall_of_civilization",
        title: "The Fall of Civilization",
        author: "fuckyeahmoment",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fall_of_civilization",
        hfyFoundationUrl: "https://hfy.foundation/series/140",
        chapterCount: 3
    },
    {
        id: "the_fall_of_eden",
        title: "The Fall of Eden",
        author: "generic_nerd96",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fall_of_eden",
        hfyFoundationUrl: "https://hfy.foundation/series/705",
        chapterCount: 17
    },
    {
        id: "the_fallen_are_watching",
        title: "The Fallen Are Watching",
        author: "Vaughen1919",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fallen_are_watching",
        hfyFoundationUrl: "https://hfy.foundation/series/4055",
        chapterCount: 4
    },
    {
        id: "far_from_home",
        title: "Far From Home",
        author: "lucasAK2004",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/far_from_home",
        hfyFoundationUrl: "https://hfy.foundation/series/2292",
        chapterCount: 4
    },
    {
        id: "feathers_asunder",
        title: "Feathers Asunder",
        author: "Link",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/feathers_asunder",
        hfyFoundationUrl: "https://hfy.foundation/series/2527",
        chapterCount: 13
    },
    {
        id: "the_feed",
        title: "The Feed",
        author: "Infernalism",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_feed",
        hfyFoundationUrl: "https://hfy.foundation/series/1178",
        chapterCount: 4
    },
    {
        id: "ferocity",
        title: "Ferocity",
        author: "Nikvidia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ferocity",
        hfyFoundationUrl: "https://hfy.foundation/series/4013",
        chapterCount: 13
    },
    {
        id: "field_notes_on_sol_3",
        title: "Field Notes On Sol-3",
        author: "Khenal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/field_notes_on_sol3",
        hfyFoundationUrl: "https://hfy.foundation/series/1048",
        chapterCount: 10
    },
    {
        id: "fieldless",
        title: "Fieldless",
        author: "DarkTrio",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fieldless",
        hfyFoundationUrl: "https://hfy.foundation/series/1080",
        chapterCount: 18
    },
    {
        id: "files_from_the_imperial_academy_of_sciences_xenobiology_division",
        title: "Files from the Imperial Academy of Sciences, Xenobiology Division",
        author: "TOSCAA",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/files_from_the_imperial_academy",
        hfyFoundationUrl: "https://hfy.foundation/series/462",
        chapterCount: 3
    },
    {
        id: "filii_ignis",
        title: "Filii Ignis",
        author: "Herocooky",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/filii_ignis",
        hfyFoundationUrl: "https://hfy.foundation/series/1141",
        chapterCount: 5
    },
    {
        id: "the_final_frontier",
        title: "The Final Frontier",
        author: "[iliveinsingapore]",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_final_frontier",
        hfyFoundationUrl: "https://hfy.foundation/series/179",
        chapterCount: 8
    },
    {
        id: "finding_grace",
        title: "Finding Grace",
        author: "PaleDirewolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/finding_grace",
        hfyFoundationUrl: "https://hfy.foundation/series/3510",
        chapterCount: 46
    },
    {
        id: "finding_posella",
        title: "Finding Posella",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/finding_posella",
        hfyFoundationUrl: "https://hfy.foundation/series/4122",
        chapterCount: 44
    },
    {
        id: "fire_within",
        title: "Fire Within",
        author: "Swimming\\_Good\\_8507",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fire_within",
        hfyFoundationUrl: "https://hfy.foundation/series/3427",
        chapterCount: 31
    },
    {
        id: "fires_of_the_sky",
        title: "Fires Of The Sky",
        author: "KingoftheRednecks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fires_of_the_sky",
        hfyFoundationUrl: "https://hfy.foundation/series/4159",
        chapterCount: 42
    },
    {
        id: "first_contact",
        title: "\"First\" Contact",
        author: "HowToAMA",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_howtoama",
        hfyFoundationUrl: "https://hfy.foundation/series/870",
        chapterCount: 4
    },
    {
        id: "first_contact_2",
        title: "First Contact",
        author: "Ackbarre",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/86",
        chapterCount: 5
    },
    {
        id: "first_contact_3",
        title: "First Contact",
        author: "CaptainChewbacca",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_captainchewbacca",
        hfyFoundationUrl: "https://hfy.foundation/series/273",
        chapterCount: 3
    },
    {
        id: "first_contact_4",
        title: "First Contact",
        author: "ChadManning1989",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_chadmanning1989",
        hfyFoundationUrl: "https://hfy.foundation/series/1281",
        chapterCount: 20
    },
    {
        id: "first_contact_5",
        title: "First Contact",
        author: "Ralts_Bloodthorne",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_ralts_bloodthorne",
        hfyFoundationUrl: "https://hfy.foundation/series/2128",
        chapterCount: 1014
    },
    {
        id: "first_contact_6",
        title: "First Contact",
        author: "SomeoneForgetable",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_someoneforgetable",
        hfyFoundationUrl: "https://hfy.foundation/series/831",
        chapterCount: 3
    },
    {
        id: "first_contact_protocols",
        title: "First Contact Protocols",
        author: "AndaBrit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_protocols",
        hfyFoundationUrl: "https://hfy.foundation/series/926",
        chapterCount: 9
    },
    {
        id: "first_contact_with_fluid_based_life",
        title: "First Contact With Fluid Based Life",
        author: "Ana_Gramm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_with_fluid_based_life",
        hfyFoundationUrl: "https://hfy.foundation/series/1089",
        chapterCount: 3
    },
    {
        id: "first_contact_with_the_iss",
        title: "First Contact With The ISS",
        author: "Nellthe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_with_the_iss",
        hfyFoundationUrl: "https://hfy.foundation/series/4286",
        chapterCount: 25
    },
    {
        id: "the_first_human_at_the_mage_academy",
        title: "The First Human At The Mage Academy",
        author: "Random3x",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_first_human_at_the_mage_academy",
        hfyFoundationUrl: "https://hfy.foundation/series/4606",
        chapterCount: 84
    },
    {
        id: "the_first_true_voyagers",
        title: "The First True Voyagers",
        author: "Frostdraken",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_first_true_voyagers",
        hfyFoundationUrl: "https://hfy.foundation/series/3665",
        chapterCount: 45
    },
    {
        id: "firstborne",
        title: "Firstborne",
        author: "Oradainer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/firstborne",
        hfyFoundationUrl: "https://hfy.foundation/series/4500",
        chapterCount: 27
    },
    {
        id: "fist_of_the_gods",
        title: "Fist Of The Gods",
        author: "BewilderedBatlamyus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fist_of_the_gods",
        hfyFoundationUrl: "https://hfy.foundation/series/1764",
        chapterCount: 4
    },
    {
        id: "the_flame_of_faith",
        title: "The Flame of Faith",
        author: "Jalapenyobuisness",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_flame_of_faith",
        hfyFoundationUrl: "https://hfy.foundation/series/144",
        chapterCount: 2
    },
    {
        id: "flight_delayed",
        title: "Flight Delayed",
        author: "vvv\\_Valkyrie\\_vvv",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/flight_delayed",
        hfyFoundationUrl: "https://hfy.foundation/series/1648",
        chapterCount: 9
    },
    {
        id: "flight_of_prometheus",
        title: "Flight Of Prometheus",
        author: "DWL52-2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/flight_of_prometheus",
        hfyFoundationUrl: "https://hfy.foundation/series/5392",
        chapterCount: 12
    },
    {
        id: "the_flight_of_the_human_legion",
        title: "The Flight of the Human Legion",
        author: "Prince_of_Savoy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_flight_of_the_human_legion",
        hfyFoundationUrl: "https://hfy.foundation/series/136",
        chapterCount: 36
    },
    {
        id: "fluffballs",
        title: "Fluffballs",
        author: "CrazyRocketEngineer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fluffballs",
        hfyFoundationUrl: "https://hfy.foundation/series/797",
        chapterCount: 4
    },
    {
        id: "the_flying_castle_of_vyzerworth",
        title: "The Flying Castle Of Vyzerworth",
        author: "DropShotEpee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_flying_castle_of_vyzerworth",
        hfyFoundationUrl: "https://hfy.foundation/series/2970",
        chapterCount: 5
    },
    {
        id: "follow_the_drinking_gourd",
        title: "Follow The Drinking Gourd",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/follow_the_drinking_gourd",
        hfyFoundationUrl: "https://hfy.foundation/series/1628",
        chapterCount: 7
    },
    {
        id: "the_force_behind_ftl",
        title: "The Force Behind FTL",
        author: "FerroMancer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_force_behind_ftl",
        hfyFoundationUrl: "https://hfy.foundation/series/3399",
        chapterCount: 28
    },
    {
        id: "foreign_warning",
        title: "Foreign Warning",
        author: "AdeptSilence",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/foreign_warning",
        hfyFoundationUrl: "https://hfy.foundation/series/1451",
        chapterCount: 4
    },
    {
        id: "the_forgotten_race",
        title: "The Forgotten Race",
        author: "justaRegular911",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_forgotten_race",
        hfyFoundationUrl: "https://hfy.foundation/series/3897",
        chapterCount: 4
    },
    {
        id: "the_forsaken",
        title: "The Forsaken",
        author: "Bunnytob",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_forsaken",
        hfyFoundationUrl: "https://hfy.foundation/series/2823",
        chapterCount: 6
    },
    {
        id: "the_forty_eight_minute_affair",
        title: "The Forty-eight Minute Affair",
        author: "Crocmon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fortyeight_minute_affair",
        hfyFoundationUrl: "https://hfy.foundation/series/2986",
        chapterCount: 7
    },
    {
        id: "found_families",
        title: "Found Families",
        author: "endersgame69",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/found_families",
        hfyFoundationUrl: "https://hfy.foundation/series/4062",
        chapterCount: 46
    },
    {
        id: "the_founder_s_strain",
        title: "The Founder's Strain",
        author: "DBrush",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_founders_strain",
        hfyFoundationUrl: "https://hfy.foundation/series/1568",
        chapterCount: 38
    },
    {
        id: "the_foundling",
        title: "The Foundling",
        author: "Polite\\_Badger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_foundling",
        hfyFoundationUrl: "https://hfy.foundation/series/2606",
        chapterCount: 26
    },
    {
        id: "four_sisters_of_the_apocalypse",
        title: "Four Sisters Of The Apocalypse",
        author: "AlexWolffe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/four_sisters_of_the_apocalypse",
        hfyFoundationUrl: "https://hfy.foundation/series/2591",
        chapterCount: 4
    },
    {
        id: "the_fourth_wave",
        title: "The Fourth Wave",
        author: "Semiloki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fourth_wave",
        hfyFoundationUrl: "https://hfy.foundation/series/362",
        chapterCount: 125
    },
    {
        id: "freaks",
        title: "Freaks",
        author: "JacobGreyson",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/freaks",
        hfyFoundationUrl: "https://hfy.foundation/series/250",
        chapterCount: 11
    },
    {
        id: "free_men",
        title: "Free Men",
        author: "JustARandomCatholic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/free_men",
        hfyFoundationUrl: "https://hfy.foundation/series/147",
        chapterCount: 2
    },
    {
        id: "frenzy",
        title: "Frenzy",
        author: "Carsenere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/frenzy",
        hfyFoundationUrl: "https://hfy.foundation/series/107",
        chapterCount: 6
    },
    {
        id: "fresh_meat",
        title: "Fresh Meat",
        author: "matrixdestiny",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fresh_meat",
        hfyFoundationUrl: "https://hfy.foundation/series/125",
        chapterCount: 6
    },
    {
        id: "friend_or_foe",
        title: "Friend Or Foe?",
        author: "lainmelle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/friend_or_foe",
        hfyFoundationUrl: "https://hfy.foundation/series/2669",
        chapterCount: 5
    },
    {
        id: "friends_in_low_places",
        title: "Friends In Low Places",
        author: "NyarlathotepWatches",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/friends_in_low_places",
        hfyFoundationUrl: "https://hfy.foundation/series/3778",
        chapterCount: 14
    },
    {
        id: "from_tooth_and_nail_to_fangs_and_claws",
        title: "From Tooth And Nail To Fangs And Claws",
        author: "Mistery_E",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/from_tooth_and_nail_to_fangs_and_claws",
        hfyFoundationUrl: "https://hfy.foundation/series/3276",
        chapterCount: 7
    },
    {
        id: "frontier_fantasy",
        title: "Frontier Fantasy",
        author: "BrodogIsMyName",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/frontier_fantasy",
        hfyFoundationUrl: "https://hfy.foundation/series/5171",
        chapterCount: 27
    },
    {
        id: "frontier_medicine",
        title: "Frontier Medicine",
        author: "Xentaps",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/frontier_medicine",
        hfyFoundationUrl: "https://hfy.foundation/series/1586",
        chapterCount: 3
    },
    {
        id: "frost_demons_from_beyond_the_stars",
        title: "Frost Demons From Beyond The Stars",
        author: "Lopakin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/frost_demons_from_beyond_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/2865",
        chapterCount: 24
    },
    {
        id: "frozen_homes",
        title: "Frozen Homes",
        author: "AngryaboutVideogames",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/frozen_homes",
        hfyFoundationUrl: "https://hfy.foundation/series/2274",
        chapterCount: 211
    },
    {
        id: "fuck_it",
        title: "Fuck It",
        author: "Wiffypitts",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fuck_it",
        hfyFoundationUrl: "https://hfy.foundation/series/256",
        chapterCount: 7
    },
    {
        id: "fuck_you_nature",
        title: "Fuck You, Nature!",
        author: "KronicBoom3",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fuck_you_nature",
        hfyFoundationUrl: "https://hfy.foundation/series/3748",
        chapterCount: 57
    },
    {
        id: "fuel",
        title: "FUEL",
        author: "starson",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fuel",
        hfyFoundationUrl: "https://hfy.foundation/series/286",
        chapterCount: 7
    },
    {
        id: "gaia_s_chosen",
        title: "Gaia's Chosen",
        author: "Bringmemorebooze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gaias_chosen",
        hfyFoundationUrl: "https://hfy.foundation/series/916",
        chapterCount: 2
    },
    {
        id: "gaianverse",
        title: "Gaianverse",
        author: "Madnyth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gaianverse",
        hfyFoundationUrl: "https://hfy.foundation/series/2121",
        chapterCount: 72
    },
    {
        id: "galactic_daycare",
        title: "Galactic Daycare",
        author: "Count_Mechula",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galactic_daycare",
        hfyFoundationUrl: "https://hfy.foundation/series/2913",
        chapterCount: 32
    },
    {
        id: "galactic_economics",
        title: "Galactic Economics",
        author: "rook-iv",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galactic_economics",
        hfyFoundationUrl: "https://hfy.foundation/series/2633",
        chapterCount: 23
    },
    {
        id: "galactic_high",
        title: "Galactic High",
        author: "Spartawolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galactic_high",
        hfyFoundationUrl: "https://hfy.foundation/series/3663",
        chapterCount: 109
    },
    {
        id: "galaxy",
        title: "Galaxy",
        author: "Kubrick_Fan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galaxy",
        hfyFoundationUrl: "https://hfy.foundation/series/67",
        chapterCount: 2
    },
    {
        id: "galaxy_of_chaos",
        title: "Galaxy Of Chaos",
        author: "IowaKidd97",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galaxy_of_chaos",
        hfyFoundationUrl: "https://hfy.foundation/series/1619",
        chapterCount: 23
    },
    {
        id: "the_galaxy_s_worst_superheros",
        title: "The Galaxy's Worst Superheros",
        author: "HenryFordYork",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_galaxys_worst_superheroes",
        hfyFoundationUrl: "https://hfy.foundation/series/820",
        chapterCount: 4
    },
    {
        id: "a_game_of_stars",
        title: "A Game Of Stars",
        author: "Kubrick_Fan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_game_of_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/68",
        chapterCount: 13
    },
    {
        id: "gamers",
        title: "Gamers",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gamers",
        hfyFoundationUrl: "https://hfy.foundation/series/1955",
        chapterCount: 7
    },
    {
        id: "these_games_we_play",
        title: "These Games We Play",
        author: "TheFirstMillionWords",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/these_games_we_play",
        hfyFoundationUrl: "https://hfy.foundation/series/1870",
        chapterCount: 2
    },
    {
        id: "garden_of_the_gods",
        title: "Garden of the Gods",
        author: "Blerkler",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/garden_of_the_gods",
        hfyFoundationUrl: "https://hfy.foundation/series/1312",
        chapterCount: 8
    },
    {
        id: "the_gardens_of_deathworlders",
        title: "The Gardens Of Deathworlders",
        author: "micktalian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gardens_of_deathworlders",
        hfyFoundationUrl: "https://hfy.foundation/series/4535",
        chapterCount: 155
    },
    {
        id: "the_gates",
        title: "The Gates",
        author: "PepperAntique",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gates",
        hfyFoundationUrl: "https://hfy.foundation/series/2610",
        chapterCount: 8
    },
    {
        id: "the_general",
        title: "The General",
        author: "Chimera\\_Tracker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_general",
        hfyFoundationUrl: "https://hfy.foundation/series/3449",
        chapterCount: 4
    },
    {
        id: "generations",
        title: "Generations",
        author: "toclacl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/generations",
        hfyFoundationUrl: "https://hfy.foundation/series/482",
        chapterCount: 4
    },
    {
        id: "genocide",
        title: "Genocide",
        author: "ulobmoga",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/genocide",
        hfyFoundationUrl: "https://hfy.foundation/series/337",
        chapterCount: 2
    },
    {
        id: "a_ghost_arises",
        title: "A Ghost Arises",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_ghost_arises",
        hfyFoundationUrl: "https://hfy.foundation/series/2254",
        chapterCount: 5
    },
    {
        id: "a_ghost_in_the_flesh",
        title: "A Ghost In The Flesh",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_ghost_in_the_flesh",
        hfyFoundationUrl: "https://hfy.foundation/series/2040",
        chapterCount: 30
    },
    {
        id: "a_ghost_in_the_machine",
        title: "A Ghost In The Machine",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_ghost_in_the_machine",
        hfyFoundationUrl: "https://hfy.foundation/series/1803",
        chapterCount: 30
    },
    {
        id: "ghost_ship",
        title: "Ghost Ship",
        author: "Mrkhrum",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ghost_ship_mrkhrum",
        hfyFoundationUrl: "https://hfy.foundation/series/4860",
        chapterCount: 9
    },
    {
        id: "gifts_from_the_beyond",
        title: "Gifts From The Beyond",
        author: "Echonaster124",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gifts_from_the_beyond",
        hfyFoundationUrl: "https://hfy.foundation/series/4727",
        chapterCount: 12
    },
    {
        id: "give_them_a_chance",
        title: "Give Them A Chance",
        author: "GIJoeVibin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/give_them_a_chance",
        hfyFoundationUrl: "https://hfy.foundation/series/2378",
        chapterCount: 3
    },
    {
        id: "glass",
        title: "Glass",
        author: "BoringAl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/glass",
        hfyFoundationUrl: "https://hfy.foundation/series/184",
        chapterCount: 5
    },
    {
        id: "a_glimpse_into_the_void",
        title: "A Glimpse into The Void",
        author: "Yuckwitte",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_glimpse_into_the_void",
        hfyFoundationUrl: "https://hfy.foundation/series/80",
        chapterCount: 6
    },
    {
        id: "glitches_in_the_universe",
        title: "Glitches in the Universe",
        author: "xenotechie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/glitches_in_the_universe",
        hfyFoundationUrl: "https://hfy.foundation/series/438",
        chapterCount: 10
    },
    {
        id: "the_god_butchers",
        title: "The God Butchers",
        author: "TrulyVisceral",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_god_butchers",
        hfyFoundationUrl: "https://hfy.foundation/series/1624",
        chapterCount: 7
    },
    {
        id: "the_god_of_fate",
        title: "The God of Fate",
        author: "CTMGame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_god_of_fate",
        hfyFoundationUrl: "https://hfy.foundation/series/628",
        chapterCount: 7
    },
    {
        id: "the_god_signal",
        title: "The God Signal",
        author: "DeeJayKoolNuts",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_god_signal",
        hfyFoundationUrl: "https://hfy.foundation/series/943",
        chapterCount: 19
    },
    {
        id: "the_gods_are_mortal",
        title: "The Gods are Mortal",
        author: "Blastch",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gods_are_mortal",
        hfyFoundationUrl: "https://hfy.foundation/series/1134",
        chapterCount: 4
    },
    {
        id: "gods_of_war",
        title: "Gods of War",
        author: "Coldfire15651",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gods_of_war",
        hfyFoundationUrl: "https://hfy.foundation/series/27",
        chapterCount: 4
    },
    {
        id: "gods_of_war_2",
        title: "Gods Of War",
        author: "The_Caleb_Mac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gods_of_war_the_caleb_mac",
        hfyFoundationUrl: "https://hfy.foundation/series/2952",
        chapterCount: 7
    },
    {
        id: "gods_saviors_people",
        title: "Gods, Saviors, People",
        author: "Click Here",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gods_saviors_people",
        hfyFoundationUrl: "https://hfy.foundation/series/3013",
        chapterCount: 28
    },
    {
        id: "the_golden_disk",
        title: "The Golden Disk",
        author: "pepelesadbot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_golden_disk",
        hfyFoundationUrl: "https://hfy.foundation/series/3095",
        chapterCount: 78
    },
    {
        id: "the_golden_pelican_of_heaven",
        title: "The Golden Pelican Of Heaven",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_golden_pelican_of_heaven",
        hfyFoundationUrl: "https://hfy.foundation/series/1577",
        chapterCount: 5
    },
    {
        id: "good_morning_class",
        title: "Good Morning, Class",
        author: "terrachron",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/good_morning_class",
        hfyFoundationUrl: "https://hfy.foundation/series/703",
        chapterCount: 10
    },
    {
        id: "grand_design",
        title: "Grand Design",
        author: "TMarkos",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/grand_design",
        hfyFoundationUrl: "https://hfy.foundation/series/1496",
        chapterCount: 45
    },
    {
        id: "the_grand_war",
        title: "The Grand War",
        author: "IAmTotallyOriginal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_grand_war",
        hfyFoundationUrl: "https://hfy.foundation/series/1731",
        chapterCount: 4
    },
    {
        id: "the_great_and_somewhat_over_the_top_galaxy_wars",
        title: "The Great And Somewhat Over The Top Galaxy Wars",
        author: "Illwood_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_great_and_somewhat_over_the_top_galaxy_wars",
        hfyFoundationUrl: "https://hfy.foundation/series/3807",
        chapterCount: 4
    },
    {
        id: "the_great_eng",
        title: "The Great Eng",
        author: "bontrose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_great_eng",
        hfyFoundationUrl: "https://hfy.foundation/series/874",
        chapterCount: 6
    },
    {
        id: "the_great_erectus_and_faun",
        title: "The Great Erectus And Faun",
        author: "slightlyassholic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_great_erectus_and_faun",
        hfyFoundationUrl: "https://hfy.foundation/series/3011",
        chapterCount: 61
    },
    {
        id: "the_great_galactic_war",
        title: "The Great Galactic War",
        author: "czs5056",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_great_galactic_war",
        hfyFoundationUrl: "https://hfy.foundation/series/798",
        chapterCount: 2
    },
    {
        id: "the_great_mistake_humans_aren_t_pets",
        title: "The Great Mistake: Humans Aren't Pets",
        author: "CatFish21sm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_great_mistake_humans_arent_pets",
        hfyFoundationUrl: "https://hfy.foundation/series/4802",
        chapterCount: 11
    },
    {
        id: "the_great_war",
        title: "The Great War",
        author: "pairt_2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_great_war",
        hfyFoundationUrl: "https://hfy.foundation/series/323",
        chapterCount: 9
    },
    {
        id: "the_greatest_strategist",
        title: "The Greatest Strategist",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_greatest_strategist",
        hfyFoundationUrl: "https://hfy.foundation/series/1441",
        chapterCount: 57
    },
    {
        id: "gremlins",
        title: "Gremlins",
        author: "TimetravelingGuide",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gremlins",
        hfyFoundationUrl: "https://hfy.foundation/series/2785",
        chapterCount: 71
    },
    {
        id: "the_gremlins",
        title: "The Gremlins",
        author: "BigWuffle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gremlins",
        hfyFoundationUrl: "https://hfy.foundation/series/1087",
        chapterCount: 38
    },
    {
        id: "grin_and_bear_it",
        title: "Grin and Bear It",
        author: "jakethesnakebakecake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/grin_and_bear_it",
        hfyFoundationUrl: "https://hfy.foundation/series/589",
        chapterCount: 2
    },
    {
        id: "growing_up_alien",
        title: "Growing Up Alien",
        author: "Adventurous-Map-9400",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/growing_up_alien",
        hfyFoundationUrl: "https://hfy.foundation/series/4457",
        chapterCount: 31
    },
    {
        id: "a_guessing_game",
        title: "A Guessing Game",
        author: "FeatherFallen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_guessing_game",
        hfyFoundationUrl: "https://hfy.foundation/series/986",
        chapterCount: 2
    },
    {
        id: "guided_progress",
        title: "Guided Progress",
        author: "Rapdactyl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/guided_progress",
        hfyFoundationUrl: "https://hfy.foundation/series/49",
        chapterCount: 4
    },
    {
        id: "gun_run",
        title: "Gun Run",
        author: "MementoMori-3",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gun_run",
        hfyFoundationUrl: "https://hfy.foundation/series/656",
        chapterCount: 3
    },
    {
        id: "halfway_point",
        title: "Halfway Point",
        author: "A_Simple_Peach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/halfway_point",
        hfyFoundationUrl: "https://hfy.foundation/series/2410",
        chapterCount: 10
    },
    {
        id: "hard_lessons",
        title: "Hard Lessons",
        author: "Firestormecho22",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hard_lessons",
        hfyFoundationUrl: "https://hfy.foundation/series/2541",
        chapterCount: 3
    },
    {
        id: "hardstuck",
        title: "Hardstuck",
        author: "arekban",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hardstuck",
        hfyFoundationUrl: "https://hfy.foundation/series/5124",
        chapterCount: 12
    },
    {
        id: "hardwired",
        title: "Hardwired",
        author: "darkPrince010",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hardwired",
        hfyFoundationUrl: "https://hfy.foundation/series/1040",
        chapterCount: 44
    },
    {
        id: "harvest_of_sorrows",
        title: "Harvest Of Sorrows",
        author: "BurjAlJerkwad",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/harvest_of_sorrows",
        hfyFoundationUrl: "https://hfy.foundation/series/5526",
        chapterCount: 13
    },
    {
        id: "have_humans_will_drop",
        title: "Have Humans, Will Drop",
        author: "PrussianJoe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/have_humans_will_drop",
        hfyFoundationUrl: "https://hfy.foundation/series/742",
        chapterCount: 5
    },
    {
        id: "he_and_she",
        title: "He and She",
        author: "Ziccu",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/he_and_she",
        hfyFoundationUrl: "https://hfy.foundation/series/314",
        chapterCount: 4
    },
    {
        id: "he_was_human",
        title: "He Was Human",
        author: "Red_Riviera",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/he_was_human",
        hfyFoundationUrl: "https://hfy.foundation/series/2110",
        chapterCount: 12
    },
    {
        id: "he_will_be_remembered",
        title: "He Will Be Remembered",
        author: "AdeptSilence",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/he_will_be_remembered",
        hfyFoundationUrl: "https://hfy.foundation/series/948",
        chapterCount: 3
    },
    {
        id: "the_heart_of_the_ring",
        title: "The Heart Of The Ring",
        author: "Zarkovik",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_heart_of_the_ring",
        hfyFoundationUrl: "https://hfy.foundation/series/3071",
        chapterCount: 2
    },
    {
        id: "the_heartless_ranger",
        title: "The Heartless Ranger",
        author: "Whovian41110",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_heartless_ranger",
        hfyFoundationUrl: "https://hfy.foundation/series/2018",
        chapterCount: 44
    },
    {
        id: "hearts_and_armour",
        title: "Hearts and Armour",
        author: "TheGentGamer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hearts_and_armour",
        hfyFoundationUrl: "https://hfy.foundation/series/257",
        chapterCount: 9
    },
    {
        id: "heat_nsfw",
        title: "Heat(NSFW)",
        author: "Czarchasem",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/heat",
        hfyFoundationUrl: "https://hfy.foundation/series/330",
        chapterCount: 2
    },
    {
        id: "hedge_knight",
        title: "Hedge Knight",
        author: "grierks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hedge_knight",
        hfyFoundationUrl: "https://hfy.foundation/series/4345",
        chapterCount: 58
    },
    {
        id: "the_hel_jumper",
        title: "The HEL Jumper",
        author: "SabatonBabylon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hel_jumper",
        hfyFoundationUrl: "https://hfy.foundation/series/1285",
        chapterCount: 178
    },
    {
        id: "hell_difficulty_tutorial",
        title: "Hell Difficulty Tutorial",
        author: "NoWallaby6855",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hell_difficulty_tutorial",
        hfyFoundationUrl: "https://hfy.foundation/series/5147",
        chapterCount: 60
    },
    {
        id: "hellfire_across_the_heavens",
        title: "Hellfire Across The Heavens",
        author: "SocialTel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hellfire_across_the_heavens",
        hfyFoundationUrl: "https://hfy.foundation/series/2684",
        chapterCount: 12
    },
    {
        id: "the_herald",
        title: "The Herald",
        author: "VagrantScrub",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_herald",
        hfyFoundationUrl: "https://hfy.foundation/series/2647",
        chapterCount: 6
    },
    {
        id: "heritage",
        title: "Heritage",
        author: "SynthoStellar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/heritage",
        hfyFoundationUrl: "https://hfy.foundation/series/2092",
        chapterCount: 41
    },
    {
        id: "the_hero",
        title: "The Hero",
        author: "Haenir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hero",
        hfyFoundationUrl: "https://hfy.foundation/series/513",
        chapterCount: 18
    },
    {
        id: "heroes_in_the_making",
        title: "Heroes In The Making",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/heroes_in_the_making",
        hfyFoundationUrl: "https://hfy.foundation/series/4722",
        chapterCount: 39
    },
    {
        id: "hidden_adversary",
        title: "Hidden Adversary",
        author: "Special-Brain5256",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hidden_adversary",
        hfyFoundationUrl: "https://hfy.foundation/series/5045",
        chapterCount: 4
    },
    {
        id: "high_tally",
        title: "High Tally",
        author: "ejpxtd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/high_tally",
        hfyFoundationUrl: "https://hfy.foundation/series/1643",
        chapterCount: 13
    },
    {
        id: "hire_a_human_engineer",
        title: "Hire A Human Engineer",
        author: "Solid-Childhood-4876",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/hire_a_human_engineer",
        hfyFoundationUrl: "https://hfy.foundation/series/5510",
        chapterCount: 16
    },
    {
        id: "history_of_the_sol_war",
        title: "History Of The Sol War",
        author: "eddieddi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/history_of_the_sol_war",
        hfyFoundationUrl: "https://hfy.foundation/series/2385",
        chapterCount: 13
    },
    {
        id: "history_sometimes_repeats",
        title: "History Sometimes Repeats",
        author: "Pondello",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/history_sometimes_repeats",
        hfyFoundationUrl: "https://hfy.foundation/series/121",
        chapterCount: 2
    },
    {
        id: "hive",
        title: "Hive",
        author: "AdventurousAerie7151",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hive",
        hfyFoundationUrl: "https://hfy.foundation/series/4897",
        chapterCount: 18
    },
    {
        id: "hobo_hero",
        title: "Hobo Hero",
        author: "ResponsibilitySad331",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hobo_hero",
        hfyFoundationUrl: "https://hfy.foundation/series/4472",
        chapterCount: 25
    },
    {
        id: "hold_my_beer",
        title: "Hold My Beer",
        author: "2kN",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hold_my_beer",
        hfyFoundationUrl: "https://hfy.foundation/series/971",
        chapterCount: 7
    },
    {
        id: "homebound",
        title: "Homebound",
        author: "crazy-ann559",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/homebound",
        hfyFoundationUrl: "https://hfy.foundation/series/1709",
        chapterCount: 5
    },
    {
        id: "the_home_worlders",
        title: "The Home Worlders",
        author: "Nnudmac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_home_worlders",
        hfyFoundationUrl: "https://hfy.foundation/series/3511",
        chapterCount: 8
    },
    {
        id: "honorary_human",
        title: "Honorary Human",
        author: "iceman0486",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/honorary_human",
        hfyFoundationUrl: "https://hfy.foundation/series/1400",
        chapterCount: 3
    },
    {
        id: "hope_in_the_darkness",
        title: "Hope In The Darkness",
        author: "Aumnayan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hope_in_the_darkness",
        hfyFoundationUrl: "https://hfy.foundation/series/3057",
        chapterCount: 3
    },
    {
        id: "a_horror",
        title: "A Horror",
        author: "eotyrannus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_horror",
        hfyFoundationUrl: "https://hfy.foundation/series/247",
        chapterCount: 4
    },
    {
        id: "the_horrors_we_choose",
        title: "The Horrors We Choose",
        author: "BlackCrescentWorks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_horrors_we_choose",
        hfyFoundationUrl: "https://hfy.foundation/series/4203",
        chapterCount: 16
    },
    {
        id: "house_guest",
        title: "House Guest",
        author: "MakeshiftShapeshift",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/house_guest",
        hfyFoundationUrl: "https://hfy.foundation/series/1539",
        chapterCount: 11
    },
    {
        id: "house_of_the_golden_oak",
        title: "House of the Golden Oak",
        author: "The_Nerian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/house_of_the_golden_oak",
        hfyFoundationUrl: "https://hfy.foundation/series/965",
        chapterCount: 24
    },
    {
        id: "how_did_we_get_here",
        title: "How Did We Get Here",
        author: "Syvajarvi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_did_we_get_here",
        hfyFoundationUrl: "https://hfy.foundation/series/3661",
        chapterCount: 24
    },
    {
        id: "how_i_became_a_reaper",
        title: "How I Became A Reaper",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_i_became_a_reaper",
        hfyFoundationUrl: "https://hfy.foundation/series/3404",
        chapterCount: 44
    },
    {
        id: "how_to_shoot_lightning",
        title: "How to Shoot Lightning",
        author: "thePatchyBeard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_to_shoot_lightning",
        hfyFoundationUrl: "https://hfy.foundation/series/98",
        chapterCount: 6
    },
    {
        id: "how_to_train_your_prey",
        title: "How To Train Your Prey",
        author: "Douglasjm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_to_train_your_prey",
        hfyFoundationUrl: "https://hfy.foundation/series/3728",
        chapterCount: 4
    },
    {
        id: "hsvs_voyager_prime",
        title: "HSVS Voyager Prime",
        author: "Tartahyuga",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hsvs_voyager_prime",
        hfyFoundationUrl: "https://hfy.foundation/series/2342",
        chapterCount: 50
    },
    {
        id: "human",
        title: "Human",
        author: "CataclysmicRhythmic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human",
        hfyFoundationUrl: "https://hfy.foundation/series/2772",
        chapterCount: 22
    },
    {
        id: "human_air_support",
        title: "Human Air Support",
        author: "Spicymuffins89",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_air_support",
        hfyFoundationUrl: "https://hfy.foundation/series/1171",
        chapterCount: 2
    },
    {
        id: "human_allies",
        title: "Human Allies",
        author: "GreyWulfen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_allies",
        hfyFoundationUrl: "https://hfy.foundation/series/891",
        chapterCount: 2
    },
    {
        id: "human_and_ai_love_story",
        title: "Human And AI Love Story",
        author: "SirScreamsABit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_and_ai_love_story",
        hfyFoundationUrl: "https://hfy.foundation/series/2824",
        chapterCount: 31
    },
    {
        id: "the_human_artificial_hivemind",
        title: "The Human Artificial Hivemind",
        author: "Storms_Wrath",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_artificial_hivemind",
        hfyFoundationUrl: "https://hfy.foundation/series/3553",
        chapterCount: 474
    },
    {
        id: "the_human_expert_series",
        title: "The Human Expert Series",
        author: "LeewardNitemare",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_expert_series",
        hfyFoundationUrl: "https://hfy.foundation/series/310",
        chapterCount: 15
    },
    {
        id: "the_human_from_a_dungeon",
        title: "The Human From A Dungeon",
        author: "itsdirector",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_from_a_dungeon",
        hfyFoundationUrl: "https://hfy.foundation/series/5031",
        chapterCount: 58
    },
    {
        id: "human_games_bugs_and_boys",
        title: "Human Games: Bugs and Boys",
        author: "chipathing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bugs_and_boys",
        hfyFoundationUrl: "https://hfy.foundation/series/1052",
        chapterCount: 17
    },
    {
        id: "human_games",
        title: "Human Games",
        author: "chipathing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_games",
        hfyFoundationUrl: "https://hfy.foundation/series/942",
        chapterCount: 27
    },
    {
        id: "the_human_is_bored",
        title: "The Human Is Bored",
        author: "I-Own-A-Voice",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_is_bored",
        hfyFoundationUrl: "https://hfy.foundation/series/2201",
        chapterCount: 85
    },
    {
        id: "human_neighbors",
        title: "Human Neighbors",
        author: "Lostfol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_neighbors",
        hfyFoundationUrl: "https://hfy.foundation/series/1666",
        chapterCount: 10
    },
    {
        id: "human_out_of_time",
        title: "Human Out Of Time",
        author: "monster_bloger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_out_of_time",
        hfyFoundationUrl: "https://hfy.foundation/series/3439",
        chapterCount: 46
    },
    {
        id: "human_question",
        title: "Human Question",
        author: "Ourcraft78",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_question",
        hfyFoundationUrl: "https://hfy.foundation/series/3534",
        chapterCount: 12
    },
    {
        id: "the_human_race",
        title: "The Human Race",
        author: "Sacamato",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_race",
        hfyFoundationUrl: "https://hfy.foundation/series/618",
        chapterCount: 3
    },
    {
        id: "human_rights",
        title: "Human Rights",
        author: "PuzzleheadedCharge4",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_rights",
        hfyFoundationUrl: "https://hfy.foundation/series/2090",
        chapterCount: 10
    },
    {
        id: "human_school",
        title: "Human School",
        author: "zachomara",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_school",
        hfyFoundationUrl: "https://hfy.foundation/series/3359",
        chapterCount: 37
    },
    {
        id: "the_human_security_officer",
        title: "The Human Security Officer",
        author: "Telemachusfar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_security_officer",
        hfyFoundationUrl: "https://hfy.foundation/series/4942",
        chapterCount: 38
    },
    {
        id: "human_slaves",
        title: "Human Slaves",
        author: "Sarius1997",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_slaves",
        hfyFoundationUrl: "https://hfy.foundation/series/774",
        chapterCount: 9
    },
    {
        id: "human_stingers",
        title: "Human Stingers",
        author: "NumerousSun4282",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_stingers",
        hfyFoundationUrl: "https://hfy.foundation/series/3810",
        chapterCount: 6
    },
    {
        id: "human_technology_advancement_is_different_than_logic_dictates",
        title: "Human Technology Advancement is Different than Logic Dictates",
        author: "NoVirtue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_technology_advancement_is_different_than_logic_dictates",
        hfyFoundationUrl: "https://hfy.foundation/series/22",
        chapterCount: 11
    },
    {
        id: "human_vengeance",
        title: "Human Vengeance",
        author: "Shalidar13",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_vengeance",
        hfyFoundationUrl: "https://hfy.foundation/series/3840",
        chapterCount: 34
    },
    {
        id: "the_human_vocabulary_and_culture",
        title: "The Human Vocabulary and Culture",
        author: "Agent78787",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_vocabulary_and_culture",
        hfyFoundationUrl: "https://hfy.foundation/series/51",
        chapterCount: 2
    },
    {
        id: "humanities_first_contact_gone_oh_so_right",
        title: "Humanities First Contact Gone Oh, So Right",
        author: "Akmedrah",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanities_first_contact_gone_oh_so_right",
        hfyFoundationUrl: "https://hfy.foundation/series/3264",
        chapterCount: 73
    },
    {
        id: "humanity_and_law",
        title: "Humanity and Law",
        author: "dinnbach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanity_and_law",
        hfyFoundationUrl: "https://hfy.foundation/series/14",
        chapterCount: 16
    },
    {
        id: "humanity_and_the_arani",
        title: "Humanity And The Arani",
        author: "MasterofNopes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanity_and_the_arani",
        hfyFoundationUrl: "https://hfy.foundation/series/3973",
        chapterCount: 16
    },
    {
        id: "humanity_fucks_you",
        title: "Humanity Fucks You",
        author: "unseenshadow2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanity_fucks_you",
        hfyFoundationUrl: "https://hfy.foundation/series/2298",
        chapterCount: 25
    },
    {
        id: "humanity_redeemed",
        title: "Humanity Redeemed",
        author: "HereToNotBeElsewhere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanity_redeemed",
        hfyFoundationUrl: "https://hfy.foundation/series/216",
        chapterCount: 2
    },
    {
        id: "humanity_s_awakening",
        title: "Humanity's Awakening",
        author: "Feyfyre1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanitys_awakening",
        hfyFoundationUrl: "https://hfy.foundation/series/3871",
        chapterCount: 424
    },
    {
        id: "humanity_s_twisted_gods",
        title: "Humanity's Twisted Gods",
        author: "Sigruldar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanitys_twisted_gods",
        hfyFoundationUrl: "https://hfy.foundation/series/3521",
        chapterCount: 13
    },
    {
        id: "on_humans",
        title: "On Humans",
        author: "DioriteIgneous",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/on_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/2362",
        chapterCount: 8
    },
    {
        id: "humans_are_alone_in_their_lack_of_psychic_abilities",
        title: "Humans Are Alone In Their Lack Of Psychic Abilities",
        author: "chickenstrips1290",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_alone_in_their_lack_of_psychic_abilities",
        hfyFoundationUrl: "https://hfy.foundation/series/3949",
        chapterCount: 7
    },
    {
        id: "humans_are_cosmic_horrors",
        title: "Humans Are Cosmic Horrors",
        author: "Tibbhipsylous",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_cosmic_horrors",
        hfyFoundationUrl: "https://hfy.foundation/series/4118",
        chapterCount: 10
    },
    {
        id: "the_humans_are_here",
        title: "The Humans Are Here",
        author: "CherubielOne",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_humans_are_here",
        hfyFoundationUrl: "https://hfy.foundation/series/5396",
        chapterCount: 11
    },
    {
        id: "humans_are_hiveminds",
        title: "Humans Are Hiveminds",
        author: "Earthfall10",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_hiveminds",
        hfyFoundationUrl: "https://hfy.foundation/series/2247",
        chapterCount: 18
    },
    {
        id: "humans_are_so_dense",
        title: "Humans Are So Dense",
        author: "Gaza1121",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_so_dense",
        hfyFoundationUrl: "https://hfy.foundation/series/4350",
        chapterCount: 5
    },
    {
        id: "humans_are_stubborn",
        title: "Humans Are Stubborn",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_stubborn",
        hfyFoundationUrl: "https://hfy.foundation/series/3904",
        chapterCount: 3
    },
    {
        id: "humans_are_the_precursors",
        title: "Humans Are The Precursors",
        author: "NightmareChameleon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_the_precursors",
        hfyFoundationUrl: "https://hfy.foundation/series/5178",
        chapterCount: 16
    },
    {
        id: "humans_are_unnerving",
        title: "Humans Are Unnerving",
        author: "ZombieRedditer9188",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_unnerving",
        hfyFoundationUrl: "https://hfy.foundation/series/2814",
        chapterCount: 9
    },
    {
        id: "humans_are_weird",
        title: "Humans Are Weird",
        author: "Betty-Adams",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_weird",
        hfyFoundationUrl: "https://hfy.foundation/series/1691",
        chapterCount: 362
    },
    {
        id: "humans_can_t_breathe_underwater",
        title: "Humans Can't Breathe Underwater",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_cant_breathe_underwater",
        hfyFoundationUrl: "https://hfy.foundation/series/3948",
        chapterCount: 3
    },
    {
        id: "humans_do_what_with_artificial_gravity",
        title: "Humans Do What With Artificial Gravity?!",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_do_what_with_artificial_gravity_",
        hfyFoundationUrl: "https://hfy.foundation/series/4171",
        chapterCount: 6
    },
    {
        id: "humans_don_t_hibernate",
        title: "Humans Don't Hibernate",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_dont_hibernate",
        hfyFoundationUrl: "https://hfy.foundation/series/4048",
        chapterCount: 81
    },
    {
        id: "humans_don_t_make_good_familiars",
        title: "Humans Don't Make Good Familiars",
        author: "ArcAngel98",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_dont_make_good_familiars",
        hfyFoundationUrl: "https://hfy.foundation/series/3007",
        chapterCount: 215
    },
    {
        id: "humans_survive",
        title: "Humans Survive",
        author: "Antirandomguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_survive",
        hfyFoundationUrl: "https://hfy.foundation/series/287",
        chapterCount: 4
    },
    {
        id: "humans_to_the_rescue_again",
        title: "Humans To The Rescue... Again",
        author: "In_sa_ni_ty",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_to_the_rescue_again",
        hfyFoundationUrl: "https://hfy.foundation/series/3198",
        chapterCount: 2
    },
    {
        id: "humans_will_pack_bond_with_anything_even_a_cannon",
        title: "Humans Will Pack Bond With Anything, Even A Cannon",
        author: "ThatOneAsswipe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_will_pack_bond_with_anything_even_a_cannon",
        hfyFoundationUrl: "https://hfy.foundation/series/3079",
        chapterCount: 3
    },
    {
        id: "humans_will_use_any_weapon",
        title: "Humans Will Use Any Weapon",
        author: "unseenshadow2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_will_use_any_weapon",
        hfyFoundationUrl: "https://hfy.foundation/series/2590",
        chapterCount: 10
    },
    {
        id: "the_hunted",
        title: "The Hunted",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hunted",
        hfyFoundationUrl: "https://hfy.foundation/series/1046",
        chapterCount: 3
    },
    {
        id: "hunter_or_huntress",
        title: "Hunter Or Huntress",
        author: "Tigra21",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hunter_or_huntress",
        hfyFoundationUrl: "https://hfy.foundation/series/2453",
        chapterCount: 213
    },
    {
        id: "hunters",
        title: "Hunters",
        author: "meterion",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hunters",
        hfyFoundationUrl: "https://hfy.foundation/series/559",
        chapterCount: 2
    },
    {
        id: "the_hunter_s_journey",
        title: "The Hunter's Journey",
        author: "The_Fallen_1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hunters_journey",
        hfyFoundationUrl: "https://hfy.foundation/series/2382",
        chapterCount: 387
    },
    {
        id: "hunting_with_predators",
        title: "Hunting With Predators",
        author: "Banancake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hunting_with_predators",
        hfyFoundationUrl: "https://hfy.foundation/series/4218",
        chapterCount: 26
    },
    {
        id: "hyperion",
        title: "Hyperion",
        author: "Haenir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hyperion",
        hfyFoundationUrl: "https://hfy.foundation/series/552",
        chapterCount: 6
    },
    {
        id: "i_am_legion_i_am_mother",
        title: "I Am Legion. I Am Mother.",
        author: "Grand-sea-emperor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_am_legion_i_am_mother",
        hfyFoundationUrl: "https://hfy.foundation/series/2767",
        chapterCount: 103
    },
    {
        id: "i_am_the_monster_the_world_needs",
        title: "I Am The Monster The World Needs",
        author: "Right_Attempt_3311",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_am_the_monster_the_world_needs",
        hfyFoundationUrl: "https://hfy.foundation/series/5174",
        chapterCount: 112
    },
    {
        id: "i_became_the_most_powerful_entity_in_the_universe_what_could_go_wrong",
        title: "I Became The Most Powerful Entity In The Universe. What Could Go Wrong?",
        author: "Code-V",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_became_the_most_powerful_entity_in_the_universe_what_could_go_wrong",
        hfyFoundationUrl: "https://hfy.foundation/series/2599",
        chapterCount: 16
    },
    {
        id: "i_guess_i_joined_the_demon_horde",
        title: "I Guess I Joined The Demon Horde",
        author: "TheGamingOnion",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_guess_i_joined_the_demon_horde",
        hfyFoundationUrl: "https://hfy.foundation/series/3960",
        chapterCount: 12
    },
    {
        id: "i_have_become",
        title: "I Have Become",
        author: "HamsterIV",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_have_become",
        hfyFoundationUrl: "https://hfy.foundation/series/1550",
        chapterCount: 18
    },
    {
        id: "i_seek_vengeance",
        title: "I Seek Vengeance",
        author: "EzekielWinters",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_seek_vengeance",
        hfyFoundationUrl: "https://hfy.foundation/series/5497",
        chapterCount: 3
    },
    {
        id: "i_want_to_be_the_dark_lord",
        title: "I Want To Be The Dark Lord",
        author: "SoulSlingers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_want_to_be_the_dark_lord",
        hfyFoundationUrl: "https://hfy.foundation/series/4637",
        chapterCount: 14
    },
    {
        id: "i_ve_been_reincarnated_as_a_bunny_girl",
        title: "I've Been Reincarnated As A Bunny Girl?!",
        author: "ShadowDragon88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ive_been_reincarnated_as_a_bunny_girl",
        hfyFoundationUrl: "https://hfy.foundation/series/4949",
        chapterCount: 14
    },
    {
        id: "i_ve_done_and_fuck_up",
        title: "I've Done And Fuck Up!",
        author: "VICXIII",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ive_done_and_fuck_up",
        hfyFoundationUrl: "https://hfy.foundation/series/3606",
        chapterCount: 66
    },
    {
        id: "iced_hearts",
        title: "Iced Hearts",
        author: "Professional\\_Prune11",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/iced_hearts",
        hfyFoundationUrl: "https://hfy.foundation/series/5211",
        chapterCount: 44
    },
    {
        id: "the_idiot_machine",
        title: "The Idiot Machine",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_idiot_machine",
        hfyFoundationUrl: "https://hfy.foundation/series/1951",
        chapterCount: 4
    },
    {
        id: "idiots_dragged_to_war",
        title: "Idiots Dragged To War",
        author: "dothhathdepression",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/idiots_dragged_to_war",
        hfyFoundationUrl: "https://hfy.foundation/series/1984",
        chapterCount: 18
    },
    {
        id: "if_only_we_had_known",
        title: "If Only We Had Known",
        author: "Lilian_Clearwaters",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/if_only_we_had_known",
        hfyFoundationUrl: "https://hfy.foundation/series/3004",
        chapterCount: 2
    },
    {
        id: "if_you_want_peace_prepare_for_war",
        title: "If You Want Peace, Prepare For War",
        author: "ubermidget1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/if_you_want_peace_prepare_for_war",
        hfyFoundationUrl: "https://hfy.foundation/series/311",
        chapterCount: 43
    },
    {
        id: "immortal_farmer",
        title: "Immortal Farmer",
        author: "EGO_10",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/immortal_farmer",
        hfyFoundationUrl: "https://hfy.foundation/series/4328",
        chapterCount: 20
    },
    {
        id: "the_impossible",
        title: "The Impossible",
        author: "ThreeDucksInAManSuit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_impossible",
        hfyFoundationUrl: "https://hfy.foundation/series/1749",
        chapterCount: 6
    },
    {
        id: "the_impossible_solar_system",
        title: "The Impossible Solar System",
        author: "zachomara",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_impossible_solar_system",
        hfyFoundationUrl: "https://hfy.foundation/series/3292",
        chapterCount: 10
    },
    {
        id: "the_immortal_roman_empress",
        title: "The Immortal Roman Empress",
        author: "ClawofBeta",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_immortal_roman_empress",
        hfyFoundationUrl: "https://hfy.foundation/series/846",
        chapterCount: 53
    },
    {
        id: "in_the_hall_of_the_mountain_king",
        title: "In the Hall of the Mountain King",
        author: "CaptainChewbacca",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hall_of_the_mountain_king",
        hfyFoundationUrl: "https://hfy.foundation/series/502",
        chapterCount: 4
    },
    {
        id: "in_the_void_of_war",
        title: "In The Void Of War",
        author: "BlantantlyAccidental",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/in_the_void_of_war",
        hfyFoundationUrl: "https://hfy.foundation/series/4405",
        chapterCount: 15
    },
    {
        id: "industrial_magicks",
        title: "Industrial Magicks",
        author: "IAmTotallyOriginal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/industrial_magicks",
        hfyFoundationUrl: "https://hfy.foundation/series/1745",
        chapterCount: 3
    },
    {
        id: "inexorable",
        title: "Inexorable",
        author: "matrixdestiny",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/inexorable",
        hfyFoundationUrl: "https://hfy.foundation/series/87",
        chapterCount: 3
    },
    {
        id: "infinite_library",
        title: "Infinite Library",
        author: "DrawingTofu",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/infinite_library",
        hfyFoundationUrl: "https://hfy.foundation/series/3623",
        chapterCount: 17
    },
    {
        id: "inheritors_of_eschaton",
        title: "Inheritors Of Eschaton",
        author: "TMarkos",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/inheritors_of_eschaton",
        hfyFoundationUrl: "https://hfy.foundation/series/2035",
        chapterCount: 67
    },
    {
        id: "insignificant_blue_dot",
        title: "Insignificant Blue Dot",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/insignificant_blue_dot",
        hfyFoundationUrl: "https://hfy.foundation/series/1972",
        chapterCount: 45
    },
    {
        id: "insurgent",
        title: "Insurgent",
        author: "Redditors_Username",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/insurgent",
        hfyFoundationUrl: "https://hfy.foundation/series/3865",
        chapterCount: 28
    },
    {
        id: "insurrection_of_the_immortals",
        title: "Insurrection Of The Immortals",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/insurrection_of_the_immortals",
        hfyFoundationUrl: "https://hfy.foundation/series/1620",
        chapterCount: 8
    },
    {
        id: "intake",
        title: "Intake",
        author: "Luponius",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/intake",
        hfyFoundationUrl: "https://hfy.foundation/series/4059",
        chapterCount: 12
    },
    {
        id: "intelligence_core",
        title: "Intelligence Core",
        author: "AJMansfield_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/intelligence_core",
        hfyFoundationUrl: "https://hfy.foundation/series/1221",
        chapterCount: 3
    },
    {
        id: "interactive_education",
        title: "Interactive Education",
        author: "bellumaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interactive_education",
        hfyFoundationUrl: "https://hfy.foundation/series/917",
        chapterCount: 96
    },
    {
        id: "intergalactic_exchange_students",
        title: "Intergalactic Exchange Students",
        author: "NinjaMonkey4200",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/intergalactic_exchange_students",
        hfyFoundationUrl: "https://hfy.foundation/series/2938",
        chapterCount: 47
    },
    {
        id: "intergalactic_challenge_games",
        title: "Intergalactic Challenge Games",
        author: "Ma7ich",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/intergalactic_challenge_games",
        hfyFoundationUrl: "https://hfy.foundation/series/479",
        chapterCount: 5
    },
    {
        id: "interloper",
        title: "Interloper",
        author: "RadPahrak",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interloper",
        hfyFoundationUrl: "https://hfy.foundation/series/2894",
        chapterCount: 11
    },
    {
        id: "interloper_2",
        title: "Interloper",
        author: "Professional_Prune11",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interloper_professional_prune11",
        hfyFoundationUrl: "https://hfy.foundation/series/4712",
        chapterCount: 16
    },
    {
        id: "interspecies_combat_games",
        title: "Interspecies Combat Games",
        author: "mgsl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interspecies_combat_games",
        hfyFoundationUrl: "https://hfy.foundation/series/2448",
        chapterCount: 5
    },
    {
        id: "into_the_dark",
        title: "Into The Dark",
        author: "cmdr_shadowstalker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/into_the_dark",
        hfyFoundationUrl: "https://hfy.foundation/series/3329",
        chapterCount: 5
    },
    {
        id: "into_the_wild",
        title: "Into The Wild",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/into_the_wild",
        hfyFoundationUrl: "https://hfy.foundation/series/105",
        chapterCount: 7
    },
    {
        id: "into_what_is_impossible",
        title: "Into What Is Impossible",
        author: "Admiral_Naehum",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/into_what_is_impossible",
        hfyFoundationUrl: "https://hfy.foundation/series/1820",
        chapterCount: 6
    },
    {
        id: "introducing_the_galaxy_to_bluffing_and_pyrrhic_victory",
        title: "Introducing the galaxy to bluffing and Pyrrhic victory",
        author: "cctsfr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/introducing_the_galaxy_to_bluffing_and_pyrrhic_victory",
        hfyFoundationUrl: "https://hfy.foundation/series/150",
        chapterCount: 2
    },
    {
        id: "invivo",
        title: "Invivo",
        author: "PTMDragon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/invivo",
        hfyFoundationUrl: "https://hfy.foundation/series/195",
        chapterCount: 2
    },
    {
        id: "ion_trail",
        title: "Ion Trail",
        author: "DariusWolfe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ion_trail",
        hfyFoundationUrl: "https://hfy.foundation/series/1430",
        chapterCount: 33
    },
    {
        id: "the_iron_mother",
        title: "The Iron Mother",
        author: "The_Black_Apostle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_iron_mother",
        hfyFoundationUrl: "https://hfy.foundation/series/249",
        chapterCount: 5
    },
    {
        id: "isekai_janitor",
        title: "Isekai Janitor",
        author: "Leather-Pound-6375",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/isekai_janitor",
        hfyFoundationUrl: "https://hfy.foundation/series/5316",
        chapterCount: 11
    },
    {
        id: "isekai_of_the_ultimate_ritualist",
        title: "Isekai Of The Ultimate Ritualist",
        author: "lucader881",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/isekai_of_the_ultimate_ritualist",
        hfyFoundationUrl: "https://hfy.foundation/series/4733",
        chapterCount: 39
    },
    {
        id: "isolation_sickness",
        title: "Isolation Sickness",
        author: "Xavius\\_Night",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/isolation_sickness",
        hfyFoundationUrl: "https://hfy.foundation/series/3052",
        chapterCount: 2
    },
    {
        id: "it_stops_here",
        title: "It Stops Here",
        author: "werecoonwarden",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/it_stops_here",
        hfyFoundationUrl: "https://hfy.foundation/series/2612",
        chapterCount: 16
    },
    {
        id: "it_took_six_years",
        title: "It Took Six Years...",
        author: "ZakkaryGreenwell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/it_took_six_years",
        hfyFoundationUrl: "https://hfy.foundation/series/4080",
        chapterCount: 19
    },
    {
        id: "it_s_the_murloc_life_for_me",
        title: "It's The Murloc Life For Me",
        author: "ImATree2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/its_the_murloc_life_for_me",
        hfyFoundationUrl: "https://hfy.foundation/series/4215",
        chapterCount: 17
    },
    {
        id: "ixian_empire_aftermath",
        title: "Ixian Empire: Aftermath",
        author: "EquestriAsura",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ixian_empire_aftermath",
        hfyFoundationUrl: "https://hfy.foundation/series/2295",
        chapterCount: 25
    },
    {
        id: "the_jack",
        title: "The Jack",
        author: "KIGrey",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_jack",
        hfyFoundationUrl: "https://hfy.foundation/series/1269",
        chapterCount: 5
    },
    {
        id: "jacob_the_monster",
        title: "Jacob the Monster",
        author: "starson",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/jacob_the_monster",
        hfyFoundationUrl: "https://hfy.foundation/series/219",
        chapterCount: 11
    },
    {
        id: "the_jade_tiger",
        title: "The Jade Tiger",
        author: "Glacialfury",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_jade_tiger",
        hfyFoundationUrl: "https://hfy.foundation/series/1431",
        chapterCount: 2
    },
    {
        id: "the_janitor",
        title: "The Janitor",
        author: "GasserHQ",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_janitor",
        hfyFoundationUrl: "https://hfy.foundation/series/2653",
        chapterCount: 14
    },
    {
        id: "jennifer_is_not_an_eldritch_horror",
        title: "Jennifer Is NOT An Eldritch Horror",
        author: "magicrectangle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/jennifer_is_not_an_eldritch_horror",
        hfyFoundationUrl: "https://hfy.foundation/series/3515",
        chapterCount: 24
    },
    {
        id: "jerry_and_the_goddesses",
        title: "Jerry And The Goddesses",
        author: "MjolnirPants",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/jerry_and_the_goddesses",
        hfyFoundationUrl: "https://hfy.foundation/series/4851",
        chapterCount: 30
    },
    {
        id: "a_job_for_a_deathworlder",
        title: "A Job For A Deathworlder",
        author: "Lanzen_Jars",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_job_for_a_deathworlder",
        hfyFoundationUrl: "https://hfy.foundation/series/2725",
        chapterCount: 316
    },
    {
        id: "the_jogger",
        title: "The Jogger",
        author: "finnegar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_jogger",
        hfyFoundationUrl: "https://hfy.foundation/series/303",
        chapterCount: 5
    },
    {
        id: "john_colby",
        title: "John Colby",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/john_colby",
        hfyFoundationUrl: "https://hfy.foundation/series/977",
        chapterCount: 18
    },
    {
        id: "johnny_comes_marching_home",
        title: "Johnny Comes Marching Home",
        author: "semiloki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/johnny_comes_marching_home",
        hfyFoundationUrl: "https://hfy.foundation/series/428",
        chapterCount: 3
    },
    {
        id: "josh_eckhart",
        title: "Josh Eckhart",
        author: "Didnotseemecomein",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/josh_eckhart",
        hfyFoundationUrl: "https://hfy.foundation/series/3238",
        chapterCount: 24
    },
    {
        id: "a_journey_through_the_apocalypse",
        title: "A Journey Through The Apocalypse",
        author: "ScribblingFox98",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_journey_through_the_apocalypse",
        hfyFoundationUrl: "https://hfy.foundation/series/3477",
        chapterCount: 9
    },
    {
        id: "journeys_of_revival",
        title: "Journeys Of Revival",
        author: "Revolutionary-Big49",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/journeys_of_revival",
        hfyFoundationUrl: "https://hfy.foundation/series/3418",
        chapterCount: 5
    },
    {
        id: "just_a_little_further",
        title: "Just A Little Further",
        author: "jpitha",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/just_a_little_further",
        hfyFoundationUrl: "https://hfy.foundation/series/4948",
        chapterCount: 26
    },
    {
        id: "the_just_species",
        title: "The Just Species",
        author: "i_eat-kids_1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_just_species",
        hfyFoundationUrl: "https://hfy.foundation/series/5234",
        chapterCount: 33
    },
    {
        id: "the_kardashev_scale",
        title: "The Kardashev Scale",
        author: "Jyxxe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_kardashev_scale",
        hfyFoundationUrl: "https://hfy.foundation/series/4497",
        chapterCount: 14
    },
    {
        id: "kaito_seriously_another_world",
        title: "Kaito, Seriously? Another World?",
        author: "veryLazybaker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kaito_seriously_another_world",
        hfyFoundationUrl: "https://hfy.foundation/series/5533",
        chapterCount: 32
    },
    {
        id: "kathekon",
        title: "Kathekon",
        author: "Kitedtk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kathekon",
        hfyFoundationUrl: "https://hfy.foundation/series/1253",
        chapterCount: 5
    },
    {
        id: "the_kevin_jenkins_experience",
        title: "The Kevin Jenkins Experience",
        author: "Hambone3110",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_kevin_jenkins_experience",
        hfyFoundationUrl: "https://hfy.foundation/series/316",
        chapterCount: 119
    },
    {
        id: "kill_the_grims",
        title: "Kill The Grims",
        author: "Xander_Eclipse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kill_the_grims",
        hfyFoundationUrl: "https://hfy.foundation/series/4771",
        chapterCount: 3
    },
    {
        id: "killer_kittens_from_outer_space",
        title: "Killer Kittens From Outer Space",
        author: "SirChickenBurger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/killer_kittens_from_outer_space",
        hfyFoundationUrl: "https://hfy.foundation/series/5612",
        chapterCount: 15
    },
    {
        id: "killshot_apocalypse",
        title: "Killshot Apocalypse",
        author: "Killshot_Apocalypse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/killshot_apocalypse",
        hfyFoundationUrl: "https://hfy.foundation/series/3351",
        chapterCount: 19
    },
    {
        id: "kinetics_and_supernaturals",
        title: "Kinetics And Supernaturals",
        author: "FatedApollo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kinetics_and_supernaturals",
        hfyFoundationUrl: "https://hfy.foundation/series/1920",
        chapterCount: 12
    },
    {
        id: "kings_of_the_sky",
        title: "Kings Of The Sky",
        author: "survivor275",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kings_of_the_sky",
        hfyFoundationUrl: "https://hfy.foundation/series/2218",
        chapterCount: 4
    },
    {
        id: "the_knight_dropped_into_contact",
        title: "The Knight: Dropped Into Contact",
        author: "CaptainMatthew1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_knight_dropped_into_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/4708",
        chapterCount: 45
    },
    {
        id: "krondor_specialist_academy",
        title: "Krondor Specialist Academy",
        author: "MythyDragonwolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/krondor_specialist_academy",
        hfyFoundationUrl: "https://hfy.foundation/series/2449",
        chapterCount: 15
    },
    {
        id: "the_kro_vak_war",
        title: "The Kro'vak War",
        author: "Mechakid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_krovak_war",
        hfyFoundationUrl: "https://hfy.foundation/series/1068",
        chapterCount: 46
    },
    {
        id: "land_of_the_babes",
        title: "Land Of The Babes",
        author: "VorpalZenith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/land_of_the_babes",
        hfyFoundationUrl: "https://hfy.foundation/series/4799",
        chapterCount: 43
    },
    {
        id: "larry",
        title: "Larry",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/larry",
        hfyFoundationUrl: "https://hfy.foundation/series/655",
        chapterCount: 6
    },
    {
        id: "the_last_12_days_on_earth",
        title: "The Last 12 Days On Earth",
        author: "startingtomorrow2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_12_days_on_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/1453",
        chapterCount: 14
    },
    {
        id: "the_last_angel",
        title: "The Last Angel",
        author: "Proximal\\_Flame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_angel",
        hfyFoundationUrl: "https://hfy.foundation/series/1268",
        chapterCount: 104
    },
    {
        id: "the_last_hope",
        title: "The Last Hope",
        author: "Kaizer5243",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_hope",
        hfyFoundationUrl: "https://hfy.foundation/series/2884",
        chapterCount: 9
    },
    {
        id: "the_last_human",
        title: "The Last Human",
        author: "PSHoffman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_human",
        hfyFoundationUrl: "https://hfy.foundation/series/2561",
        chapterCount: 153
    },
    {
        id: "the_last_man_standing",
        title: "The Last Man Standing",
        author: "FlorisTLMS",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_man_standing",
        hfyFoundationUrl: "https://hfy.foundation/series/2237",
        chapterCount: 23
    },
    {
        id: "the_last_progenitor",
        title: "The Last Progenitor",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_progenitor",
        hfyFoundationUrl: "https://hfy.foundation/series/1555",
        chapterCount: 14
    },
    {
        id: "the_last_ship_of_humanity",
        title: "The Last Ship Of Humanity",
        author: "Mussarelinhagames",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_ship_of_humanity",
        hfyFoundationUrl: "https://hfy.foundation/series/4978",
        chapterCount: 14
    },
    {
        id: "the_last_son_of_earth",
        title: "The Last Son of Earth",
        author: "hitchopottimus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_son_of_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/836",
        chapterCount: 2
    },
    {
        id: "the_leaching_tree",
        title: "The Leaching Tree",
        author: "United\\_Bit2904",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_leaching_tree",
        hfyFoundationUrl: "https://hfy.foundation/series/4957",
        chapterCount: 11
    },
    {
        id: "lecture_on_space_and_magic",
        title: "Lecture on Space and Magic",
        author: "riyan_gendut",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lecture_on_space_and_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/932",
        chapterCount: 6
    },
    {
        id: "legacy",
        title: "Legacy",
        author: "Zephylandantus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/legacy",
        hfyFoundationUrl: "https://hfy.foundation/series/2144",
        chapterCount: 11
    },
    {
        id: "legacy_doesn_t_mean_obsolete",
        title: "Legacy Doesn't Mean Obsolete",
        author: "HexKm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/legacy_doesnt_mean_obsolete",
        hfyFoundationUrl: "https://hfy.foundation/series/5267",
        chapterCount: 56
    },
    {
        id: "a_legacy_to_salvage",
        title: "A Legacy To Salvage",
        author: "terran\\_mikkus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_legacy_to_salvage",
        hfyFoundationUrl: "https://hfy.foundation/series/1108",
        chapterCount: 9
    },
    {
        id: "legend",
        title: "Legend",
        author: "UnreliableNarrat0r",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/legend",
        hfyFoundationUrl: "https://hfy.foundation/series/1428",
        chapterCount: 99
    },
    {
        id: "the_legend",
        title: "The Legend",
        author: "kingkongbuddha",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_legend",
        hfyFoundationUrl: "https://hfy.foundation/series/2420",
        chapterCount: 4
    },
    {
        id: "a_lesson_in_scionics",
        title: "A Lesson In Scionics",
        author: "Saint-Andros",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_lesson_in_scionics",
        hfyFoundationUrl: "https://hfy.foundation/series/4892",
        chapterCount: 19
    },
    {
        id: "let_sleeping_dogs_lie",
        title: "Let Sleeping Dogs Lie",
        author: "vvv\\_Valkyrie\\_vvv",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/let_sleeping_dogs_lie",
        hfyFoundationUrl: "https://hfy.foundation/series/1409",
        chapterCount: 9
    },
    {
        id: "lethal_humans",
        title: "Lethal Humans",
        author: "tweakbz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lethal_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/1497",
        chapterCount: 2
    },
    {
        id: "leviathans",
        title: "Leviathans",
        author: "TheWr1ter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/leviathans",
        hfyFoundationUrl: "https://hfy.foundation/series/2032",
        chapterCount: 17
    },
    {
        id: "liberation_day",
        title: "Liberation Day",
        author: "dnqxtsck5",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/liberation_day",
        hfyFoundationUrl: "https://hfy.foundation/series/66",
        chapterCount: 8
    },
    {
        id: "liberation",
        title: "Liberation",
        author: "creaturecoby",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/liberation",
        hfyFoundationUrl: "https://hfy.foundation/series/443",
        chapterCount: 3
    },
    {
        id: "life_as_a_bed_slave",
        title: "Life As A Bed Slave",
        author: "Leather_and_chintz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_as_a_bed_slave",
        hfyFoundationUrl: "https://hfy.foundation/series/3256",
        chapterCount: 25
    },
    {
        id: "life_of_emeron",
        title: "Life Of Emeron",
        author: "Angel466",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_of_emeron",
        hfyFoundationUrl: "https://hfy.foundation/series/3993",
        chapterCount: 77
    },
    {
        id: "the_life_of_a_galactic_postal_employee",
        title: "The Life of a Galactic Postal Employee",
        author: "Kaiden333",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_life_of_a_galactic_postal_employee",
        hfyFoundationUrl: "https://hfy.foundation/series/193",
        chapterCount: 4
    },
    {
        id: "the_life_of_a_teenage_hellworlder",
        title: "The Life Of A Teenage Hellworlder",
        author: "not-so-british-brit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_life_of_a_teenage_hellworlder",
        hfyFoundationUrl: "https://hfy.foundation/series/2409",
        chapterCount: 42
    },
    {
        id: "life_on_jupiter_station",
        title: "Life On Jupiter Station",
        author: "Wiktry",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_on_jupiter_station",
        hfyFoundationUrl: "https://hfy.foundation/series/1646",
        chapterCount: 8
    },
    {
        id: "life_with_an_alien_girlfriend",
        title: "Life With An Alien Girlfriend",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_with_an_alien_girlfriend",
        hfyFoundationUrl: "https://hfy.foundation/series/532",
        chapterCount: 11
    },
    {
        id: "life_s_tangled_skeins",
        title: "Life's Tangled Skeins",
        author: "nevermind1123",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lifes_tangled_skeins",
        hfyFoundationUrl: "https://hfy.foundation/series/4592",
        chapterCount: 41
    },
    {
        id: "a_light_in_the_dark",
        title: "A Light in the Dark",
        author: "Chaelek",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_light_in_the_dark",
        hfyFoundationUrl: "https://hfy.foundation/series/113",
        chapterCount: 7
    },
    {
        id: "lion_and_mirri_s_rent_a_human",
        title: "Lion And Mirri's Rent A Human",
        author: "Assaultkitten",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lion_and_mirris_rent_a_human",
        hfyFoundationUrl: "https://hfy.foundation/series/1975",
        chapterCount: 9
    },
    {
        id: "little_black_boxes",
        title: "Little, Black Boxes",
        author: "Swim_Jong_Eel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/little_black_boxes",
        hfyFoundationUrl: "https://hfy.foundation/series/275",
        chapterCount: 2
    },
    {
        id: "the_little_round_ear_engineer",
        title: "The Little Round-ear Engineer",
        author: "deadeyelee1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_little_roundear_engineer",
        hfyFoundationUrl: "https://hfy.foundation/series/1520",
        chapterCount: 7
    },
    {
        id: "living_with_a_human_crew",
        title: "Living With A Human Crew",
        author: "Sea-Wolverine-882",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/living_with_a_human_crew",
        hfyFoundationUrl: "https://hfy.foundation/series/3463",
        chapterCount: 16
    },
    {
        id: "logs_from_the_sasarian_war",
        title: "Logs from the Sasarian War",
        author: "tentaclesquid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/logs_from_the_sasarian_war",
        hfyFoundationUrl: "https://hfy.foundation/series/203",
        chapterCount: 3
    },
    {
        id: "lonely_souls",
        title: "Lonely Souls",
        author: "MyNameMeansBentNose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lonely_souls",
        hfyFoundationUrl: "https://hfy.foundation/series/1790",
        chapterCount: 29
    },
    {
        id: "a_long_cold_winter",
        title: "A Long Cold Winter",
        author: "Anarcho-Gelatin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_long_cold_winter",
        hfyFoundationUrl: "https://hfy.foundation/series/2269",
        chapterCount: 32
    },
    {
        id: "the_long_game",
        title: "The Long Game",
        author: "webkilla",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_long_game",
        hfyFoundationUrl: "https://hfy.foundation/series/3327",
        chapterCount: 61
    },
    {
        id: "the_long_war_s_newcomers",
        title: "The Long War's Newcomers",
        author: "Gloomius",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_long_wars_newcomers",
        hfyFoundationUrl: "https://hfy.foundation/series/3098",
        chapterCount: 241
    },
    {
        id: "longhunter",
        title: "Longhunter",
        author: "Snekguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/longhunter",
        hfyFoundationUrl: "https://hfy.foundation/series/3541",
        chapterCount: 47
    },
    {
        id: "lord_of_the_flies_of_the_rings",
        title: "Lord Of The Flies Of The Rings",
        author: "FermisFolly",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lord_of_the_flies_of_the_rings",
        hfyFoundationUrl: "https://hfy.foundation/series/2142",
        chapterCount: 20
    },
    {
        id: "lord_protector",
        title: "Lord Protector",
        author: "DefNihilman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lord_protector",
        hfyFoundationUrl: "https://hfy.foundation/series/3808",
        chapterCount: 67
    },
    {
        id: "lords_of_war",
        title: "Lords of War",
        author: "Scotscin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lords_of_war",
        hfyFoundationUrl: "https://hfy.foundation/series/141",
        chapterCount: 47
    },
    {
        id: "lost_boys",
        title: "Lost Boys",
        author: "iceman0486",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lost_boys",
        hfyFoundationUrl: "https://hfy.foundation/series/1424",
        chapterCount: 5
    },
    {
        id: "the_lost_princess",
        title: "The Lost Princess",
        author: "CadobaDelta",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_lost_princess",
        hfyFoundationUrl: "https://hfy.foundation/series/2578",
        chapterCount: 18
    },
    {
        id: "lost_star",
        title: "Lost Star",
        author: "DR-Fluffy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lost_star",
        hfyFoundationUrl: "https://hfy.foundation/series/1638",
        chapterCount: 10
    },
    {
        id: "lotus_station",
        title: "Lotus Station",
        author: "Meatfcker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lotus_station",
        hfyFoundationUrl: "https://hfy.foundation/series/28",
        chapterCount: 7
    },
    {
        id: "love_larceny",
        title: "Love & Larceny",
        author: "Ankar0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/love__larceny",
        hfyFoundationUrl: "https://hfy.foundation/series/3735",
        chapterCount: 9
    },
    {
        id: "love_amongst_the_stars",
        title: "Love Amongst The Stars",
        author: "potato_rocket_05",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/love_amongst_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/2402",
        chapterCount: 10
    },
    {
        id: "luck_and_butterflies",
        title: "Luck And Butterflies",
        author: "vector010",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/luck_and_butterflies",
        hfyFoundationUrl: "https://hfy.foundation/series/1278",
        chapterCount: 2
    },
    {
        id: "the_magi_s_society",
        title: "The Magi's Society",
        author: "Sullengar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_magis_society",
        hfyFoundationUrl: "https://hfy.foundation/series/4700",
        chapterCount: 34
    },
    {
        id: "magic_bus",
        title: "Magic Bus",
        author: "6e6f6e2d62696e617279",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/magic_bus",
        hfyFoundationUrl: "https://hfy.foundation/series/2129",
        chapterCount: 4
    },
    {
        id: "magic_is_programming",
        title: "Magic Is Programming",
        author: "Douglasjm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/magic_is_programming",
        hfyFoundationUrl: "https://hfy.foundation/series/5022",
        chapterCount: 45
    },
    {
        id: "a_magic_of_man",
        title: "A Magic Of Man",
        author: "107zombly",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_magic_of_man",
        hfyFoundationUrl: "https://hfy.foundation/series/2752",
        chapterCount: 6
    },
    {
        id: "the_magineer",
        title: "The Magineer",
        author: "voodooattack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_magineer",
        hfyFoundationUrl: "https://hfy.foundation/series/1075",
        chapterCount: 46
    },
    {
        id: "making_the_greater_good_great_again",
        title: "Making The Greater Good Great Again",
        author: "Slumberfreeze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/making_the_greater_good_great_again",
        hfyFoundationUrl: "https://hfy.foundation/series/1177",
        chapterCount: 10
    },
    {
        id: "man_of_hope",
        title: "Man Of Hope",
        author: "SSB: The only thing that matters",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/man_of_hope",
        hfyFoundationUrl: "https://hfy.foundation/series/4539",
        chapterCount: 39
    },
    {
        id: "the_man_in_the_machine",
        title: "The Man In The Machine",
        author: "HeadSmashDesk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_man_in_the_machine",
        hfyFoundationUrl: "https://hfy.foundation/series/1818",
        chapterCount: 18
    },
    {
        id: "the_man_who_saved_us",
        title: "The Man Who Saved Us",
        author: "TheNoob950",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_man_who_saved_us",
        hfyFoundationUrl: "https://hfy.foundation/series/1922",
        chapterCount: 39
    },
    {
        id: "the_man_with_a_mouse",
        title: "The Man With A Mouse",
        author: "Dr-Autist",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_man_with_a_mouse",
        hfyFoundationUrl: "https://hfy.foundation/series/1735",
        chapterCount: 3
    },
    {
        id: "manifest_fantasy",
        title: "Manifest Fantasy",
        author: "DrDoritosMD",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/manifest_fantasy",
        hfyFoundationUrl: "https://hfy.foundation/series/5432",
        chapterCount: 18
    },
    {
        id: "the_marine",
        title: "The Marine",
        author: "Clokw8rk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_marine",
        hfyFoundationUrl: "https://hfy.foundation/series/1415",
        chapterCount: 29
    },
    {
        id: "marooned",
        title: "Marooned",
        author: "Luna\\_LoveWell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/marooned",
        hfyFoundationUrl: "https://hfy.foundation/series/960",
        chapterCount: 6
    },
    {
        id: "matte_black",
        title: "Matte Black",
        author: "abloobudoo009",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/matte_black",
        hfyFoundationUrl: "https://hfy.foundation/series/595",
        chapterCount: 14
    },
    {
        id: "the_means_of_production",
        title: "The Means Of Production",
        author: "Bergusia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_means_of_production",
        hfyFoundationUrl: "https://hfy.foundation/series/2947",
        chapterCount: 48
    },
    {
        id: "means_of_transportation",
        title: "Means Of Transportation",
        author: "comyk79",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/means_of_transportation",
        hfyFoundationUrl: "https://hfy.foundation/series/4600",
        chapterCount: 4
    },
    {
        id: "the_mechanic",
        title: "The Mechanic",
        author: "luke_poley",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_mechanic",
        hfyFoundationUrl: "https://hfy.foundation/series/154",
        chapterCount: 5
    },
    {
        id: "mech_and_magic",
        title: "Mech And Magic",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mech_and_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/4154",
        chapterCount: 43
    },
    {
        id: "a_mediator_has_breakfast",
        title: "A Mediator has breakfast",
        author: "Eventime",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_mediator_has_breakfast",
        hfyFoundationUrl: "https://hfy.foundation/series/143",
        chapterCount: 2
    },
    {
        id: "the_medical_conference",
        title: "The Medical Conference",
        author: "ShadowDancerBrony",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_medical_conference",
        hfyFoundationUrl: "https://hfy.foundation/series/4012",
        chapterCount: 17
    },
    {
        id: "meet_the_freak",
        title: "Meet The Freak",
        author: "ThisHasNotGoneWell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/meet_the_freak",
        hfyFoundationUrl: "https://hfy.foundation/series/2222",
        chapterCount: 84
    },
    {
        id: "a_meeting_of_shadows",
        title: "A Meeting Of Shadows",
        author: "Xildrax",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_meeting_of_shadows",
        hfyFoundationUrl: "https://hfy.foundation/series/3069",
        chapterCount: 104
    },
    {
        id: "of_men_and_dragons",
        title: "Of Men And Dragons",
        author: "DrBlackJack21",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/of_men_and_dragons",
        hfyFoundationUrl: "https://hfy.foundation/series/2124",
        chapterCount: 220
    },
    {
        id: "of_men_and_spiders",
        title: "Of Men And Spiders",
        author: "DrBlackJack21",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/of_men_and_spiders",
        hfyFoundationUrl: "https://hfy.foundation/series/5187",
        chapterCount: 110
    },
    {
        id: "men_of_silicon_and_steel",
        title: "Men of Silicon and Steel",
        author: "drunkrobot97",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/men_of_silicon_and_steel",
        hfyFoundationUrl: "https://hfy.foundation/series/1",
        chapterCount: 2
    },
    {
        id: "men_with_green_faces",
        title: "Men With Green Faces",
        author: "duddlered",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/men_with_green_faces",
        hfyFoundationUrl: "https://hfy.foundation/series/3638",
        chapterCount: 29
    },
    {
        id: "the_merchants_of_blight",
        title: "The Merchants Of Blight",
        author: "GreenerThngs",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_merchants_of_blight",
        hfyFoundationUrl: "https://hfy.foundation/series/5282",
        chapterCount: 16
    },
    {
        id: "the_mercy_of_humans",
        title: "The Mercy Of Humans",
        author: "LordCoale",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_mercy_of_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/4769",
        chapterCount: 77
    },
    {
        id: "the_messenger",
        title: "The Messenger",
        author: "Bhockzer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_messenger",
        hfyFoundationUrl: "https://hfy.foundation/series/4009",
        chapterCount: 18
    },
    {
        id: "milestones",
        title: "Milestones",
        author: "j1xwnbsr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/milestones",
        hfyFoundationUrl: "https://hfy.foundation/series/576",
        chapterCount: 9
    },
    {
        id: "military_analyst_for_the_galactic_senate",
        title: "Military Analyst For The Galactic Senate",
        author: "FiauraTanks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/military_analyst_for_the_galactic_senate",
        hfyFoundationUrl: "https://hfy.foundation/series/4917",
        chapterCount: 3
    },
    {
        id: "militia_isn_t_service",
        title: "Militia Isn't Service",
        author: "deathB4dessert",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/militia_isnt_service",
        hfyFoundationUrl: "https://hfy.foundation/series/4398",
        chapterCount: 18
    },
    {
        id: "a_milky_way_odyssey",
        title: "A Milky Way Odyssey",
        author: "Mr_Reach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_milky_way_odyssey",
        hfyFoundationUrl: "https://hfy.foundation/series/845",
        chapterCount: 20
    },
    {
        id: "mind_over_matter",
        title: "Mind Over Matter",
        author: "Dantrith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mind_over_matter",
        hfyFoundationUrl: "https://hfy.foundation/series/138",
        chapterCount: 5
    },
    {
        id: "mistakes_of_the_universe",
        title: "Mistakes Of The Universe",
        author: "OperationTechnician",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mistakes_of_the_universe",
        hfyFoundationUrl: "https://hfy.foundation/series/887",
        chapterCount: 21
    },
    {
        id: "mistakes_were_made",
        title: "Mistakes Were Made",
        author: "SpartanR259",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mistakes_were_made",
        hfyFoundationUrl: "https://hfy.foundation/series/1806",
        chapterCount: 5
    },
    {
        id: "monster",
        title: "Monster",
        author: "Fornicious_Fogbottom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/monster",
        hfyFoundationUrl: "https://hfy.foundation/series/2209",
        chapterCount: 69
    },
    {
        id: "the_monster",
        title: "The Monster",
        author: "railmaniac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_monster",
        hfyFoundationUrl: "https://hfy.foundation/series/94",
        chapterCount: 5
    },
    {
        id: "monsterous_adaptability",
        title: "Monsterous Adaptability",
        author: "Expensive-Movie-5021",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/monsterous_adaptability",
        hfyFoundationUrl: "https://hfy.foundation/series/5104",
        chapterCount: 9
    },
    {
        id: "monsters_and_maidens",
        title: "Monsters And Maidens",
        author: "RavniTrappedInANovel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/monsters_and_maidens",
        hfyFoundationUrl: "https://hfy.foundation/series/3390",
        chapterCount: 75
    },
    {
        id: "monstrum_narratus",
        title: "Monstrum Narratus",
        author: "EvilKrista",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/monstrum_narratus",
        hfyFoundationUrl: "https://hfy.foundation/series/4078",
        chapterCount: 7
    },
    {
        id: "moon_s_third_eye",
        title: "Moon's Third Eye",
        author: "97cweb",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/moons_third_eye",
        hfyFoundationUrl: "https://hfy.foundation/series/3630",
        chapterCount: 9
    },
    {
        id: "moonlighting",
        title: "Moonlighting",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/moonlighting",
        hfyFoundationUrl: "https://hfy.foundation/series/451",
        chapterCount: 27
    },
    {
        id: "more_printers_more_problems",
        title: "More Printers, More Problems",
        author: "Capt_Blackmoore",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/more_printers_more_problems",
        hfyFoundationUrl: "https://hfy.foundation/series/1872",
        chapterCount: 2
    },
    {
        id: "the_mortal_acts",
        title: "The Mortal Acts",
        author: "pinnacle\\_preacher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_mortal_acts",
        hfyFoundationUrl: "https://hfy.foundation/series/2638",
        chapterCount: 96
    },
    {
        id: "the_most_glorious_adventures_of_princess_iona_and_her_not_so_well_published_mishaps",
        title: "The Most Glorious Adventures Of Princess Iona (And Her Not So Well-published Mishaps)",
        author: "storywriter109",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_most_glorious_adventures_of_princess_iona_and_her_not_so_wellpublished_mishaps",
        hfyFoundationUrl: "https://hfy.foundation/series/2715",
        chapterCount: 3
    },
    {
        id: "the_most_impressive_planet",
        title: "The Most Impressive Planet!",
        author: "Voltstagge",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_most_impressive_planet",
        hfyFoundationUrl: "https://hfy.foundation/series/398",
        chapterCount: 61
    },
    {
        id: "mostly_human",
        title: "Mostly Human",
        author: "ArctosCinereus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mostly_human",
        hfyFoundationUrl: "https://hfy.foundation/series/1686",
        chapterCount: 31
    },
    {
        id: "mote_of_light",
        title: "Mote of Light",
        author: "generic_nerd96",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mote_of_light",
        hfyFoundationUrl: "https://hfy.foundation/series/773",
        chapterCount: 3
    },
    {
        id: "mountains_when_you_are_just_a_hill",
        title: "Mountains (When You Are Just A Hill)",
        author: "Ourliazo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mountains_when_you_are_just_a_hill",
        hfyFoundationUrl: "https://hfy.foundation/series/5483",
        chapterCount: 12
    },
    {
        id: "musings_of_a_beekeeper",
        title: "Musings Of A Beekeeper",
        author: "Crocmon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/musings_of_a_beekeeper",
        hfyFoundationUrl: "https://hfy.foundation/series/2989",
        chapterCount: 3
    },
    {
        id: "mutations_in_lockdown",
        title: "Mutations in Lockdown",
        author: "blablabliam",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mutations_in_lockdown",
        hfyFoundationUrl: "https://hfy.foundation/series/685",
        chapterCount: 2
    },
    {
        id: "my_best_friend_is_a_deathworlder",
        title: "My Best Friend Is A Deathworlder",
        author: "Sir-Paperbag",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_best_friend_is_a_deathworlder",
        hfyFoundationUrl: "https://hfy.foundation/series/3287",
        chapterCount: 53
    },
    {
        id: "my_journey_to_danmachi",
        title: "My Journey To Danmachi",
        author: "TonoJohn-thespaceorc",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_journey_to_danmachi",
        hfyFoundationUrl: "https://hfy.foundation/series/3741",
        chapterCount: 16
    },
    {
        id: "my_magus_academy_is_run_by_players",
        title: "My Magus Academy Is Run By Players?!",
        author: "AstraMagically",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_magus_academy_is_run_by_players",
        hfyFoundationUrl: "https://hfy.foundation/series/5252",
        chapterCount: 17
    },
    {
        id: "my_own_might",
        title: "My Own Might",
        author: "ReaperTheEmo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_own_might",
        hfyFoundationUrl: "https://hfy.foundation/series/5589",
        chapterCount: 11
    },
    {
        id: "myth_s_adventure",
        title: "Myth's Adventure",
        author: "dinnbach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/myths_adventure",
        hfyFoundationUrl: "https://hfy.foundation/series/120",
        chapterCount: 7
    },
    {
        id: "national_parks",
        title: "National Parks",
        author: "hfyposter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/national_parks",
        hfyFoundationUrl: "https://hfy.foundation/series/4886",
        chapterCount: 10
    },
    {
        id: "nature_of_humanity",
        title: "Nature Of Humanity",
        author: "BiasMushroom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nature_of_humanity",
        hfyFoundationUrl: "https://hfy.foundation/series/4814",
        chapterCount: 55
    },
    {
        id: "nature_of_outcasts",
        title: "Nature Of Outcasts",
        author: "SamakSalmon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nature_of_outcasts",
        hfyFoundationUrl: "https://hfy.foundation/series/4791",
        chapterCount: 11
    },
    {
        id: "the_nature_of_predators",
        title: "The Nature Of Predators",
        author: "SpacePaladin15",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_nature_of_predators",
        hfyFoundationUrl: "https://hfy.foundation/series/3826",
        chapterCount: 193
    },
    {
        id: "necessary_measures",
        title: "Necessary Measures",
        author: "Sinoix",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/necessary_measures",
        hfyFoundationUrl: "https://hfy.foundation/series/108",
        chapterCount: 5
    },
    {
        id: "negotiations_underway",
        title: "Negotiations Underway",
        author: "cbb88christian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/negotiations_underway",
        hfyFoundationUrl: "https://hfy.foundation/series/4830",
        chapterCount: 11
    },
    {
        id: "nektar_reports",
        title: "Nektar Reports",
        author: "Inqeuet",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nektar_reports",
        hfyFoundationUrl: "https://hfy.foundation/series/2145",
        chapterCount: 2
    },
    {
        id: "a_nerd_s_guide_to_deathworld_survival",
        title: "A Nerd's Guide To Deathworld Survival!",
        author: "lordpanzerhund",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_nerds_guide_to_deathworld_survival",
        hfyFoundationUrl: "https://hfy.foundation/series/1395",
        chapterCount: 14
    },
    {
        id: "never_surrender",
        title: "Never Surrender",
        author: "beobabski",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/never_surrender",
        hfyFoundationUrl: "https://hfy.foundation/series/2359",
        chapterCount: 6
    },
    {
        id: "the_neverfought_war",
        title: "The Neverfought War",
        author: "Endemiclegacy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_neverfought_war",
        hfyFoundationUrl: "https://hfy.foundation/series/342",
        chapterCount: 2
    },
    {
        id: "a_new_eden",
        title: "A New Eden",
        author: "Menilik",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_new_eden",
        hfyFoundationUrl: "https://hfy.foundation/series/4333",
        chapterCount: 23
    },
    {
        id: "new_horizons",
        title: "New Horizons",
        author: "Isamov123",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/new_horizons",
        hfyFoundationUrl: "https://hfy.foundation/series/137",
        chapterCount: 18
    },
    {
        id: "new_horizons_2",
        title: "New Horizons",
        author: "Meatfcker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/contact_procedures_new_horizons",
        hfyFoundationUrl: "https://hfy.foundation/series/39",
        chapterCount: 4
    },
    {
        id: "a_new_idea",
        title: "A New Idea",
        author: "Genuine55",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_new_idea",
        hfyFoundationUrl: "https://hfy.foundation/series/1302",
        chapterCount: 32
    },
    {
        id: "the_new_species",
        title: "The New Species",
        author: "itsdirector",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_new_species",
        hfyFoundationUrl: "https://hfy.foundation/series/4400",
        chapterCount: 84
    },
    {
        id: "new_students",
        title: "New Students",
        author: "-ragingpotato-",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/new_students",
        hfyFoundationUrl: "https://hfy.foundation/series/1729",
        chapterCount: 65
    },
    {
        id: "new_terra",
        title: "New Terra",
        author: "Pastah_Farian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/new_terra",
        hfyFoundationUrl: "https://hfy.foundation/series/407",
        chapterCount: 4
    },
    {
        id: "the_newcomer",
        title: "The Newcomer",
        author: "Dr-Mantis-Tobbogan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_newcomer",
        hfyFoundationUrl: "https://hfy.foundation/series/3644",
        chapterCount: 71
    },
    {
        id: "nexus",
        title: "Nexus",
        author: "Mgl1206",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nexus",
        hfyFoundationUrl: "https://hfy.foundation/series/3237",
        chapterCount: 11
    },
    {
        id: "nexus_2",
        title: "Nexus",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nexus_th3frozenpriest",
        hfyFoundationUrl: "https://hfy.foundation/series/3819",
        chapterCount: 109
    },
    {
        id: "nine_out_of_ten",
        title: "Nine Out Of Ten",
        author: "bott99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nine_out_of_ten",
        hfyFoundationUrl: "https://hfy.foundation/series/1583",
        chapterCount: 3
    },
    {
        id: "no_air_in_the_stars",
        title: "No Air In The Stars",
        author: "SkullbombRaging",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_air_in_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/3646",
        chapterCount: 22
    },
    {
        id: "no_honor",
        title: "No Honor",
        author: "Turul___Madar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_honor",
        hfyFoundationUrl: "https://hfy.foundation/series/471",
        chapterCount: 6
    },
    {
        id: "no_longer_a_tourist_attraction",
        title: "No Longer A Tourist Attraction",
        author: "GrimThyGreat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_longer_a_tourist_attraction",
        hfyFoundationUrl: "https://hfy.foundation/series/1341",
        chapterCount: 7
    },
    {
        id: "no_one_left_behind",
        title: "No One Left Behind",
        author: "TinyBard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_one_left_behind",
        hfyFoundationUrl: "https://hfy.foundation/series/1263",
        chapterCount: 4
    },
    {
        id: "no_rest_for_the_wicked",
        title: "No Rest For The Wicked",
        author: "Blursed-Penguin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_rest_for_the_wicked",
        hfyFoundationUrl: "https://hfy.foundation/series/4663",
        chapterCount: 66
    },
    {
        id: "no_separate_peace",
        title: "No Separate Peace",
        author: "stickmaster_flex",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_separate_peace",
        hfyFoundationUrl: "https://hfy.foundation/series/2813",
        chapterCount: 47
    },
    {
        id: "no_simple_beast",
        title: "No Simple Beast",
        author: "CadobaDelta",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_simple_beast",
        hfyFoundationUrl: "https://hfy.foundation/series/4274",
        chapterCount: 57
    },
    {
        id: "no_strings_on_me",
        title: "No Strings On Me",
        author: "ecoolasice",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_strings_on_me",
        hfyFoundationUrl: "https://hfy.foundation/series/3260",
        chapterCount: 5
    },
    {
        id: "nomad",
        title: "Nomad",
        author: "TheBatesRobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nomad",
        hfyFoundationUrl: "https://hfy.foundation/series/1945",
        chapterCount: 12
    },
    {
        id: "the_nomad",
        title: "The Nomad",
        author: "Wolven5",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_nomad",
        hfyFoundationUrl: "https://hfy.foundation/series/3331",
        chapterCount: 21
    },
    {
        id: "none_can_resist_the_power_of",
        title: "None can resist the power of...",
        author: "HenryFordYork",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/none_can_resist_the_power_of",
        hfyFoundationUrl: "https://hfy.foundation/series/805",
        chapterCount: 2
    },
    {
        id: "the_not_immortal_blacksmith",
        title: "The Not-Immortal Blacksmith",
        author: "Vast-Listen1457",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_notimmortal_blacksmith",
        hfyFoundationUrl: "https://hfy.foundation/series/3315",
        chapterCount: 176
    },
    {
        id: "not_as_it_seems",
        title: "Not As It Seems",
        author: "RavniTrappedInANovel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/not_as_it_seems",
        hfyFoundationUrl: "https://hfy.foundation/series/1747",
        chapterCount: 16
    },
    {
        id: "not_your_bronze_age",
        title: "Not Your Bronze Age",
        author: "PAzoo42",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/not_your_bronze_age",
        hfyFoundationUrl: "https://hfy.foundation/series/2460",
        chapterCount: 9
    },
    {
        id: "now_boarding",
        title: "Now Boarding",
        author: "AlanharTheRiver",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/now_boarding",
        hfyFoundationUrl: "https://hfy.foundation/series/4089",
        chapterCount: 33
    },
    {
        id: "nuclear_sub",
        title: "Nuclear Sub",
        author: "PsuchicNRG",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nuclear_sub",
        hfyFoundationUrl: "https://hfy.foundation/series/4067",
        chapterCount: 12
    },
    {
        id: "oafish_gnomes",
        title: "Oafish Gnomes",
        author: "Slumberfreeze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oafish_gnomes",
        hfyFoundationUrl: "https://hfy.foundation/series/1058",
        chapterCount: 4
    },
    {
        id: "off_my_dock",
        title: "Off My Dock",
        author: "KonstanceDucks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/off_my_dock",
        hfyFoundationUrl: "https://hfy.foundation/series/4777",
        chapterCount: 28
    },
    {
        id: "oh_this_has_not_gone_well",
        title: "Oh This Has Not Gone Well",
        author: "ThisHasNotGoneWell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oh_this_has_not_gone_well",
        hfyFoundationUrl: "https://hfy.foundation/series/925",
        chapterCount: 144
    },
    {
        id: "oil_on_troubled_waters",
        title: "Oil On Troubled Waters",
        author: "GIJoeVibin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oil_on_troubled_waters",
        hfyFoundationUrl: "https://hfy.foundation/series/5590",
        chapterCount: 9
    },
    {
        id: "old_age_and_treachery",
        title: "Old Age And Treachery",
        author: "the\\_lonely\\_poster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/old_age_and_treachery",
        hfyFoundationUrl: "https://hfy.foundation/series/5079",
        chapterCount: 13
    },
    {
        id: "one_giant_leap",
        title: "One Giant Leap",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/one_giant_leap",
        hfyFoundationUrl: "https://hfy.foundation/series/1671",
        chapterCount: 38
    },
    {
        id: "one_hell_of_a_vacation",
        title: "One Hell Of A Vacation",
        author: "WaveOfWire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/one_hell_of_a_vacation",
        hfyFoundationUrl: "https://hfy.foundation/series/4495",
        chapterCount: 135
    },
    {
        id: "one_of_a_kind",
        title: "One Of A Kind",
        author: "Acclue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/one_of_a_kind",
        hfyFoundationUrl: "https://hfy.foundation/series/5346",
        chapterCount: 30
    },
    {
        id: "the_ones_that_are",
        title: "The Ones That Are",
        author: "0skar15",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ones_that_are",
        hfyFoundationUrl: "https://hfy.foundation/series/5491",
        chapterCount: 12
    },
    {
        id: "the_only_child",
        title: "The Only Child",
        author: "sweetbabysquirrel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_only_child",
        hfyFoundationUrl: "https://hfy.foundation/series/3777",
        chapterCount: 25
    },
    {
        id: "oops_i_accidentally_started_an_industrial_revolution_in_another_world",
        title: "Oops! I Accidentally Started An Industrial Revolution In Another World",
        author: "pat_campbell42069",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oops_i_accidentally_started_an_industrial_revolution_in_another_world",
        hfyFoundationUrl: "https://hfy.foundation/series/4598",
        chapterCount: 20
    },
    {
        id: "operation_replicator",
        title: "Operation Replicator",
        author: "107zombly",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/operation_replicator",
        hfyFoundationUrl: "https://hfy.foundation/series/1783",
        chapterCount: 3
    },
    {
        id: "operation_snow_eagle",
        title: "Operation Snow Eagle",
        author: "lucasAK2004",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/operation_snow_eagle",
        hfyFoundationUrl: "https://hfy.foundation/series/5238",
        chapterCount: 24
    },
    {
        id: "opposing_views",
        title: "Opposing Views",
        author: "Belgarion262",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/opposing_views",
        hfyFoundationUrl: "https://hfy.foundation/series/118",
        chapterCount: 2
    },
    {
        id: "orc_harem",
        title: "Orc Harem",
        author: "TheoRyswell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/orc_harem",
        hfyFoundationUrl: "https://hfy.foundation/series/4241",
        chapterCount: 10
    },
    {
        id: "orcish_blood",
        title: "Orcish Blood",
        author: "Dejers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/orcish_blood",
        hfyFoundationUrl: "https://hfy.foundation/series/588",
        chapterCount: 11
    },
    {
        id: "the_other_kind_of_god",
        title: "The Other Kind Of God",
        author: "Nyeregog",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_other_kind_of_god",
        hfyFoundationUrl: "https://hfy.foundation/series/4628",
        chapterCount: 8
    },
    {
        id: "the_other_path",
        title: "The Other Path",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_other_path",
        hfyFoundationUrl: "https://hfy.foundation/series/1534",
        chapterCount: 14
    },
    {
        id: "our_blood_sweat_and_tears",
        title: "Our Blood, Sweat And Tears",
        author: "Unoriginal-joker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_blood_sweat_and_tears",
        hfyFoundationUrl: "https://hfy.foundation/series/3387",
        chapterCount: 53
    },
    {
        id: "our_demons_are_their_saints",
        title: "Our Demons Are Their Saints",
        author: "Random3x",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_demons_are_their_saints",
        hfyFoundationUrl: "https://hfy.foundation/series/3144",
        chapterCount: 17
    },
    {
        id: "our_differences",
        title: "Our Differences",
        author: "MythyDragonwolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_differences",
        hfyFoundationUrl: "https://hfy.foundation/series/2257",
        chapterCount: 2
    },
    {
        id: "our_legacy",
        title: "Our Legacy",
        author: "ascandalia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_legacy",
        hfyFoundationUrl: "https://hfy.foundation/series/492",
        chapterCount: 2
    },
    {
        id: "our_universe_is_hell",
        title: "Our Universe Is Hell",
        author: "Morrigan_NicDanu",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_universe_is_hell",
        hfyFoundationUrl: "https://hfy.foundation/series/3271",
        chapterCount: 52
    },
    {
        id: "out_of_cruel_space",
        title: "Out Of Cruel Space",
        author: "KyleKKent",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/out_of_cruel_space",
        hfyFoundationUrl: "https://hfy.foundation/series/2859",
        chapterCount: 925
    },
    {
        id: "out_of_cruel_space_game",
        title: "Out Of Cruel Space [Game?]",
        author: "Game?",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/out_of_cruel_space_game",
        hfyFoundationUrl: "https://hfy.foundation/series/3996",
        chapterCount: 33
    },
    {
        id: "out_of_the_null_zone",
        title: "Out Of The Null Zone",
        author: "Teleros",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/out_of_the_null_zone",
        hfyFoundationUrl: "https://hfy.foundation/series/2778",
        chapterCount: 67
    },
    {
        id: "overkill",
        title: "Overkill",
        author: "zarikimbo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/overkill",
        hfyFoundationUrl: "https://hfy.foundation/series/718",
        chapterCount: 6
    },
    {
        id: "overture_of_the_renewal_symphony",
        title: "Overture Of The Renewal Symphony",
        author: "Sarjenkat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/overture_of_the_renewal_symphony",
        hfyFoundationUrl: "https://hfy.foundation/series/3845",
        chapterCount: 33
    },
    {
        id: "pack_bond",
        title: "Pack Bond",
        author: "PressPawsToJoin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pack_bond",
        hfyFoundationUrl: "https://hfy.foundation/series/3417",
        chapterCount: 5
    },
    {
        id: "pale_green_dot",
        title: "Pale Green Dot",
        author: "FormerFutureAuthor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pale_green_dot",
        hfyFoundationUrl: "https://hfy.foundation/series/698",
        chapterCount: 29
    },
    {
        id: "the_pantomath_becomes_a_dungeon",
        title: "The Pantomath Becomes A Dungeon",
        author: "Mizque",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_pantomath_becomes_a_dungeon",
        hfyFoundationUrl: "https://hfy.foundation/series/4431",
        chapterCount: 45
    },
    {
        id: "paradise",
        title: "Paradise",
        author: "Tastes_like_SATAN",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/paradise",
        hfyFoundationUrl: "https://hfy.foundation/series/735",
        chapterCount: 5
    },
    {
        id: "paralus",
        title: "Paralus",
        author: "deadeyelee1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/paralus",
        hfyFoundationUrl: "https://hfy.foundation/series/1673",
        chapterCount: 4
    },
    {
        id: "passing_grade",
        title: "Passing Grade",
        author: "storywriter109",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/passing_grade",
        hfyFoundationUrl: "https://hfy.foundation/series/2485",
        chapterCount: 3
    },
    {
        id: "pattern_finders",
        title: "Pattern-finders",
        author: "TempestuousTrident",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/patternfinders",
        hfyFoundationUrl: "https://hfy.foundation/series/2750",
        chapterCount: 12
    },
    {
        id: "pax_galactica",
        title: "Pax Galactica",
        author: "FermisFolly",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pax_galactica",
        hfyFoundationUrl: "https://hfy.foundation/series/2114",
        chapterCount: 16
    },
    {
        id: "penance",
        title: "Penance",
        author: "steampoweredfishcake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/penance",
        hfyFoundationUrl: "https://hfy.foundation/series/966",
        chapterCount: 10
    },
    {
        id: "perfect_storm",
        title: "Perfect Storm",
        author: "CanadianSnowLeopard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/perfect_storm",
        hfyFoundationUrl: "https://hfy.foundation/series/600",
        chapterCount: 9
    },
    {
        id: "perfectly_wrong",
        title: "Perfectly Wrong",
        author: "Maxton1811",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/perfectly_wrong",
        hfyFoundationUrl: "https://hfy.foundation/series/5012",
        chapterCount: 42
    },
    {
        id: "persistence",
        title: "Persistence",
        author: "ThatGuyBob0101",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/persistence",
        hfyFoundationUrl: "https://hfy.foundation/series/3782",
        chapterCount: 17
    },
    {
        id: "persistence_reloaded",
        title: "Persistence Reloaded",
        author: "theLegendaryJ",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/persistence_reloaded",
        hfyFoundationUrl: "https://hfy.foundation/series/3976",
        chapterCount: 17
    },
    {
        id: "pheidippides_the_modern_marathon",
        title: "Pheidippides, The Modern Marathon",
        author: "PatchworthPlus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pheidippides_the_modern_marathon",
        hfyFoundationUrl: "https://hfy.foundation/series/2586",
        chapterCount: 3
    },
    {
        id: "pieces_of_8_bit",
        title: "Pieces Of 8-bit",
        author: "rhinobird",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pieces_of_8bit",
        hfyFoundationUrl: "https://hfy.foundation/series/974",
        chapterCount: 5
    },
    {
        id: "pigshit",
        title: "Pigshit",
        author: "NomadofExile",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pigshit",
        hfyFoundationUrl: "https://hfy.foundation/series/176",
        chapterCount: 12
    },
    {
        id: "pilots",
        title: "Pilots",
        author: "theflyingcheese",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pilots",
        hfyFoundationUrl: "https://hfy.foundation/series/199",
        chapterCount: 4
    },
    {
        id: "the_pioneer",
        title: "The Pioneer",
        author: "hereiamxD1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_pioneer",
        hfyFoundationUrl: "https://hfy.foundation/series/4954",
        chapterCount: 71
    },
    {
        id: "pioneers_collision_of_worlds",
        title: "Pioneers: Collision Of Worlds",
        author: "Admiral\\_Naehum",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pioneers_collision_of_worlds",
        hfyFoundationUrl: "https://hfy.foundation/series/1546",
        chapterCount: 3
    },
    {
        id: "pioneers_wings",
        title: "Pioneers Wings",
        author: "apatchworkquilt",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pioneers_wings",
        hfyFoundationUrl: "https://hfy.foundation/series/1233",
        chapterCount: 4
    },
    {
        id: "pink_one",
        title: "Pink One",
        author: "RhoZie013",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pink_one",
        hfyFoundationUrl: "https://hfy.foundation/series/2473",
        chapterCount: 7
    },
    {
        id: "the_pits_of_boteka",
        title: "The Pits Of Boteka",
        author: "Mustard_Jarr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_pits_of_boteka",
        hfyFoundationUrl: "https://hfy.foundation/series/4112",
        chapterCount: 19
    },
    {
        id: "place_of_the_broken",
        title: "Place Of The Broken",
        author: "a-soul-flame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/place_of_the_broken",
        hfyFoundationUrl: "https://hfy.foundation/series/3323",
        chapterCount: 13
    },
    {
        id: "the_plague_doctor",
        title: "The Plague Doctor",
        author: "Alarmed-Painting-121",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_plague_doctor",
        hfyFoundationUrl: "https://hfy.foundation/series/3436",
        chapterCount: 4
    },
    {
        id: "planet_bun",
        title: "Planet Bun",
        author: "ShadowDragon88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/planet_bun",
        hfyFoundationUrl: "https://hfy.foundation/series/4786",
        chapterCount: 4
    },
    {
        id: "planet_killers",
        title: "Planet Killers",
        author: "SpacemanBates",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/planet_killers",
        hfyFoundationUrl: "https://hfy.foundation/series/741",
        chapterCount: 3
    },
    {
        id: "plasma_and_science_aren_t_the_same_as_fireballs_and_magic",
        title: "Plasma And Science Aren't The Same As Fireballs And Magic",
        author: "VowAndSwear",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plasma_and_science_arent_the_same_as_fireballs_and_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/4509",
        chapterCount: 23
    },
    {
        id: "plugged_in",
        title: "Plugged In",
        author: "hellol111",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plugged_in",
        hfyFoundationUrl: "https://hfy.foundation/series/1450",
        chapterCount: 12
    },
    {
        id: "plunged_into_the_darkness",
        title: "Plunged Into The Darkness",
        author: "TOHSNBN",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plunged_into_the_darkness",
        hfyFoundationUrl: "https://hfy.foundation/series/759",
        chapterCount: 7
    },
    {
        id: "the_po_yafr",
        title: "The Po'yafr",
        author: "NomadofExile",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_poyafr",
        hfyFoundationUrl: "https://hfy.foundation/series/69",
        chapterCount: 3
    },
    {
        id: "the_point_isn_t_winning",
        title: "The Point Isn't Winning",
        author: "smrtak32",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_point_isnt_winning",
        hfyFoundationUrl: "https://hfy.foundation/series/3068",
        chapterCount: 10
    },
    {
        id: "the_point_of_the_spear",
        title: "The Point Of The Spear",
        author: "Monsterbate",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_point_of_the_spear",
        hfyFoundationUrl: "https://hfy.foundation/series/84",
        chapterCount: 26
    },
    {
        id: "polyhumans",
        title: "Polyhumans",
        author: "semiloki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/polyhumans",
        hfyFoundationUrl: "https://hfy.foundation/series/865",
        chapterCount: 8
    },
    {
        id: "post_scarcity_isn_t_post_suffering",
        title: "Post-scarcity Isn't Post-suffering",
        author: "Street-Accountant796",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/postscarcity_isnt_postsuffering",
        hfyFoundationUrl: "https://hfy.foundation/series/3849",
        chapterCount: 77
    },
    {
        id: "post_war_rules",
        title: "Post War Rules",
        author: "DehLeprechaun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/post_war_rules",
        hfyFoundationUrl: "https://hfy.foundation/series/2042",
        chapterCount: 30
    },
    {
        id: "the_power_of_friendship",
        title: "The Power Of Friendship",
        author: "Lost-Klaus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_power_of_friendship",
        hfyFoundationUrl: "https://hfy.foundation/series/3921",
        chapterCount: 31
    },
    {
        id: "powered_armor_and_lost_in_another_world_after_defeating_the_bbeg_because_someone_s_magic_tv_broke",
        title: "Powered Armor And Lost In Another World After Defeating The Bbeg Because Someone's Magic Tv Broke",
        author: "Delta_The_Coywolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/powered_armor_and_lost_in_another_world_after_defeating_the_bbeg_because_someones_magic_tv_broke",
        hfyFoundationUrl: "https://hfy.foundation/series/5099",
        chapterCount: 13
    },
    {
        id: "powerless",
        title: "Powerless",
        author: "Drakos8706",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/powerless",
        hfyFoundationUrl: "https://hfy.foundation/series/3603",
        chapterCount: 70
    },
    {
        id: "a_practical_game",
        title: "A Practical Game",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_practical_game",
        hfyFoundationUrl: "https://hfy.foundation/series/1521",
        chapterCount: 7
    },
    {
        id: "precursor",
        title: "Precursor",
        author: "2bitpsycho",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/precursor",
        hfyFoundationUrl: "https://hfy.foundation/series/54",
        chapterCount: 7
    },
    {
        id: "a_predator_among_the_herd",
        title: "A Predator Among The Herd",
        author: "StrageDragonShadow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_predator_among_the_herd",
        hfyFoundationUrl: "https://hfy.foundation/series/3015",
        chapterCount: 15
    },
    {
        id: "prelude_to_the_mayhem",
        title: "Prelude To The Mayhem",
        author: "Vivid-Membership3959",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/prelude_to_the_mayhem",
        hfyFoundationUrl: "https://hfy.foundation/series/5376",
        chapterCount: 13
    },
    {
        id: "pretty_little_deathworlders",
        title: "Pretty Little Deathworlders",
        author: "giftedearth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pretty_little_deathworlders",
        hfyFoundationUrl: "https://hfy.foundation/series/2050",
        chapterCount: 18
    },
    {
        id: "prey",
        title: "Prey",
        author: "paradigmblue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/prey",
        hfyFoundationUrl: "https://hfy.foundation/series/5398",
        chapterCount: 3
    },
    {
        id: "primal_essence",
        title: "Primal Essence",
        author: "Velocichickendragon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/primal_essence",
        hfyFoundationUrl: "https://hfy.foundation/series/1901",
        chapterCount: 30
    },
    {
        id: "primis",
        title: "Primis",
        author: "TinyBard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/primis",
        hfyFoundationUrl: "https://hfy.foundation/series/1306",
        chapterCount: 4
    },
    {
        id: "primitive_design_consultant",
        title: "Primitive Design Consultant",
        author: "Vidar_biigfoot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/primitive_design_consultant",
        hfyFoundationUrl: "https://hfy.foundation/series/3500",
        chapterCount: 62
    },
    {
        id: "primitive_lives",
        title: "Primitive Lives",
        author: "BelgianRockfan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/primitive_lives",
        hfyFoundationUrl: "https://hfy.foundation/series/142",
        chapterCount: 3
    },
    {
        id: "the_primordial_tower",
        title: "The Primordial Tower",
        author: "PsnNikrim",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_primordial_tower",
        hfyFoundationUrl: "https://hfy.foundation/series/2579",
        chapterCount: 23
    },
    {
        id: "the_princess_and_the_human",
        title: "The Princess And The Human",
        author: "Dak1on",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_princess_and_the_human",
        hfyFoundationUrl: "https://hfy.foundation/series/3530",
        chapterCount: 60
    },
    {
        id: "the_privateer",
        title: "The Privateer",
        author: "DestroyatronMk8",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_privateer",
        hfyFoundationUrl: "https://hfy.foundation/series/2816",
        chapterCount: 150
    },
    {
        id: "privateers",
        title: "Privateers",
        author: "johneever1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/privateers",
        hfyFoundationUrl: "https://hfy.foundation/series/5075",
        chapterCount: 23
    },
    {
        id: "prison_break",
        title: "Prison Break",
        author: "TOSCAA",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/prison_break",
        hfyFoundationUrl: "https://hfy.foundation/series/394",
        chapterCount: 37
    },
    {
        id: "the_prize",
        title: "The Prize",
        author: "Zjackrum",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_prize",
        hfyFoundationUrl: "https://hfy.foundation/series/1339",
        chapterCount: 14
    },
    {
        id: "a_product_of_physics",
        title: "A Product Of Physics",
        author: "Alex_146",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_product_of_physics",
        hfyFoundationUrl: "https://hfy.foundation/series/2143",
        chapterCount: 9
    },
    {
        id: "progress_marches",
        title: "Progress Marches",
        author: "EternalCanadian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/progress_marches",
        hfyFoundationUrl: "https://hfy.foundation/series/1885",
        chapterCount: 8
    },
    {
        id: "project_p_commander_zorn",
        title: "Project (P). Commander Zorn",
        author: "PatchworthPlus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/project_p_commander_zorn",
        hfyFoundationUrl: "https://hfy.foundation/series/2454",
        chapterCount: 5
    },
    {
        id: "project_orion",
        title: "Project Orion",
        author: "boomchacle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/project_orion",
        hfyFoundationUrl: "https://hfy.foundation/series/3277",
        chapterCount: 26
    },
    {
        id: "project_stargazer",
        title: "Project STARGAZER",
        author: "CircleRelatedAnxiety",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/project_stargazer",
        hfyFoundationUrl: "https://hfy.foundation/series/2272",
        chapterCount: 43
    },
    {
        id: "proportional_response",
        title: "Proportional Response",
        author: "Fearadhach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/proportional_response",
        hfyFoundationUrl: "https://hfy.foundation/series/2818",
        chapterCount: 79
    },
    {
        id: "protect_and_serve",
        title: "Protect and Serve",
        author: "zarikimbo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/protect_and_serve",
        hfyFoundationUrl: "https://hfy.foundation/series/800",
        chapterCount: 5
    },
    {
        id: "protium",
        title: "Protium",
        author: "Megamickel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/protium",
        hfyFoundationUrl: "https://hfy.foundation/series/1244",
        chapterCount: 3
    },
    {
        id: "quarantine",
        title: "Quarantine",
        author: "loki130",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/quarantine",
        hfyFoundationUrl: "https://hfy.foundation/series/429",
        chapterCount: 107
    },
    {
        id: "queen_anne",
        title: "Queen Anne",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/queen_anne",
        hfyFoundationUrl: "https://hfy.foundation/series/1311",
        chapterCount: 3
    },
    {
        id: "quill_still",
        title: "Quill & Still",
        author: "PastafarianGames",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/quill__still",
        hfyFoundationUrl: "https://hfy.foundation/series/4224",
        chapterCount: 53
    },
    {
        id: "quod_erat_demonstrandum",
        title: "Quod Erat Demonstrandum",
        author: "devourerkwi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/quod_erat_demonstrandum",
        hfyFoundationUrl: "https://hfy.foundation/series/197",
        chapterCount: 9
    },
    {
        id: "radio_transmundane",
        title: "Radio Transmundane",
        author: "Radio Transmundane",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/radio_transmundane",
        hfyFoundationUrl: "https://hfy.foundation/series/2180",
        chapterCount: 100
    },
    {
        id: "ragnarok",
        title: "Ragnarok",
        author: "Cysanic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ragnarok",
        hfyFoundationUrl: "https://hfy.foundation/series/1499",
        chapterCount: 3
    },
    {
        id: "the_ranger",
        title: "The Ranger",
        author: "ElGatoBandito",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ranger",
        hfyFoundationUrl: "https://hfy.foundation/series/350",
        chapterCount: 5
    },
    {
        id: "the_rask_rebellion",
        title: "The Rask Rebellion",
        author: "Snekguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_rask_rebellion",
        hfyFoundationUrl: "https://hfy.foundation/series/3464",
        chapterCount: 144
    },
    {
        id: "reactivation",
        title: "Reactivation",
        author: "TACNUK3Z",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reactivation",
        hfyFoundationUrl: "https://hfy.foundation/series/2421",
        chapterCount: 12
    },
    {
        id: "the_reapers",
        title: "The Reapers",
        author: "IHaveABetWithMyBro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_reapers",
        hfyFoundationUrl: "https://hfy.foundation/series/1437",
        chapterCount: 3
    },
    {
        id: "the_reaving_and_plundering_captain_broadside",
        title: "The Reaving And Plundering Captain Broadside",
        author: "IHaveABetWithMyBro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_reaving_and_plundering_captain_broadside",
        hfyFoundationUrl: "https://hfy.foundation/series/1280",
        chapterCount: 2
    },
    {
        id: "rebellion",
        title: "Rebellion",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rebellion",
        hfyFoundationUrl: "https://hfy.foundation/series/841",
        chapterCount: 10
    },
    {
        id: "rebels_can_t_go_home",
        title: "Rebels Can't Go Home",
        author: "ThisStoryNow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rebels_cant_go_home",
        hfyFoundationUrl: "https://hfy.foundation/series/1477",
        chapterCount: 65
    },
    {
        id: "rebirth",
        title: "Rebirth",
        author: "Asikar_Tehjan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rebirth",
        hfyFoundationUrl: "https://hfy.foundation/series/1412",
        chapterCount: 15
    },
    {
        id: "a_recipe_for_disaster",
        title: "A Recipe For Disaster",
        author: "YakiTapioca",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_recipe_for_disaster",
        hfyFoundationUrl: "https://hfy.foundation/series/4647",
        chapterCount: 38
    },
    {
        id: "reconquista",
        title: "Reconquista",
        author: "Han_Uh-oh",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reconquista",
        hfyFoundationUrl: "https://hfy.foundation/series/448",
        chapterCount: 3
    },
    {
        id: "recursion",
        title: "Recursion",
        author: "rasputinette",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/recursion",
        hfyFoundationUrl: "https://hfy.foundation/series/2429",
        chapterCount: 5
    },
    {
        id: "red_blood",
        title: "Red Blood",
        author: "Gentlemanchaos",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_blood",
        hfyFoundationUrl: "https://hfy.foundation/series/363",
        chapterCount: 10
    },
    {
        id: "red_blood_2",
        title: "Red Blood",
        author: "NumerousSun4282",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_blood_numeroussun4282",
        hfyFoundationUrl: "https://hfy.foundation/series/4243",
        chapterCount: 3
    },
    {
        id: "red_hands",
        title: "Red Hands",
        author: "Rai_Darkblade",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_hands",
        hfyFoundationUrl: "https://hfy.foundation/series/3357",
        chapterCount: 7
    },
    {
        id: "red_moon_falls",
        title: "Red Moon Falls",
        author: "ShadowDragon88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_moon_falls",
        hfyFoundationUrl: "https://hfy.foundation/series/5307",
        chapterCount: 3
    },
    {
        id: "red_pill_blue_pill",
        title: "Red Pill, Blue Pill",
        author: "EntangledBottles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_pill_blue_pill",
        hfyFoundationUrl: "https://hfy.foundation/series/1526",
        chapterCount: 3
    },
    {
        id: "red_world_blues",
        title: "Red World Blues",
        author: "AlecPEnnis",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_world_blues",
        hfyFoundationUrl: "https://hfy.foundation/series/3169",
        chapterCount: 37
    },
    {
        id: "the_relic",
        title: "The Relic",
        author: "Jallorn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_relic",
        hfyFoundationUrl: "https://hfy.foundation/series/575",
        chapterCount: 3
    },
    {
        id: "relics_of_man",
        title: "Relics Of Man",
        author: "KingHenrytheI",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/relics_of_man",
        hfyFoundationUrl: "https://hfy.foundation/series/3127",
        chapterCount: 2
    },
    {
        id: "the_remains_of_terra_prime",
        title: "The Remains Of Terra Prime",
        author: "PapaPalps91",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_remains_of_terra_prime",
        hfyFoundationUrl: "https://hfy.foundation/series/3262",
        chapterCount: 42
    },
    {
        id: "remembrance",
        title: "Remembrance",
        author: "YukiteruAmano92",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/remembrance",
        hfyFoundationUrl: "https://hfy.foundation/series/5005",
        chapterCount: 28
    },
    {
        id: "remnants",
        title: "Remnants",
        author: "Kagarn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/remnants",
        hfyFoundationUrl: "https://hfy.foundation/series/127",
        chapterCount: 2
    },
    {
        id: "remnants_amongst_the_ashes",
        title: "Remnants Amongst The Ashes",
        author: "Illwood_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/remnants_amongst_the_ashes",
        hfyFoundationUrl: "https://hfy.foundation/series/4506",
        chapterCount: 13
    },
    {
        id: "retreat_hell",
        title: "Retreat, Hell",
        author: "Ilithi_Dragon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/retreat_hell",
        hfyFoundationUrl: "https://hfy.foundation/series/1782",
        chapterCount: 32
    },
    {
        id: "the_retribution_of_the_silent",
        title: "The Retribution Of The Silent",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_retribution_of_the_silent",
        hfyFoundationUrl: "https://hfy.foundation/series/1362",
        chapterCount: 2
    },
    {
        id: "return_of_the_fifth",
        title: "Return Of The Fifth",
        author: "IHaveABetWithMyBro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/return_of_the_fifth",
        hfyFoundationUrl: "https://hfy.foundation/series/1132",
        chapterCount: 5
    },
    {
        id: "return_to_earth",
        title: "Return To Earth",
        author: "ImSoBored123456",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/return_to_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/1589",
        chapterCount: 15
    },
    {
        id: "reverse_engineering",
        title: "Reverse Engineering",
        author: "Mackelsaur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reverse_engineering",
        hfyFoundationUrl: "https://hfy.foundation/series/2275",
        chapterCount: 2
    },
    {
        id: "rex_hardbody_and_the_planet_of_the_ultraboobs",
        title: "Rex Hardbody and the Planet Of the Ultraboobs",
        author: "semiloki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rex_hardbody",
        hfyFoundationUrl: "https://hfy.foundation/series/426",
        chapterCount: 3
    },
    {
        id: "rift_rats",
        title: "Rift Rats",
        author: "CycloneDensity",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rift_rats",
        hfyFoundationUrl: "https://hfy.foundation/series/5414",
        chapterCount: 4
    },
    {
        id: "rifts_of_war",
        title: "Rifts Of War",
        author: "Sinpleton025",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rifts_of_war",
        hfyFoundationUrl: "https://hfy.foundation/series/4841",
        chapterCount: 28
    },
    {
        id: "right_yes_of_course",
        title: "Right, Yes, Of Course!",
        author: "salt001",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/right_yes_of_course",
        hfyFoundationUrl: "https://hfy.foundation/series/1705",
        chapterCount: 10
    },
    {
        id: "ring_of_fire",
        title: "Ring of Fire",
        author: "Sgt_Hydroxide",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ring_of_fire",
        hfyFoundationUrl: "https://hfy.foundation/series/463",
        chapterCount: 26
    },
    {
        id: "the_rise_of_earth",
        title: "The Rise Of Earth",
        author: "WarmStew23",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_rise_of_earth",
        hfyFoundationUrl: "https://hfy.foundation/series/4015",
        chapterCount: 24
    },
    {
        id: "rise_of_the_dungeon_smith",
        title: "Rise Of The Dungeon Smith",
        author: "Tyberius92",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rise_of_the_dungeon_smith",
        hfyFoundationUrl: "https://hfy.foundation/series/4433",
        chapterCount: 16
    },
    {
        id: "rise_of_the_valkyrie",
        title: "Rise Of The Valkyrie",
        author: "BeaverFur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rise_of_the_valkyrie",
        hfyFoundationUrl: "https://hfy.foundation/series/460",
        chapterCount: 11
    },
    {
        id: "rishien_apex_species_database",
        title: "Rishien Apex Species Database",
        author: "Risesohigh33",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rishien_apex_species_database",
        hfyFoundationUrl: "https://hfy.foundation/series/2887",
        chapterCount: 8
    },
    {
        id: "rising_titans",
        title: "Rising Titans",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rising_titans",
        hfyFoundationUrl: "https://hfy.foundation/series/470",
        chapterCount: 86
    },
    {
        id: "the_ritzag_chronicles",
        title: "The Ritzag Chronicles",
        author: "Phalanks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ritzag_chronicles",
        hfyFoundationUrl: "https://hfy.foundation/series/40",
        chapterCount: 3
    },
    {
        id: "a_roar_in_space",
        title: "A Roar In Space",
        author: "marshalzukov",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_roar_in_space",
        hfyFoundationUrl: "https://hfy.foundation/series/5144",
        chapterCount: 16
    },
    {
        id: "the_rockers",
        title: "The Rockers",
        author: "LordHenry7898",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_rockers",
        hfyFoundationUrl: "https://hfy.foundation/series/2013",
        chapterCount: 2
    },
    {
        id: "the_rogue_chronicles",
        title: "The Rogue Chronicles",
        author: "TheManwithaNoPlan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_rogue_chronicles",
        hfyFoundationUrl: "https://hfy.foundation/series/4736",
        chapterCount: 16
    },
    {
        id: "rogue_fleet_equinox",
        title: "Rogue Fleet Equinox",
        author: "ThisStoryNow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rogue_fleet_equinox",
        hfyFoundationUrl: "https://hfy.foundation/series/1544",
        chapterCount: 49
    },
    {
        id: "rolf_s_time_at_the_academy",
        title: "Rolf's Time at the Academy",
        author: "Belisares",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rolfs_time_at_the_academy",
        hfyFoundationUrl: "https://hfy.foundation/series/691",
        chapterCount: 7
    },
    {
        id: "ruin_or_salvation",
        title: "Ruin Or Salvation",
        author: "Amarun_Daite",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ruin_or_salvation",
        hfyFoundationUrl: "https://hfy.foundation/series/4287",
        chapterCount: 12
    },
    {
        id: "ruins",
        title: "Ruins",
        author: "fadingremnants",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ruins",
        hfyFoundationUrl: "https://hfy.foundation/series/235",
        chapterCount: 6
    },
    {
        id: "rules_of_engagement",
        title: "Rules Of Engagement",
        author: "Rough_Sea",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rules_of_engagement",
        hfyFoundationUrl: "https://hfy.foundation/series/2789",
        chapterCount: 3
    },
    {
        id: "rules_to_be_broken",
        title: "Rules To Be Broken",
        author: "AFatFlyingWhale",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rules_to_be_broken",
        hfyFoundationUrl: "https://hfy.foundation/series/1220",
        chapterCount: 8
    },
    {
        id: "rumours_of_humans",
        title: "Rumours Of Humans",
        author: "Mdlp1991",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rumours_of_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/844",
        chapterCount: 7
    },
    {
        id: "runner_s_high",
        title: "Runner's High",
        author: "equatorialbaconstrip",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/runners_high",
        hfyFoundationUrl: "https://hfy.foundation/series/582",
        chapterCount: 12
    },
    {
        id: "sacrifices",
        title: "Sacrifices",
        author: "Ardorus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sacrifices",
        hfyFoundationUrl: "https://hfy.foundation/series/2191",
        chapterCount: 127
    },
    {
        id: "the_saga_of_robert_samson",
        title: "The Saga Of Robert Samson",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_saga_of_robert_samson",
        hfyFoundationUrl: "https://hfy.foundation/series/5492",
        chapterCount: 29
    },
    {
        id: "the_sagas_of_mortaholme",
        title: "The Sagas Of Mortaholme",
        author: "ThomFoxsmith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sagas_of_mortaholme",
        hfyFoundationUrl: "https://hfy.foundation/series/1518",
        chapterCount: 17
    },
    {
        id: "saints_in_exile",
        title: "Saints in Exile",
        author: "slice_of_pi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/saints_in_exile",
        hfyFoundationUrl: "https://hfy.foundation/series/579",
        chapterCount: 3
    },
    {
        id: "salvage",
        title: "Salvage",
        author: "Rantarian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/salvage",
        hfyFoundationUrl: "https://hfy.foundation/series/200",
        chapterCount: 100
    },
    {
        id: "sand_and_legends",
        title: "Sand And Legends",
        author: "Guncaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sand_and_legends",
        hfyFoundationUrl: "https://hfy.foundation/series/1336",
        chapterCount: 23
    },
    {
        id: "scales_of_ice",
        title: "Scales Of Ice",
        author: "MechaJay88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/scales_of_ice",
        hfyFoundationUrl: "https://hfy.foundation/series/3111",
        chapterCount: 14
    },
    {
        id: "school_among_the_stars",
        title: "School Among The Stars",
        author: "Apprehensive_Ad_995",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/school_among_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/3791",
        chapterCount: 9
    },
    {
        id: "scientific_magic",
        title: "Scientific Magic",
        author: "Nettle_Queen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/scientific_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/4141",
        chapterCount: 33
    },
    {
        id: "the_scuu_paradox",
        title: "The Scuu Paradox",
        author: "LiseEclaire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_scuu_paradox",
        hfyFoundationUrl: "https://hfy.foundation/series/2291",
        chapterCount: 65
    },
    {
        id: "sea_of_hope_paradigm",
        title: "Sea Of Hope: Paradigm",
        author: "YC-012_Bourbon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sea_of_hope_paradigm",
        hfyFoundationUrl: "https://hfy.foundation/series/2317",
        chapterCount: 16
    },
    {
        id: "the_seas_of_solace",
        title: "The Seas Of Solace",
        author: "SterlingMagleby",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_seas_of_solace",
        hfyFoundationUrl: "https://hfy.foundation/series/1974",
        chapterCount: 4
    },
    {
        id: "second_contact",
        title: "Second Contact",
        author: "Nothingisartificial",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/second_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/1021",
        chapterCount: 6
    },
    {
        id: "second_contact_2",
        title: "Second Contact",
        author: "JohnFalkirk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/second_contact_johnfalkirk",
        hfyFoundationUrl: "https://hfy.foundation/series/1304",
        chapterCount: 13
    },
    {
        id: "second_contact_3",
        title: "Second Contact",
        author: "LateralThinker13",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/second_contact_lateralthinker13",
        hfyFoundationUrl: "https://hfy.foundation/series/4113",
        chapterCount: 27
    },
    {
        id: "second_god",
        title: "Second God",
        author: "Akmedrah",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/second_god",
        hfyFoundationUrl: "https://hfy.foundation/series/3310",
        chapterCount: 12
    },
    {
        id: "secure",
        title: "Secure",
        author: "SCPunited",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/secure",
        hfyFoundationUrl: "https://hfy.foundation/series/3174",
        chapterCount: 10
    },
    {
        id: "the_seeders",
        title: "The Seeders",
        author: "grepe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_seeders",
        hfyFoundationUrl: "https://hfy.foundation/series/152",
        chapterCount: 2
    },
    {
        id: "semper_shil_vati",
        title: "Semper Shil'vati",
        author: "AmericanPride2814",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/semper_shilvati",
        hfyFoundationUrl: "https://hfy.foundation/series/2623",
        chapterCount: 42
    },
    {
        id: "the_sentinels",
        title: "The Sentinels",
        author: "tpehli",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sentinels",
        hfyFoundationUrl: "https://hfy.foundation/series/728",
        chapterCount: 3
    },
    {
        id: "servant_son_of_the_stars",
        title: "Servant Son Of The Stars",
        author: "Risesohigh33",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/servant_son_of_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/3291",
        chapterCount: 2
    },
    {
        id: "seven_days_of_fire",
        title: "Seven Days Of Fire",
        author: "LittleSeraphim",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/seven_days_of_fire",
        hfyFoundationUrl: "https://hfy.foundation/series/1814",
        chapterCount: 46
    },
    {
        id: "the_seven_deadly_sins",
        title: "The Seven Deadly Sins",
        author: "storywriter109",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_seven_deadly_sins",
        hfyFoundationUrl: "https://hfy.foundation/series/2456",
        chapterCount: 3
    },
    {
        id: "sexy_sect_babes",
        title: "Sexy Sect Babes",
        author: "BlueFishcake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sexy_sect_babes",
        hfyFoundationUrl: "https://hfy.foundation/series/5390",
        chapterCount: 88
    },
    {
        id: "sexy_space_babes",
        title: "Sexy Space Babes",
        author: "BlueFishcake",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/sexy_space_babes",
        hfyFoundationUrl: "https://hfy.foundation/series/2506",
        chapterCount: 82
    },
    {
        id: "shackled_minds",
        title: "Shackled Minds",
        author: "Frame_Late",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shackled_minds",
        hfyFoundationUrl: "https://hfy.foundation/series/5152",
        chapterCount: 3
    },
    {
        id: "shadow_under_plato",
        title: "Shadow Under Plato",
        author: "PistolShrimpWrites",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shadow_under_plato",
        hfyFoundationUrl: "https://hfy.foundation/series/3425",
        chapterCount: 4
    },
    {
        id: "shard_of_darkness",
        title: "Shard Of Darkness",
        author: "nickgreyden",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shard_of_darkness",
        hfyFoundationUrl: "https://hfy.foundation/series/3220",
        chapterCount: 28
    },
    {
        id: "shards",
        title: "Shards",
        author: "FerriteFox",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shards",
        hfyFoundationUrl: "https://hfy.foundation/series/2849",
        chapterCount: 29
    },
    {
        id: "shattered",
        title: "Shattered",
        author: "jakimfett",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shattered",
        hfyFoundationUrl: "https://hfy.foundation/series/1385",
        chapterCount: 3
    },
    {
        id: "shattered_glass",
        title: "Shattered Glass",
        author: "12oclocknomemories",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shattered_glass",
        hfyFoundationUrl: "https://hfy.foundation/series/3304",
        chapterCount: 12
    },
    {
        id: "shattered_helix",
        title: "Shattered Helix",
        author: "Daphonic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shattered_helix",
        hfyFoundationUrl: "https://hfy.foundation/series/2476",
        chapterCount: 76
    },
    {
        id: "she_ignites_me",
        title: "She Ignites Me",
        author: "AlieHaleyy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/she_ignites_me",
        hfyFoundationUrl: "https://hfy.foundation/series/1991",
        chapterCount: 4
    },
    {
        id: "shenanigans",
        title: "Shenanigans",
        author: "YesThatMoses",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shenanigans",
        hfyFoundationUrl: "https://hfy.foundation/series/3461",
        chapterCount: 37
    },
    {
        id: "the_shining_knight_saga",
        title: "The Shining Knight Saga",
        author: "Frostdraken",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_shining_knight_saga",
        hfyFoundationUrl: "https://hfy.foundation/series/3551",
        chapterCount: 27
    },
    {
        id: "ship_of_theseus",
        title: "Ship Of Theseus",
        author: "SyntheticDreamy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ship_of_theseus",
        hfyFoundationUrl: "https://hfy.foundation/series/3378",
        chapterCount: 21
    },
    {
        id: "ship_s_medic",
        title: "Ship's Medic",
        author: "Gatekeeper-Z",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ships_medic",
        hfyFoundationUrl: "https://hfy.foundation/series/3599",
        chapterCount: 22
    },
    {
        id: "shotgun_fantasy",
        title: "Shotgun Fantasy",
        author: "That2009WeirdEmoKid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shotgun_fantasy",
        hfyFoundationUrl: "https://hfy.foundation/series/2199",
        chapterCount: 29
    },
    {
        id: "the_shoulders_of_orion",
        title: "The Shoulders Of Orion",
        author: "STATICinMOTION",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_shoulders_of_orion",
        hfyFoundationUrl: "https://hfy.foundation/series/2366",
        chapterCount: 14
    },
    {
        id: "shura_saga",
        title: "Shura Saga",
        author: "NLstories",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shura_saga",
        hfyFoundationUrl: "https://hfy.foundation/series/2756",
        chapterCount: 19
    },
    {
        id: "sideways_in_hyperspace",
        title: "Sideways in Hyperspace",
        author: "Sagebrysh",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sideways_in_hyperspace",
        hfyFoundationUrl: "https://hfy.foundation/series/776",
        chapterCount: 46
    },
    {
        id: "the_sign_of_the_sun",
        title: "The Sign of the Sun",
        author: "ZathuraRay",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sign_of_the_sun",
        hfyFoundationUrl: "https://hfy.foundation/series/424",
        chapterCount: 10
    },
    {
        id: "the_signal",
        title: "The Signal",
        author: "fred_lowe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_signal",
        hfyFoundationUrl: "https://hfy.foundation/series/2903",
        chapterCount: 15
    },
    {
        id: "the_silent_service",
        title: "The Silent Service",
        author: "sand_trout",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_silent_service",
        hfyFoundationUrl: "https://hfy.foundation/series/351",
        chapterCount: 3
    },
    {
        id: "silver",
        title: "Silver",
        author: "comyk79",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/silver",
        hfyFoundationUrl: "https://hfy.foundation/series/4480",
        chapterCount: 4
    },
    {
        id: "silver_amelia",
        title: "Silver Amelia",
        author: "Feirut",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/silver_amelia",
        hfyFoundationUrl: "https://hfy.foundation/series/1100",
        chapterCount: 69
    },
    {
        id: "silver_swordsman",
        title: "Silver Swordsman",
        author: "dlschindler",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/silver_swordsman",
        hfyFoundationUrl: "https://hfy.foundation/series/5049",
        chapterCount: 12
    },
    {
        id: "simultaneous_contact",
        title: "Simultaneous Contact",
        author: "SobanSa",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/simultaneous_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/413",
        chapterCount: 8
    },
    {
        id: "singularity",
        title: "Singularity",
        author: "WeaverofFables",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/singularity",
        hfyFoundationUrl: "https://hfy.foundation/series/2836",
        chapterCount: 90
    },
    {
        id: "sins_of_ash",
        title: "Sins Of Ash",
        author: "Arceroth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sins_of_ash",
        hfyFoundationUrl: "https://hfy.foundation/series/1868",
        chapterCount: 50
    },
    {
        id: "sionia",
        title: "Sionia",
        author: "TheOneTrueAnimeGod",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sionia",
        hfyFoundationUrl: "https://hfy.foundation/series/5588",
        chapterCount: 17
    },
    {
        id: "the_skies_of_venus",
        title: "The Skies Of Venus",
        author: "litcityblues",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_skies_of_venus",
        hfyFoundationUrl: "https://hfy.foundation/series/2620",
        chapterCount: 21
    },
    {
        id: "skyclad",
        title: "Skyclad",
        author: "a\\_man\\_in\\_black",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/skyclad",
        hfyFoundationUrl: "https://hfy.foundation/series/1770",
        chapterCount: 9
    },
    {
        id: "skyfall",
        title: "Skyfall",
        author: "grepe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/skyfall",
        hfyFoundationUrl: "https://hfy.foundation/series/161",
        chapterCount: 3
    },
    {
        id: "skyrates",
        title: "Skyrates?!",
        author: "CRonIckler",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/skyrates",
        hfyFoundationUrl: "https://hfy.foundation/series/3576",
        chapterCount: 12
    },
    {
        id: "the_skymen",
        title: "The Skymen",
        author: "LordHenry7898",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_skymen",
        hfyFoundationUrl: "https://hfy.foundation/series/1754",
        chapterCount: 12
    },
    {
        id: "the_slave",
        title: "The Slave",
        author: "Critical7A",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_slave",
        hfyFoundationUrl: "https://hfy.foundation/series/2745",
        chapterCount: 3
    },
    {
        id: "sleeping_dogs",
        title: "Sleeping Dogs",
        author: "Zinsurin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sleeping_dogs",
        hfyFoundationUrl: "https://hfy.foundation/series/2078",
        chapterCount: 5
    },
    {
        id: "small_galaxy",
        title: "Small Galaxy",
        author: "Laddimor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/small_galaxy",
        hfyFoundationUrl: "https://hfy.foundation/series/2601",
        chapterCount: 176
    },
    {
        id: "the_smol_engineer",
        title: "The Smol Engineer",
        author: "InfamousVenous",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_smol_engineer",
        hfyFoundationUrl: "https://hfy.foundation/series/1688",
        chapterCount: 6
    },
    {
        id: "smol_roadtrip",
        title: "Smol Roadtrip",
        author: "BenchNotA",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/smol_roadtrip",
        hfyFoundationUrl: "https://hfy.foundation/series/1682",
        chapterCount: 6
    },
    {
        id: "the_smooth_talker",
        title: "The Smooth Talker",
        author: "Halfton81",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_smooth_talker",
        hfyFoundationUrl: "https://hfy.foundation/series/128",
        chapterCount: 3
    },
    {
        id: "so_i_can_t_finish_my_poutine",
        title: "So... I Can't Finish My Poutine?",
        author: "netmobs",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/so_i_cant_finish_my_poutine",
        hfyFoundationUrl: "https://hfy.foundation/series/1559",
        chapterCount: 9
    },
    {
        id: "soft_target",
        title: "Soft Target",
        author: "Nik\\_2213",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soft_target",
        hfyFoundationUrl: "https://hfy.foundation/series/1469",
        chapterCount: 8
    },
    {
        id: "solaria_rising",
        title: "Solaria Rising",
        author: "TheHypomaniac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/solaria_rising",
        hfyFoundationUrl: "https://hfy.foundation/series/1675",
        chapterCount: 11
    },
    {
        id: "some_difficulties_interrogating_a_captive_hjuman_sas_soldier",
        title: "Some Difficulties Interrogating A Captive Hjuman Sas Soldier",
        author: "Street-Accountant796",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/some_difficulties_interrogating_a_captive_hjuman_sas_soldier",
        hfyFoundationUrl: "https://hfy.foundation/series/4026",
        chapterCount: 3
    },
    {
        id: "some_of_my_best_friends_are_human",
        title: "Some of My Best Friends are Human",
        author: "All Fubsyverse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/some_of_my_best_friends_are_human",
        hfyFoundationUrl: "https://hfy.foundation/series/1164",
        chapterCount: 11
    },
    {
        id: "a_song_in_the_dark",
        title: "A Song In The Dark",
        author: "magicrectangle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_song_in_the_dark",
        hfyFoundationUrl: "https://hfy.foundation/series/3468",
        chapterCount: 12
    },
    {
        id: "the_song_in_the_stars",
        title: "The Song In The Stars",
        author: "BrokenDreamyard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_song_in_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/5358",
        chapterCount: 25
    },
    {
        id: "the_song_of_the_softwalkers",
        title: "The Song of the SoftWalkers",
        author: "chipathing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_song_of_the_softwalkers",
        hfyFoundationUrl: "https://hfy.foundation/series/879",
        chapterCount: 11
    },
    {
        id: "songkiller",
        title: "Songkiller",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/songkiller",
        hfyFoundationUrl: "https://hfy.foundation/series/3775",
        chapterCount: 28
    },
    {
        id: "songs_of_mercy",
        title: "Songs Of Mercy",
        author: "ElusiveMonty",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/songs_of_mercy",
        hfyFoundationUrl: "https://hfy.foundation/series/2681",
        chapterCount: 33
    },
    {
        id: "sooo_i_m_a_familiar_now",
        title: "Sooo... I'm A Familiar Now?",
        author: "Derpin0ides",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sooo_im_a_familiar_now",
        hfyFoundationUrl: "https://hfy.foundation/series/4339",
        chapterCount: 26
    },
    {
        id: "sophie_pioneer",
        title: "Sophie, Pioneer",
        author: "LeVentNoir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sophie_pioneer",
        hfyFoundationUrl: "https://hfy.foundation/series/490",
        chapterCount: 7
    },
    {
        id: "soul_bound",
        title: "Soul Bound",
        author: "FatedApollo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soul_bound",
        hfyFoundationUrl: "https://hfy.foundation/series/1902",
        chapterCount: 10
    },
    {
        id: "soul_stealer",
        title: "Soul Stealer",
        author: "ItsDumi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soul_stealer",
        hfyFoundationUrl: "https://hfy.foundation/series/4989",
        chapterCount: 27
    },
    {
        id: "soundless_conflicts",
        title: "Soundless Conflicts",
        author: "Susceptive",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soundless_conflicts",
        hfyFoundationUrl: "https://hfy.foundation/series/2508",
        chapterCount: 46
    },
    {
        id: "the_sparks_within_darkness",
        title: "The Sparks Within Darkness",
        author: "Revolutionary-Big49",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sparks_within_darkness",
        hfyFoundationUrl: "https://hfy.foundation/series/4364",
        chapterCount: 15
    },
    {
        id: "spears_among_the_stars",
        title: "Spears Among The Stars",
        author: "KingoftheRednecks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spears_among_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/4612",
        chapterCount: 38
    },
    {
        id: "species_of_duality",
        title: "Species of Duality",
        author: "Deegibo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/species_of_duality",
        hfyFoundationUrl: "https://hfy.foundation/series/145",
        chapterCount: 6
    },
    {
        id: "speed_demons",
        title: "Speed Demons",
        author: "Alarmed-Painting-121",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/speed_demons",
        hfyFoundationUrl: "https://hfy.foundation/series/3433",
        chapterCount: 30
    },
    {
        id: "spiral",
        title: "Spiral",
        author: "Aetharan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spiral",
        hfyFoundationUrl: "https://hfy.foundation/series/3560",
        chapterCount: 13
    },
    {
        id: "spirit_animal",
        title: "Spirit Animal",
        author: "TheFirstMillionWords",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spirit_animal",
        hfyFoundationUrl: "https://hfy.foundation/series/1827",
        chapterCount: 4
    },
    {
        id: "spirit_radio",
        title: "Spirit Radio",
        author: "WingbeatPony",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spirit_radio",
        hfyFoundationUrl: "https://hfy.foundation/series/1660",
        chapterCount: 7
    },
    {
        id: "splinters_in_the_dark",
        title: "Splinters in the Dark",
        author: "levsco",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/splinters_in_the_dark",
        hfyFoundationUrl: "https://hfy.foundation/series/124",
        chapterCount: 2
    },
    {
        id: "star_west",
        title: "Star West",
        author: "SpacemanBates",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/star_west",
        hfyFoundationUrl: "https://hfy.foundation/series/877",
        chapterCount: 8
    },
    {
        id: "the_stars_beckon",
        title: "The Stars Beckon",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_stars_beckon",
        hfyFoundationUrl: "https://hfy.foundation/series/1379",
        chapterCount: 43
    },
    {
        id: "stardivers_the_genesis_of_the_senov",
        title: "Stardivers: The Genesis of The Senov",
        author: "Kubrick_Fan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stardivers_the_genesis_of_the_senov",
        hfyFoundationUrl: "https://hfy.foundation/series/35",
        chapterCount: 6
    },
    {
        id: "a_starforce_among_alien_skies",
        title: "A Starforce Among Alien Skies",
        author: "DSiren",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_starforce_among_alien_skies",
        hfyFoundationUrl: "https://hfy.foundation/series/1968",
        chapterCount: 27
    },
    {
        id: "starhawks",
        title: "Starhawks",
        author: "Kasern",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/starhawks",
        hfyFoundationUrl: "https://hfy.foundation/series/3964",
        chapterCount: 14
    },
    {
        id: "starlight_starlight",
        title: "Starlight, Starlight",
        author: "Basil_9",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/starlight_starlight",
        hfyFoundationUrl: "https://hfy.foundation/series/2033",
        chapterCount: 41
    },
    {
        id: "starshine",
        title: "StarShine",
        author: "Ma7ich",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/starshine",
        hfyFoundationUrl: "https://hfy.foundation/series/734",
        chapterCount: 4
    },
    {
        id: "stasis",
        title: "Stasis",
        author: "fluffysilverunicorn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stasis",
        hfyFoundationUrl: "https://hfy.foundation/series/149",
        chapterCount: 4
    },
    {
        id: "status_endangered",
        title: "Status : Endangered",
        author: "wololololow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/status_endangered",
        hfyFoundationUrl: "https://hfy.foundation/series/816",
        chapterCount: 6
    },
    {
        id: "steel_and_sarcasm",
        title: "Steel and Sarcasm",
        author: "LimblessArmsman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/steel_and_sarcasm",
        hfyFoundationUrl: "https://hfy.foundation/series/883",
        chapterCount: 15
    },
    {
        id: "stellar_cartography_101",
        title: "Stellar Cartography 101",
        author: "bjorntfh",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stellar_cartography_101",
        hfyFoundationUrl: "https://hfy.foundation/series/1152",
        chapterCount: 11
    },
    {
        id: "stereotypical_isekai",
        title: "Stereotypical Isekai",
        author: "Mountain_Revenue_353",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stereotypical_isekai",
        hfyFoundationUrl: "https://hfy.foundation/series/3140",
        chapterCount: 76
    },
    {
        id: "the_stories_were_true",
        title: "The Stories Were True",
        author: "coldfireknight",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_stories_were_true",
        hfyFoundationUrl: "https://hfy.foundation/series/2091",
        chapterCount: 7
    },
    {
        id: "storm",
        title: "STORM",
        author: "lukeb28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/storm_hurrican_caesar",
        hfyFoundationUrl: "https://hfy.foundation/series/175",
        chapterCount: 3
    },
    {
        id: "the_story_of_arg_nathar",
        title: "The Story of Arg'Nathar",
        author: "Wotalooza",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_story_of_argnathar",
        hfyFoundationUrl: "https://hfy.foundation/series/254",
        chapterCount: 7
    },
    {
        id: "stranded",
        title: "Stranded",
        author: "Exotic_Fish",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stranded",
        hfyFoundationUrl: "https://hfy.foundation/series/189",
        chapterCount: 7
    },
    {
        id: "stranded_2",
        title: "Stranded",
        author: "WheezyWhiner",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stranded_wheezywhiner",
        hfyFoundationUrl: "https://hfy.foundation/series/1679",
        chapterCount: 20
    },
    {
        id: "stranded_will_you_help_me",
        title: "Stranded: Will You Help Me?",
        author: "DanteCharlstnJamesJr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stranded_will_you_help_me",
        hfyFoundationUrl: "https://hfy.foundation/series/2733",
        chapterCount: 7
    },
    {
        id: "stranded_on_a_world_of_birds",
        title: "Stranded On A World Of Birds",
        author: "Imjustthatguyok",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stranded_on_a_world_of_birds",
        hfyFoundationUrl: "https://hfy.foundation/series/3733",
        chapterCount: 15
    },
    {
        id: "stranded_on_deathworld_with_the_deathworlders",
        title: "Stranded On Deathworld With The Deathworlders",
        author: "ChairsMiddleLeg",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stranded_on_deathworld_with_the_deathworlders",
        hfyFoundationUrl: "https://hfy.foundation/series/2471",
        chapterCount: 2
    },
    {
        id: "strangers_in_our_midst",
        title: "Strangers In Our Midst",
        author: "Lostfol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/strangers_in_our_midst",
        hfyFoundationUrl: "https://hfy.foundation/series/1495",
        chapterCount: 26
    },
    {
        id: "strength_in_reserve",
        title: "Strength in Reserve",
        author: "blablabliam",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/strength_in_reserve",
        hfyFoundationUrl: "https://hfy.foundation/series/714",
        chapterCount: 2
    },
    {
        id: "stroke_of_luck",
        title: "Stroke of Luck",
        author: "Raivax",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stroke_of_luck",
        hfyFoundationUrl: "https://hfy.foundation/series/248",
        chapterCount: 3
    },
    {
        id: "a_stroll_around_kalamati",
        title: "A Stroll Around Kalamati",
        author: "thashepherd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_stroll_around_kalamati",
        hfyFoundationUrl: "https://hfy.foundation/series/1880",
        chapterCount: 3
    },
    {
        id: "stubbornness",
        title: "Stubbornness",
        author: "TangoDeltaBravo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stubbornness",
        hfyFoundationUrl: "https://hfy.foundation/series/10",
        chapterCount: 2
    },
    {
        id: "a_study_of_humerisite_kings",
        title: "A Study Of Humerisite Kings",
        author: "PatchworthPlus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_study_of_humerisite_kings",
        hfyFoundationUrl: "https://hfy.foundation/series/2481",
        chapterCount: 2
    },
    {
        id: "the_stuff_of_legends",
        title: "The Stuff Of Legends",
        author: "writerunblocked",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_stuff_of_legends",
        hfyFoundationUrl: "https://hfy.foundation/series/2685",
        chapterCount: 7
    },
    {
        id: "stuff_of_legends",
        title: "Stuff Of Legends",
        author: "conquerorwiggles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stuff_of_legends",
        hfyFoundationUrl: "https://hfy.foundation/series/1359",
        chapterCount: 3
    },
    {
        id: "sufficiently_advanced",
        title: "Sufficiently Advanced",
        author: "rocconteur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sufficiently_advanced",
        hfyFoundationUrl: "https://hfy.foundation/series/3655",
        chapterCount: 38
    },
    {
        id: "summoning_kobolds_at_midnight",
        title: "Summoning Kobolds At Midnight",
        author: "Necrolancer96",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/summoning_kobolds_at_midnight",
        hfyFoundationUrl: "https://hfy.foundation/series/4496",
        chapterCount: 178
    },
    {
        id: "the_sun_once_rose",
        title: "The Sun Once Rose",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sun_once_rose",
        hfyFoundationUrl: "https://hfy.foundation/series/1960",
        chapterCount: 3
    },
    {
        id: "sundered_realms",
        title: "Sundered Realms",
        author: "Rainor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sundered_realms",
        hfyFoundationUrl: "https://hfy.foundation/series/1776",
        chapterCount: 22
    },
    {
        id: "super_soldier_in_another_world",
        title: "Super Soldier In Another World",
        author: "Nivilack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/super_soldier_in_another_world",
        hfyFoundationUrl: "https://hfy.foundation/series/4092",
        chapterCount: 22
    },
    {
        id: "supervillainy_and_other_poor_career_choices",
        title: "Supervillainy And Other Poor Career Choices",
        author: "SoggyRed",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/supervillainy_and_other_poor_career_choices",
        hfyFoundationUrl: "https://hfy.foundation/series/1664",
        chapterCount: 61
    },
    {
        id: "support_is_here",
        title: "Support Is Here",
        author: "BirdieBlackWhite",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/support_is_here",
        hfyFoundationUrl: "https://hfy.foundation/series/3915",
        chapterCount: 66
    },
    {
        id: "survival",
        title: "Survival!",
        author: "PhilattheGame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/survival",
        hfyFoundationUrl: "https://hfy.foundation/series/2216",
        chapterCount: 23
    },
    {
        id: "surviving",
        title: "Surviving",
        author: "MagicMayhem117",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/surviving",
        hfyFoundationUrl: "https://hfy.foundation/series/4485",
        chapterCount: 28
    },
    {
        id: "surviving_the_deadliest_magic_academy",
        title: "Surviving The Deadliest Magic Academy",
        author: "water\\_melon99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/surviving_the_deadliest_magic_academy",
        hfyFoundationUrl: "https://hfy.foundation/series/5605",
        chapterCount: 26
    },
    {
        id: "the_survivor_becomes_a_dungeon",
        title: "The Survivor Becomes A Dungeon",
        author: "ScribblingFox98",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_survivor_becomes_a_dungeon",
        hfyFoundationUrl: "https://hfy.foundation/series/4288",
        chapterCount: 151
    },
    {
        id: "the_swarm",
        title: "The Swarm",
        author: "ArchDragon99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_swarm",
        hfyFoundationUrl: "https://hfy.foundation/series/1615",
        chapterCount: 16
    },
    {
        id: "sweetness",
        title: "Sweetness",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sweetness",
        hfyFoundationUrl: "https://hfy.foundation/series/681",
        chapterCount: 7
    },
    {
        id: "a_sword_s_shadow",
        title: "A Sword's Shadow",
        author: "Thorous_the3rd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_swords_shadow",
        hfyFoundationUrl: "https://hfy.foundation/series/239",
        chapterCount: 10
    },
    {
        id: "sword_and_shield",
        title: "Sword and Shield",
        author: "Jurodan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sword_and_shield_jurodan",
        hfyFoundationUrl: "https://hfy.foundation/series/780",
        chapterCount: 5
    },
    {
        id: "synchronizing_minds",
        title: "Synchronizing Minds",
        author: "CherubielOne",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/synchronizing_minds",
        hfyFoundationUrl: "https://hfy.foundation/series/5395",
        chapterCount: 11
    },
    {
        id: "synthcorp",
        title: "Synthcorp",
        author: "ainsleyeadams",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/synthcorp",
        hfyFoundationUrl: "https://hfy.foundation/series/2683",
        chapterCount: 5
    },
    {
        id: "taken",
        title: "Taken",
        author: "Pasteltichan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/taken",
        hfyFoundationUrl: "https://hfy.foundation/series/44",
        chapterCount: 3
    },
    {
        id: "tale_of_tales",
        title: "Tale Of Tales",
        author: "Nikola_Stefan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tale_of_tales",
        hfyFoundationUrl: "https://hfy.foundation/series/3911",
        chapterCount: 24
    },
    {
        id: "tales_for_death",
        title: "Tales For Death",
        author: "floofusest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_for_death",
        hfyFoundationUrl: "https://hfy.foundation/series/4187",
        chapterCount: 4
    },
    {
        id: "tales_from_a_far_flung_mining_colony",
        title: "Tales From A Far-flung Mining Colony",
        author: "someone_FIN",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_a_farflung_mining_colony",
        hfyFoundationUrl: "https://hfy.foundation/series/2021",
        chapterCount: 2
    },
    {
        id: "tales_from_space_tech_support",
        title: "Tales From Space Tech Support",
        author: "Teulisch",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_space_tech_support",
        hfyFoundationUrl: "https://hfy.foundation/series/1142",
        chapterCount: 15
    },
    {
        id: "tales_from_the_glassvine_wilds",
        title: "Tales From The Glassvine Wilds",
        author: "SamuelDancing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_the_glassvine_wilds",
        hfyFoundationUrl: "https://hfy.foundation/series/3734",
        chapterCount: 44
    },
    {
        id: "tales_from_the_terran_republic",
        title: "Tales From The Terran Republic",
        author: "slightlyassholic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_the_terran_republic",
        hfyFoundationUrl: "https://hfy.foundation/series/1824",
        chapterCount: 322
    },
    {
        id: "tales_of_round_the_galaxy_dumbassery_madness_and_excessive_ammounts_of_half_baked_memes",
        title: "Tales Of 'Round The Galaxy: Dumbassery, Madness, And Excessive Ammounts Of Half-baked Memes",
        author: "Darkorvit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_round_the_galaxy_dumbassery_madness_and_excessive_ammounts_of_halfbaked_memes",
        hfyFoundationUrl: "https://hfy.foundation/series/3113",
        chapterCount: 38
    },
    {
        id: "tales_of_aldmera",
        title: "Tales Of Aldmera",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_aldmera",
        hfyFoundationUrl: "https://hfy.foundation/series/190",
        chapterCount: 21
    },
    {
        id: "tales_of_nautilus_station",
        title: "Tales Of Nautilus Station",
        author: "Ciryher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_nautilus_station",
        hfyFoundationUrl: "https://hfy.foundation/series/649",
        chapterCount: 3
    },
    {
        id: "tales_of_the_queer_islands",
        title: "Tales Of The Queer Islands",
        author: "gslakes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_the_queer_islands",
        hfyFoundationUrl: "https://hfy.foundation/series/4660",
        chapterCount: 23
    },
    {
        id: "tales_of_unlikely_wizard",
        title: "Tales Of Unlikely Wizard",
        author: "Cookie-Crumble-",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_unlikely_wizard",
        hfyFoundationUrl: "https://hfy.foundation/series/2846",
        chapterCount: 61
    },
    {
        id: "the_tapestry",
        title: "The Tapestry",
        author: "tripplewitch",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_tapestry",
        hfyFoundationUrl: "https://hfy.foundation/series/4393",
        chapterCount: 39
    },
    {
        id: "tarie_help_me",
        title: "Tarie Help Me",
        author: "Deaven200",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tarie_help_me",
        hfyFoundationUrl: "https://hfy.foundation/series/1457",
        chapterCount: 3
    },
    {
        id: "task_force_doomer_gets_isekai_ed",
        title: "Task Force Doomer Gets Isekai'ed",
        author: "Riomine1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/task_force_doomer_gets_isekaied",
        hfyFoundationUrl: "https://hfy.foundation/series/4037",
        chapterCount: 37
    },
    {
        id: "telum_est",
        title: "Telum Est",
        author: "coldfireknight",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/telum_est",
        hfyFoundationUrl: "https://hfy.foundation/series/4525",
        chapterCount: 8
    },
    {
        id: "the_temple_of_ash",
        title: "The Temple of Ash",
        author: "novatheelf",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_temple_of_ash",
        hfyFoundationUrl: "https://hfy.foundation/series/2434",
        chapterCount: 8
    },
    {
        id: "terpsichore",
        title: "Terpsichore",
        author: "Catullus74",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terpsichore",
        hfyFoundationUrl: "https://hfy.foundation/series/1324",
        chapterCount: 5
    },
    {
        id: "terra_rise",
        title: "Terra, Rise",
        author: "CaptainKind",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terra_rise",
        hfyFoundationUrl: "https://hfy.foundation/series/590",
        chapterCount: 3
    },
    {
        id: "the_terran_and_the_fox",
        title: "The Terran And The Fox",
        author: "Fabulous-Tax2445",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_terran_and_the_fox",
        hfyFoundationUrl: "https://hfy.foundation/series/5302",
        chapterCount: 34
    },
    {
        id: "terran_contact",
        title: "Terran Contact",
        author: "VexTrooper",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terran_contact",
        hfyFoundationUrl: "https://hfy.foundation/series/4870",
        chapterCount: 60
    },
    {
        id: "a_terran_space_story_academy_days",
        title: "A Terran Space Story: Academy Days",
        author: "Recent-Development10",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_terran_space_story_academy_days",
        hfyFoundationUrl: "https://hfy.foundation/series/2990",
        chapterCount: 329
    },
    {
        id: "terrans_on_board",
        title: "Terrans On Board",
        author: "PhoenixGreen32",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terrans_on_board",
        hfyFoundationUrl: "https://hfy.foundation/series/3012",
        chapterCount: 22
    },
    {
        id: "the_terror_neighbour",
        title: "The Terror Neighbour",
        author: "DuringSummerMidnight",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_terror_neighbour",
        hfyFoundationUrl: "https://hfy.foundation/series/2611",
        chapterCount: 26
    },
    {
        id: "testing",
        title: "Testing",
        author: "RedShiftRazor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/testing",
        hfyFoundationUrl: "https://hfy.foundation/series/2408",
        chapterCount: 7
    },
    {
        id: "that_could_have_gone_better",
        title: "That Could Have Gone Better",
        author: "spidergod99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/that_could_have_gone_better",
        hfyFoundationUrl: "https://hfy.foundation/series/1338",
        chapterCount: 74
    },
    {
        id: "there_goes_the_neighborhood",
        title: "There Goes The Neighborhood",
        author: "ubermidget1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/there_goes_the_neighborhood",
        hfyFoundationUrl: "https://hfy.foundation/series/264",
        chapterCount: 14
    },
    {
        id: "there_will_be_scritches",
        title: "There Will Be Scritches",
        author: "YukiteruAmano92",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/there_will_be_scritches",
        hfyFoundationUrl: "https://hfy.foundation/series/3448",
        chapterCount: 547
    },
    {
        id: "there_s_a_demon_lord_renting_out_my_attic",
        title: "There's a Demon Lord Renting Out My Attic",
        author: "all_the_cliches",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/theres_a_demon_lord_renting_out_my_attic",
        hfyFoundationUrl: "https://hfy.foundation/series/760",
        chapterCount: 25
    },
    {
        id: "theseus",
        title: "Theseus",
        author: "Acclue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/theseus",
        hfyFoundationUrl: "https://hfy.foundation/series/5232",
        chapterCount: 52
    },
    {
        id: "they_always_slip_up",
        title: "They Always Slip Up",
        author: "TheWildColonialBoy1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_always_slip_up",
        hfyFoundationUrl: "https://hfy.foundation/series/2784",
        chapterCount: 6
    },
    {
        id: "they_called_him_kenny_g",
        title: "They Called Him Kenny G.",
        author: "Ryanqzqz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_called_him_kenny_g",
        hfyFoundationUrl: "https://hfy.foundation/series/1509",
        chapterCount: 5
    },
    {
        id: "they_have_no_spark",
        title: "They Have No Spark",
        author: "HereToNotBeElsewhere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_have_no_spark",
        hfyFoundationUrl: "https://hfy.foundation/series/647",
        chapterCount: 8
    },
    {
        id: "they_ve_been_here_all_along",
        title: "They've been here all along",
        author: "JCollierDavis",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/theyve_been_here_all_along",
        hfyFoundationUrl: "https://hfy.foundation/series/164",
        chapterCount: 9
    },
    {
        id: "they_were_our_friends",
        title: "They Were Our Friends",
        author: "ComposedAnarchy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_were_our_friends",
        hfyFoundationUrl: "https://hfy.foundation/series/4895",
        chapterCount: 10
    },
    {
        id: "they_were_the_last_resort",
        title: "They Were The Last Resort",
        author: "Hylianhero71",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_were_the_last_resort",
        hfyFoundationUrl: "https://hfy.foundation/series/3594",
        chapterCount: 9
    },
    {
        id: "things_that_go_bump_in_the_night",
        title: "Things That Go Bump In The Night",
        author: "Cryptek_Fashionista",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/things_that_go_bump_in_the_night",
        hfyFoundationUrl: "https://hfy.foundation/series/2249",
        chapterCount: 16
    },
    {
        id: "the_third_species",
        title: "The Third Species",
        author: "WeebleKeneeble",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_third_species",
        hfyFoundationUrl: "https://hfy.foundation/series/1446",
        chapterCount: 39
    },
    {
        id: "the_third_vor_war",
        title: "The Third Vor War",
        author: "governormilitantsmit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_third_vor_war",
        hfyFoundationUrl: "https://hfy.foundation/series/416",
        chapterCount: 5
    },
    {
        id: "this_one_was_different",
        title: "This One Was... Different",
        author: "ImaginationGamer24",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/this_one_was_different",
        hfyFoundationUrl: "https://hfy.foundation/series/2800",
        chapterCount: 6
    },
    {
        id: "this_is_bullshit",
        title: "This Is Bullshit",
        author: "xx_69mlgnoob_69xx",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/this_is_bullshit",
        hfyFoundationUrl: "https://hfy.foundation/series/3503",
        chapterCount: 48
    },
    {
        id: "those_are_our_damn_ships",
        title: "Those are our damn ships!",
        author: "\\_Sky__",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/those_are_our_damn_ships",
        hfyFoundationUrl: "https://hfy.foundation/series/1128",
        chapterCount: 6
    },
    {
        id: "those_days_with_the_monsters",
        title: "Those Days With The Monsters",
        author: "PlsHlpMyFriend",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/those_days_with_the_monsters",
        hfyFoundationUrl: "https://hfy.foundation/series/2910",
        chapterCount: 64
    },
    {
        id: "those_forgotten",
        title: "Those Forgotten",
        author: "Wotalooza",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/those_forgotten",
        hfyFoundationUrl: "https://hfy.foundation/series/546",
        chapterCount: 2
    },
    {
        id: "those_who_walk_unseen",
        title: "Those Who Walk Unseen",
        author: "manufacture_reborn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/those_who_walk_unseen",
        hfyFoundationUrl: "https://hfy.foundation/series/1310",
        chapterCount: 14
    },
    {
        id: "thralls",
        title: "Thralls",
        author: "notmuch123",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/thralls",
        hfyFoundationUrl: "https://hfy.foundation/series/2923",
        chapterCount: 35
    },
    {
        id: "three_billy_xenos_gruff",
        title: "Three Billy Xenos Gruff",
        author: "Chengelao",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/three_billy_xenos_gruff",
        hfyFoundationUrl: "https://hfy.foundation/series/1007",
        chapterCount: 3
    },
    {
        id: "tides_of_magic",
        title: "Tides Of Magic",
        author: "Arceroth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tides_of_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/1545",
        chapterCount: 47
    },
    {
        id: "tied_to_infinity",
        title: "Tied To Infinity",
        author: "Rustmyer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tied_to_infinity",
        hfyFoundationUrl: "https://hfy.foundation/series/3205",
        chapterCount: 18
    },
    {
        id: "ties_that_bind",
        title: "Ties That Bind",
        author: "fortis_in_verbis",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ties_that_bind",
        hfyFoundationUrl: "https://hfy.foundation/series/395",
        chapterCount: 2
    },
    {
        id: "time_for_pen_and_paper",
        title: "Time For Pen And Paper",
        author: "Plainside",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/time_for_pen_and_paper",
        hfyFoundationUrl: "https://hfy.foundation/series/1954",
        chapterCount: 2
    },
    {
        id: "to_hell_and_back",
        title: "To Hell And Back",
        author: "Objective_Campaign82",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_hell_and_back",
        hfyFoundationUrl: "https://hfy.foundation/series/3780",
        chapterCount: 85
    },
    {
        id: "to_kill_a_god_only_man_can",
        title: "To Kill A God, Only Man Can!",
        author: "Javisno",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_kill_a_god_only_man_can",
        hfyFoundationUrl: "https://hfy.foundation/series/5379",
        chapterCount: 4
    },
    {
        id: "to_the_end_of_the_river",
        title: "To the End of the River",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_the_end_of_the_river",
        hfyFoundationUrl: "https://hfy.foundation/series/202",
        chapterCount: 2
    },
    {
        id: "to_touch_the_stars",
        title: "To Touch The Stars",
        author: "Ilithi_Dragon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_touch_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/1668",
        chapterCount: 4
    },
    {
        id: "today_we_will_return",
        title: "Today, we will return",
        author: "TehBaggins",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/today_we_will_return",
        hfyFoundationUrl: "https://hfy.foundation/series/455",
        chapterCount: 2
    },
    {
        id: "todd_c_mcgraw",
        title: "Todd C. McGraw",
        author: "AJMansfield_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/todd_c_mcgraw",
        hfyFoundationUrl: "https://hfy.foundation/series/1508",
        chapterCount: 2
    },
    {
        id: "tome_of_the_body",
        title: "Tome Of The Body",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tome_of_the_body",
        hfyFoundationUrl: "https://hfy.foundation/series/3316",
        chapterCount: 76
    },
    {
        id: "tools_of_the_trade",
        title: "Tools of the trade",
        author: "TheWalrusResplendent",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tools_of_the_trade",
        hfyFoundationUrl: "https://hfy.foundation/series/1193",
        chapterCount: 4
    },
    {
        id: "torchbearer_from_the_stars",
        title: "Torchbearer From The Stars",
        author: "Insert\\_Name\\_Here\\_\\_1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/torchbearer_from_the_stars",
        hfyFoundationUrl: "https://hfy.foundation/series/5426",
        chapterCount: 12
    },
    {
        id: "torches",
        title: "Torches",
        author: "jakethesnakebakecake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/torches",
        hfyFoundationUrl: "https://hfy.foundation/series/561",
        chapterCount: 6
    },
    {
        id: "toxic_diplomacy",
        title: "Toxic Diplomacy",
        author: "Delicious-Bat-3341",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/toxic_diplomacy",
        hfyFoundationUrl: "https://hfy.foundation/series/3674",
        chapterCount: 7
    },
    {
        id: "a_trail_of_debris",
        title: "A Trail Of Debris",
        author: "Negative-Chickens",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_trail_of_debris",
        hfyFoundationUrl: "https://hfy.foundation/series/2917",
        chapterCount: 4
    },
    {
        id: "the_train",
        title: "The Train",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_train",
        hfyFoundationUrl: "https://hfy.foundation/series/4025",
        chapterCount: 2
    },
    {
        id: "the_tramp",
        title: "The Tramp",
        author: "Hobbio",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_tramp",
        hfyFoundationUrl: "https://hfy.foundation/series/409",
        chapterCount: 5
    },
    {
        id: "transcendence",
        title: "Transcendence",
        author: "aryeh56",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/transcendence",
        hfyFoundationUrl: "https://hfy.foundation/series/223",
        chapterCount: 2
    },
    {
        id: "transcripts",
        title: "Transcripts",
        author: "squigglestorystudios",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/transcripts",
        hfyFoundationUrl: "https://hfy.foundation/series/898",
        chapterCount: 111
    },
    {
        id: "transfer_orders",
        title: "Transfer Orders",
        author: "punnynfunny",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/transfer_orders",
        hfyFoundationUrl: "https://hfy.foundation/series/3537",
        chapterCount: 16
    },
    {
        id: "the_traveler_from_far_away",
        title: "The Traveler From Far Away",
        author: "Kobsel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_traveler_from_far_away",
        hfyFoundationUrl: "https://hfy.foundation/series/5270",
        chapterCount: 11
    },
    {
        id: "traverse",
        title: "Traverse",
        author: "TheStabbyBrit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/traverse",
        hfyFoundationUrl: "https://hfy.foundation/series/2052",
        chapterCount: 15
    },
    {
        id: "treacherous_soul",
        title: "Treacherous Soul",
        author: "Expired_Coffee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/treacherous_soul",
        hfyFoundationUrl: "https://hfy.foundation/series/3128",
        chapterCount: 4
    },
    {
        id: "the_trekkil",
        title: "The Trekkil",
        author: "gridcube",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_trekkil",
        hfyFoundationUrl: "https://hfy.foundation/series/1257",
        chapterCount: 10
    },
    {
        id: "trenches",
        title: "Trenches",
        author: "adoeak",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trenches",
        hfyFoundationUrl: "https://hfy.foundation/series/4023",
        chapterCount: 5
    },
    {
        id: "the_trial",
        title: "The Trial",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_trial",
        hfyFoundationUrl: "https://hfy.foundation/series/832",
        chapterCount: 15
    },
    {
        id: "trials_and_tribulations",
        title: "Trials And Tribulations",
        author: "WolfxBlood22",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trials_and_tribulations",
        hfyFoundationUrl: "https://hfy.foundation/series/4083",
        chapterCount: 8
    },
    {
        id: "trifear",
        title: "TriFear",
        author: "looktosee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trifear",
        hfyFoundationUrl: "https://hfy.foundation/series/90",
        chapterCount: 5
    },
    {
        id: "trinity",
        title: "Trinity",
        author: "Ackbarre",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trinity",
        hfyFoundationUrl: "https://hfy.foundation/series/12",
        chapterCount: 3
    },
    {
        id: "trouble_in_paradise",
        title: "Trouble In Paradise",
        author: "fex1128",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/trouble_in_paradise",
        hfyFoundationUrl: "https://hfy.foundation/series/5241",
        chapterCount: 13
    },
    {
        id: "trouble_in_triskel",
        title: "Trouble in Triskel",
        author: "seylek",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trouble_in_triskel",
        hfyFoundationUrl: "https://hfy.foundation/series/777",
        chapterCount: 2
    },
    {
        id: "trucking",
        title: "Trucking",
        author: "Allergoric",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trucking",
        hfyFoundationUrl: "https://hfy.foundation/series/2941",
        chapterCount: 3
    },
    {
        id: "true_awakening",
        title: "True Awakening",
        author: "Suck_My_Diabeetus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/true_awakening",
        hfyFoundationUrl: "https://hfy.foundation/series/129",
        chapterCount: 7
    },
    {
        id: "true_predators",
        title: "True Predators",
        author: "TheFrostborn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/true_predators",
        hfyFoundationUrl: "https://hfy.foundation/series/4161",
        chapterCount: 30
    },
    {
        id: "the_trust_of_humans",
        title: "The Trust of Humans",
        author: "DracheGraethe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_trust_of_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/1327",
        chapterCount: 7
    },
    {
        id: "the_turning_point",
        title: "The Turning Point",
        author: "Balthos",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_turning_point",
        hfyFoundationUrl: "https://hfy.foundation/series/13",
        chapterCount: 10
    },
    {
        id: "twisted_hell",
        title: "Twisted Hell",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/twisted_hell",
        hfyFoundationUrl: "https://hfy.foundation/series/1588",
        chapterCount: 198
    },
    {
        id: "the_twists_of_fate",
        title: "The Twists Of Fate",
        author: "bjplague",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_twists_of_fate",
        hfyFoundationUrl: "https://hfy.foundation/series/2617",
        chapterCount: 9
    },
    {
        id: "two_souls",
        title: "Two Souls",
        author: "u/creaturecoby",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/two_souls",
        hfyFoundationUrl: "https://hfy.foundation/series/356",
        chapterCount: 20
    },
    {
        id: "type_a_and_type_b",
        title: "Type A And Type B",
        author: "DeathJester13",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/type_a_and_type_b",
        hfyFoundationUrl: "https://hfy.foundation/series/1321",
        chapterCount: 10
    },
    {
        id: "unburdened",
        title: "Unburdened",
        author: "Frame_Late",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unburdened",
        hfyFoundationUrl: "https://hfy.foundation/series/5259",
        chapterCount: 4
    },
    {
        id: "uncharted_waters",
        title: "Uncharted Waters",
        author: "LiseEclaire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/uncharted_waters",
        hfyFoundationUrl: "https://hfy.foundation/series/4867",
        chapterCount: 15
    },
    {
        id: "the_uncle_tal_stories",
        title: "The Uncle Tal Stories",
        author: "ack1308",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_uncle_tal_stories",
        hfyFoundationUrl: "https://hfy.foundation/series/2198",
        chapterCount: 21
    },
    {
        id: "the_undamned",
        title: "The Undamned",
        author: "Anus_Blenders",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_undamned",
        hfyFoundationUrl: "https://hfy.foundation/series/338",
        chapterCount: 6
    },
    {
        id: "under_the_authority",
        title: "Under The Authority",
        author: "traveller-16-16-",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/under_the_authority",
        hfyFoundationUrl: "https://hfy.foundation/series/5010",
        chapterCount: 11
    },
    {
        id: "understanding_humanity",
        title: "Understanding Humanity",
        author: "sirkaid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/understanding_humanity",
        hfyFoundationUrl: "https://hfy.foundation/series/29",
        chapterCount: 3
    },
    {
        id: "an_unfortunate_accident",
        title: "An Unfortunate Accident",
        author: "Tunnel--Rat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_unfortunate_accident",
        hfyFoundationUrl: "https://hfy.foundation/series/2369",
        chapterCount: 2
    },
    {
        id: "unity_series",
        title: "Unity Series",
        author: "Wotalooza",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unity_series",
        hfyFoundationUrl: "https://hfy.foundation/series/293",
        chapterCount: 11
    },
    {
        id: "universal_constants",
        title: "Universal Constants",
        author: "Alternative-Pumpkin9",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/universal_constants",
        hfyFoundationUrl: "https://hfy.foundation/series/3115",
        chapterCount: 3
    },
    {
        id: "a_universe_of_magic",
        title: "A Universe Of Magic",
        author: "Lazy-Personality4024",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_universe_of_magic",
        hfyFoundationUrl: "https://hfy.foundation/series/3136",
        chapterCount: 99
    },
    {
        id: "the_universe_went_fucky",
        title: "The Universe Went Fucky",
        author: "Sweggler",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_universe_went_fucky",
        hfyFoundationUrl: "https://hfy.foundation/series/3766",
        chapterCount: 23
    },
    {
        id: "unleashed",
        title: "Unleashed",
        author: "Author - Sooperdude24",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unleashed",
        hfyFoundationUrl: "https://hfy.foundation/series/2152",
        chapterCount: 79
    },
    {
        id: "the_unlikely_guardian",
        title: "The Unlikely Guardian",
        author: "SkullbombRaging",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_unlikely_guardian",
        hfyFoundationUrl: "https://hfy.foundation/series/3235",
        chapterCount: 3
    },
    {
        id: "unraveling_the_enigmite",
        title: "Unraveling The Enigmite",
        author: "Dejers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unraveling_the_enigmite",
        hfyFoundationUrl: "https://hfy.foundation/series/2299",
        chapterCount: 16
    },
    {
        id: "an_unstoppable_machine",
        title: "An Unstoppable Machine",
        author: "tannenbanannen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_unstoppable_machine",
        hfyFoundationUrl: "https://hfy.foundation/series/1217",
        chapterCount: 3
    },
    {
        id: "the_unsworn",
        title: "The Unsworn",
        author: "ryderintow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_unsworn",
        hfyFoundationUrl: "https://hfy.foundation/series/1085",
        chapterCount: 3
    },
    {
        id: "untitled_document",
        title: "Untitled Document",
        author: "AthiestBroker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/untitled_document",
        hfyFoundationUrl: "https://hfy.foundation/series/188",
        chapterCount: 7
    },
    {
        id: "uplift_protocol",
        title: "Uplift Protocol",
        author: "CalmBeforeTheEclipse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/uplift_protocol",
        hfyFoundationUrl: "https://hfy.foundation/series/1122",
        chapterCount: 70
    },
    {
        id: "the_uplifters",
        title: "The Uplifters",
        author: "lukeb28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_uplifters",
        hfyFoundationUrl: "https://hfy.foundation/series/302",
        chapterCount: 4
    },
    {
        id: "vaid_empire_conquest",
        title: "Vaid Empire: Conquest",
        author: "MrGreen103",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/vaid_empire_conquest",
        hfyFoundationUrl: "https://hfy.foundation/series/4555",
        chapterCount: 76
    },
    {
        id: "valkyrie",
        title: "Valkyrie",
        author: "Lightenant",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/valkyrie",
        hfyFoundationUrl: "https://hfy.foundation/series/2296",
        chapterCount: 4
    },
    {
        id: "valkyrie_off",
        title: "Valkyrie:Off",
        author: "DessicatedTytrations",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/valkyrieoff",
        hfyFoundationUrl: "https://hfy.foundation/series/1734",
        chapterCount: 2
    },
    {
        id: "a_valkyrie_s_saga",
        title: "A Valkyrie's Saga",
        author: "MountainSkald",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_valkyries_saga",
        hfyFoundationUrl: "https://hfy.foundation/series/5352",
        chapterCount: 100
    },
    {
        id: "the_valiant_few",
        title: "The Valiant Few",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_valiant_few",
        hfyFoundationUrl: "https://hfy.foundation/series/644",
        chapterCount: 11
    },
    {
        id: "veal",
        title: "Veal",
        author: "Dangermanagement",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/veal",
        hfyFoundationUrl: "https://hfy.foundation/series/329",
        chapterCount: 4
    },
    {
        id: "veldin",
        title: "Veldin",
        author: "somenomad",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/veldin",
        hfyFoundationUrl: "https://hfy.foundation/series/570",
        chapterCount: 6
    },
    {
        id: "the_vengeance_bargain",
        title: "The Vengeance Bargain",
        author: "alexdelacluj",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_vengeance_bargain",
        hfyFoundationUrl: "https://hfy.foundation/series/2699",
        chapterCount: 3
    },
    {
        id: "very_clever_primitives",
        title: "Very Clever Primitives",
        author: "GraveyardOperations",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/very_clever_primitives",
        hfyFoundationUrl: "https://hfy.foundation/series/1219",
        chapterCount: 19
    },
    {
        id: "a_very_good_reason",
        title: "A Very Good Reason",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_very_good_reason",
        hfyFoundationUrl: "https://hfy.foundation/series/2268",
        chapterCount: 10
    },
    {
        id: "the_viking",
        title: "The Viking",
        author: "ElGatoBandito",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_viking",
        hfyFoundationUrl: "https://hfy.foundation/series/392",
        chapterCount: 8
    },
    {
        id: "the_villainess_is_an_ss_rank_adventurer",
        title: "The Villainess Is An SS+ Rank Adventurer",
        author: "kayenano",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_villainess_is_an_ss_rank_adventurer",
        hfyFoundationUrl: "https://hfy.foundation/series/4839",
        chapterCount: 199
    },
    {
        id: "a_viper_s_nest",
        title: "A Viper's Nest",
        author: "VioletOrchid85",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_vipers_nest",
        hfyFoundationUrl: "https://hfy.foundation/series/3569",
        chapterCount: 31
    },
    {
        id: "virtual_friendship",
        title: "Virtual Friendship",
        author: "Nelsyv",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/virtual_friendship",
        hfyFoundationUrl: "https://hfy.foundation/series/1834",
        chapterCount: 7
    },
    {
        id: "the_voice_in_his_head",
        title: "The Voice In His Head",
        author: "jldew",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_voice_in_his_head",
        hfyFoundationUrl: "https://hfy.foundation/series/2616",
        chapterCount: 46
    },
    {
        id: "void_afire",
        title: "Void Afire",
        author: "manufacture_reborn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/void_afire",
        hfyFoundationUrl: "https://hfy.foundation/series/793",
        chapterCount: 7
    },
    {
        id: "void_predators",
        title: "Void Predators",
        author: "runs-with-scissors42",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/void_predators",
        hfyFoundationUrl: "https://hfy.foundation/series/3479",
        chapterCount: 51
    },
    {
        id: "voidrunner_tales",
        title: "VoidRunner Tales",
        author: "the_crazypineapple",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/voidrunner_tales",
        hfyFoundationUrl: "https://hfy.foundation/series/225",
        chapterCount: 4
    },
    {
        id: "the_voluntold",
        title: "The Voluntold",
        author: "stonesdoorsbeatles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_voluntold",
        hfyFoundationUrl: "https://hfy.foundation/series/2705",
        chapterCount: 71
    },
    {
        id: "wait_am_i_the_orc_overlord",
        title: "Wait, Am I The Orc Overlord?",
        author: "JiangRong222",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wait_am_i_the_orc_overlord",
        hfyFoundationUrl: "https://hfy.foundation/series/3422",
        chapterCount: 23
    },
    {
        id: "wait_is_this_just_gate",
        title: "Wait, Is This Just GATE?",
        author: "PepperAntique",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wait_is_this_just_gate",
        hfyFoundationUrl: "https://hfy.foundation/series/3340",
        chapterCount: 759
    },
    {
        id: "walker",
        title: "Walker",
        author: "ack1308",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/walker",
        hfyFoundationUrl: "https://hfy.foundation/series/2211",
        chapterCount: 13
    },
    {
        id: "the_wanderer",
        title: "The Wanderer",
        author: "PrussianJoe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_wanderer",
        hfyFoundationUrl: "https://hfy.foundation/series/186",
        chapterCount: 4
    },
    {
        id: "the_wandering_ai",
        title: "The Wandering AI",
        author: "a-soul-flame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_wandering_ai",
        hfyFoundationUrl: "https://hfy.foundation/series/3584",
        chapterCount: 56
    },
    {
        id: "war_isn_t_hell",
        title: "War Isn't Hell",
        author: "MachDhai",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/war_isnt_hell",
        hfyFoundationUrl: "https://hfy.foundation/series/1290",
        chapterCount: 21
    },
    {
        id: "the_war_of_exaltation",
        title: "The War Of Exaltation",
        author: "Cabalist_writes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_war_of_exaltation",
        hfyFoundationUrl: "https://hfy.foundation/series/3339",
        chapterCount: 27
    },
    {
        id: "warmaster",
        title: "Warmaster",
        author: "ludomastro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warmaster",
        hfyFoundationUrl: "https://hfy.foundation/series/2076",
        chapterCount: 4
    },
    {
        id: "warning_entering_hostile_territory",
        title: "Warning: Entering Hostile Territory",
        author: "DioriteIgneous",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warning_entering_hostile_territory",
        hfyFoundationUrl: "https://hfy.foundation/series/3186",
        chapterCount: 4
    },
    {
        id: "warrior_nomads_guardians_of_peace_bearers_of_death",
        title: "Warrior Nomads, Guardians Of Peace, Bearers Of Death",
        author: "RaiderUnit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warrior_nomads_guardians_of_peace_bearers_of_death",
        hfyFoundationUrl: "https://hfy.foundation/series/1983",
        chapterCount: 9
    },
    {
        id: "waterworld",
        title: "Waterworld",
        author: "Ember072",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/waterworld",
        hfyFoundationUrl: "https://hfy.foundation/series/1697",
        chapterCount: 6
    },
    {
        id: "waterworld_2",
        title: "Waterworld",
        author: "puzzleheadeddrinker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/waterworld_puzzleheadeddrinker",
        hfyFoundationUrl: "https://hfy.foundation/series/2360",
        chapterCount: 11
    },
    {
        id: "we_do_not_want_to_fight",
        title: "We do not want to fight",
        author: "snjoi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_do_not_want_to_fight",
        hfyFoundationUrl: "https://hfy.foundation/series/511",
        chapterCount: 3
    },
    {
        id: "we_intend_no_harm",
        title: "We Intend No Harm",
        author: "UpIsOben",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_intend_no_harm",
        hfyFoundationUrl: "https://hfy.foundation/series/2267",
        chapterCount: 54
    },
    {
        id: "we_leave_none_behind",
        title: "We Leave None Behind",
        author: "Ruggi_2001",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_leave_none_behind",
        hfyFoundationUrl: "https://hfy.foundation/series/3163",
        chapterCount: 6
    },
    {
        id: "we_lucky_few",
        title: "We Lucky Few",
        author: "Meatfcker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_lucky_few",
        hfyFoundationUrl: "https://hfy.foundation/series/218",
        chapterCount: 10
    },
    {
        id: "we_need_a_deathworlder",
        title: "We Need A Deathworlder!",
        author: "Demonicking101",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_need_a_deathworlder",
        hfyFoundationUrl: "https://hfy.foundation/series/2919",
        chapterCount: 109
    },
    {
        id: "we_need_a_job_for_a_deathworlder",
        title: "We Need A Job For A Deathworlder",
        author: "Demonicking101",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_need_a_job_for_a_deathworlder",
        hfyFoundationUrl: "https://hfy.foundation/series/3161",
        chapterCount: 64
    },
    {
        id: "we_thought_wrong",
        title: "We Thought Wrong",
        author: "endersgame69",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_thought_wrong",
        hfyFoundationUrl: "https://hfy.foundation/series/2911",
        chapterCount: 22
    },
    {
        id: "we_were_the_ones",
        title: "We were the ones",
        author: "philliplikefrog",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_were_the_ones",
        hfyFoundationUrl: "https://hfy.foundation/series/389",
        chapterCount: 7
    },
    {
        id: "we_d_like_to_discuss_your_surrender",
        title: "We'd Like To Discuss Your Surrender",
        author: "yejustanotheraccount",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wed_like_to_discuss_your_surrender",
        hfyFoundationUrl: "https://hfy.foundation/series/4010",
        chapterCount: 9
    },
    {
        id: "weapons_and_potions",
        title: "Weapons And Potions",
        author: "blizz2415",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/weapons_and_potions",
        hfyFoundationUrl: "https://hfy.foundation/series/3240",
        chapterCount: 22
    },
    {
        id: "wearing_power_armor_to_a_magic_school",
        title: "Wearing Power Armor To A Magic School",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wearing_power_armor_to_a_magic_school",
        hfyFoundationUrl: "https://hfy.foundation/series/4399",
        chapterCount: 66
    },
    {
        id: "the_weary_warrior",
        title: "The Weary Warrior",
        author: "DerpyWriting68",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_weary_warrior",
        hfyFoundationUrl: "https://hfy.foundation/series/1120",
        chapterCount: 9
    },
    {
        id: "welcome_to_demon_school",
        title: "Welcome To Demon School",
        author: "AlieHaleyy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/welcome_to_demon_school",
        hfyFoundationUrl: "https://hfy.foundation/series/1989",
        chapterCount: 12
    },
    {
        id: "welcome_to_the_50s",
        title: "Welcome To The '50s",
        author: "NineteenSkylines",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/welcome_to_the_50s",
        hfyFoundationUrl: "https://hfy.foundation/series/2221",
        chapterCount: 8
    },
    {
        id: "welcome_to_valhalla",
        title: "Welcome To Valhalla",
        author: "bonk1969",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/welcome_to_valhalla",
        hfyFoundationUrl: "https://hfy.foundation/series/2667",
        chapterCount: 11
    },
    {
        id: "welcoming_committee",
        title: "Welcoming Committee",
        author: "JohnFalkirk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/welcoming_committee",
        hfyFoundationUrl: "https://hfy.foundation/series/918",
        chapterCount: 28
    },
    {
        id: "what_a_strange_galaxy",
        title: "What A Strange Galaxy",
        author: "Original_Richgame",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_a_strange_galaxy",
        hfyFoundationUrl: "https://hfy.foundation/series/3120",
        chapterCount: 9
    },
    {
        id: "what_can_be_said_of_humans",
        title: "What can be said of Humans?",
        author: "grierks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_can_be_said_of_humans",
        hfyFoundationUrl: "https://hfy.foundation/series/871",
        chapterCount: 23
    },
    {
        id: "what_does_it_mean_to_be_human",
        title: "What does it mean to be Human?",
        author: "HenryFordYork",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_does_it_mean_to_be_human",
        hfyFoundationUrl: "https://hfy.foundation/series/854",
        chapterCount: 6
    },
    {
        id: "what_ever_happened_to_humanity",
        title: "What Ever Happened To Humanity?",
        author: "chipgw",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_ever_happened_to_humanity",
        hfyFoundationUrl: "https://hfy.foundation/series/683",
        chapterCount: 25
    },
    {
        id: "what_humanity_means_to_me",
        title: "What Humanity Means To Me",
        author: "PTELuno",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_humanity_means_to_me",
        hfyFoundationUrl: "https://hfy.foundation/series/91",
        chapterCount: 3
    },
    {
        id: "what_i_ve_become",
        title: "What I've Become",
        author: "KnightBreeze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_ive_become",
        hfyFoundationUrl: "https://hfy.foundation/series/1622",
        chapterCount: 18
    },
    {
        id: "what_is_humanities_core",
        title: "What Is Humanities Core",
        author: "Yrwestilhere_05",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_is_humanities_core",
        hfyFoundationUrl: "https://hfy.foundation/series/5433",
        chapterCount: 17
    },
    {
        id: "what_s_underneath_a_human_s_helmet",
        title: "What's Underneath A Human's Helmet?",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/whats_underneath_a_humans_helmet",
        hfyFoundationUrl: "https://hfy.foundation/series/4290",
        chapterCount: 3
    },
    {
        id: "when_a_universe_dies",
        title: "When A Universe Dies",
        author: "Steller_Drifter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_a_universe_dies",
        hfyFoundationUrl: "https://hfy.foundation/series/4302",
        chapterCount: 5
    },
    {
        id: "when_deathworlders_chat",
        title: "When Deathworlders Chat",
        author: "theLegendaryJ",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_deathworlders_chat",
        hfyFoundationUrl: "https://hfy.foundation/series/3247",
        chapterCount: 48
    },
    {
        id: "when_deathworlders_meet",
        title: "When Deathworlders Meet",
        author: "andrews\\_2nd\\_account",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_deathworlders_meet",
        hfyFoundationUrl: "https://hfy.foundation/series/1331",
        chapterCount: 34
    },
    {
        id: "when_giants_come_knocking",
        title: "When Giants Come Knocking",
        author: "WeaverofW0rlds",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_giants_come_knocking",
        hfyFoundationUrl: "https://hfy.foundation/series/5277",
        chapterCount: 4
    },
    {
        id: "when_isekai_goes_wrong",
        title: "When Isekai Goes Wrong",
        author: "Zhule88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_isekai_goes_wrong",
        hfyFoundationUrl: "https://hfy.foundation/series/4264",
        chapterCount: 12
    },
    {
        id: "when_mind_and_matter_collide",
        title: "When Mind And Matter Collide",
        author: "Steller_Drifter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_mind_and_matter_collide",
        hfyFoundationUrl: "https://hfy.foundation/series/3242",
        chapterCount: 11
    },
    {
        id: "when_paths_collide",
        title: "When Paths Collide",
        author: "Raivene",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_paths_collide",
        hfyFoundationUrl: "https://hfy.foundation/series/3411",
        chapterCount: 58
    },
    {
        id: "when_the_gods_come_to_visit",
        title: "When The Gods Come To Visit",
        author: "Savyna154",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_the_gods_come_to_visit",
        hfyFoundationUrl: "https://hfy.foundation/series/1831",
        chapterCount: 28
    },
    {
        id: "when_the_worldships_of_humanity_came",
        title: "When the Worldships of Humanity Came",
        author: "Dexterous_Baroness",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_the_worldships_of_humanity_came",
        hfyFoundationUrl: "https://hfy.foundation/series/1012",
        chapterCount: 8
    },
    {
        id: "when_they_come",
        title: "When they come",
        author: "drizzt9889",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_they_come",
        hfyFoundationUrl: "https://hfy.foundation/series/106",
        chapterCount: 17
    },
    {
        id: "white_flame",
        title: "White Flame",
        author: "lordfaultington",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/white_flame",
        hfyFoundationUrl: "https://hfy.foundation/series/3929",
        chapterCount: 11
    },
    {
        id: "the_white_room",
        title: "The White Room",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_white_room",
        hfyFoundationUrl: "https://hfy.foundation/series/1356",
        chapterCount: 9
    },
    {
        id: "who_the_hell_are_you",
        title: "Who the hell are you?",
        author: "basement_crusader",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/who_the_hell_are_you",
        hfyFoundationUrl: "https://hfy.foundation/series/730",
        chapterCount: 13
    },
    {
        id: "why_humans_avoid_war",
        title: "Why Humans Avoid War",
        author: "SpacePaladin15",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/why_humans_avoid_war",
        hfyFoundationUrl: "https://hfy.foundation/series/2697",
        chapterCount: 27
    },
    {
        id: "why_humans_can_t_have_nice_things",
        title: "Why Humans Can't Have Nice Things",
        author: "wyrdsmith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/why_humans_cant_have_nice_things",
        hfyFoundationUrl: "https://hfy.foundation/series/1426",
        chapterCount: 2
    },
    {
        id: "why_you_don_t_anger_a_human",
        title: "Why You Don't Anger A Human",
        author: "Hyratel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/why_you_dont_anger_a_human",
        hfyFoundationUrl: "https://hfy.foundation/series/169",
        chapterCount: 2
    },
    {
        id: "why_you_should_never_date_a_space_roomba",
        title: "Why You Should Never Date A Space Roomba",
        author: "daikael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/why_you_should_never_date_a_space_roomba",
        hfyFoundationUrl: "https://hfy.foundation/series/2093",
        chapterCount: 4
    },
    {
        id: "will_play_for_space_travel",
        title: "Will Play For Space Travel",
        author: "CaptainCrochetHook",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/will_play_for_space_travel",
        hfyFoundationUrl: "https://hfy.foundation/series/1185",
        chapterCount: 13
    },
    {
        id: "a_wish_come_true",
        title: "A Wish Come True",
        author: "Cool_ball999",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_wish_come_true",
        hfyFoundationUrl: "https://hfy.foundation/series/3729",
        chapterCount: 30
    },
    {
        id: "the_witch_dungeon",
        title: "The Witch Dungeon",
        author: "ItsOKcomics",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_witch_dungeon",
        hfyFoundationUrl: "https://hfy.foundation/series/4796",
        chapterCount: 12
    },
    {
        id: "within_us_they_live_for_we_remember",
        title: "Within Us They Live, For We Remember",
        author: "repulsive-ardor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/within_us_they_live_for_we_remember",
        hfyFoundationUrl: "https://hfy.foundation/series/5554",
        chapterCount: 9
    },
    {
        id: "witness",
        title: "Witness",
        author: "Aggravating_Worth485",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/witness",
        hfyFoundationUrl: "https://hfy.foundation/series/5485",
        chapterCount: 26
    },
    {
        id: "witness_me",
        title: "Witness Me",
        author: "caesel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/witness_me",
        hfyFoundationUrl: "https://hfy.foundation/series/2730",
        chapterCount: 5
    },
    {
        id: "wizards_don_t_make_good_familiars",
        title: "Wizards Don't Make Good Familiars",
        author: "BontoSyl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wizards_dont_make_good_familiars",
        hfyFoundationUrl: "https://hfy.foundation/series/3583",
        chapterCount: 22
    },
    {
        id: "wolves_on_the_rim",
        title: "Wolves On The Rim",
        author: "175Genius",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wolves_on_the_rim",
        hfyFoundationUrl: "https://hfy.foundation/series/64",
        chapterCount: 2
    },
    {
        id: "a_world_away_from_yesterday",
        title: "A World Away From Yesterday",
        author: "equatorialbaconstrip",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_world_away_from_yesterday",
        hfyFoundationUrl: "https://hfy.foundation/series/642",
        chapterCount: 14
    },
    {
        id: "the_world_i_froze_in_time",
        title: "The World I Froze In Time",
        author: "Tim_Saian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_world_i_froze_in_time",
        hfyFoundationUrl: "https://hfy.foundation/series/2788",
        chapterCount: 86
    },
    {
        id: "the_world_of_death_and_war",
        title: "The World Of Death And War",
        author: "Vaughen1919",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_world_of_death_and_war",
        hfyFoundationUrl: "https://hfy.foundation/series/3219",
        chapterCount: 4
    },
    {
        id: "a_world_of_monsters",
        title: "A World Of Monsters",
        author: "Ankur_93_taken",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_world_of_monsters",
        hfyFoundationUrl: "https://hfy.foundation/series/2431",
        chapterCount: 18
    },
    {
        id: "the_worlds_of_the_war",
        title: "The Worlds Of The War",
        author: "IAmTheOutsider",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_worlds_of_the_war",
        hfyFoundationUrl: "https://hfy.foundation/series/1392",
        chapterCount: 10
    },
    {
        id: "the_world_that_was",
        title: "The World That Was",
        author: "J3P7",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_world_that_was",
        hfyFoundationUrl: "https://hfy.foundation/series/5122",
        chapterCount: 43
    },
    {
        id: "worldship_avalon",
        title: "Worldship Avalon",
        author: "mavranel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/worldship_avalon",
        hfyFoundationUrl: "https://hfy.foundation/series/3483",
        chapterCount: 35
    },
    {
        id: "worrisome_strength",
        title: "Worrisome Strength",
        author: "SwiftHound",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/worrisome_strength",
        hfyFoundationUrl: "https://hfy.foundation/series/3123",
        chapterCount: 35
    },
    {
        id: "the_worst_space_pirates_ever",
        title: "The Worst Space Pirates Ever",
        author: "RealRagingLlama",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_worst_space_pirates_ever",
        hfyFoundationUrl: "https://hfy.foundation/series/1794",
        chapterCount: 7
    },
    {
        id: "the_wounded_skies",
        title: "The Wounded Skies",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_wounded_skies",
        hfyFoundationUrl: "https://hfy.foundation/series/1371",
        chapterCount: 3
    },
    {
        id: "wrench_in_the_system",
        title: "Wrench in the System",
        author: "LSSUDommo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wrench_in_the_system",
        hfyFoundationUrl: "https://hfy.foundation/series/16",
        chapterCount: 3
    },
    {
        id: "wuulphee_human_bonds",
        title: "Wuulphee/Human Bonds",
        author: "cunvikted",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wuulphee_human_bonds",
        hfyFoundationUrl: "https://hfy.foundation/series/893",
        chapterCount: 7
    },
    {
        id: "wvss_rusalka",
        title: "WVSS Rusalka",
        author: "Tartahyuga",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wvss_rusalka",
        hfyFoundationUrl: "https://hfy.foundation/series/2589",
        chapterCount: 11
    },
    {
        id: "wyld_hunt",
        title: "Wyld Hunt",
        author: "toclacl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wyld_hunt",
        hfyFoundationUrl: "https://hfy.foundation/series/592",
        chapterCount: 8
    },
    {
        id: "xenoblade",
        title: "Xenoblade",
        author: "wormyish",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/xenobane",
        hfyFoundationUrl: "https://hfy.foundation/series/410",
        chapterCount: 6
    },
    {
        id: "the_xi_chang_saga",
        title: "The Xi�� Chang saga",
        author: "Hambone3110",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_xiu_chang_saga",
        hfyFoundationUrl: "https://hfy.foundation/series/213",
        chapterCount: 14
    },
    {
        id: "a_year_at_the_zoo",
        title: "A Year At The Zoo",
        author: "Aeogeus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_year_at_the_zoo",
        hfyFoundationUrl: "https://hfy.foundation/series/3608",
        chapterCount: 49
    },
    {
        id: "year_one",
        title: "Year One",
        author: "LordHenry7898",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/year_one",
        hfyFoundationUrl: "https://hfy.foundation/series/2030",
        chapterCount: 7
    },
    {
        id: "the_yes_and_the_y_all",
        title: "The Yes And The Y'all",
        author: "SoStrangeHere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_yes_and_the_yall",
        hfyFoundationUrl: "https://hfy.foundation/series/1884",
        chapterCount: 2
    },
    {
        id: "yesterday_s_hero",
        title: "Yesterday's Hero",
        author: "Righteous_Fury224",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/yesterdays_hero",
        hfyFoundationUrl: "https://hfy.foundation/series/3944",
        chapterCount: 113
    },
    {
        id: "yet_unnamed",
        title: "Yet Unnamed",
        author: "kaluce",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/yet_unnamed",
        hfyFoundationUrl: "https://hfy.foundation/series/83",
        chapterCount: 3
    },
    {
        id: "you_are_not_human",
        title: "YOU ARE NOT HUMAN!",
        author: "Zeus67",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/you_are_not_human",
        hfyFoundationUrl: "https://hfy.foundation/series/1162",
        chapterCount: 7
    },
    {
        id: "you_are_safe_now",
        title: "You Are Safe Now",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/you_are_safe_now",
        hfyFoundationUrl: "https://hfy.foundation/series/3962",
        chapterCount: 5
    },
    {
        id: "you_encountered_what",
        title: "You Encountered WHAT?!",
        author: "Seeker-Of-The-Void",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/you_encountered_what",
        hfyFoundationUrl: "https://hfy.foundation/series/2721",
        chapterCount: 15
    },
    {
        id: "you_re_a_human",
        title: "You're A Human",
        author: "ecoolasice",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/youre_a_human",
        hfyFoundationUrl: "https://hfy.foundation/series/2512",
        chapterCount: 5
    },
    {
        id: "the_z_team",
        title: "The Z Team",
        author: "ChrisDWrites",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_z_team",
        hfyFoundationUrl: "https://hfy.foundation/series/4478",
        chapterCount: 46
    },
    {
        id: "zeta_station",
        title: "Zeta Station",
        author: "Luna\\_LoveWell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/zeta_station",
        hfyFoundationUrl: "https://hfy.foundation/series/1094",
        chapterCount: 2
    },
    {
        id: "chaos_and_mayhem",
        title: "Chaos and Mayhem",
        author: "lordhenry7898",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/lordhenry7898/chaos_and_mayhem",
        hfyFoundationUrl: "https://hfy.foundation/series/2598",
        chapterCount: 44
    },
    {
        id: "top_lasgun",
        title: "Top Lasgun",
        author: "compasswithhat",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/compasswithhat/top_lasgun",
        hfyFoundationUrl: "https://hfy.foundation/series/3300",
        chapterCount: 45
    },
    {
        id: "place_holder",
        title: "Place Holder",
        author: "wastedhope17",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/wastedhope17/place_holder",
        hfyFoundationUrl: "https://hfy.foundation/series/3083",
        chapterCount: 25
    },
    {
        id: "harem_a_sexy_space_babes_story",
        title: "Harem: A Sexy Space Babes Story",
        author: "v1k1ng1990",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/v1k1ng1990/harem",
        hfyFoundationUrl: "https://hfy.foundation/series/2645",
        chapterCount: 9
    },
    {
        id: "sons_of_thunder",
        title: "Sons of Thunder",
        author: "captainlinux",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/captainlinux/sons_of_thunder",
        hfyFoundationUrl: "https://hfy.foundation/series/2827",
        chapterCount: 6
    },
    {
        id: "sex_ed",
        title: "Sex Ed",
        author: "sturdy_frikkin_table",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/sturdy_frikkin_table/sex_ed",
        hfyFoundationUrl: "https://hfy.foundation/series/3021",
        chapterCount: 7
    },
    {
        id: "12_festive_cathurals",
        title: "12 Festive Cathurals",
        author: "ImaginationGamer24",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/12_festive_cathurals",
        chapterCount: 13
    },
    {
        id: "the_4th_horseman",
        title: "The 4th Horseman",
        author: "ParisienneWalkways",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_4th_horseman",
        chapterCount: 9
    },
    {
        id: "7",
        title: "7",
        author: "Zephylandantus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/7",
        chapterCount: 1
    },
    {
        id: "99_9_of_the_universe",
        title: "99.9% Of The Universe",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/999_of_the_universe",
        chapterCount: 190
    },
    {
        id: "a_r_c_h_the_resonance",
        title: "A.R.C.H.: The Resonance",
        author: "Diver_Ill",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/arch_the_resonance",
        chapterCount: 14
    },
    {
        id: "abduction_2",
        title: "Abduction",
        author: "Monty_The_Snek",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/abduction_monty_the_snek",
        chapterCount: 5
    },
    {
        id: "above_eden",
        title: "Above Eden",
        author: "okmangeez",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/above_eden",
        chapterCount: 16
    },
    {
        id: "accidental_adventures",
        title: "Accidental Adventures",
        author: "Egrediorta",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/accidental_adventures",
        chapterCount: 4
    },
    {
        id: "accidental_displacement",
        title: "Accidental Displacement",
        author: "Toxinsliver",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/accidental_displacement",
        chapterCount: 12
    },
    {
        id: "accidental_gods",
        title: "Accidental Gods",
        author: "Void\\_Vagabond",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/accidental_gods",
        chapterCount: 9
    },
    {
        id: "accommodation_guidelines",
        title: "Accommodation Guidelines",
        author: "Thomas_Dimensor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/accommodation_guidelines",
        chapterCount: 1
    },
    {
        id: "the_ace_of_hayzeon",
        title: "The Ace Of Hayzeon",
        author: "Internal-Ad6147",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_ace_of_hayzeon",
        chapterCount: 49
    },
    {
        id: "ad_astra_per_aspera_et_ultra_ad_logos",
        title: "Ad Astra Per Aspera Et Ultra Ad Logos",
        author: "FeeAdventurous9416",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ad_astra_per_aspera_et_ultra_ad_logos",
        chapterCount: 12
    },
    {
        id: "address_of_the_grand_conclave",
        title: "Address Of The Grand Conclave",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/address_of_the_grand_conclave",
        chapterCount: 3
    },
    {
        id: "adrenaline_is_a_hell_of_a_drug",
        title: "Adrenaline Is A Hell Of A Drug",
        author: "Unique_Relief_5601",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adrenaline_is_a_hell_of_a_drug",
        chapterCount: 18
    },
    {
        id: "adrift_a_long_way_from_home",
        title: "Adrift A Long Way From Home",
        author: "WhatDidJohnDo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adrift_a_long_way_from_home",
        chapterCount: 14
    },
    {
        id: "adrift_encounter",
        title: "Adrift Encounter",
        author: "K4Hamguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adrift_encounter",
        chapterCount: 11
    },
    {
        id: "advent_of_eternity",
        title: "Advent Of Eternity",
        author: "AJNadir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/advent_of_eternity",
        chapterCount: 6
    },
    {
        id: "advent_of_the_divine",
        title: "Advent Of The Divine",
        author: "Safe\\_Committee9381",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/advent_of_the_divine",
        chapterCount: 7
    },
    {
        id: "adventures_of_a_teenage_superhero",
        title: "Adventures Of A Teenage Superhero",
        author: "Ruggi_2001",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/adventures_of_a_teenage_superhero",
        chapterCount: 9
    },
    {
        id: "the_adventures_of_stan_the_bounty_hunter",
        title: "The Adventures Of Stan The Bounty Hunter",
        author: "Shadycrazyman",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_adventures_of_stan_the_bounty_hunter",
        chapterCount: 49
    },
    {
        id: "aegis",
        title: "Aegis",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aegis",
        chapterCount: 0
    },
    {
        id: "after_a_god",
        title: "After A God",
        author: "floofusest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/after_a_god",
        chapterCount: 7
    },
    {
        id: "aggro",
        title: "Aggro",
        author: "Maloryauthor",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/aggro",
        chapterCount: 21
    },
    {
        id: "ain_t_a_hero",
        title: "Ain't A Hero",
        author: "Lakstoties",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aint_a_hero",
        chapterCount: 0
    },
    {
        id: "airborne",
        title: "Airborne",
        author: "MyNameIsRags",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/airborne",
        chapterCount: 0
    },
    {
        id: "alex_the_demon_hunter",
        title: "Alex The Demon Hunter",
        author: "ImmortalPartheon",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/alex_the_demon_hunter",
        chapterCount: 15
    },
    {
        id: "these_aliens_are_interesting",
        title: "These Aliens Are... Interesting",
        author: "ImaginationGamer24",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/these_aliens_are_interesting",
        chapterCount: 11
    },
    {
        id: "all_about_limniads",
        title: "All About Limniads",
        author: "All Fubsyverse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_about_limniads",
        chapterCount: 22
    },
    {
        id: "all_about_the_credits",
        title: "All About The Credits",
        author: "Fornicious_Fogbottom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_about_the_credits",
        chapterCount: 3
    },
    {
        id: "all_gods_must_die",
        title: "All Gods Must Die",
        author: "Gwunders",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_gods_must_die",
        chapterCount: 3
    },
    {
        id: "all_roads_lead_to_dirt",
        title: "All Roads Lead to Dirt",
        author: "timeless1991",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_roads_lead_to_dirt",
        chapterCount: 2
    },
    {
        id: "it_all_started_with_magnets",
        title: "It All Started With Magnets",
        author: "Cultural_Candidate48",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/it_all_started_with_magnets",
        chapterCount: 20
    },
    {
        id: "all_systems_science_university",
        title: "All Systems Science University",
        author: "apophis-pegasus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/all_systems_science_university",
        chapterCount: 4
    },
    {
        id: "along_for_the_ride",
        title: "Along For The Ride",
        author: "sgtjoy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/along_for_the_ride",
        chapterCount: 8
    },
    {
        id: "alpha_ai",
        title: "Alpha Ai",
        author: "No-Net5827",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/alpha_ai",
        chapterCount: 39
    },
    {
        id: "the_ambassador_2",
        title: "The Ambassador",
        author: "root-node",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ambassador_root-node",
        chapterCount: 9
    },
    {
        id: "amongst_the_bones_of_heroes",
        title: "Amongst The Bones Of Heroes",
        author: "GirogiArts",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/amongst_the_bones_of_heroes",
        chapterCount: 10
    },
    {
        id: "anchor_points_age_of_heroes",
        title: "Anchor Points: Age Of Heroes",
        author: "AnchorPointsOfficial",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/anchor_points_age_of_heroes",
        chapterCount: 30
    },
    {
        id: "the_ancient_awakes",
        title: "The Ancient Awakes",
        author: "KingHenrytheI",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ancient_awakes",
        chapterCount: 14
    },
    {
        id: "and_even_the_stars_felt_fear",
        title: "And Even The Stars Felt Fear",
        author: "In\\_Yellow\\_Clad",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/and_even_the_stars_felt_fear",
        chapterCount: 35
    },
    {
        id: "the_android",
        title: "The Android",
        author: "British_Tea_Company",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_android",
        chapterCount: 0
    },
    {
        id: "andromeda_encounter",
        title: "Andromeda Encounter",
        author: "kinexxona06",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/andromeda_encounter",
        chapterCount: 4
    },
    {
        id: "angel_of_the_red_sun",
        title: "Angel Of The Red Sun",
        author: "ReadsLikeBadFiction",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/angel_of_the_red_sun",
        chapterCount: 20
    },
    {
        id: "the_angels_cometh",
        title: "The Angels cometh",
        author: "DeityGamesJesus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_angels_cometh",
        chapterCount: 9
    },
    {
        id: "anger_management",
        title: "Anger Management",
        author: "Hambone3110",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/anger_management",
        chapterCount: 3
    },
    {
        id: "antithesis",
        title: "Antithesis",
        author: "vladimirivan67",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/antithesis",
        chapterCount: 17
    },
    {
        id: "anywhere_but_here",
        title: "Anywhere But Here",
        author: "Peregrinans98",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/anywhere_but_here",
        chapterCount: 6
    },
    {
        id: "apex_of_creation",
        title: "Apex of Creation",
        author: "captainmeta4",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/apex_of_creation",
        chapterCount: 0
    },
    {
        id: "apex",
        title: "Apex",
        author: "Glacialfury",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/apex",
        chapterCount: 12
    },
    {
        id: "aphotic",
        title: "Aphotic",
        author: "Xzenergy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aphotic",
        chapterCount: 7
    },
    {
        id: "the_apocalypse_grinder",
        title: "The Apocalypse Grinder",
        author: "AdventuresseNovels",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_apocalypse_grinder",
        chapterCount: 28
    },
    {
        id: "aquatic_galaxy",
        title: "Aquatic Galaxy",
        author: "Omen224",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aquatic_galaxy",
        chapterCount: 9
    },
    {
        id: "the_archive_logs",
        title: "The Archive Logs",
        author: "Return to my main wiki page",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_archive_logs",
        chapterCount: 15
    },
    {
        id: "aris_cretu",
        title: "Aris Cretu",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/aris_cretu",
        chapterCount: 0
    },
    {
        id: "armless",
        title: "Armless",
        author: "Guncaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/armless",
        chapterCount: 5
    },
    {
        id: "articles_of_galactic_union_acceptance",
        title: "Articles Of Galactic Union Acceptance",
        author: "Socially8roken",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/articles_of_galactic_union_acceptance",
        chapterCount: 5
    },
    {
        id: "artificial_dumbness",
        title: "Artificial Dumbness",
        author: "Dapper_Bug_9473",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/artificial_dumbness",
        chapterCount: 8
    },
    {
        id: "as_astra",
        title: "As Astra",
        author: "PWOFalcon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/as_astra",
        chapterCount: 13
    },
    {
        id: "ascension_of_the_primalist",
        title: "Ascension Of The Primalist",
        author: "NB\\_Dravenlord",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/ascension_of_the_primalist",
        chapterCount: 82
    },
    {
        id: "ascended",
        title: "Ascended",
        author: "NarodnayaToast",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ascended",
        chapterCount: 30
    },
    {
        id: "the_asgar_chronicle",
        title: "The Asgar Chronicle",
        author: "Milc-Scribbler",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_asgar_chronicle",
        chapterCount: 11
    },
    {
        id: "ashes_of_the_earth",
        title: "Ashes Of The Earth",
        author: "Xeno-Hollow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ashes_of_the_earth",
        chapterCount: 6
    },
    {
        id: "ass_drivers",
        title: "Ass Drivers",
        author: "webkilla",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ass_drivers",
        chapterCount: 9
    },
    {
        id: "at_the_choice_of_a_trigger",
        title: "At The Choice Of A Trigger",
        author: "Cola\\_Dad",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/at_the_choice_of_a_trigger",
        chapterCount: 10
    },
    {
        id: "averix_call_of_the_everloft",
        title: "Averix: Call Of The Everloft",
        author: "TraversingtheDark",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/averix_call_of_the_everloft",
        chapterCount: 8
    },
    {
        id: "the_awakened_giant",
        title: "The Awakened Giant",
        author: "Huge-Animal-8818",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_awakened_giant",
        chapterCount: 4
    },
    {
        id: "awakening",
        title: "Awakening",
        author: "jpitha",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/awakening",
        chapterCount: 17
    },
    {
        id: "back_to_human",
        title: "Back to Human",
        author: "TaoWolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/back_to_human",
        chapterCount: 40
    },
    {
        id: "bahal_genocide",
        title: "Bahal Genocide",
        author: "vannedthrowaway",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bahal_genocide",
        chapterCount: 2
    },
    {
        id: "baldr_s_branch",
        title: "Baldr's Branch",
        author: "StoryTaleBooks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/baldrs_branch",
        chapterCount: 9
    },
    {
        id: "the_ballad_of_orange_tobby",
        title: "The Ballad Of Orange Tobby",
        author: "Lakeel100",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_ballad_of_orange_tobby",
        chapterCount: 23
    },
    {
        id: "ballistic_coefficient",
        title: "Ballistic Coefficient",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ballistic_coefficient",
        chapterCount: 0
    },
    {
        id: "balls_deep_in_ally_territory",
        title: "Balls Deep In Ally Territory",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/balls_deep_in_ally_territory",
        chapterCount: 0
    },
    {
        id: "bargaining",
        title: "Bargaining",
        author: "frostadept",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bargaining",
        chapterCount: 19
    },
    {
        id: "barran_kal_morga_the_human",
        title: "Barran Kal-morga, The Human",
        author: "tylertoon2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/barran_kal-morga_the_human",
        chapterCount: 6
    },
    {
        id: "be_careful_what_you_wish_for",
        title: "Be Careful What You Wish For",
        author: "FM_Jellico",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/be_careful_what_you_wish_for_fm_jellico",
        chapterCount: 14
    },
    {
        id: "be_careful_what_you_wish_for_2",
        title: "Be Careful What You Wish For",
        author: "Infernalism",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/be_careful_what_you_wish_for",
        chapterCount: 4
    },
    {
        id: "beat_the_odds",
        title: "Beat The Odds",
        author: "unholypepperoni",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beat_the_odds",
        chapterCount: 8
    },
    {
        id: "because_they_are_human",
        title: "Because, They Are Human",
        author: "Syegone",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/because_they_are_human",
        chapterCount: 3
    },
    {
        id: "beelzebub",
        title: "Beelzebub",
        author: "StrageDragonShadow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beelzebub",
        chapterCount: 2
    },
    {
        id: "beneath_an_eagles_banner",
        title: "Beneath An Eagles Banner",
        author: "DuckBurgger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beneath_an_eagles_banner",
        chapterCount: 11
    },
    {
        id: "between_seconds",
        title: "Between Seconds",
        author: "WartomeWrites",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/between_seconds",
        chapterCount: 12
    },
    {
        id: "beyond",
        title: "Beyond",
        author: "Xavius\\_Night",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/beyond",
        chapterCount: 7
    },
    {
        id: "beyond_midgard",
        title: "Beyond Midgard",
        author: "TheGruamach",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/beyond_midgard",
        chapterCount: 11
    },
    {
        id: "beyond_the_void_2",
        title: "Beyond the Void",
        author: "AhrKyv",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/beyond_the_void_ahrkyv",
        chapterCount: 13
    },
    {
        id: "big_bad_wolf",
        title: "Big Bad Wolf",
        author: "pinsndneedles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/big_bad_wolf",
        chapterCount: 2
    },
    {
        id: "big_iron",
        title: "Big Iron",
        author: "someguynamedted",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/big_iron",
        chapterCount: 0
    },
    {
        id: "big_iron_diplomacy",
        title: "Big Iron Diplomacy",
        author: "Anarcho-Gelatin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/big_iron_diplomacy",
        chapterCount: 5
    },
    {
        id: "billy_bob_space_trucker",
        title: "Billy-Bob Space Trucker",
        author: "RegalLegalEagle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/billybob_space_trucker",
        chapterCount: 18
    },
    {
        id: "binary_heart",
        title: "Binary Heart",
        author: "lainmelle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/binary_heart",
        chapterCount: 2
    },
    {
        id: "bioships",
        title: "Bioships",
        author: "Ok-Dig-2932",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bioships",
        chapterCount: 7
    },
    {
        id: "birds_of_prey",
        title: "Birds Of Prey",
        author: "Snekguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/birds_of_prey",
        chapterCount: 10
    },
    {
        id: "the_black_fleet",
        title: "The Black Fleet",
        author: "Emperor\\_Huey\\_Long",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_black_fleet",
        chapterCount: 3
    },
    {
        id: "the_black_pearl_year_zero",
        title: "The Black Pearl: Year Zero",
        author: "\\_Melodos\\_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_black_pearl_year_zero",
        chapterCount: 14
    },
    {
        id: "the_black_ship",
        title: "The Black Ship",
        author: "awsomesawsome",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_black_ship",
        chapterCount: 3
    },
    {
        id: "black_white_and_red",
        title: "Black, White and Red",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/black_white_and_red",
        chapterCount: 0
    },
    {
        id: "blackbeard",
        title: "Blackbeard",
        author: "Sanctusmorti",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/blackbeard",
        chapterCount: 2
    },
    {
        id: "the_blank",
        title: "The Blank",
        author: "Ceramic\\_Boi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_blank",
        chapterCount: 17
    },
    {
        id: "the_blood_runs_hot",
        title: "The Blood Runs Hot",
        author: "EoArmillo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_blood_runs_hot",
        chapterCount: 2
    },
    {
        id: "bloodlines",
        title: "Bloodlines",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bloodlines",
        chapterCount: 0
    },
    {
        id: "bloodred_stars",
        title: "Bloodred Stars",
        author: "scribble_sun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bloodred_stars",
        chapterCount: 2
    },
    {
        id: "the_blue_blood",
        title: "The Blue Blood",
        author: "Slime\\_Special\\_681",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_blue_blood",
        chapterCount: 19
    },
    {
        id: "the_bone_of_the_beast",
        title: "The Bone Of The Beast",
        author: "Easy\\_Anxiety\\_4062",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bone_of_the_beast",
        chapterCount: 10
    },
    {
        id: "boon_bounty_bad_decisions",
        title: "Boon, Bounty, & Bad Decisions",
        author: "danny69production",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/boon_bounty__bad_decisions",
        chapterCount: 17
    },
    {
        id: "born_to_fly",
        title: "Born To Fly",
        author: "keblastkavich",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/born_to_fly",
        chapterCount: 6
    },
    {
        id: "the_boy_and_the_imaginary_armor",
        title: "The Boy And The Imaginary Armor",
        author: "Crafty-Ad-3993",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_boy_and_the_imaginary_armor",
        chapterCount: 5
    },
    {
        id: "the_boy_who_stole_a_world",
        title: "The Boy Who Stole A World",
        author: "Keastreth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_boy_who_stole_a_world",
        chapterCount: 6
    },
    {
        id: "the_breaking",
        title: "The Breaking",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_breaking",
        chapterCount: 0
    },
    {
        id: "breaking_the_cage",
        title: "Breaking The Cage",
        author: "Due\\_Bodybuilder\\_1621",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/breaking_the_cage",
        chapterCount: 9
    },
    {
        id: "brian_the_isekai",
        title: "Brian The Isekai",
        author: "Heavy\\_Lead\\_2798",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/brian_the_isekai",
        chapterCount: 10
    },
    {
        id: "the_bridge",
        title: "The Bridge",
        author: "LeoDuhVinci",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_bridge",
        chapterCount: 0
    },
    {
        id: "a_brief_history_of_teleportation",
        title: "A Brief History Of Teleportation",
        author: "CurvatureTensor",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/a_brief_history_of_teleportation",
        chapterCount: 38
    },
    {
        id: "brothers_in_arms_2",
        title: "Brothers In Arms",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/brothers_in_arms",
        chapterCount: 0
    },
    {
        id: "the_bright_eyes_revolution",
        title: "The \"Bright-eyes\" Revolution",
        author: "FreshAmphibian6247",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_brighteyes_revolution",
        chapterCount: 13
    },
    {
        id: "bringing_a_new_age",
        title: "Bringing A New Age",
        author: "WhiteSagettarius",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/bringing_a_new_age",
        chapterCount: 18
    },
    {
        id: "british_blood_and_irish_whisky",
        title: "British Blood and Irish Whisky",
        author: "Arecam",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/british_blood_and_irish_whisky",
        chapterCount: 2
    },
    {
        id: "bubba_yaga",
        title: "Bubba Yaga",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bubba_yaga",
        chapterCount: 27
    },
    {
        id: "bug_infestation",
        title: "Bug Infestation",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bug_infestation",
        chapterCount: 10
    },
    {
        id: "to_build_a_starship",
        title: "To Build A Starship",
        author: "gloomy__pangolin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_build_a_starship",
        chapterCount: 12
    },
    {
        id: "the_burden_of_rebirth",
        title: "The Burden Of Rebirth",
        author: "ShyPaladin187",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_burden_of_rebirth",
        chapterCount: 7
    },
    {
        id: "burning",
        title: "Burning",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/burning",
        chapterCount: 12
    },
    {
        id: "bush_wookies",
        title: "Bush Wookies",
        author: "Recon1342",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/bush_wookies",
        chapterCount: 12
    },
    {
        id: "c1764",
        title: "C1764",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/c1764",
        chapterCount: 12
    },
    {
        id: "calico_squad",
        title: "Calico Squad",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/calico_squad",
        chapterCount: 7
    },
    {
        id: "the_calling",
        title: "The Calling",
        author: "Tusselpunk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_calling",
        chapterCount: 21
    },
    {
        id: "captain_john",
        title: "Captain John",
        author: "IHaveABetWithMyBro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/captain_john",
        chapterCount: 2
    },
    {
        id: "captain_simmons",
        title: "Captain Simmons",
        author: "KamikazeErection",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/captain_simmons",
        chapterCount: 3
    },
    {
        id: "cara_s_new_home",
        title: "Cara's New Home",
        author: "Melvinator25",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/caras_new_home",
        chapterCount: 2
    },
    {
        id: "carcinizate",
        title: "Carcinizate",
        author: "Helgeland",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/carcinizate",
        chapterCount: 12
    },
    {
        id: "case_study_on_human_behavioral_aberrations",
        title: "Case Study On Human Behavioral Aberrations",
        author: "AlgravesBurning",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/case_study_on_human_behavioral_aberrations",
        chapterCount: 5
    },
    {
        id: "a_cat_that_really_was_gone",
        title: "A Cat That Really Was Gone",
        author: "Big\\_Grug",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_cat_that_really_was_gone",
        chapterCount: 9
    },
    {
        id: "cat_s_at_the_cradle",
        title: "Cat's At The Cradle",
        author: "BAIN_420",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cats_at_the_cradle",
        chapterCount: 14
    },
    {
        id: "category_5",
        title: "Category 5",
        author: "InnovAsians",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/category_5",
        chapterCount: 4
    },
    {
        id: "causal_results",
        title: "Causal Results",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/causal_results",
        chapterCount: 9
    },
    {
        id: "cease_and_desist",
        title: "Cease And Desist",
        author: "yejustanotheraccount",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cease_and_desist",
        chapterCount: 4
    },
    {
        id: "celestial_ladder",
        title: "Celestial Ladder",
        author: "adoom1e2000",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/celestial_ladder",
        chapterCount: 12
    },
    {
        id: "a_certain_scientist_in_another_world",
        title: "A Certain Scientist In Another World",
        author: "crackdark15",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_certain_scientist_in_another_world",
        chapterCount: 9
    },
    {
        id: "chainbreakers",
        title: "Chainbreakers",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chainbreakers",
        chapterCount: 0
    },
    {
        id: "champion_is_playing",
        title: "Champion Is Playing",
        author: "DanyaWlasko",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/champion_is_playing",
        chapterCount: 19
    },
    {
        id: "changing_faces",
        title: "Changing Faces",
        author: "aiwhisper",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/changing_faces",
        chapterCount: 13
    },
    {
        id: "charlie_macnamara_space_pirate",
        title: "Charlie MacNamara, Space Pirate",
        author: "Derin_Edala",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/charlie_macnamara_space_pirate",
        chapterCount: 23
    },
    {
        id: "the_chef",
        title: "The Chef",
        author: "Spines",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_chef",
        chapterCount: 4
    },
    {
        id: "chhayagarh",
        title: "Chhayagarh",
        author: "BuddhaTheGreat",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/chhayagarh",
        chapterCount: 25
    },
    {
        id: "children_of_abraham",
        title: "Children Of Abraham",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/children_of_abraham",
        chapterCount: 34
    },
    {
        id: "children_of_eternity",
        title: "Children Of Eternity",
        author: "StoneTimeKeeper",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/children_of_eternity",
        chapterCount: 9
    },
    {
        id: "chimeraverse",
        title: "ChimeraVerse",
        author: "Hodhandr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chimeraverse",
        chapterCount: 3
    },
    {
        id: "the_chronicles_of_clint_stone",
        title: "The Chronicles of Clint Stone",
        author: "someguynamedted",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_chronicles_of_clint_stone",
        chapterCount: 0
    },
    {
        id: "chronicles_of_mann",
        title: "Chronicles Of Mann",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chronicles_of_mann",
        chapterCount: 0
    },
    {
        id: "chronicles_of_the_resistance",
        title: "Chronicles Of The Resistance",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chronicles_of_the_resistance",
        chapterCount: 0
    },
    {
        id: "chrysalis",
        title: "Chrysalis",
        author: "BeaverFur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/chrysalis",
        chapterCount: 16
    },
    {
        id: "city_slickers_and_hayseeds",
        title: "City Slickers And Hayseeds",
        author: "randomtinkerer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/city_slickers_and_hayseeds",
        chapterCount: 45
    },
    {
        id: "c_leena_thomas_prosthetist",
        title: "C'leena Thomas, Prosthetist",
        author: "mage\\_in\\_training",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cleena_thomas_prosthetist",
        chapterCount: 9
    },
    {
        id: "the_coalition_series",
        title: "The Coalition Series",
        author: "StaplerTwelve",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_coalition_series",
        chapterCount: 3
    },
    {
        id: "coin_s_edge_reincarnated_as_a_nobody",
        title: "Coin's Edge: Reincarnated As A Nobody",
        author: "Lopsided_Ant_4531",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/coins_edge_reincarnated_as_a_nobody",
        chapterCount: 13
    },
    {
        id: "cog_cultivator",
        title: "Cog Cultivator",
        author: "CommercialBee6585",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cog_cultivator",
        chapterCount: 7
    },
    {
        id: "cold_as_ice",
        title: "Cold As Ice",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cold_as_ice",
        chapterCount: 13
    },
    {
        id: "the_cold_fates",
        title: "The Cold Fates",
        author: "KieveKRS",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cold_fates",
        chapterCount: 24
    },
    {
        id: "cold_souls",
        title: "Cold Souls",
        author: "Brownoniongravy1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cold_souls",
        chapterCount: 2
    },
    {
        id: "colony_dirt",
        title: "Colony Dirt",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/colony_dirt",
        chapterCount: 40
    },
    {
        id: "a_color_of_misunderstandings",
        title: "A Color Of Misunderstandings",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_color_of_misunderstandings",
        chapterCount: 0
    },
    {
        id: "combat_oracle",
        title: "Combat Oracle",
        author: "DreadDreck",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/combat_oracle",
        chapterCount: 20
    },
    {
        id: "commander_s_log",
        title: "Commander's Log",
        author: "DragonStryk72",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/commanders_log",
        chapterCount: 8
    },
    {
        id: "on_the_concept_of_demons",
        title: "On The Concept Of Demons",
        author: "redditaggie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/on_the_concept_of_demons",
        chapterCount: 7
    },
    {
        id: "the_condescension_of_the_elves",
        title: "The Condescension Of The Elves",
        author: "0-M-I",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_condescension_of_the_elves",
        chapterCount: 2
    },
    {
        id: "the_consultant",
        title: "The Consultant",
        author: "Ma7ich",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_consultant",
        chapterCount: 2
    },
    {
        id: "conscripted_crafter",
        title: "Conscripted Crafter",
        author: "AlexandersenTheGreat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/conscripted_crafter",
        chapterCount: 32
    },
    {
        id: "consummate_matte_black_prologue",
        title: "Consummate (Matte Black Prologue)",
        author: "abloobudoo009",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/consummate_matte_black_prologue",
        chapterCount: 1
    },
    {
        id: "contact_protocol",
        title: "Contact Protocol",
        author: "DisapointedVoid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/contact_protocol",
        chapterCount: 22
    },
    {
        id: "contact_with_the_empire",
        title: "Contact With The Empire",
        author: "Alixastyr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/contact_with_the_empire",
        chapterCount: 29
    },
    {
        id: "continuation",
        title: "Continuation",
        author: "Conofrac",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/continuation",
        chapterCount: 6
    },
    {
        id: "the_continued_adventures_of_jimothy",
        title: "The Continued Adventures of Jimothy",
        author: "whodidyouthink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_continued_adventures_of_jimothy",
        chapterCount: 0
    },
    {
        id: "contractors",
        title: "Contractors",
        author: "Alpha-Sierra-Charlie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/contractors",
        chapterCount: 8
    },
    {
        id: "cookieverse",
        title: "Cookieverse",
        author: "EqualWrite",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cookieverse",
        chapterCount: 9
    },
    {
        id: "coping_with_a_new_reality",
        title: "Coping With A New Reality",
        author: "streakinghellfire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/coping_with_a_new_reality",
        chapterCount: 2
    },
    {
        id: "corazon",
        title: "Corazon",
        author: "anzhalyumitethe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/corazon",
        chapterCount: 5
    },
    {
        id: "corridors",
        title: "Corridors",
        author: "Nanoprober",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/corridors",
        chapterCount: 40
    },
    {
        id: "council_of_worlds",
        title: "Council of Worlds",
        author: "Catullus74",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/council_of_worlds",
        chapterCount: 5
    },
    {
        id: "counting_the_days_lost_among_the_stars",
        title: "Counting The Days Lost Among The Stars",
        author: "Sleeping_Humanity",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/counting_the_days_lost_among_the_stars",
        chapterCount: 21
    },
    {
        id: "the_courting_of_life_and_death",
        title: "The Courting Of Life And Death",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_courting_of_life_and_death",
        chapterCount: 0
    },
    {
        id: "crab_world",
        title: "Crab World",
        author: "ack1308",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/crab_world",
        chapterCount: 4
    },
    {
        id: "crashlanding",
        title: "Crashlanding",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/crashlanding",
        chapterCount: 29
    },
    {
        id: "crimewave",
        title: "Crimewave",
        author: "SCPunited",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/crimewave",
        chapterCount: 19
    },
    {
        id: "the_crossroads_hotel",
        title: "The Crossroads Hotel",
        author: "karenvideoeditor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_crossroads_hotel",
        chapterCount: 17
    },
    {
        id: "crossroads_of_time",
        title: "Crossroads Of Time",
        author: "DeepMacaron1446",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/crossroads_of_time",
        chapterCount: 17
    },
    {
        id: "the_crown_colony",
        title: "The Crown Colony",
        author: "Zarkovik",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_crown_colony",
        chapterCount: 3
    },
    {
        id: "crusoe",
        title: "Crusoe",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/crusoe",
        chapterCount: 0
    },
    {
        id: "the_cudgel",
        title: "The Cudgel",
        author: "British_Tea_Company",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cudgel",
        chapterCount: 0
    },
    {
        id: "cultivation_is_a_game",
        title: "Cultivation Is A Game",
        author: "Kalzara",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cultivation_is_a_game",
        chapterCount: 16
    },
    {
        id: "cultivation_is_creation",
        title: "Cultivation Is Creation",
        author: "RecentFeature1646",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/cultivation_is_creation",
        chapterCount: 19
    },
    {
        id: "a_curious_discovery",
        title: "A Curious Discovery",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_curious_discovery",
        chapterCount: 0
    },
    {
        id: "curious_event",
        title: "Curious Event",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/curious_event",
        chapterCount: 8
    },
    {
        id: "the_curiosity_of_humanity",
        title: "The Curiosity of Humanity",
        author: "swiftsIayer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_curiosity_of_humanity",
        chapterCount: 2
    },
    {
        id: "cybernetic_alchemist",
        title: "Cybernetic Alchemist",
        author: "PhoenixSpace",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/cybernetic_alchemist",
        chapterCount: 5
    },
    {
        id: "the_cycle",
        title: "The Cycle",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_cycle",
        chapterCount: 0
    },
    {
        id: "da_of_urn",
        title: "Da of Urn",
        author: "MrStargazer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/da_of_urn",
        chapterCount: 2
    },
    {
        id: "dancing_with_death",
        title: "Dancing With Death",
        author: "RetroInferno",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dancing_with_death",
        chapterCount: 10
    },
    {
        id: "danger_close",
        title: "Danger Close",
        author: "nkonrad",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/danger_close",
        chapterCount: 2
    },
    {
        id: "dangerous_competitors_from_hell",
        title: "Dangerous Competitors From Hell",
        author: "kinexxona06",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dangerous_competitors_from_hell",
        chapterCount: 5
    },
    {
        id: "dangerverse",
        title: "Dangerverse",
        author: "WarAdmiral2420",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dangerverse",
        chapterCount: 14
    },
    {
        id: "damara_the_valiant",
        title: "Damara The Valiant",
        author: "Beginning_Debt9670",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/damara_the_valiant",
        chapterCount: 17
    },
    {
        id: "damnation_s_trail",
        title: "Damnation's Trail",
        author: "Unhappy_Spare_6563",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/damnations_trail",
        chapterCount: 11
    },
    {
        id: "dao_of_cooking",
        title: "Dao Of Cooking",
        author: "New_Delivery6734",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dao_of_cooking",
        chapterCount: 12
    },
    {
        id: "dark",
        title: "Dark",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dark",
        chapterCount: 11
    },
    {
        id: "dark_days",
        title: "Dark Days",
        author: "fuerfrost",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dark_days",
        chapterCount: 16
    },
    {
        id: "the_dark_ones",
        title: "The Dark Ones",
        author: "Nymphrena",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dark_ones",
        chapterCount: 1
    },
    {
        id: "darkest_void",
        title: "Darkest Void",
        author: "Top\\_Hat\\_surgeon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/darkest_void",
        chapterCount: 24
    },
    {
        id: "darkness_3",
        title: "Darkness",
        author: "Arceroth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/darkness",
        chapterCount: 4
    },
    {
        id: "the_darkness",
        title: "The Darkness",
        author: "looktosee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_darkness",
        chapterCount: 2
    },
    {
        id: "dawn_approaching",
        title: "Dawn Approaching",
        author: "Paladin_of_Drangleic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dawn_approaching",
        chapterCount: 7
    },
    {
        id: "dawnrise",
        title: "Dawnrise",
        author: "roninjedi78",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dawnrise",
        chapterCount: 13
    },
    {
        id: "dead_star_dockyards",
        title: "Dead Star Dockyards",
        author: "cakeonfrosting",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dead_star_dockyards",
        chapterCount: 20
    },
    {
        id: "a_dead_world_living",
        title: "A Dead World Living",
        author: "goodnames679",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_dead_world_living",
        chapterCount: 0
    },
    {
        id: "the_deadlands",
        title: "The Deadlands",
        author: "Harfus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_deadlands",
        chapterCount: 3
    },
    {
        id: "deadlier_of_the_species",
        title: "Deadlier Of The Species",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deadlier_of_the_species",
        chapterCount: 0
    },
    {
        id: "deathworld_origins",
        title: "Deathworld Origins",
        author: "captainmeta4",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deathworld_origins",
        chapterCount: 0
    },
    {
        id: "a_deathworlders_ambition",
        title: "A Deathworlders Ambition",
        author: "Sporadic_passions",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_deathworlders_ambition",
        chapterCount: 13
    },
    {
        id: "debris",
        title: "Debris",
        author: "TheAusNerd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/debris",
        chapterCount: 96
    },
    {
        id: "dedicated_minuteman",
        title: "Dedicated Minuteman",
        author: "deathB4dessert",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dedicated_minuteman",
        chapterCount: 17
    },
    {
        id: "defence_of_sentience",
        title: "Defence Of Sentience",
        author: "Salmonbattle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/defence_of_sentience",
        chapterCount: 2
    },
    {
        id: "defiance",
        title: "Defiance",
        author: "Boss_Dude",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/defiance",
        chapterCount: 0
    },
    {
        id: "defiance_of_extinction",
        title: "Defiance Of Extinction",
        author: "DefianceIsEverything",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/defiance_of_extinction",
        chapterCount: 20
    },
    {
        id: "designation_terran",
        title: "Designation: Terran!",
        author: "elevendog",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/designation_terran",
        chapterCount: 0
    },
    {
        id: "desolation_among_the_stars",
        title: "Desolation Among The Stars",
        author: "Christie_Wright",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/desolation_among_the_stars",
        chapterCount: 14
    },
    {
        id: "deus_ex_nihilo",
        title: "Deus Ex Nihilo",
        author: "deus_x_machin4",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/deus_ex_nihilo",
        chapterCount: 4
    },
    {
        id: "devilish_delights",
        title: "Devilish Delights",
        author: "NSFWJack21",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/devilish_delights",
        chapterCount: 12
    },
    {
        id: "devils",
        title: "Devils",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/devils",
        chapterCount: 0
    },
    {
        id: "the_devine_demon",
        title: "The Devine Demon",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_devine_demon",
        chapterCount: 0
    },
    {
        id: "devourers",
        title: "Devourers",
        author: "toclacl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/devourers",
        chapterCount: 4
    },
    {
        id: "diadem",
        title: "Diadem",
        author: "whodidyouthink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/diadem",
        chapterCount: 2
    },
    {
        id: "diary_of_a_deathworlder",
        title: "Diary Of A Deathworlder",
        author: "BntyHntrMstr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/diary_of_a_deathworlder",
        chapterCount: 4
    },
    {
        id: "die_respawn_repeat",
        title: "Die. Respawn. Repeat.",
        author: "Quetzhal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/die_respawn_repeat",
        chapterCount: 83
    },
    {
        id: "dimming_stars",
        title: "Dimming Stars",
        author: "harrythebait",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/dimming_stars",
        chapterCount: 11
    },
    {
        id: "discovery",
        title: "Discovery",
        author: "liberalpyromania",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/discovery",
        chapterCount: 2
    },
    {
        id: "dissonant_thought",
        title: "Dissonant Thought",
        author: "Knaevry",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dissonant_thought",
        chapterCount: 5
    },
    {
        id: "distant_thunder_2",
        title: "Distant Thunder",
        author: "Muzolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/distant_thunder_muzolf",
        chapterCount: 9
    },
    {
        id: "the_distinguished_mr_rose",
        title: "The Distinguished Mr. Rose",
        author: "QuiteTheSlacker1",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_distinguished_mr_rose",
        chapterCount: 22
    },
    {
        id: "do_not_touch",
        title: "Do Not Touch",
        author: "TinyBard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/do_not_touch",
        chapterCount: 16
    },
    {
        id: "dog_or_not",
        title: "Dog...? Or Not!",
        author: "horizonsong",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dog_or_not",
        chapterCount: 5
    },
    {
        id: "dogs_of_war",
        title: "Dogs of War",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dogs_of_war",
        chapterCount: 0
    },
    {
        id: "don_t_step_on_snek",
        title: "Don't Step On Snek",
        author: "EngieNeer1968",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dont_step_on_snek",
        chapterCount: 13
    },
    {
        id: "don_t_underestimate_the_terrans",
        title: "Don't Underestimate The Terrans",
        author: "AndyCD2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dont_underestimate_the_terrans",
        chapterCount: 7
    },
    {
        id: "don_t_worry_you_re_not_human",
        title: "Don't Worry, You're Not Human",
        author: "The_Eternal_palace",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dont_worry_youre_not_human",
        chapterCount: 25
    },
    {
        id: "doros",
        title: "Doros",
        author: "Stumpy-JIm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/doros",
        chapterCount: 11
    },
    {
        id: "dovetail",
        title: "Dovetail",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dovetail",
        chapterCount: 12
    },
    {
        id: "a_draconic_rebirth",
        title: "A Draconic Rebirth",
        author: "Undercover\\_Dragon1",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/a_draconic_rebirth",
        chapterCount: 15
    },
    {
        id: "drafted",
        title: "Drafted",
        author: "KronicBoom3",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/drafted",
        chapterCount: 23
    },
    {
        id: "the_dragon_wrangler",
        title: "The Dragon Wrangler",
        author: "Wiktry",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dragon_wrangler",
        chapterCount: 16
    },
    {
        id: "draven",
        title: "Draven",
        author: "EzekielWinters",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/draven",
        chapterCount: 5
    },
    {
        id: "the_dread_knight",
        title: "The Dread Knight",
        author: "blackjackn",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_dread_knight",
        chapterCount: 11
    },
    {
        id: "dreadnought_the_immortal",
        title: "Dreadnought, The Immortal",
        author: "MrIzuarel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dreadnought_the_immortal",
        chapterCount: 16
    },
    {
        id: "dreams_of_hyacinth",
        title: "Dreams Of Hyacinth",
        author: "jpitha",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/dreams_of_hyacinth",
        chapterCount: 23
    },
    {
        id: "drift_saga",
        title: "Drift Saga",
        author: "Volkmek",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/drift_saga",
        chapterCount: 26
    },
    {
        id: "dropship",
        title: "Dropship",
        author: "SomeOtherTroper",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/dropship",
        chapterCount: 32
    },
    {
        id: "drop_pod_green",
        title: "Drop Pod Green",
        author: "Guardbro",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/drop_pod_green",
        chapterCount: 36
    },
    {
        id: "a_duke_out_of_time",
        title: "A Duke Out Of Time",
        author: "Ok\\_Cartographer\\_6111",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/a_duke_out_of_time",
        chapterCount: 12
    },
    {
        id: "dungeon_keeper",
        title: "Dungeon Keeper",
        author: "Chaperone-Tales",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/dungeon_keeper",
        chapterCount: 23
    },
    {
        id: "dungeon_of_growth",
        title: "Dungeon Of Growth",
        author: "Alaqi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dungeon_of_growth",
        chapterCount: 11
    },
    {
        id: "dungeon_tour_guide",
        title: "Dungeon Tour Guide",
        author: "Slifer274",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dungeon_tour_guide",
        chapterCount: 11
    },
    {
        id: "dungeons_deliveries",
        title: "Dungeons & Deliveries",
        author: "SagaScribe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/dungeons__deliveries",
        chapterCount: 18
    },
    {
        id: "e_a_r_t_h",
        title: "E.A.R.T.H.",
        author: "croatianspy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earth",
        chapterCount: 4
    },
    {
        id: "earth_fall",
        title: "Earth Fall",
        author: "lukeb28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earth_fall",
        chapterCount: 2
    },
    {
        id: "earth_is_a_lost_colony",
        title: "Earth Is A Lost Colony",
        author: "ApprehensiveCap6525",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earth_is_a_lost_colony",
        chapterCount: 17
    },
    {
        id: "earth_is_my_galactic_punishment",
        title: "Earth Is My Galactic Punishment",
        author: "space_farmer_luke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earth_is_my_galactic_punishment",
        chapterCount: 4
    },
    {
        id: "earth_s_long_night",
        title: "Earth's Long Night",
        author: "atalantes88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/earths_long_night",
        chapterCount: 13
    },
    {
        id: "ebonreach",
        title: "Ebonreach",
        author: "palabamyo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ebonreach",
        chapterCount: 10
    },
    {
        id: "echo_squad",
        title: "Echo Squad",
        author: "Ember072",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/echo_squad",
        chapterCount: 3
    },
    {
        id: "the_echo_of_truth",
        title: "The Echo Of Truth",
        author: "tbuljevic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_echo_of_truth",
        chapterCount: 8
    },
    {
        id: "echoes_in_the_dark",
        title: "Echoes In The Dark",
        author: "MadCowCrazy666",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/echoes_in_the_dark",
        chapterCount: 12
    },
    {
        id: "the_egixus_war",
        title: "The Egixus War",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_egixus_war",
        chapterCount: 0
    },
    {
        id: "ek_lara_goes_human",
        title: "Ek'lara Goes Human",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/eklara_goes_human",
        chapterCount: 0
    },
    {
        id: "elder_race",
        title: "Elder Race",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/elder_race",
        chapterCount: 0
    },
    {
        id: "elyndor_the_last_omnimancer",
        title: "Elyndor: The Last Omnimancer",
        author: "skypaulplays",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/elyndor_the_last_omnimancer",
        chapterCount: 62
    },
    {
        id: "the_embassy_s_crater",
        title: "The Embassy's Crater",
        author: "earl_colby_pottinger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_embassys_crater",
        chapterCount: 8
    },
    {
        id: "emergency_human",
        title: "Emergency Human",
        author: "stasersonphun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/emergency_human",
        chapterCount: 12
    },
    {
        id: "the_emperor_s_gambit",
        title: "The Emperor's Gambit",
        author: "Socially8roken",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_emperors_gambit",
        chapterCount: 6
    },
    {
        id: "empire_of_a_thousand_sermons",
        title: "Empire Of A Thousand Sermons",
        author: "SeriousAirline6204",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/empire_of_a_thousand_sermons",
        chapterCount: 16
    },
    {
        id: "enclave",
        title: "Enclave",
        author: "Rougey",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/enclave",
        chapterCount: 5
    },
    {
        id: "endless_summer",
        title: "Endless Summer",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/endless_summer",
        chapterCount: 14
    },
    {
        id: "the_enemy_of_my_enemy",
        title: "The Enemy Of My Enemy",
        author: "WenderToast",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_enemy_of_my_enemy",
        chapterCount: 7
    },
    {
        id: "engineering_magic_and_kitsune",
        title: "Engineering, Magic, And Kitsune",
        author: "SteelTrim",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/engineering_magic_and_kitsune",
        chapterCount: 10
    },
    {
        id: "engineers",
        title: "Engineers",
        author: "ComradeH_VIE",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/engineers",
        chapterCount: 3
    },
    {
        id: "engines_of_arachnea",
        title: "Engines Of Arachnea",
        author: "hoggersbridge",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/engines_of_arachnea",
        chapterCount: 38
    },
    {
        id: "enigma_humanity",
        title: "Enigma Humanity",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/enigma_humanity",
        chapterCount: 19
    },
    {
        id: "enigma_s_multiverse",
        title: "Enigma's Multiverse",
        author: "PsnNikrim",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/enigmas_multiverse",
        chapterCount: 1
    },
    {
        id: "entrepenuer",
        title: "Entrepenuer",
        author: "Boss_Dude",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/entrepreneur",
        chapterCount: 0
    },
    {
        id: "essays_on_the_sixth_galaxy",
        title: "Essays on the Sixth Galaxy",
        author: "MalaclypseTheEldar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/essays_on_the_sixth_galaxy",
        chapterCount: 8
    },
    {
        id: "eternal_blade",
        title: "Eternal Blade",
        author: "Long-Teach-9101",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/eternal_blade",
        chapterCount: 20
    },
    {
        id: "eternal_ruin",
        title: "Eternal Ruin",
        author: "Electrical-Test773",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/eternal_ruin",
        chapterCount: 14
    },
    {
        id: "even_outdated_deathworlders_are_terrifying",
        title: "Even Outdated, Deathworlders Are Terrifying",
        author: "WritingDrakon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/even_outdated_deathworlders_are_terrifying",
        chapterCount: 14
    },
    {
        id: "everflame",
        title: "Everflame",
        author: "dr4chm4",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/everflame",
        chapterCount: 9
    },
    {
        id: "every_road_leads_to_space",
        title: "Every Road Leads to Space",
        author: "Battle Sneeze",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/every_road_leads_to_space",
        chapterCount: 0
    },
    {
        id: "evocati",
        title: "Evocati",
        author: "Crocodilly_Pontifex",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/evocati",
        chapterCount: 3
    },
    {
        id: "exceptional_heroes",
        title: "Exceptional Heroes",
        author: "Gasmaskbro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exceptional_heroes",
        chapterCount: 3
    },
    {
        id: "excerpts",
        title: "Excerpts",
        author: "Guncaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/excerpts",
        chapterCount: 12
    },
    {
        id: "the_exchange_teacher",
        title: "The Exchange Teacher",
        author: "shoemilk",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_exchange_teacher",
        chapterCount: 59
    },
    {
        id: "excidium",
        title: "Excidium",
        author: "Treijim",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/excidium",
        chapterCount: 18
    },
    {
        id: "exiled",
        title: "Exiled",
        author: "Zephylandantus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exiled",
        chapterCount: 4
    },
    {
        id: "exiles",
        title: "Exiles",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exiles",
        chapterCount: 5
    },
    {
        id: "exodus",
        title: "Exodus",
        author: "Guncaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exodus",
        chapterCount: 1
    },
    {
        id: "the_expendables",
        title: "The Expendables",
        author: "lukeb28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_expendables",
        chapterCount: 2
    },
    {
        id: "experiment_space_school",
        title: "Experiment: Space School",
        author: "Valerie_Da_Silva",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/experiment_space_school",
        chapterCount: 2
    },
    {
        id: "explorer_of_edregon",
        title: "Explorer Of Edregon",
        author: "Wizardly\\_Dude",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/explorer_of_edregon",
        chapterCount: 11
    },
    {
        id: "exterminators",
        title: "Exterminators?",
        author: "HarneyDragon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/exterminators",
        chapterCount: 11
    },
    {
        id: "external_threat",
        title: "External Threat",
        author: "TheRealVerviedi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/external_threat",
        chapterCount: 25
    },
    {
        id: "f_you_i_m_an_axe",
        title: "F*** You, I'm An Axe!",
        author: "vehino",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/f_you_im_an_axe",
        chapterCount: 35
    },
    {
        id: "the_factory_must_grow",
        title: "The Factory Must Grow",
        author: "EV-187",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_factory_must_grow",
        chapterCount: 18
    },
    {
        id: "faith_in_humanity",
        title: "Faith In Humanity",
        author: "Xentaps",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/faith_in_humanity",
        chapterCount: 5
    },
    {
        id: "the_faircourt_agency",
        title: "The Faircourt Agency",
        author: "Ivan_the_Unpleasant",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_faircourt_agency",
        chapterCount: 21
    },
    {
        id: "fall_from_grace",
        title: "Fall From Grace",
        author: "Insertrandomnickname",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fall_from_grace",
        chapterCount: 4
    },
    {
        id: "the_fall_of_kreznath",
        title: "The Fall of Kreznath",
        author: "KamikazeErection",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fall_of_kreznath",
        chapterCount: 2
    },
    {
        id: "fall_of_the_k_nori_empire",
        title: "Fall of the K'nori Empire",
        author: "Drakvor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fall_of_the_knori_empire",
        chapterCount: 2
    },
    {
        id: "the_fall_of_mars",
        title: "The Fall Of Mars",
        author: "CompletelyFlammable",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fall_of_mars",
        chapterCount: 6
    },
    {
        id: "the_fallen_ones",
        title: "The Fallen Ones",
        author: "Niedski",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fallen_ones",
        chapterCount: 2
    },
    {
        id: "falling_sky",
        title: "Falling Sky",
        author: "WeirdSpecter",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/falling_sky",
        chapterCount: 10
    },
    {
        id: "far_from_home_2",
        title: "Far From Home",
        author: "Emotional_Sector_249",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/far_from_home_emotional_sector_249",
        chapterCount: 20
    },
    {
        id: "far_from_the_stars",
        title: "Far From The Stars",
        author: "JournalistBusy5684",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/far_from_the_stars",
        chapterCount: 19
    },
    {
        id: "the_farlands_campaign",
        title: "The Farlands Campaign",
        author: "pracksack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_farlands_campaign",
        chapterCount: 16
    },
    {
        id: "a_fate_among_stars",
        title: "A Fate Among Stars",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_fate_among_stars",
        chapterCount: 0
    },
    {
        id: "the_faults_of_our_forebears",
        title: "The Faults Of Our Forebears",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_faults_of_our_forebears",
        chapterCount: 0
    },
    {
        id: "fear_of_the_dark",
        title: "Fear Of The Dark",
        author: "OldManWarhammer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fear_of_the_dark",
        chapterCount: 20
    },
    {
        id: "the_featherlight_transmission",
        title: "The Featherlight Transmission",
        author: "CadaverCommander",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_featherlight_transmission",
        chapterCount: 38
    },
    {
        id: "fight_club",
        title: "Fight Club",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fight_club",
        chapterCount: 0
    },
    {
        id: "fight_night",
        title: "Fight Night",
        author: "ubermidget1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fight_night",
        chapterCount: 5
    },
    {
        id: "to_fight_the_dark",
        title: "To Fight The Dark",
        author: "poached\\_egg99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_fight_the_dark",
        chapterCount: 8
    },
    {
        id: "a_figment_of_imagination",
        title: "A Figment Of Imagination",
        author: "AI_Phoenix",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_figment_of_imagination",
        chapterCount: 15
    },
    {
        id: "final_frontier",
        title: "Final Frontier",
        author: "[Baileyjrob]",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/final_frontier",
        chapterCount: 5
    },
    {
        id: "finality",
        title: "Finality",
        author: "AdmanUK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/finality",
        chapterCount: 6
    },
    {
        id: "a_fire_against_the_void",
        title: "A Fire Against The Void",
        author: "J\\_rd\\_nRD",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_fire_against_the_void",
        chapterCount: 10
    },
    {
        id: "first_contact_last_laugh",
        title: "First Contact: Last Laugh",
        author: "Wlund",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_contact_last_laugh",
        chapterCount: 13
    },
    {
        id: "first_contact_wars",
        title: "First Contact Wars",
        author: "Arceroth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first",
        chapterCount: 4
    },
    {
        id: "first_contact_was_a_warning_we_didn_t_listen",
        title: "First Contact Was A Warning. We Didn't Listen",
        author: "DependentAlgae",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/first_contact_was_a_warning_we_didnt_listen",
        chapterCount: 7
    },
    {
        id: "first_encounters_of_the_spacey_kind",
        title: "First Encounters Of The Spacey Kind",
        author: "MadDucksofDoom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_encounters_of_the_spacey_kind",
        chapterCount: 11
    },
    {
        id: "first_impressions",
        title: "First Impressions",
        author: "eumenedies",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_impressions",
        chapterCount: 2
    },
    {
        id: "the_first_rift_war",
        title: "The First Rift War",
        author: "Xerxeskingofkings",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_first_rift_war",
        chapterCount: 9
    },
    {
        id: "first_trillion",
        title: "First Trillion",
        author: "FivePence",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_trillion",
        chapterCount: 7
    },
    {
        id: "first_war_of_the_paladins",
        title: "First War of The Paladins",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/first_war_of_the_paladins",
        chapterCount: 0
    },
    {
        id: "fixing_caves",
        title: "Fixing Caves",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fixing_caves",
        chapterCount: 21
    },
    {
        id: "flesh_fury_and_freedom",
        title: "Flesh, Fury And Freedom",
        author: "Astral\\_Mushroom\\_Team",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/flesh_fury_and_freedom",
        chapterCount: 9
    },
    {
        id: "the_flesh_is_not_weak",
        title: "The Flesh Is (Not) Weak",
        author: "RavniTrappedInANovel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_flesh_is_not_weak",
        chapterCount: 34
    },
    {
        id: "food_for_thought",
        title: "Food For Thought",
        author: "Lvl25-human-nerd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/food_for_thought",
        chapterCount: 33
    },
    {
        id: "football_vs_magic",
        title: "Football Vs Magic",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/football_vs_magic",
        chapterCount: 2
    },
    {
        id: "for_humanity",
        title: "For Humanity",
        author: "Jurodan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/for_humanity",
        chapterCount: 3
    },
    {
        id: "forced_expansion",
        title: "Forced expansion",
        author: "Avskygod0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/forced_expansion",
        chapterCount: 2
    },
    {
        id: "the_forest",
        title: "The Forest",
        author: "FormerFutureAuthor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_forest",
        chapterCount: 30
    },
    {
        id: "forgetting",
        title: "Forgetting",
        author: "poisonsparadise",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/forgetting",
        chapterCount: 6
    },
    {
        id: "the_fort",
        title: "The Fort",
        author: "nkonrad",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fort",
        chapterCount: 13
    },
    {
        id: "fossils_of_tomorrow",
        title: "Fossils Of Tomorrow",
        author: "UCCLANno1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fossils_of_tomorrow",
        chapterCount: 2
    },
    {
        id: "found",
        title: "Found",
        author: "ShadowDragon88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/found",
        chapterCount: 5
    },
    {
        id: "foundation_of_a_fallen_spirit",
        title: "Foundation Of A Fallen Spirit",
        author: "Thorous_the3rd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/foundation_of_a_fallen_spirit",
        chapterCount: 5
    },
    {
        id: "foundations_of_humanity",
        title: "Foundations Of Humanity",
        author: "cruisingNW",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/foundations_of_humanity",
        chapterCount: 46
    },
    {
        id: "the_fourth_apex",
        title: "The Fourth Apex",
        author: "eCyanic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fourth_apex",
        chapterCount: 5
    },
    {
        id: "a_free_slave",
        title: "A Free Slave",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_free_slave",
        chapterCount: 39
    },
    {
        id: "free_will",
        title: "Free Will",
        author: "nordamerican",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/free_will",
        chapterCount: 2
    },
    {
        id: "freezing_edge",
        title: "Freezing Edge",
        author: "Foxeater2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/freezing_edge",
        chapterCount: 11
    },
    {
        id: "friends_for_the_ride",
        title: "Friends for the Ride",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/friends_for_the_ride",
        chapterCount: 0
    },
    {
        id: "the_fringe",
        title: "The Fringe",
        author: "No-Occasion-2387",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_fringe",
        chapterCount: 17
    },
    {
        id: "from_the_future",
        title: "From the Future",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/from_the_future",
        chapterCount: 0
    },
    {
        id: "from_the_past",
        title: "From the Past",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/from_the_past",
        chapterCount: 0
    },
    {
        id: "frozen_in_time",
        title: "Frozen In Time",
        author: "Fragmented_Earth_277",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/frozen_in_time",
        chapterCount: 23
    },
    {
        id: "the_future_that_never_was",
        title: "The Future That Never Was",
        author: "SpacePickle_TFTNW",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_future_that_never_was",
        chapterCount: 23
    },
    {
        id: "fuzzy_s_adventures",
        title: "Fuzzy's Adventures",
        author: "Syegone",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/fuzzys_adventures",
        chapterCount: 10
    },
    {
        id: "galactic_pit",
        title: "Galactic Pit",
        author: "Sinpleton025",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galactic_pit",
        chapterCount: 7
    },
    {
        id: "galactic_police_force",
        title: "Galactic Police Force",
        author: "Isamov123",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/galactic_police_force",
        chapterCount: 1
    },
    {
        id: "the_gamble",
        title: "The Gamble",
        author: "Dry\\_Preparation9195",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gamble",
        chapterCount: 6
    },
    {
        id: "the_game_of_the_gods",
        title: "The Game Of The Gods",
        author: "Remarkable-Feed9424",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_game_of_the_gods",
        chapterCount: 18
    },
    {
        id: "the_garden_of_eden",
        title: "The Garden of Eden",
        author: "iamawritertrustme",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_garden_of_eden",
        chapterCount: 2
    },
    {
        id: "the_gate",
        title: "The Gate",
        author: "AntiMoneySquandering",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gate",
        chapterCount: 5
    },
    {
        id: "gatekeepers",
        title: "Gatekeepers",
        author: "TheStabbyBrit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gatekeepers",
        chapterCount: 5
    },
    {
        id: "gateway_dirt",
        title: "Gateway Dirt",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gateway_dirt",
        chapterCount: 55
    },
    {
        id: "the_gestalt_dossier",
        title: "The Gestalt Dossier",
        author: "TanyaSapien",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gestalt_dossier",
        chapterCount: 15
    },
    {
        id: "gg",
        title: "GG",
        author: "Hikaraka",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gg",
        chapterCount: 10
    },
    {
        id: "ghost_ship_2",
        title: "Ghost Ship",
        author: "endtostart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ghost_ship",
        chapterCount: 0
    },
    {
        id: "the_gladiator",
        title: "The Gladiator",
        author: "Desolane900",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_gladiator",
        chapterCount: 8
    },
    {
        id: "go_ask_the_demon",
        title: "Go Ask The Demon",
        author: "TheDeliciousMeats",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/go_ask_the_demon",
        chapterCount: 4
    },
    {
        id: "god_dammit_dave",
        title: "... God Dammit Dave",
        author: "The_Fallen_1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/_god_dammit_dave",
        chapterCount: 11
    },
    {
        id: "the_gol_bria",
        title: "The Gol'bria",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_golbria",
        chapterCount: 9
    },
    {
        id: "the_golden_knight",
        title: "The Golden Knight",
        author: "PixelatedM-",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_golden_knight",
        chapterCount: 38
    },
    {
        id: "the_goodbois",
        title: "The Goodbois",
        author: "noobvs\\_aeternvm",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_goodbois",
        chapterCount: 8
    },
    {
        id: "good_training",
        title: "Good Training",
        author: "ctwelve",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/good_training",
        chapterCount: 4
    },
    {
        id: "goodbye_forever",
        title: "Goodbye Forever",
        author: "Ok-Significance-1752",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/goodbye_forever",
        chapterCount: 8
    },
    {
        id: "grass_eaters",
        title: "Grass Eaters",
        author: "Spooker0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/grass_eaters",
        chapterCount: 49
    },
    {
        id: "the_grand_historical_record_of_humanity",
        title: "The Grand Historical Record Of Humanity",
        author: "Meep2609",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_grand_historical_record_of_humanity",
        chapterCount: 11
    },
    {
        id: "grasping_for_eternity",
        title: "Grasping For Eternity",
        author: "Ambitious-Basil-5518",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/grasping_for_eternity",
        chapterCount: 10
    },
    {
        id: "the_gravity_of_the_situation",
        title: "The Gravity Of The Situation",
        author: "McBoobenstein",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_gravity_of_the_situation",
        chapterCount: 13
    },
    {
        id: "gravity_wraiths",
        title: "Gravity Wraiths",
        author: "madp1atypus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gravity_wraiths",
        chapterCount: 11
    },
    {
        id: "great_expectations",
        title: "Great Expectations",
        author: "Frame_Late",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/great_expectations",
        chapterCount: 12
    },
    {
        id: "greater_good",
        title: "Greater Good",
        author: "Zinsurin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/greater_good",
        chapterCount: 4
    },
    {
        id: "the_greatest_congame_in_the_history_of_the_universe",
        title: "The Greatest Congame In The History Of The Universe",
        author: "Murky_waterLLC",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_greatest_congame_in_the_history_of_the_universe",
        chapterCount: 8
    },
    {
        id: "the_greatest_trick_ever_sold",
        title: "The Greatest Trick Ever Sold",
        author: "Gabmaister",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_greatest_trick_ever_sold",
        chapterCount: 11
    },
    {
        id: "the_greedy_collector_of_chances",
        title: "The Greedy Collector Of Chances",
        author: "BoriCats11",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_greedy_collector_of_chances",
        chapterCount: 28
    },
    {
        id: "green_in_bed",
        title: "Green In Bed",
        author: "TheoRyswell",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/green_in_bed",
        chapterCount: 8
    },
    {
        id: "greentree",
        title: "Greentree",
        author: "thetwitchy1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/greentree",
        chapterCount: 12
    },
    {
        id: "the_grey_paladin",
        title: "The Grey Paladin",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_grey_paladin",
        chapterCount: 0
    },
    {
        id: "gribble",
        title: "Gribble",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gribble",
        chapterCount: 0
    },
    {
        id: "the_grinning_skull",
        title: "The Grinning Skull",
        author: "RegalLegalEagle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_grinning_skull",
        chapterCount: 0
    },
    {
        id: "the_guardian",
        title: "The Guardian",
        author: "bjplague",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_guardian",
        chapterCount: 7
    },
    {
        id: "a_guest_aboard_the_ship",
        title: "A Guest Aboard the Ship",
        author: "British_Tea_Company",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_guest_aboard_the_ship",
        chapterCount: 0
    },
    {
        id: "the_guide_s_journey",
        title: "The Guide's Journey",
        author: "HeadlessChickenCrew",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_guides_journey",
        chapterCount: 10
    },
    {
        id: "guildless_knight",
        title: "Guildless Knight",
        author: "Educational\\_Sail6884",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/guildless_knight",
        chapterCount: 25
    },
    {
        id: "gunfight_at_the_ok_nebula",
        title: "Gunfight at the OK Nebula",
        author: "LucidMagi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gunfight_at_the_ok_nebula",
        chapterCount: 9
    },
    {
        id: "gunslinger_s_blues",
        title: "Gunslinger's Blues",
        author: "luke_poley",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/gunslingers_blues",
        chapterCount: 2
    },
    {
        id: "guttersnipe",
        title: "Guttersnipe",
        author: "Crocodilly_Pontifex",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/guttersnipe",
        chapterCount: 8
    },
    {
        id: "habeas_corpus",
        title: "Habeas Corpus",
        author: "whodidyouthink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/habeas_corpus",
        chapterCount: 9
    },
    {
        id: "hacker_robots",
        title: "Hacker Robots",
        author: "UCCLANno1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hacker_robots",
        chapterCount: 16
    },
    {
        id: "hal_thomas",
        title: "Hal Thomas",
        author: "Glacialfury",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hal_thomas",
        chapterCount: 1
    },
    {
        id: "halfway_to_home",
        title: "Halfway To Home",
        author: "Inorai",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/halfway_to_home",
        chapterCount: 14
    },
    {
        id: "hammer_and_anvil",
        title: "Hammer And Anvil",
        author: "ack1308",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hammer_and_anvil",
        chapterCount: 4
    },
    {
        id: "a_happening",
        title: "A Happening",
        author: "eotyrannus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_happening",
        chapterCount: 1
    },
    {
        id: "hard_knock_life",
        title: "Hard Knock Life",
        author: "BlackSunPublishing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hard_knock_life",
        chapterCount: 13
    },
    {
        id: "the_hard_way",
        title: "The Hard Way",
        author: "PSHoffman",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hard_way",
        chapterCount: 8
    },
    {
        id: "the_hardest",
        title: "The Hardest",
        author: "tikudz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hardest",
        chapterCount: 15
    },
    {
        id: "haven",
        title: "Haven",
        author: "slice\\_of\\_pi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/haven",
        chapterCount: 5
    },
    {
        id: "havenbound",
        title: "Havenbound",
        author: "Starlight Von Aurora",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/havenbound",
        chapterCount: 19
    },
    {
        id: "having_power_sucks",
        title: "Having Power Sucks",
        author: "EvilKrista",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/having_power_sucks",
        chapterCount: 5
    },
    {
        id: "he_stood_taller_than_most",
        title: "He Stood Taller Than Most",
        author: "IneenAldrop",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/he_stood_taller_than_most",
        chapterCount: 93
    },
    {
        id: "hearse",
        title: "Hearse",
        author: "KnightKasket",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hearse",
        chapterCount: 9
    },
    {
        id: "heart_of_steel",
        title: "Heart Of Steel",
        author: "A_Calm_Dragon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/heart_of_steel",
        chapterCount: 11
    },
    {
        id: "hellbound",
        title: "Hellbound",
        author: "Ma7ich",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hellbound",
        chapterCount: 28
    },
    {
        id: "the_hellwalker",
        title: "The Hellwalker",
        author: "Lost_lamb-19",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hellwalker",
        chapterCount: 8
    },
    {
        id: "here_there_be_dragons",
        title: "Here, There Be Dragons",
        author: "FiauraTanks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/here_there_be_dragons",
        chapterCount: 6
    },
    {
        id: "the_hero_of_station_774_3",
        title: "The Hero Of Station 774-3",
        author: "Syegone",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hero_of_station_7743",
        chapterCount: 5
    },
    {
        id: "hero_to_zero_chasing_gold",
        title: "Hero to Zero, Chasing Gold",
        author: "Starlight Von Aurora",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/hero_to_zero",
        chapterCount: 8
    },
    {
        id: "hex",
        title: "HEX",
        author: "AntiMoneySquandering",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hex",
        chapterCount: 10
    },
    {
        id: "hex_knight",
        title: "Hex Knight",
        author: "ManiAxe21",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hex_knight",
        chapterCount: 31
    },
    {
        id: "the_hidden_one",
        title: "The Hidden One",
        author: "scribble_sun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hidden_one",
        chapterCount: 6
    },
    {
        id: "the_hidden_sage_and_the_star_chariot",
        title: "The Hidden Sage And The Star Chariot",
        author: "TheCatWalk_VI",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hidden_sage_and_the_star_chariot",
        chapterCount: 31
    },
    {
        id: "hiring_protection",
        title: "Hiring Protection",
        author: "British_Tea_Company",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hiring_protection",
        chapterCount: 0
    },
    {
        id: "the_his_rebellion_the_siege_of_sector_eta",
        title: "The HIS Rebellion: The Siege Of Sector Eta",
        author: "Frostdraken",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_his_rebellion_the_siege_of_sector_eta",
        chapterCount: 2
    },
    {
        id: "the_historian",
        title: "The Historian",
        author: "frustratinbubble",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_historian",
        chapterCount: 3
    },
    {
        id: "the_history_of_humans",
        title: "The History of Humans",
        author: "dotakin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_history_of_humans",
        chapterCount: 0
    },
    {
        id: "ho_en_chronicler_tales",
        title: "Ho'en Chronicler Tales",
        author: "Dejers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hoen_chronicler_tales",
        chapterCount: 5
    },
    {
        id: "homecoming",
        title: "Homecoming",
        author: "-not-a-serial-killer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/homecoming",
        chapterCount: 5
    },
    {
        id: "homo_mechanicus",
        title: "Homo Mechanicus",
        author: "whodidyouthink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/homo_mechanicus",
        chapterCount: 0
    },
    {
        id: "the_hope_in_humanity",
        title: "The Hope In Humanity",
        author: "rwall0105",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hope_in_humanity",
        chapterCount: 2
    },
    {
        id: "the_horror_of_vega_iv",
        title: "The Horror Of Vega IV",
        author: "T-shitr\\_man",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_horror_of_vega_iv",
        chapterCount: 6
    },
    {
        id: "horror_saves_the_humans",
        title: "Horror saves the humans",
        author: "Mnementh2230",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/horror_saves_the_humans",
        chapterCount: 2
    },
    {
        id: "the_horrors_of_a_desperate_species",
        title: "The Horrors of a Desperate Species",
        author: "NoVirtue",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_horrors_of_a_desperate_species",
        chapterCount: 0
    },
    {
        id: "hotel_foxtrot_yankee",
        title: "Hotel Foxtrot Yankee",
        author: "frozenmoose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hotel_foxtrot_yankee",
        chapterCount: 4
    },
    {
        id: "house_of_death",
        title: "House Of Death",
        author: "EzekielWinters",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/house_of_death",
        chapterCount: 5
    },
    {
        id: "house_of_mouse",
        title: "House Of Mouse",
        author: "CarolOfTheHells",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/house_of_mouse",
        chapterCount: 7
    },
    {
        id: "house_of_wolves",
        title: "House Of Wolves",
        author: "DecebalRex",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/house_of_wolves",
        chapterCount: 35
    },
    {
        id: "how_did_earth_fall",
        title: "How Did Earth Fall",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_did_earth_fall",
        chapterCount: 0
    },
    {
        id: "how_did_they_get_there",
        title: "How Did They Get There?",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_did_they_get_there",
        chapterCount: 0
    },
    {
        id: "how_i_came_to_tolerate_a_human_in_my_residency",
        title: "How I Came To Tolerate A Human In My Residency",
        author: "MarzBeMarz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/how_i_came_to_tolerate_a_human_in_my_residency",
        chapterCount: 6
    },
    {
        id: "the_human_system",
        title: "The 'Human' System",
        author: "Thatariesbloke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_system",
        chapterCount: 11
    },
    {
        id: "human_altered",
        title: "Human Altered",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_altered",
        chapterCount: 13
    },
    {
        id: "human_at_the_academy",
        title: "Human At The Academy!?",
        author: "Ergonomic\\_Brick",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/human_at_the_academy",
        chapterCount: 13
    },
    {
        id: "human_companionship",
        title: "Human Companionship",
        author: "TheFa11enAnge1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_companionship",
        chapterCount: 3
    },
    {
        id: "human_defense",
        title: "Human Defense",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_defense",
        chapterCount: 3
    },
    {
        id: "human_fodder",
        title: "Human Fodder",
        author: "Ozu95supein",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_fodder",
        chapterCount: 3
    },
    {
        id: "human_galactic_project",
        title: "Human Galactic Project",
        author: "nine_tailed_smthng",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_galactic_project",
        chapterCount: 8
    },
    {
        id: "human_gods",
        title: "Human Gods",
        author: "Profound231",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_gods",
        chapterCount: 14
    },
    {
        id: "human_idioms",
        title: "Human Idioms",
        author: "Dinomyar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_idioms",
        chapterCount: 14
    },
    {
        id: "human_ingenuity",
        title: "Human Ingenuity",
        author: "Alpha-Sierra-Charlie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_ingenuity",
        chapterCount: 12
    },
    {
        id: "human_integration",
        title: "Human Integration",
        author: "Lugbor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_integration",
        chapterCount: 11
    },
    {
        id: "human_master",
        title: "Human Master",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_master",
        chapterCount: 4
    },
    {
        id: "human_mating_day",
        title: "Human Mating Day",
        author: "Blerkler",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_mating_day",
        chapterCount: 9
    },
    {
        id: "human_onboard",
        title: "Human Onboard",
        author: "clonk3D",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_onboard",
        chapterCount: 7
    },
    {
        id: "the_human_pet_emporium",
        title: "The Human Pet Emporium",
        author: "karenvideoeditor",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_pet_emporium",
        chapterCount: 9
    },
    {
        id: "human_play",
        title: "Human Play",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_play",
        chapterCount: 4
    },
    {
        id: "human_resources",
        title: "Human Resources",
        author: "ButIDontKnowHow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_resources",
        chapterCount: 6
    },
    {
        id: "the_human_support_and_guidance_forum",
        title: "The Human Support And Guidance Forum",
        author: "NekrounRose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_support_and_guidance_forum",
        chapterCount: 8
    },
    {
        id: "the_human_traitor",
        title: "The Human Traitor",
        author: "iFingerHamsters",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_traitor",
        chapterCount: 13
    },
    {
        id: "the_human_trapped_in_my_head",
        title: "The Human Trapped In My Head",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_human_trapped_in_my_head",
        chapterCount: 4
    },
    {
        id: "human_weaponry",
        title: "Human Weaponry",
        author: "Tunnel--Rat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/human_weaponry",
        chapterCount: 11
    },
    {
        id: "humanity_conquers_three_galaxies",
        title: "Humanity Conquers Three Galaxies",
        author: "MobileDistrict9784",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanity_conquers_three_galaxies",
        chapterCount: 11
    },
    {
        id: "humanity_a_threat",
        title: "Humanity, A Threat?",
        author: "Wonderful\\_Nail\\_615",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanity_a_threat",
        chapterCount: 9
    },
    {
        id: "humanity_s",
        title: "Humanity's ___.",
        author: "AdmiralStarNight",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanitys___",
        chapterCount: 2
    },
    {
        id: "r_hfy_wiki_series_humanitys_1_fan",
        title: "/r/HFY/wiki/series/humanitys_1_fan",
        author: "-Illiriel-",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/humanitys_1_fan",
        chapterCount: 73
    },
    {
        id: "humanity_s_approach_to_utilizing_gods",
        title: "Humanity's Approach To Utilizing Gods",
        author: "caesel",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humanitys_approach_to_utilizing_gods",
        chapterCount: 2
    },
    {
        id: "humans_are_a_myth",
        title: "Humans Are A Myth",
        author: "firefighter_raven",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_a_myth",
        chapterCount: 6
    },
    {
        id: "the_humans_are_coming",
        title: "The Humans Are Coming!",
        author: "Intelligent_Ad8406",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_humans_are_coming",
        chapterCount: 10
    },
    {
        id: "humans_are_crazy",
        title: "Humans Are Crazy!",
        author: "raja-ulat",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/humans_are_crazy",
        chapterCount: 13
    },
    {
        id: "humans_are_deadworlders",
        title: "Humans Are DEADworlders",
        author: "Khaden\\_Allast",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/humans_are_deadworlders",
        chapterCount: 4
    },
    {
        id: "humans_are_jackasses",
        title: "Humans Are [Jackasses]",
        author: "Jackasses",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_jackasses",
        chapterCount: 11
    },
    {
        id: "humans_are_liars",
        title: "HUMANS ARE LIARS!",
        author: "PrussianJoe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_liars",
        chapterCount: 2
    },
    {
        id: "humans_are_space_rednecks",
        title: "Humans Are Space Rednecks",
        author: "Doc\\_Zed\\_42",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_space_rednecks",
        chapterCount: 62
    },
    {
        id: "humans_are_the_reluctant_masters_of_warfare",
        title: "Humans Are The Reluctant Masters Of Warfare",
        author: "XfoXshoreX",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_are_the_reluctant_masters_of_warfare",
        chapterCount: 11
    },
    {
        id: "humans_are_unstoppable",
        title: "Humans Are Unstoppable",
        author: "who\\_reads\\_username",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/humans_are_unstoppable",
        chapterCount: 10
    },
    {
        id: "humans_can_not",
        title: "Humans Can Not",
        author: "goobre",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_can_not",
        chapterCount: 3
    },
    {
        id: "humans_don_t_discriminate_even_against_deathworlders",
        title: "Humans Don't Discriminate Even Against Deathworlders",
        author: "Both\\_Goat3757",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_dont_discriminate_even_against_deathworlders",
        chapterCount: 5
    },
    {
        id: "humans_don_t_have_magic_but_they_clearly_do",
        title: "Humans Don't Have Magic... But They Clearly Do?",
        author: "BuddingDreamer123",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_dont_have_magic_but_they_clearly_do",
        chapterCount: 20
    },
    {
        id: "humans_don_t_make_good_pets",
        title: "Humans Don't Make Good Pets",
        author: "guidosbestfriend",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_dont_make_good_pets",
        chapterCount: 0
    },
    {
        id: "humans_for_hire",
        title: "Humans For Hire",
        author: "Auggy74",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/humans_for_hire",
        chapterCount: 42
    },
    {
        id: "humans_never_die",
        title: "Humans Never Die",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/humans_never_die",
        chapterCount: 0
    },
    {
        id: "hunt_for_the_maji_the_blue_guitar",
        title: "Hunt For The Maji: The Blue Guitar",
        author: "greblaksnew\\_auth",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/hunt_for_the_maji_the_blue_guitar",
        chapterCount: 46
    },
    {
        id: "the_hunter_of_hunters",
        title: "The Hunter Of Hunters",
        author: "Soggy_Helicopter8589",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_hunter_of_hunters",
        chapterCount: 5
    },
    {
        id: "hunter_or_huntress_black_scales",
        title: "Hunter Or Huntress: Black Scales",
        author: "Evil-Emps",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/hunter_or_huntress_black_scales",
        chapterCount: 9
    },
    {
        id: "i_am_human_and_humans_are_not_allowed_to_die",
        title: "I Am Human And Humans Are Not Allowed To Die",
        author: "jstank2",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/i_am_human_and_humans_are_not_allowed_to_die",
        chapterCount: 10
    },
    {
        id: "i_became_a_commander_whatever_that_means",
        title: "I Became A Commander, Whatever That Means",
        author: "RedCastoff",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_became_a_commander_whatever_that_means",
        chapterCount: 16
    },
    {
        id: "i_cast_gun",
        title: "I Cast Gun",
        author: "Express-coal",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/i_cast_gun",
        chapterCount: 28
    },
    {
        id: "i_don_t_think_i_m_an_assassin",
        title: "I Don't THINK I'm An Assassin?",
        author: "thrownawaz092",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_dont_think_im_an_assassin",
        chapterCount: 17
    },
    {
        id: "i_downloaded_a_sketchy_game_now_the_main_character_is_talking_to_me",
        title: "I Downloaded A Sketchy Game... Now The Main Character Is Talking To Me",
        author: "Kanilan\\_",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/i_downloaded_a_sketchy_game_now_the_main_character_is_talking_to_me",
        chapterCount: 11
    },
    {
        id: "i_guess_they_thought_we_would_quit",
        title: "I guess they thought we would quit",
        author: "Jkallgren",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_guess_they_thought_we_would_quit",
        chapterCount: 2
    },
    {
        id: "i_must_protect",
        title: "I Must Protect",
        author: "Individual_Fishing57",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/i_must_protect",
        chapterCount: 13
    },
    {
        id: "i_ll_be_the_red_ranger",
        title: "I'll Be The Red Ranger",
        author: "Mthread",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/ill_be_the_red_ranger",
        chapterCount: 11
    },
    {
        id: "i_m_human",
        title: "I'm Human",
        author: "CrackHeadSchzioMarin",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/im_human",
        chapterCount: 12
    },
    {
        id: "idmagf",
        title: "IDMAGF",
        author: "bossleboss",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/idmagf",
        chapterCount: 11
    },
    {
        id: "if_we_aren_t_dead",
        title: "If We Aren't Dead",
        author: "Dejers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/if_we_arent_dead",
        chapterCount: 10
    },
    {
        id: "ignis",
        title: "Ignis",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ignis",
        chapterCount: 0
    },
    {
        id: "the_immortal_emperor_orphanage_of_the_damned",
        title: "The Immortal Emperor: Orphanage Of The Damned",
        author: "EmrysThomas",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_immortal_emperor_orphanage_of_the_damned",
        chapterCount: 19
    },
    {
        id: "imperial_legions",
        title: "Imperial Legions",
        author: "Thorous_the3rd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/imperial_legions",
        chapterCount: 5
    },
    {
        id: "impossible",
        title: "Impossible",
        author: "Czarchasem",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/impossible",
        chapterCount: 10
    },
    {
        id: "in_a_devil_s_care",
        title: "In A Devil's Care",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/in_a_devils_care",
        chapterCount: 81
    },
    {
        id: "in_dying_starlight",
        title: "In Dying Starlight",
        author: "light_shadows_7",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/in_dying_starlight",
        chapterCount: 11
    },
    {
        id: "in_the_blink_of_an_eye",
        title: "In The Blink Of An Eye",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/in_the_blink_of_an_eye",
        chapterCount: 0
    },
    {
        id: "in_the_days_after_the_cataclysm",
        title: "In The Days After The Cataclysm",
        author: "ObscureDragom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/in_the_days_after_the_cataclysm",
        chapterCount: 10
    },
    {
        id: "incarceration",
        title: "Incarceration",
        author: "Baileyjrob",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/incarceration",
        chapterCount: 6
    },
    {
        id: "incident_at_rainbow_station",
        title: "Incident at \"Rainbow\" Station",
        author: "DeityGamesJesus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/incident_at_rainbow_station",
        chapterCount: 2
    },
    {
        id: "incremental_improvement",
        title: "Incremental Improvement",
        author: "DragonStryk72",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/incremental_improvement",
        chapterCount: 56
    },
    {
        id: "incursion",
        title: "Incursion",
        author: "HarvesterFullCrumb",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/incursion",
        chapterCount: 8
    },
    {
        id: "incursions",
        title: "Incursions",
        author: "Muzolf",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/incursions",
        chapterCount: 11
    },
    {
        id: "incursion_protocol",
        title: "Incursion Protocol",
        author: "EjectedStar",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/incursion_protocol",
        chapterCount: 16
    },
    {
        id: "industrial_mage",
        title: "Industrial Mage",
        author: "No_Marzipan_1230",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/industrial_mage",
        chapterCount: 23
    },
    {
        id: "an_inescapable_perspective",
        title: "An Inescapable Perspective",
        author: "blazingscience",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_inescapable_perspective",
        chapterCount: 8
    },
    {
        id: "infinity_america",
        title: "Infinity America",
        author: "Accomplished\\_Wall804",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/infinity_america",
        chapterCount: 23
    },
    {
        id: "ingress",
        title: "Ingress",
        author: "bellumaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ingress",
        chapterCount: 29
    },
    {
        id: "inhuman_judgment",
        title: "Inhuman Judgment",
        author: "Downtown-Sand-1592",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/inhuman_judgment",
        chapterCount: 24
    },
    {
        id: "instinct",
        title: "Instinct",
        author: "quintus_duke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/instinct",
        chapterCount: 3
    },
    {
        id: "intel_wars",
        title: "Intel Wars",
        author: "ChadManning1989",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/intel_wars",
        chapterCount: 34
    },
    {
        id: "intergalactic_cultural_research",
        title: "Intergalactic Cultural Research",
        author: "LowHunTolerance",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/intergalactic_cultural_research",
        chapterCount: 15
    },
    {
        id: "interlaced",
        title: "Interlaced",
        author: "ClownOfTheYear69",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interlaced",
        chapterCount: 3
    },
    {
        id: "interspecies_acclimation",
        title: "Interspecies Acclimation",
        author: "Bhawk-11",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interspecies_acclimation",
        chapterCount: 4
    },
    {
        id: "interview_with_newbeard",
        title: "Interview with NewBeard",
        author: "Aspiring-Owner",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/interview_with_newbeard",
        chapterCount: 2
    },
    {
        id: "into_the_abyss",
        title: "Into The Abyss",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/into_the_abyss",
        chapterCount: 0
    },
    {
        id: "into_the_deep",
        title: "Into the Deep",
        author: "External\\_Panda9726",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/into_the_deep",
        chapterCount: 9
    },
    {
        id: "into_the_hulk",
        title: "Into The Hulk",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/into_the_hulk",
        chapterCount: 0
    },
    {
        id: "introduction_to_human_biology",
        title: "Introduction To Human Biology",
        author: "Digital332006",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/introduction_to_human_biology",
        chapterCount: 5
    },
    {
        id: "intruders_in_the_hive",
        title: "Intruders In The Hive",
        author: "No-Philosopher2552",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/intruders_in_the_hive",
        chapterCount: 15
    },
    {
        id: "the_invaders",
        title: "The Invaders",
        author: "Malikalein",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_invaders",
        chapterCount: 10
    },
    {
        id: "the_invasion",
        title: "The Invasion",
        author: "Drajac",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_invasion",
        chapterCount: 2
    },
    {
        id: "the_invasion_of_hell",
        title: "The Invasion of Hell",
        author: "XcessiveSmash",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_invasion_of_hell",
        chapterCount: 4
    },
    {
        id: "invasion_of_terra",
        title: "Invasion Of Terra",
        author: "ThatOneAsswipe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/invasion_of_terra",
        chapterCount: 5
    },
    {
        id: "investigations_log_into_human_communication",
        title: "Investigations Log into Human Communication",
        author: "yumyumpants",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/investigations_log_into_human_communication",
        chapterCount: 7
    },
    {
        id: "invictus",
        title: "Invictus",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/invictus",
        chapterCount: 16
    },
    {
        id: "invincible",
        title: "Invincible",
        author: "TheFlameTouched",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/invincible",
        chapterCount: 5
    },
    {
        id: "the_iron_in_the_rock",
        title: "The Iron in the Rock",
        author: "CyberMan0196",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_iron_in_the_rock",
        chapterCount: 0
    },
    {
        id: "it_did_what",
        title: "It........did What?",
        author: "Kokir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/itdid_what",
        chapterCount: 11
    },
    {
        id: "it_s_the_little_things",
        title: "It's The Little Things",
        author: "Sweggler",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/its_the_little_things",
        chapterCount: 3
    },
    {
        id: "the_jackal_guards",
        title: "The Jackal Guards",
        author: "PointMan97",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_jackal_guards",
        chapterCount: 18
    },
    {
        id: "jeff_has_a_bad_day",
        title: "Jeff Has A Bad Day",
        author: "SkullbombRaging",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/jeff_has_a_bad_day",
        chapterCount: 5
    },
    {
        id: "job_arseoth",
        title: "Job Arseoth",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/job_arseoth",
        chapterCount: 0
    },
    {
        id: "job_interview_with_terran_space_pirates",
        title: "Job Interview With Terran Space Pirates",
        author: "Frosty_Incident666",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/job_interview_with_terran_space_pirates",
        chapterCount: 6
    },
    {
        id: "john_and_jane",
        title: "John and Jane",
        author: "NoProofImNotABot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/john_and_jane",
        chapterCount: 4
    },
    {
        id: "join_the_navy_and_see_new_places",
        title: "Join The Navy And See New Places",
        author: "TailGunnner_Writes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/join_the_navy_and_see_new_places",
        chapterCount: 12
    },
    {
        id: "joining_the_empire",
        title: "Joining The Empire",
        author: "atra55",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/joining_the_empire",
        chapterCount: 6
    },
    {
        id: "jord_s_troubled_life",
        title: "Jord's Troubled Life",
        author: "MyReal132",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/jords_troubled_life",
        chapterCount: 12
    },
    {
        id: "the_journals_of_humanity",
        title: "The Journals of Humanity",
        author: "blueninjatiger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_journals_of_humanity",
        chapterCount: 3
    },
    {
        id: "just_a_business_man",
        title: "Just a Business Man",
        author: "endtostart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/just_a_business_man",
        chapterCount: 0
    },
    {
        id: "the_keepers_wing",
        title: "The Keepers Wing",
        author: "AlgravesBurning",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_keepers_wing",
        chapterCount: 12
    },
    {
        id: "the_klapishae_affair",
        title: "The Klapishae Affair",
        author: "Mirikon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_klapishae_affair",
        chapterCount: 7
    },
    {
        id: "knight_of_the_night",
        title: "Knight Of The Night",
        author: "WingAdditional",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/knight_of_the_night",
        chapterCount: 12
    },
    {
        id: "the_knights_in_blue",
        title: "The Knights In Blue",
        author: "Ok-Significance-1752",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_knights_in_blue",
        chapterCount: 3
    },
    {
        id: "the_krall",
        title: "The Krall",
        author: "W3ps",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_krall",
        chapterCount: 8
    },
    {
        id: "ksem_raala_an_icebound_odyssey",
        title: "Ksem & Raala: An Icebound Odyssey",
        author: "YukiteruAmano92",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ksem__raala_an_icebound_odyssey",
        chapterCount: 45
    },
    {
        id: "the_kung_war",
        title: "The Kung War",
        author: "Romanticon",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_kung_war",
        chapterCount: 4
    },
    {
        id: "kunlun_sect_s_weakest_disciple",
        title: "Kunlun Sect's Weakest Disciple",
        author: "DragonKnov",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kunlun_sects_weakest_disciple",
        chapterCount: 31
    },
    {
        id: "kurrzk_mattic_audio_log",
        title: "Kurrzk Mattic Audio Log",
        author: "CasePaper33831",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/kurrzk_mattic_audio_log",
        chapterCount: 10
    },
    {
        id: "the_labyrinth_lazarus",
        title: "The Labyrinth: Lazarus",
        author: "desenterrado",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_labyrinth_lazarus",
        chapterCount: 16
    },
    {
        id: "land_of_blue_sky",
        title: "Land Of Blue Sky",
        author: "-Expedition99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/land_of_blue_sky",
        chapterCount: 3
    },
    {
        id: "lands_unknown",
        title: "Lands Unknown",
        author: "Which\\_Marsupial\\_7557",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/lands_unknown",
        chapterCount: 13
    },
    {
        id: "the_last",
        title: "The Last",
        author: "END\\_ME21",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last",
        chapterCount: 11
    },
    {
        id: "r_hfy_wiki_series_the_last_dainvs_road_to_not_become_an_eldritch_horror",
        title: "/r/HFY/wiki/series/the_last_dainvs_road_to_not_become_an_eldritch_horror",
        author: "seofumi",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_last_dainvs_road_to_not_become_an_eldritch_horror",
        chapterCount: 52
    },
    {
        id: "the_last_human_2",
        title: "The Last Human",
        author: "Negativetangelo6984",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_human_negativetangelo6984",
        chapterCount: 15
    },
    {
        id: "last_of_the_defenders",
        title: "Last Of The Defenders",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/last_of_the_defenders",
        chapterCount: 0
    },
    {
        id: "the_last_one",
        title: "The Last One",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_one",
        chapterCount: 0
    },
    {
        id: "the_last_precursor",
        title: "The Last Precursor",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_precursor",
        chapterCount: 0
    },
    {
        id: "the_last_prince_of_rennaya",
        title: "The Last Prince Of Rennaya",
        author: "Dot200",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_prince_of_rennaya",
        chapterCount: 21
    },
    {
        id: "the_last_roar_of_humanity",
        title: "The Last Roar of Humanity",
        author: "TheSovreignColonies",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_last_roar_of_humanity",
        chapterCount: 5
    },
    {
        id: "the_last_woman_on_earth",
        title: "The Last Woman On Earth",
        author: "danny69production",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_last_woman_on_earth",
        chapterCount: 10
    },
    {
        id: "the_law",
        title: "The Law",
        author: "Avskygod0",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_law",
        chapterCount: 3
    },
    {
        id: "the_laziest_god_in_existence",
        title: "The Laziest God In Existence",
        author: "Bhawk-11",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_laziest_god_in_existence",
        chapterCount: 2
    },
    {
        id: "lebab",
        title: "Lebab",
        author: "OpinionatedIMO",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lebab",
        chapterCount: 12
    },
    {
        id: "a_leap_of_faith",
        title: "A Leap Of Faith",
        author: "Xerosese",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_leap_of_faith",
        chapterCount: 10
    },
    {
        id: "legacy_banality_of_good_and_evil",
        title: "Legacy - Banality Of Good And Evil",
        author: "AnxiousMycologist600",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/legacy__banality_of_good_and_evil",
        chapterCount: 22
    },
    {
        id: "legend_of_the_void",
        title: "Legend Of The Void",
        author: "i_eat-kids_1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/legend_of_the_void",
        chapterCount: 5
    },
    {
        id: "legends_of_an_empire_of_sand",
        title: "Legends of an Empire of Sand",
        author: "Thorous_the3rd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/legends_of_an_empire_of_sand",
        chapterCount: 6
    },
    {
        id: "the_legend_of_norman_barman",
        title: "The Legend of Norman Barman",
        author: "Lostfol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_legend_of_norman_barman",
        chapterCount: 6
    },
    {
        id: "the_legion",
        title: "The Legion",
        author: "Kelgrimm",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_legion",
        chapterCount: 2
    },
    {
        id: "letters_from_earth",
        title: "Letters From Earth",
        author: "McShaggit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/letters_from_earth",
        chapterCount: 2
    },
    {
        id: "letters_from_the_archive",
        title: "Letters From The Archive",
        author: "Syegone",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/letters_from_the_archive",
        chapterCount: 0
    },
    {
        id: "letters_from_the_front",
        title: "Letters From The Front",
        author: "czs5056",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/letters_from_the_front",
        chapterCount: 0
    },
    {
        id: "level_1_ghost",
        title: "Level 1 Ghost",
        author: "HowardDentWriting",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/level_1_ghost",
        chapterCount: 38
    },
    {
        id: "level_one_god",
        title: "Level One God",
        author: "ZscottLITRPG",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/level_one_god",
        chapterCount: 30
    },
    {
        id: "lf_friends_will_travel",
        title: "LF Friends, Will Travel",
        author: "BainshieWrites",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lf_friends_will_travel",
        chapterCount: 8
    },
    {
        id: "liberation_war",
        title: "Liberation War",
        author: "dnqxtsck5",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/liberation_war",
        chapterCount: 3
    },
    {
        id: "library_of_void",
        title: "Library Of Void",
        author: "Longjumping_Swim3745",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/library_of_void",
        chapterCount: 20
    },
    {
        id: "the_life_and_times_of_lord_ulric",
        title: "The Life and Times of Lord Ulric",
        author: "whodidyouthink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_life_and_times_of_lord_ulric",
        chapterCount: 2
    },
    {
        id: "the_life_and_times_of_rian",
        title: "The Life and Times of Rian",
        author: "RegalLegalEagle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_life_and_times_of_rian",
        chapterCount: 0
    },
    {
        id: "life_looks_for_life",
        title: "Life Looks For Life",
        author: "elderrion",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_looks_for_life",
        chapterCount: 5
    },
    {
        id: "life_mage",
        title: "Life Mage",
        author: "Cythblackfrost",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_mage",
        chapterCount: 20
    },
    {
        id: "life_with_my_2d_waifu",
        title: "Life with my 2d Waifu",
        author: "ChadManning1989",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/life_with_my_2d_waifu",
        chapterCount: 38
    },
    {
        id: "lightning_war",
        title: "Lightning War",
        author: "bonk1969",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lightning_war",
        chapterCount: 4
    },
    {
        id: "little_gaia",
        title: "Little Gaia",
        author: "Weerdo5255",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/little_gaia",
        chapterCount: 4
    },
    {
        id: "living_fossils",
        title: "Living Fossils",
        author: "GeorgeCrecy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/living_fossils",
        chapterCount: 17
    },
    {
        id: "load_kitty",
        title: "Load Kitty",
        author: "Few\\_Carpenter\\_9185",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/load_kitty",
        chapterCount: 15
    },
    {
        id: "the_lone_human",
        title: "The Lone Human",
        author: "Holiday-Possible29",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_lone_human",
        chapterCount: 9
    },
    {
        id: "the_lonely_world",
        title: "The Lonely World",
        author: "ArcAngel98",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_lonely_world",
        chapterCount: 15
    },
    {
        id: "the_lord_of_silvershade",
        title: "The Lord Of Silvershade",
        author: "Zinthorr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_lord_of_silvershade",
        chapterCount: 40
    },
    {
        id: "lord_of_starlight",
        title: "Lord Of Starlight",
        author: "Unorthedox\\_Doggie117",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/lord_of_starlight",
        chapterCount: 22
    },
    {
        id: "lords_of_war_bellum_in_carne",
        title: "Lords of War: Bellum in Carne",
        author: "Scotscin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lords_of_war_bellum_in_carne",
        chapterCount: 6
    },
    {
        id: "loss_of_humanity",
        title: "Loss Of Humanity",
        author: "Safe\\_Committee9381",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/loss_of_humanity",
        chapterCount: 6
    },
    {
        id: "lost_in_reality_found_in_confusion",
        title: "Lost In Reality, Found In Confusion",
        author: "Phoenixfury12",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lost_in_reality_found_in_confusion",
        chapterCount: 15
    },
    {
        id: "lost_in_the_void",
        title: "Lost in the Void",
        author: "Niveker14",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/lost_in_the_void",
        chapterCount: 18
    },
    {
        id: "the_lost_minstrel",
        title: "The Lost Minstrel",
        author: "doules1071",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_lost_minstrel",
        chapterCount: 19
    },
    {
        id: "lost_terran",
        title: "Lost Terran",
        author: "EffectSubstantial909",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/lost_terran",
        chapterCount: 8
    },
    {
        id: "love_war_apocalypse",
        title: "Love, War, Apocalypse",
        author: "ArturSpatuzziAuthor",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/love_war_apocalypse",
        chapterCount: 15
    },
    {
        id: "a_love_hate_relationship",
        title: "A Love-Hate Relationship",
        author: "Drakknir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_lovehate_relationship",
        chapterCount: 4
    },
    {
        id: "ludo_brax_intergalactic_gig_worker",
        title: "Ludo Brax: Intergalactic Gig Worker",
        author: "wetmosealrise",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ludo_brax_intergalactic_gig_worker",
        chapterCount: 62
    },
    {
        id: "lythinia_incident",
        title: "Lythinia Incident",
        author: "VenusUberAlles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/lythinia_incident",
        chapterCount: 8
    },
    {
        id: "the_machine_from_beyond_the_void",
        title: "The Machine from Beyond the Void",
        author: "slender2112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_machine_from_beyond_the_void",
        chapterCount: 2
    },
    {
        id: "the_machine_s_ghost",
        title: "The Machine's Ghost",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_machines_ghost",
        chapterCount: 0
    },
    {
        id: "mad",
        title: "MAD",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mad",
        chapterCount: 0
    },
    {
        id: "made_for_war",
        title: "Made For War",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/made_for_war",
        chapterCount: 0
    },
    {
        id: "madness_of_the_void",
        title: "Madness Of The Void",
        author: "ill\\_B\\_In\\_MyBunk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/madness_of_the_void",
        chapterCount: 4
    },
    {
        id: "mage_turning_the_tides_of_war",
        title: "Mage: Turning The Tides Of War",
        author: "Maradina88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mage_turning_the_tides_of_war",
        chapterCount: 5
    },
    {
        id: "mage_steel",
        title: "Mage Steel",
        author: "Domr707",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/mage_steel",
        chapterCount: 30
    },
    {
        id: "magic_academy_roskastyrksn_m",
        title: "Magic Academy ��Roskastyrksn��m",
        author: "Broadsiderz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/magic_academy_throskastyrksnam",
        chapterCount: 13
    },
    {
        id: "magic_is_electricity",
        title: "Magic Is Electricity?!",
        author: "97cweb",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/magic_is_electricity",
        chapterCount: 57
    },
    {
        id: "magical_engineering",
        title: "Magical Engineering",
        author: "OriginalButtopia",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/magical_engineering",
        chapterCount: 11
    },
    {
        id: "magus_reborn",
        title: "Magus Reborn",
        author: "Weird-Listen-3166",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/magus_reborn",
        chapterCount: 12
    },
    {
        id: "malgania",
        title: "Malgania",
        author: "Ma7ich",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/malgania",
        chapterCount: 3
    },
    {
        id: "the_mammals_in_tan",
        title: "The Mammals In Tan",
        author: "Greninja5097",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_mammals_in_tan",
        chapterCount: 7
    },
    {
        id: "the_man",
        title: "The Man",
        author: "PM_ME_FIREARMS",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_man",
        chapterCount: 4
    },
    {
        id: "man_eat_man",
        title: "Man Eat Man",
        author: "Cola\\_Dad",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/man_eat_man",
        chapterCount: 12
    },
    {
        id: "man_made_mystery",
        title: "Man Made Mystery",
        author: "KuroKitsune_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/man_made_mystery",
        chapterCount: 24
    },
    {
        id: "mankind_diaspora",
        title: "Mankind Diaspora",
        author: "RKlehm",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/mankind_diaspora",
        chapterCount: 11
    },
    {
        id: "mankind_s_gambit",
        title: "Mankind's Gambit",
        author: "gregovin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mankinds_gambit",
        chapterCount: 3
    },
    {
        id: "a_mans_end",
        title: "A Mans End",
        author: "Thorous_the3rd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_mans_end",
        chapterCount: 2
    },
    {
        id: "the_many_limbed_ones",
        title: "The Many-Limbed Ones",
        author: "Guncaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_manylimbed_ones",
        chapterCount: 4
    },
    {
        id: "many_worlds",
        title: "Many worlds",
        author: "tikkunmytime",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/many_worlds",
        chapterCount: 3
    },
    {
        id: "the_marauder",
        title: "The Marauder",
        author: "jellybeanbazooka",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_marauder",
        chapterCount: 13
    },
    {
        id: "marker_of_god",
        title: "Marker Of God",
        author: "alexdelacluj",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/marker_of_god",
        chapterCount: 8
    },
    {
        id: "martial_immortal",
        title: "Martial Immortal",
        author: "Natural_Estate_9690",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/martial_immortal",
        chapterCount: 12
    },
    {
        id: "the_master_of_souls",
        title: "The Master Of Souls",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_master_of_souls",
        chapterCount: 0
    },
    {
        id: "mass_multiversal_mayhem",
        title: "Mass Multiversal Mayhem",
        author: "Vivid-Membership3959",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mass_multiversal_mayhem",
        chapterCount: 7
    },
    {
        id: "masters_and_monsters",
        title: "Masters And Monsters",
        author: "CompletelyFlammable",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/masters_and_monsters",
        chapterCount: 2
    },
    {
        id: "material_differences",
        title: "Material Differences",
        author: "RegalLegalEagle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/material_differences",
        chapterCount: 0
    },
    {
        id: "matte_black_pt_ii",
        title: "Matte Black Pt. II",
        author: "abloobudoo009",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/matte_black_pt_ii",
        chapterCount: 3
    },
    {
        id: "a_matter_of_definitions",
        title: "A Matter Of Definitions",
        author: "No\\_Reception\\_4075",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/a_matter_of_definitions",
        chapterCount: 9
    },
    {
        id: "mcmasters_saga",
        title: "Mcmasters Saga",
        author: "Chairsofter10",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mcmasters_saga",
        chapterCount: 2
    },
    {
        id: "a_mech_s_life",
        title: "A Mech's Life",
        author: "Digital332006",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_mechs_life",
        chapterCount: 5
    },
    {
        id: "mechanized_warfare",
        title: "Mechanized Warfare",
        author: "CastratorofWomen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mechanized_warfare",
        chapterCount: 2
    },
    {
        id: "megacorporations_and_mages",
        title: "Megacorporations And Mages",
        author: "RaidneSkuldia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/megacorporations_and_mages",
        chapterCount: 7
    },
    {
        id: "memetic_apotheosis",
        title: "Memetic Apotheosis",
        author: "Aetharan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/memetic_apotheosis",
        chapterCount: 7
    },
    {
        id: "memoirs_of_first_contact",
        title: "Memoirs Of First Contact",
        author: "Aumnayan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/memoirs_of_first_contact",
        chapterCount: 30
    },
    {
        id: "memories_of_creature_88",
        title: "Memories of Creature 88",
        author: "RegalLegalEagle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/creature_88",
        chapterCount: 0
    },
    {
        id: "memory_record",
        title: "Memory Record",
        author: "salthin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/memory_record",
        chapterCount: 11
    },
    {
        id: "of_men_and_ghost_ships",
        title: "Of Men And Ghost Ships",
        author: "DrBlackJack21",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/of_men_and_ghost_ships",
        chapterCount: 112
    },
    {
        id: "men_of_sol",
        title: "Men of Sol",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/men_of_sol",
        chapterCount: 0
    },
    {
        id: "men_of_the_watch",
        title: "Men of the Watch",
        author: "Haenir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/men_of_the_watch",
        chapterCount: 2
    },
    {
        id: "mermaid_s_shoal",
        title: "Mermaid's Shoal",
        author: "QE\\_Saenz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mermaids_shoal",
        chapterCount: 21
    },
    {
        id: "metal_demons",
        title: "Metal Demons",
        author: "ABrokenRomeo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/metal_demons",
        chapterCount: 3
    },
    {
        id: "metrics",
        title: "Metrics",
        author: "HypotheticalShoggoth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/metrics",
        chapterCount: 5
    },
    {
        id: "mia",
        title: "MIA",
        author: "GoingAnywhereButHere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/mia",
        chapterCount: 0
    },
    {
        id: "mid_earth_maidens",
        title: "Mid-Earth Maidens",
        author: "Hope-for-hopeless",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/midearth_maidens",
        chapterCount: 8
    },
    {
        id: "midjagardaz",
        title: "Midjagardaz",
        author: "\\_\\_te\\_\\_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/midjagardaz",
        chapterCount: 3
    },
    {
        id: "miesenthrop",
        title: "Miesenthrop",
        author: "Celestial_Zwei_Dei",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/miesenthrop",
        chapterCount: 19
    },
    {
        id: "minds_apart",
        title: "Minds Apart",
        author: "Zephylandantus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/minds_apart",
        chapterCount: 15
    },
    {
        id: "the_more_you_sweat",
        title: "The More You Sweat",
        author: "meatfcker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_more_you_sweat",
        chapterCount: 2
    },
    {
        id: "a_morphing_universe",
        title: "A Morphing Universe",
        author: "Express_Ad_6664",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_morphing_universe",
        chapterCount: 14
    },
    {
        id: "mortal_protection_services",
        title: "Mortal Protection Services",
        author: "kiltedfrog",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/mortal_protection_services",
        chapterCount: 46
    },
    {
        id: "a_most_confusing_series",
        title: "A Most Confusing Series",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_most_confusing_series",
        chapterCount: 0
    },
    {
        id: "mother_s_love",
        title: "Mother's Love",
        author: "Tulip\\_Mama7",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/mothers_love",
        chapterCount: 20
    },
    {
        id: "much_ado",
        title: "Much Ado...",
        author: "bott99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/much_ado",
        chapterCount: 4
    },
    {
        id: "multiversal_explorer",
        title: "Multiversal Explorer",
        author: "KrighterineOxanimite",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/multiversal_explorer",
        chapterCount: 11
    },
    {
        id: "music_in_space",
        title: "Music In Space",
        author: "Red_Riviera",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/music_in_space",
        chapterCount: 2
    },
    {
        id: "musings_of_a_whiny_machine_intelligence",
        title: "Musings Of A Whiny Machine Intelligence",
        author: "tsavong117",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/musings_of_a_whiny_machine_intelligence",
        chapterCount: 2
    },
    {
        id: "my_best_friend_is_a_snake_girl",
        title: "My Best Friend Is A Snake-girl",
        author: "KurtisEckstein",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_best_friend_is_a_snakegirl",
        chapterCount: 33
    },
    {
        id: "my_evolution_system",
        title: "My Evolution System",
        author: "The_Interference",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_evolution_system",
        chapterCount: 11
    },
    {
        id: "my_mother_got_me_into_a_monster_fight_club",
        title: "My Mother Got Me Into A Monster Fight Club",
        author: "978866",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/my_mother_got_me_into_a_monster_fight_club",
        chapterCount: 22
    },
    {
        id: "my_name_isn_t_bon_bon",
        title: "My Name Isn't Bon Bon",
        author: "Dejers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/my_name_isnt_bon_bon",
        chapterCount: 10
    },
    {
        id: "mysidian_wanderings",
        title: "Mysidian Wanderings",
        author: "AfterImageEclipse",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/mysidian_wanderings",
        chapterCount: 13
    },
    {
        id: "nat_and_kini_related_occurrences_and_how_not_to_address_them",
        title: "Nat And Kini Related Occurrences And How Not To Address Them",
        author: "trustmeijustgetweird",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nat_and_kini_related_occurrences_and_how_not_to_address_them",
        chapterCount: 4
    },
    {
        id: "the_nature_of_crows_a_nature_of_predators_fan_fiction",
        title: "The Nature Of Crows: A Nature Of Predators Fan Fiction",
        author: "Illwood_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_nature_of_crows_a_nature_of_predators_fan_fiction",
        chapterCount: 10
    },
    {
        id: "the_necromancer",
        title: "The Necromancer",
        author: "kem81",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_necromancer",
        chapterCount: 14
    },
    {
        id: "necromanic",
        title: "Necromanic",
        author: "endtostart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/necromanic",
        chapterCount: 0
    },
    {
        id: "necrotis_morphonic_animalia",
        title: "Necrotis Morphonic Animalia",
        author: "EvilKrista",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/necrotis_morphonic_animalia",
        chapterCount: 1
    },
    {
        id: "neodrius",
        title: "Neodrius",
        author: "i\\_lick\\_chairs",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/neodrius",
        chapterCount: 42
    },
    {
        id: "the_network",
        title: "The Network",
        author: "bronic12",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_network",
        chapterCount: 16
    },
    {
        id: "new_horizons_3",
        title: "New Horizons",
        author: "Gridinad",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/new_horizons_gridinad",
        chapterCount: 28
    },
    {
        id: "the_new_kids",
        title: "The New Kids",
        author: "Left_Nut_McGee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_new_kids",
        chapterCount: 2
    },
    {
        id: "new_terran_refuge",
        title: "New Terran Refuge",
        author: "luckytron",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/new_terran_refuge",
        chapterCount: 32
    },
    {
        id: "nexus_revolution",
        title: "Nexus Revolution",
        author: "th3frozenpriest",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nexus_revolution",
        chapterCount: 41
    },
    {
        id: "night_rise",
        title: "Night Rise",
        author: "humanoidtiphoon",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/night_rise",
        chapterCount: 8
    },
    {
        id: "no_alien_s_land",
        title: "No Alien's Land",
        author: "YisouKou",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_aliens_land",
        chapterCount: 5
    },
    {
        id: "no_moon",
        title: "No Moon",
        author: "OfficialLeeHadan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no_moon",
        chapterCount: 19
    },
    {
        id: "no_one_trusts_a_shape_shifter",
        title: "No-one trusts a shape-shifter",
        author: "Ententacled-Regalia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/no-one_trusts_a_shape-shifter",
        chapterCount: 2
    },
    {
        id: "non_player_characters",
        title: "Non-Player Characters",
        author: "DracheGraethe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/non-player_characters",
        chapterCount: 2
    },
    {
        id: "the_noola_and_the_zarr",
        title: "The Noola And The Zarr",
        author: "Ben_Hocking",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_noola_and_the_zarr",
        chapterCount: 10
    },
    {
        id: "not_so_isekied_psionic",
        title: "Not-so-isekied Psionic",
        author: "In_sa_ni_ty",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/notsoisekied_psionic",
        chapterCount: 6
    },
    {
        id: "not_holding_back",
        title: "Not Holding Back",
        author: "Abramus5250",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/not_holding_back",
        chapterCount: 4
    },
    {
        id: "not_human",
        title: "Not Human",
        author: "DependentAlgae",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/not_human",
        chapterCount: 5
    },
    {
        id: "not_my_problem",
        title: "Not My Problem",
        author: "BrokenOldBastage",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/not_my_problem",
        chapterCount: 13
    },
    {
        id: "nova_wars_tie_in",
        title: "Nova Wars Tie-in",
        author: "Vridiantoast",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/nova_wars_tiein",
        chapterCount: 25
    },
    {
        id: "the_novymia_archives",
        title: "The Novymia Archives",
        author: "morbiusgreen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_novymia_archives",
        chapterCount: 13
    },
    {
        id: "obsolete_future",
        title: "Obsolete Future",
        author: "neutronfish",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/obsolete_future",
        chapterCount: 13
    },
    {
        id: "the_occupation_of_planet_four",
        title: "The Occupation Of Planet Four",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_occupation_of_planet_four",
        chapterCount: 0
    },
    {
        id: "occupational_hazards",
        title: "Occupational Hazards",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/occupational_hazards",
        chapterCount: 0
    },
    {
        id: "ocean_of_zanmuldune",
        title: "Ocean Of Zanmuldune",
        author: "clivecummings",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ocean_of_zanmuldune",
        chapterCount: 7
    },
    {
        id: "offspring",
        title: "Offspring",
        author: "browneorum",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/offspring",
        chapterCount: 28
    },
    {
        id: "oh_great_now_i_m_a_dungeon",
        title: "Oh Great, Now I'm A Dungeon",
        author: "Gloomy-Wedding9837",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oh_great_now_im_a_dungeon",
        chapterCount: 11
    },
    {
        id: "oh_things_could_be_worse",
        title: "Oh Things Could Be Worse",
        author: "Darksteel_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oh_things_could_be_worse",
        chapterCount: 8
    },
    {
        id: "oh_noes",
        title: "OH-NOES",
        author: "voodooattack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oh-noes",
        chapterCount: 13
    },
    {
        id: "old_terran_soul",
        title: "Old Terran Soul",
        author: "NorSec1987",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/old_terran_soul",
        chapterCount: 15
    },
    {
        id: "on_the_balance_of_fate",
        title: "On The Balance Of Fate",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/on_the_balance_of_fate",
        chapterCount: 5
    },
    {
        id: "on_the_beaches",
        title: "On The Beaches",
        author: "ForanIdah",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/on_the_beaches",
        chapterCount: 2
    },
    {
        id: "one_way_trip",
        title: "One-way Trip",
        author: "rewt66dewd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/oneway_trip",
        chapterCount: 6
    },
    {
        id: "one_hell_of_a_gap_year",
        title: "One Hell Of A Gap Year",
        author: "ToWitToWhom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/one_hell_of_a_gap_year",
        chapterCount: 8
    },
    {
        id: "one_last_try",
        title: "One Last Try",
        author: "slender2112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/one_last_try",
        chapterCount: 3
    },
    {
        id: "operation_firestorm_the_ensuing_occupation_and_how_we_dealt_with_it",
        title: "Operation Firestorm, The Ensuing Occupation, And How We Dealt With It",
        author: "123WhoGivesAShit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/operation_firestorm_the_ensuing_occupation_and_how_we_dealt_with_it",
        chapterCount: 4
    },
    {
        id: "operation_savior",
        title: "Operation Savior",
        author: "Manufacture",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/operation_savior",
        chapterCount: 4
    },
    {
        id: "operation_scare_and_tear",
        title: "Operation Scare and Tear",
        author: "Humptybumpty",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/operation_scare_and_tear",
        chapterCount: 2
    },
    {
        id: "orange_is_an_odd_number",
        title: "Orange Is An Odd Number",
        author: "OpinionatedIMO",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/orange_is_an_odd_number",
        chapterCount: 5
    },
    {
        id: "order_and_chaos",
        title: "Order and Chaos",
        author: "xmangoslushie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/order_and_chaos",
        chapterCount: 0
    },
    {
        id: "origins_of_the_httt_patriarchy",
        title: "Origins of the Httt Patriarchy",
        author: "ZankerH",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/origins_of_the_httt_patriarchy",
        chapterCount: 2
    },
    {
        id: "orion_chronicles",
        title: "Orion Chronicles",
        author: "Schwarzer_R",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/orion_chronicles",
        chapterCount: 7
    },
    {
        id: "orphan",
        title: "Orphan",
        author: "Orphan_Guy_Incognito",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/orphan",
        chapterCount: 14
    },
    {
        id: "otherworld_mansion",
        title: "Otherworld Mansion",
        author: "areswalker8",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/otherworld_mansion",
        chapterCount: 18
    },
    {
        id: "our_just_purpose",
        title: "Our Just Purpose",
        author: "BeaverFur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_just_purpose",
        chapterCount: 6
    },
    {
        id: "our_new_peaceful_friends",
        title: "Our New Peaceful Friends",
        author: "Psychronia",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/our_new_peaceful_friends",
        chapterCount: 32
    },
    {
        id: "our_promise",
        title: "Our promise",
        author: "gods_fear_me",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/our_promise",
        chapterCount: 6
    },
    {
        id: "our_sins_ghosts",
        title: "Our Sins Ghosts",
        author: "Arrowhead2009",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/our_sins_ghosts",
        chapterCount: 14
    },
    {
        id: "out_of_our_element",
        title: "Out Of Our Element",
        author: "Saint-Andros",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/out_of_our_element",
        chapterCount: 8
    },
    {
        id: "an_outcast_in_another_world",
        title: "An Outcast In Another World",
        author: "Determination7",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_outcast_in_another_world",
        chapterCount: 12
    },
    {
        id: "outer_reaches",
        title: "Outer Reaches",
        author: "L_Tanuki",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/outer_reaches",
        chapterCount: 25
    },
    {
        id: "outsiders",
        title: "Outsiders",
        author: "codewalrus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/outsiders",
        chapterCount: 3
    },
    {
        id: "overriding_instincts",
        title: "Overriding Instincts",
        author: "AsshatVik",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/overriding_instincts",
        chapterCount: 5
    },
    {
        id: "the_overtesian_bird",
        title: "The Overtesian Bird",
        author: "del\\_elle\\_0816",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_overtesian_bird",
        chapterCount: 4
    },
    {
        id: "ozzie_in_another_world_or_bat_shit_crazy",
        title: "Ozzie In Another World Or Bat Shit Crazy",
        author: "Select_Basket9975",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ozzie_in_another_world_or_bat_shit_crazy",
        chapterCount: 14
    },
    {
        id: "pack_bonding",
        title: "Pack Bonding",
        author: "Rebelhero",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pack_bonding",
        chapterCount: 6
    },
    {
        id: "painful_discoveries",
        title: "Painful Discoveries",
        author: "iamawritertrustme",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/painful_discoveries",
        chapterCount: 2
    },
    {
        id: "paint_the_stars_red",
        title: "Paint The Stars Red",
        author: "MountainSkald",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/paint_the_stars_red",
        chapterCount: 4
    },
    {
        id: "paradise_delayed",
        title: "Paradise Delayed",
        author: "JWGibsonWrites",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/paradise_delayed",
        chapterCount: 31
    },
    {
        id: "past_death_itself",
        title: "Past Death Itself",
        author: "Tumbmar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/past_death_itself",
        chapterCount: 15
    },
    {
        id: "the_pawn_rebellion",
        title: "The Pawn Rebellion",
        author: "thePatchyBeard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_pawn_rebellion",
        chapterCount: 1
    },
    {
        id: "pawstruck",
        title: "Pawstruck",
        author: "TraversingtheDark",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pawstruck",
        chapterCount: 4
    },
    {
        id: "pax_caelestia",
        title: "Pax Caelestia",
        author: "whodidyouthink",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pax_caelestia",
        chapterCount: 3
    },
    {
        id: "pay_the_piper",
        title: "Pay the Piper",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pay_the_piper",
        chapterCount: 0
    },
    {
        id: "peace_keeper",
        title: "Peace Keeper",
        author: "ill\\_B\\_In\\_MyBunk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/peace_keeper",
        chapterCount: 6
    },
    {
        id: "the_people_of_the_valleys",
        title: "The People Of The Valleys",
        author: "Fabulous-Tax2445",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_people_of_the_valleys",
        chapterCount: 5
    },
    {
        id: "per_aspera_ad_astra",
        title: "Per Aspera, Ad Astra",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/per_aspera_ad_astra",
        chapterCount: 2
    },
    {
        id: "perfectly_safe_demons",
        title: "Perfectly Safe Demons",
        author: "Mista9000",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/perfectly_safe_demons",
        chapterCount: 31
    },
    {
        id: "the_perseid_empire",
        title: "The Perseid Empire",
        author: "Dreadworker",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_perseid_empire",
        chapterCount: 4
    },
    {
        id: "persistence_training",
        title: "Persistence Training",
        author: "Ryantific_theory",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/persistence_training",
        chapterCount: 4
    },
    {
        id: "perspective",
        title: "Perspective",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/perspective",
        chapterCount: 0
    },
    {
        id: "petty_revenge",
        title: "Petty Revenge",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/petty_revenge",
        chapterCount: 0
    },
    {
        id: "phoenix",
        title: "Phoenix",
        author: "Haenir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/phoenix",
        chapterCount: 3
    },
    {
        id: "the_phoenix_s_descent",
        title: "The Phoenix's Descent",
        author: "QrangeJuice",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_phoenixs_descent",
        chapterCount: 3
    },
    {
        id: "physical_ethereal",
        title: "Physical Ethereal",
        author: "Mr_Reach",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/physical_ethereal",
        chapterCount: 7
    },
    {
        id: "picking_the_wrong_prey",
        title: "Picking The Wrong Prey",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/picking_the_wrong_prey",
        chapterCount: 4
    },
    {
        id: "a_pirate_s_life",
        title: "A Pirate's Life",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_pirates_life",
        chapterCount: 0
    },
    {
        id: "pizzaman_of_the_galaxy",
        title: "Pizzaman Of The Galaxy",
        author: "CaptainChristopher02",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pizzaman_of_the_galaxy",
        chapterCount: 12
    },
    {
        id: "plague",
        title: "Plague",
        author: "SPO_Megarith",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plague",
        chapterCount: 3
    },
    {
        id: "the_plague_called_humanity",
        title: "The Plague called Humanity",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plague_called_humanity",
        chapterCount: 5
    },
    {
        id: "planet_dirt",
        title: "Planet Dirt",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/planet_dirt",
        chapterCount: 31
    },
    {
        id: "planet_fall",
        title: "Planet fall",
        author: "fadingremnants",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/planet_fall",
        chapterCount: 4
    },
    {
        id: "the_planet_that_hates_you",
        title: "The Planet That Hates You",
        author: "SometimesATroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_planet_that_hates_you",
        chapterCount: 0
    },
    {
        id: "plausible_deniability",
        title: "Plausible Deniability",
        author: "Arceroth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plausible_deniability",
        chapterCount: 4
    },
    {
        id: "please_send_help",
        title: "Please Send Help",
        author: "Foreign-Affect7871",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/please_send_help",
        chapterCount: 6
    },
    {
        id: "plight",
        title: "Plight",
        author: "The-Corinthian-Man",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/plight",
        chapterCount: 4
    },
    {
        id: "political_games",
        title: "Political Games",
        author: "endtostart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/political_games",
        chapterCount: 0
    },
    {
        id: "post_scarcity",
        title: "Post Scarcity",
        author: "SonokaGM",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/post_scarcity",
        chapterCount: 12
    },
    {
        id: "post_apocalypse_bar_and_grill",
        title: "Post Apocalypse Bar And Grill",
        author: "Armored_Grizzly",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/post_apocalypse_bar_and_grill",
        chapterCount: 42
    },
    {
        id: "power_on",
        title: "Power On",
        author: "Bekahelen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/power_on",
        chapterCount: 13
    },
    {
        id: "pray_the_conquistadores",
        title: "Pray The Conquistadores",
        author: "Reptani",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pray_the_conquistadores",
        chapterCount: 20
    },
    {
        id: "pre_warp_survival",
        title: "Pre-warp Survival",
        author: "DragonStryk72",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/prewarp_survival",
        chapterCount: 40
    },
    {
        id: "precious_life",
        title: "Precious Life",
        author: "HedgehogOk5040",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/precious_life",
        chapterCount: 10
    },
    {
        id: "predator_and_prey",
        title: "Predator and Prey",
        author: "Visser946",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/predator_and_prey",
        chapterCount: 8
    },
    {
        id: "predator_complex",
        title: "Predator Complex",
        author: "EnoKhanVT",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/predator_complex",
        chapterCount: 11
    },
    {
        id: "preemptive_strike",
        title: "Preemptive Strike",
        author: "antirandomguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/preemptive_strike",
        chapterCount: 3
    },
    {
        id: "pride_and_power",
        title: "Pride And Power",
        author: "Feeling_Glovely",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pride_and_power",
        chapterCount: 10
    },
    {
        id: "primordial_awakening",
        title: "Primordial: Awakening",
        author: "Puzzled-Ad-5413",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/primordial_awakening",
        chapterCount: 22
    },
    {
        id: "prince_of_the_apple_towns",
        title: "Prince Of The Apple Towns",
        author: "del\\_elle\\_0816",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/prince_of_the_apple_towns",
        chapterCount: 7
    },
    {
        id: "the_princess_s_man",
        title: "The Princess's Man",
        author: "Akmedrah",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_princesss_man",
        chapterCount: 36
    },
    {
        id: "the_problems_with_humanity",
        title: "The Problems With Humanity",
        author: "Obsequium_Minaris",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_problems_with_humanity",
        chapterCount: 30
    },
    {
        id: "profiler",
        title: "Profiler",
        author: "Lostfol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/profiler",
        chapterCount: 4
    },
    {
        id: "progenitor",
        title: "Progenitor",
        author: "TeddyBearWriter",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/progenitor",
        chapterCount: 12
    },
    {
        id: "project_dirt",
        title: "Project Dirt",
        author: "Engletroll",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/project_dirt",
        chapterCount: 22
    },
    {
        id: "project_genesis",
        title: "Project Genesis",
        author: "Cultural-Classic-197",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/project_genesis",
        chapterCount: 19
    },
    {
        id: "project_avalon",
        title: "Project Avalon",
        author: "Lost_lamb-19",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/project_avalon",
        chapterCount: 4
    },
    {
        id: "prometheus",
        title: "Prometheus",
        author: "lukeb28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/prometheus",
        chapterCount: 6
    },
    {
        id: "the_prophecy_of_the_end",
        title: "The Prophecy Of The End",
        author: "HFY_Inspired",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_prophecy_of_the_end",
        chapterCount: 44
    },
    {
        id: "the_protected",
        title: "The Protected",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_protected",
        chapterCount: 0
    },
    {
        id: "protectors",
        title: "Protectors",
        author: "gamingwolfie",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/protectors",
        chapterCount: 6
    },
    {
        id: "the_prototype",
        title: "The Prototype",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_prototype",
        chapterCount: 0
    },
    {
        id: "pursuit_predation",
        title: "Pursuit Predation",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pursuit_predation",
        chapterCount: 0
    },
    {
        id: "pyramid_to_the_stars",
        title: "Pyramid to the Stars",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/pyramid_to_the_stars",
        chapterCount: 0
    },
    {
        id: "the_quantum_empress",
        title: "The Quantum Empress",
        author: "NeonQuill42",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_quantum_empress",
        chapterCount: 18
    },
    {
        id: "the_questwright",
        title: "The Questwright",
        author: "AbnormalVAverage",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_questwright",
        chapterCount: 30
    },
    {
        id: "a_quiet_apostasy",
        title: "A Quiet Apostasy",
        author: "QuietVestige",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_quiet_apostasy",
        chapterCount: 10
    },
    {
        id: "a_quiet_man_in_strange_lands",
        title: "A Quiet Man In Strange Lands",
        author: "Some_Guy_Existing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_quiet_man_in_strange_lands",
        chapterCount: 12
    },
    {
        id: "quorum_of_war",
        title: "Quorum Of War",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/quorum_of_war",
        chapterCount: 8
    },
    {
        id: "radio_free_orion",
        title: "Radio Free Orion",
        author: "Saylor_Man",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/radio_free_orion",
        chapterCount: 22
    },
    {
        id: "radiotrophic",
        title: "Radiotrophic",
        author: "Arquimond",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/radiotrophic",
        chapterCount: 18
    },
    {
        id: "ravenverse",
        title: "Ravenverse",
        author: "TheStabbyBrit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ravenverse",
        chapterCount: 3
    },
    {
        id: "realms_of_the_veiled_paths",
        title: "Realms Of The Veiled Paths",
        author: "SolomonHZAbraham",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/realms_of_the_veiled_paths",
        chapterCount: 14
    },
    {
        id: "rebirth_protocol",
        title: "Rebirth Protocol",
        author: "divingintodivinity",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rebirth_protocol",
        chapterCount: 20
    },
    {
        id: "reborn_as_a_fantasy_general",
        title: "Reborn As A Fantasy General",
        author: "CommercialBee6585",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reborn_as_a_fantasy_general",
        chapterCount: 11
    },
    {
        id: "reborn_as_a_goat",
        title: "Reborn As A Goat",
        author: "Legitimate_Ear_1682",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reborn_as_a_goat",
        chapterCount: 15
    },
    {
        id: "reborn_as_a_witch_in_another_world",
        title: "Reborn As A Witch In Another World",
        author: "SharpWatch1014",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/reborn_as_a_witch_in_another_world",
        chapterCount: 11
    },
    {
        id: "rebuilding",
        title: "Rebuilding",
        author: "Xildrax",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rebuilding",
        chapterCount: 13
    },
    {
        id: "reckoning",
        title: "Reckoning",
        author: "VagrantScrub",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reckoning",
        chapterCount: 6
    },
    {
        id: "reclamation",
        title: "Reclamation",
        author: "fadingremnants",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reclamation",
        chapterCount: 3
    },
    {
        id: "a_record_of_the_journey_to_the_capital",
        title: "A Record Of The Journey To The Capital",
        author: "Easy\\_Anxiety\\_4062",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_record_of_the_journey_to_the_capital",
        chapterCount: 6
    },
    {
        id: "the_records_of_enlightenment",
        title: "The Records Of Enlightenment",
        author: "Cola\\_Dad",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_records_of_enlightenment",
        chapterCount: 25
    },
    {
        id: "red_hand",
        title: "Red Hand",
        author: "Grindlebone",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/red_hand",
        chapterCount: 17
    },
    {
        id: "reductionism",
        title: "Reductionism",
        author: "atomic_cheese",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reductionism",
        chapterCount: 4
    },
    {
        id: "the_remnants_of_terra",
        title: "The Remnants Of Terra",
        author: "Huge-Animal-8818",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_remnants_of_terra",
        chapterCount: 9
    },
    {
        id: "remember_geneva",
        title: "Remember Geneva",
        author: "The\\_Vadami",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/remember_geneva",
        chapterCount: 5
    },
    {
        id: "remember_the_revolution",
        title: "Remember the Revolution",
        author: "BeaverFur",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/remember_the_revolution",
        chapterCount: 5
    },
    {
        id: "the_remnant",
        title: "The Remnant",
        author: "MachDhai",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_remnant",
        chapterCount: 3
    },
    {
        id: "remnants_of_the_terran_republic",
        title: "Remnants Of The Terran Republic",
        author: "space_farmer_luke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/remnants_of_the_terran_republic",
        chapterCount: 8
    },
    {
        id: "renewed_interest",
        title: "Renewed Interest",
        author: "endtostart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/renewed_interest",
        chapterCount: 0
    },
    {
        id: "republic_of_sol",
        title: "Republic of Sol",
        author: "ZombieSouffle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/republic_of_sol",
        chapterCount: 3
    },
    {
        id: "re_soldier",
        title: "Re:Soldier",
        author: "Troopa36",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/resoldier",
        chapterCount: 11
    },
    {
        id: "re_soldier_2",
        title: "Re:Soldier",
        author: "resoldier12",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/resoldier_resoldier12",
        chapterCount: 11
    },
    {
        id: "resilience",
        title: "Resilience",
        author: "WadlingPangolin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/resilience",
        chapterCount: 12
    },
    {
        id: "resurgence",
        title: "Resurgence",
        author: "PrussianJoe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/resurgence",
        chapterCount: 3
    },
    {
        id: "the_return",
        title: "The Return",
        author: "alejeron",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_return",
        chapterCount: 11
    },
    {
        id: "reunion",
        title: "Reunion",
        author: "TOSCAA",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reunion",
        chapterCount: 2
    },
    {
        id: "revenge",
        title: "Revenge",
        author: "Muffer-Nl",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/revenge",
        chapterCount: 0
    },
    {
        id: "reversekai_d",
        title: "Reversekai'd",
        author: "ChampionshipFine5258",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/reversekaid",
        chapterCount: 19
    },
    {
        id: "ribcage_serenades",
        title: "Ribcage Serenades",
        author: "PattableGreeb",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/ribcage_serenades",
        chapterCount: 7
    },
    {
        id: "richard_quickdraw_mccallister_a_eulogy",
        title: "Richard \"Quickdraw\" Mccallister: A Eulogy",
        author: "TAHaywood",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/richard_quickdraw_mccallister_a_eulogy",
        chapterCount: 12
    },
    {
        id: "a_right",
        title: "A Right",
        author: "walid_shoebats_dick",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_right",
        chapterCount: 2
    },
    {
        id: "rise_of_an_empire",
        title: "Rise Of An Empire",
        author: "TrueWiner5047",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rise_of_an_empire",
        chapterCount: 6
    },
    {
        id: "rise_of_earth",
        title: "Rise Of Earth",
        author: "Random_Trinidadian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rise_of_earth",
        chapterCount: 10
    },
    {
        id: "the_rise_of_the_core",
        title: "The Rise Of The Core",
        author: "shadowtycho",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_rise_of_the_core",
        chapterCount: 3
    },
    {
        id: "rise_of_the_infernal_paladin",
        title: "Rise Of The Infernal Paladin",
        author: "EmrysAmbrosius",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/rise_of_the_infernal_paladin",
        chapterCount: 5
    },
    {
        id: "a_robotic_overmind_for_a_dungeon",
        title: "A Robotic Overmind For A Dungeon",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_robotic_overmind_for_a_dungeon",
        chapterCount: 0
    },
    {
        id: "rock_paper_scissors",
        title: "Rock, Paper, Scissors",
        author: "EchoingCascade",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rock_paper_scissors",
        chapterCount: 9
    },
    {
        id: "the_roles_reversed",
        title: "The Roles Reversed",
        author: "TaleGateChapters",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_roles_reversed",
        chapterCount: 27
    },
    {
        id: "rough_relationships",
        title: "Rough Relationships",
        author: "HFYThrowaway",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rough_relationships",
        chapterCount: 6
    },
    {
        id: "the_royal_system",
        title: "The Royal System",
        author: "NiallStephens",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_royal_system",
        chapterCount: 16
    },
    {
        id: "rules_are_guidelines",
        title: "Rules are Guidelines",
        author: "Turul___Madar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rules_are_guidelines",
        chapterCount: 2
    },
    {
        id: "rules_of_magical_engagement",
        title: "Rules Of Magical Engagement",
        author: "keptin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/rules_of_magical_engagement",
        chapterCount: 12
    },
    {
        id: "the_rumors_that_still_live",
        title: "The Rumors That Still Live",
        author: "CornSquashBeans",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_rumors_that_still_live",
        chapterCount: 5
    },
    {
        id: "on_the_run",
        title: "On The Run",
        author: "Professional_Hope598",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/on_the_run",
        chapterCount: 7
    },
    {
        id: "s_41234_dw_4_or_trust_me_people_it_could_be_worse",
        title: "[S-41234 (Dw-4)] Or Trust Me People It Could Be Worse",
        author: "Aeogeus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/s41234_dw4_or_trust_me_people_it_could_be_worse",
        chapterCount: 25
    },
    {
        id: "sailing_ships_of_steam",
        title: "Sailing Ships of Steam",
        author: "Reaperdude97",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sailing_ships_of_steam",
        chapterCount: 3
    },
    {
        id: "samiya_of_the_wandering_flesh",
        title: "Samiya Of The Wandering Flesh",
        author: "countingfoxes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/samiya_of_the_wandering_flesh",
        chapterCount: 21
    },
    {
        id: "saved_by_the_bel_air",
        title: "Saved By The Bel Air",
        author: "coldfireknight",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/saved_by_the_bel_air",
        chapterCount: 15
    },
    {
        id: "saving_the_lich_queen",
        title: "Saving The Lich Queen",
        author: "matizuwinsatlife",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/saving_the_lich_queen",
        chapterCount: 24
    },
    {
        id: "scarlette_dangerfield",
        title: "Scarlette Dangerfield",
        author: "crazy-ann559",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/scarlette_dangerfield",
        chapterCount: 7
    },
    {
        id: "scent_bonded",
        title: "Scent Bonded",
        author: "TheGruamach",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/scent_bonded",
        chapterCount: 10
    },
    {
        id: "the_scroll_keeper",
        title: "The Scroll Keeper",
        author: "Fit_Professional4936",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_scroll_keeper",
        chapterCount: 11
    },
    {
        id: "searching_for_common_threads",
        title: "Searching For Common Threads",
        author: "kcr141",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/searching_for_common_threads",
        chapterCount: 13
    },
    {
        id: "seca_prime",
        title: "Seca Prime",
        author: "Proof\\_Cheesecake3925",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/seca_prime",
        chapterCount: 10
    },
    {
        id: "second_galactic_war",
        title: "Second Galactic War",
        author: "Number\\_One\\_American",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/second_galactic_war",
        chapterCount: 7
    },
    {
        id: "the_second_stranger",
        title: "The Second Stranger",
        author: "Sadsquatch4",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_second_stranger",
        chapterCount: 17
    },
    {
        id: "sectorverse",
        title: "Sectorverse",
        author: "Lvl25-human-nerd",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sectorverse",
        chapterCount: 6
    },
    {
        id: "security_robot_in_fantasy",
        title: "Security Robot In Fantasy",
        author: "xotos750",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/security_robot_in_fantasy",
        chapterCount: 9
    },
    {
        id: "seeds_of_magic_hollow_home",
        title: "Seeds Of Magic: Hollow Home",
        author: "MyNameMeansBentNose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/seeds_of_magic_hollow_home",
        chapterCount: 40
    },
    {
        id: "selections_from_the_grand_bazaar",
        title: "Selections From The Grand Bazaar",
        author: "ConsequenceBorn4895",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/selections_from_the_grand_bazaar",
        chapterCount: 21
    },
    {
        id: "selling_out",
        title: "Selling Out",
        author: "Ljegulja",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/selling_out",
        chapterCount: 1
    },
    {
        id: "the_senator",
        title: "The Senator",
        author: "matthosofseaworth",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_senator",
        chapterCount: 10
    },
    {
        id: "send_a_monster",
        title: "Send A Monster",
        author: "The\\_First\\_Viking",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/send_a_monster",
        chapterCount: 24
    },
    {
        id: "sentinel",
        title: "Sentinel",
        author: "Shayaan5612",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sentinel",
        chapterCount: 44
    },
    {
        id: "separate_paths",
        title: "Separate Paths",
        author: "muigleb",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/separate_paths",
        chapterCount: 17
    },
    {
        id: "september",
        title: "September",
        author: "Erichartmann352",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/september",
        chapterCount: 15
    },
    {
        id: "seriously_dude",
        title: "Seriously Dude",
        author: "jackleraid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/seriously_dude",
        chapterCount: 10
    },
    {
        id: "seven_lies_of_killer_bard",
        title: "Seven Lies Of Killer Bard",
        author: "Great_Ad_5561",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/seven_lies_of_killer_bard",
        chapterCount: 10
    },
    {
        id: "seven_robots_later",
        title: "Seven Robots Later",
        author: "7RobotsLater",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/seven_robots_later",
        chapterCount: 19
    },
    {
        id: "sexy_pirate",
        title: "Sexy pirate",
        author: "wololololow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sexy_pirate",
        chapterCount: 10
    },
    {
        id: "shackled_destiny",
        title: "Shackled Destiny",
        author: "AidenMarquis",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/shackled_destiny",
        chapterCount: 30
    },
    {
        id: "shackled_exalted",
        title: "Shackled Exalted",
        author: "SpyRole\\_",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/shackled_exalted",
        chapterCount: 13
    },
    {
        id: "the_shadow",
        title: "The Shadow",
        author: "PropRatActual",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_shadow",
        chapterCount: 5
    },
    {
        id: "the_shadows_speak",
        title: "The Shadows Speak",
        author: "Dagaz9565",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_shadows_speak",
        chapterCount: 12
    },
    {
        id: "shadow_ascendant",
        title: "Shadow Ascendant",
        author: "Educational\\_Sail6884",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shadow_ascendant",
        chapterCount: 8
    },
    {
        id: "shaking_red_hands",
        title: "Shaking Red Hands",
        author: "TriZeven",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shaking_red_hands",
        chapterCount: 11
    },
    {
        id: "shaman_in_space",
        title: "Shaman In Space",
        author: "IZXD",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shaman_in_space",
        chapterCount: 12
    },
    {
        id: "the_shape_of_resolve",
        title: "The Shape Of Resolve",
        author: "tbuljevic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_shape_of_resolve",
        chapterCount: 8
    },
    {
        id: "shaper_of_metal",
        title: "Shaper Of Metal",
        author: "RainHarlow",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/shaper_of_metal",
        chapterCount: 20
    },
    {
        id: "sharper_than_a_serpent_s_tooth",
        title: "Sharper Than A Serpent's Tooth",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sharper_than_a_serpents_tooth",
        chapterCount: 0
    },
    {
        id: "shattered_darkness",
        title: "Shattered Darkness",
        author: "KoolCatz-Creations",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shattered_darkness",
        chapterCount: 11
    },
    {
        id: "shattered_dawn",
        title: "Shattered Dawn",
        author: "williamreigns",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/shattered_dawn",
        chapterCount: 20
    },
    {
        id: "shattered_terra",
        title: "Shattered Terra",
        author: "DioriteIgneous",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shattered_terra",
        chapterCount: 5
    },
    {
        id: "she_took_what",
        title: "She Took What?",
        author: "KipperBeanGrower",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/she_took_what",
        chapterCount: 172
    },
    {
        id: "ship_repair_facility",
        title: "Ship Repair Facility",
        author: "Goldenpity",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ship_repair_facility",
        chapterCount: 6
    },
    {
        id: "the_ships_cat",
        title: "The Ships Cat",
        author: "mikeromeokilo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ships_cat",
        chapterCount: 18
    },
    {
        id: "shipping_mishaps",
        title: "Shipping Mishaps",
        author: "Vast-Listen1457",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/shipping_mishaps",
        chapterCount: 11
    },
    {
        id: "sierna",
        title: "Sierna",
        author: "Crimson\\_Knight45",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/sierna",
        chapterCount: 9
    },
    {
        id: "sierra_six",
        title: "Sierra Six",
        author: "TargetMaleficent2114",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/sierra_six",
        chapterCount: 9
    },
    {
        id: "the_sigma_sector_bugle",
        title: "The Sigma Sector Bugle",
        author: "HenryFordYork",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sigma_sector_bugle",
        chapterCount: 0
    },
    {
        id: "signals_from_the_deep",
        title: "Signals From The Deep",
        author: "BortoRico",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/signals_from_the_deep",
        chapterCount: 31
    },
    {
        id: "the_silent_drop",
        title: "The Silent Drop",
        author: "thewiggins",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_silent_drop",
        chapterCount: 0
    },
    {
        id: "silentverse",
        title: "Silentverse",
        author: "NoBarracuda2587",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/silentverse",
        chapterCount: 14
    },
    {
        id: "the_silicon_theogony",
        title: "The Silicon Theogony",
        author: "Sea_Albatross7243",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_silicon_theogony",
        chapterCount: 19
    },
    {
        id: "simple_man",
        title: "Simple Man",
        author: "madp1atypus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/simple_man",
        chapterCount: 0
    },
    {
        id: "sin_city",
        title: "Sin City",
        author: "Letsseeifthisworks_2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sin_city",
        chapterCount: 6
    },
    {
        id: "a_single_ideal",
        title: "A Single Ideal",
        author: "Foreign-Affect7871",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_single_ideal",
        chapterCount: 3
    },
    {
        id: "the_singularity",
        title: "The Singularity",
        author: "CurtDoironPublishing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_singularity",
        chapterCount: 26
    },
    {
        id: "sins_of_an_interstellar_species",
        title: "Sins Of An Interstellar Species",
        author: "Traditional_Soup9579",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sins_of_an_interstellar_species",
        chapterCount: 21
    },
    {
        id: "sit_and_listen",
        title: "Sit and Listen",
        author: "feydars",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sit_and_listen",
        chapterCount: 3
    },
    {
        id: "skulltaker",
        title: "Skulltaker",
        author: "SgtSkulltaker",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/skulltaker",
        chapterCount: 29
    },
    {
        id: "sleek_zeke_space_racer",
        title: "Sleek Zeke: Space Racer",
        author: "Poppedeyes",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sleek_zeke_space_racer",
        chapterCount: 24
    },
    {
        id: "small_exploits",
        title: "Small Exploits",
        author: "Engr00",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/small_exploits",
        chapterCount: 0
    },
    {
        id: "snthors_story",
        title: "Snthors' Story",
        author: "Yrwestilhere_05",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/snthors_story",
        chapterCount: 4
    },
    {
        id: "so_others_may_live",
        title: "So Others May Live",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/so_others_may_live",
        chapterCount: 0
    },
    {
        id: "so_you_want_to_own_a_human",
        title: "So You Want To Own A Human",
        author: "terran\\_mikkus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/so_you_want_to_own_a_human",
        chapterCount: 9
    },
    {
        id: "so_we_aren_t_alone",
        title: "So... We Aren't Alone?",
        author: "kem81",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/so_we_arent_alone",
        chapterCount: 12
    },
    {
        id: "the_soldiers_core",
        title: "The Soldiers Core",
        author: "CopperKast",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_soldiers_core",
        chapterCount: 16
    },
    {
        id: "soldiers_of_sol",
        title: "Soldiers of Sol",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soldiers_of_sol",
        chapterCount: 0
    },
    {
        id: "solitary_awake",
        title: "Solitary Awake",
        author: "TheCblack",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/solitary_awake",
        chapterCount: 15
    },
    {
        id: "something_begins",
        title: "Something Begins",
        author: "basement_crusader",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/something_begins",
        chapterCount: 2
    },
    {
        id: "a_songbird_s_name",
        title: "A Songbird's Name",
        author: "Fabulous-Tax2445",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_songbirds_name",
        chapterCount: 5
    },
    {
        id: "songs",
        title: "Songs",
        author: "SomeoneForgetable",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/songs",
        chapterCount: 3
    },
    {
        id: "the_sorceress_s_soul",
        title: "The Sorceress's Soul",
        author: "Few_Fee3331",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sorceresss_soul",
        chapterCount: 22
    },
    {
        id: "the_sorcyber",
        title: "The SorCyber",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_sorcyber",
        chapterCount: 0
    },
    {
        id: "soul_of_a_human",
        title: "Soul Of A Human",
        author: "Hot-West9928",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soul_of_a_human",
        chapterCount: 30
    },
    {
        id: "soulbound",
        title: "Soulbound",
        author: "AJNadir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/soulbound",
        chapterCount: 10
    },
    {
        id: "souls_and_coins",
        title: "Souls And Coins",
        author: "humanoidtiphoon",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/souls_and_coins",
        chapterCount: 14
    },
    {
        id: "the_sovereign_s_toll",
        title: "The Sovereign's Toll",
        author: "Jon\\_Stonekey",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_sovereigns_toll",
        chapterCount: 45
    },
    {
        id: "space_cargo_guns_and_more",
        title: "Space, Cargo, Guns And More",
        author: "britasian189",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/space_cargo_guns_and_more",
        chapterCount: 5
    },
    {
        id: "space_the_first_frontier",
        title: "Space: The First Frontier",
        author: "Starbuck_Mischief",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/space_the_first_frontier",
        chapterCount: 0
    },
    {
        id: "the_space_monster",
        title: "The Space Monster",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_space_monster",
        chapterCount: 0
    },
    {
        id: "the_space_race",
        title: "The Space Race",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_space_race",
        chapterCount: 0
    },
    {
        id: "the_spacer_s_guide_to_caring_for_your_pet_human",
        title: "The Spacer's Guide To Caring For Your Pet Human",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_spacers_guide_to_caring_for_your_pet_human",
        chapterCount: 0
    },
    {
        id: "spacial_mishaps",
        title: "Spacial Mishaps",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spacial_mishaps",
        chapterCount: 0
    },
    {
        id: "spark_of_the_ancient",
        title: "Spark Of The Ancient",
        author: "ProgramPatient1319",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/spark_of_the_ancient",
        chapterCount: 58
    },
    {
        id: "spatial_magic_is_overpowered",
        title: "Spatial Magic Is Overpowered",
        author: "gregovin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spatial_magic_is_overpowered",
        chapterCount: 30
    },
    {
        id: "special_delivery",
        title: "Special Delivery",
        author: "GIJoeVibin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/special_delivery",
        chapterCount: 2
    },
    {
        id: "special_operator_in_another_world",
        title: "Special Operator In Another World",
        author: "DobryPolaczek",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/special_operator_in_another_world",
        chapterCount: 15
    },
    {
        id: "speciation",
        title: "Speciation",
        author: "andrewtater",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/speciation",
        chapterCount: 5
    },
    {
        id: "the_species_that_refused_to_die",
        title: "The Species that refused to die",
        author: "nogoodusernamesleft8",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_species_that_refused_to_die",
        chapterCount: 0
    },
    {
        id: "spellslinger",
        title: "Spellslinger",
        author: "RegalLegalEagle",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spellslinger",
        chapterCount: 0
    },
    {
        id: "spiritbound",
        title: "Spiritbound",
        author: "Substantial\\_Cup\\_7056",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/spiritbound",
        chapterCount: 13
    },
    {
        id: "spqr",
        title: "SPQR",
        author: "KanzeonRiver",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/spqr",
        chapterCount: 5
    },
    {
        id: "stairsekai",
        title: "StairSekai",
        author: "8237th-whitt",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stairsekai",
        chapterCount: 19
    },
    {
        id: "stalker",
        title: "Stalker",
        author: "TheTrustyBandit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stalker",
        chapterCount: 27
    },
    {
        id: "standing_against_giants",
        title: "Standing Against Giants",
        author: "Kralizec\\_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/standing_against_giants",
        chapterCount: 16
    },
    {
        id: "star_truck",
        title: "Star Truck",
        author: "CalmFeature2965",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/star_truck",
        chapterCount: 11
    },
    {
        id: "the_stars_in_realignment",
        title: "The Stars In Realignment",
        author: "The\\_Lucky\\_7",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_stars_in_realignment",
        chapterCount: 22
    },
    {
        id: "starbound_vampire",
        title: "Starbound Vampire",
        author: "darkrounin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/starbound_vampire",
        chapterCount: 45
    },
    {
        id: "starchaser_beyond",
        title: "Starchaser: Beyond",
        author: "Plus-Insect6864",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/starchaser_beyond",
        chapterCount: 8
    },
    {
        id: "stardivers",
        title: "Stardivers",
        author: "Kubrick_Fan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stardivers",
        chapterCount: 0
    },
    {
        id: "stargazer",
        title: "Stargazer",
        author: "stargazer_hfy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stargazer",
        chapterCount: 37
    },
    {
        id: "station_ship",
        title: "Station Ship",
        author: "Street-Accountant796",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/station_ship",
        chapterCount: 6
    },
    {
        id: "status_dependent_spouse_human",
        title: "Status: Dependent Spouse-Human",
        author: "KANSAN\\_IN\\_BANGKOK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/status_dependent_spousehuman",
        chapterCount: 12
    },
    {
        id: "the_stone_gods",
        title: "The Stone Gods",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_stone_gods",
        chapterCount: 0
    },
    {
        id: "stop_drop_and_roll",
        title: "Stop, Drop, and Roll",
        author: "MalaclypseTheEldar",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stop_drop_and_roll",
        chapterCount: 4
    },
    {
        id: "stories_of_the_apex",
        title: "Stories Of The Apex",
        author: "Salishaz",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stories_of_the_apex",
        chapterCount: 28
    },
    {
        id: "the_storm",
        title: "The Storm",
        author: "smithbird",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_storm",
        chapterCount: 18
    },
    {
        id: "the_storm_and_the_blade",
        title: "The Storm And The Blade",
        author: "LRKnight_writing",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_storm_and_the_blade",
        chapterCount: 5
    },
    {
        id: "the_storm_runner",
        title: "The Storm Runner",
        author: "ThreeDucksInAManSuit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_storm_runner",
        chapterCount: 4
    },
    {
        id: "the_stowaway",
        title: "The Stowaway",
        author: "Dragondancer123",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_stowaway_dragondancer123",
        chapterCount: 9
    },
    {
        id: "the_stowaway_2",
        title: "The Stowaway",
        author: "Hanson_the_third",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_stowaway",
        chapterCount: 9
    },
    {
        id: "the_strength_of_humanity",
        title: "The Strength of Humanity",
        author: "Someguynamedted",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_strength_of_humanity",
        chapterCount: 0
    },
    {
        id: "stranded_3",
        title: "Stranded",
        author: "Cobalt1027",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/stranded_cobalt1027",
        chapterCount: 10
    },
    {
        id: "strange_bedfellows",
        title: "Strange Bedfellows",
        author: "RetroInferno",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/strange_bedfellows",
        chapterCount: 9
    },
    {
        id: "strange_creature",
        title: "Strange Creature",
        author: "DiscombobulatedPay51",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/strange_creature",
        chapterCount: 11
    },
    {
        id: "a_strange_offer",
        title: "A Strange Offer",
        author: "HarambesBlunt",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_strange_offer",
        chapterCount: 11
    },
    {
        id: "strangers_among_us",
        title: "Strangers Among Us",
        author: "ThatSoftware4946",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/strangers_among_us",
        chapterCount: 11
    },
    {
        id: "a_strangers_ship",
        title: "A Strangers Ship",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_strangers_ship",
        chapterCount: 10
    },
    {
        id: "strategic_buffer_zone",
        title: "Strategic Buffer Zone",
        author: "LeifRoberts",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/strategic_buffer_zone",
        chapterCount: 2
    },
    {
        id: "strays",
        title: "Strays",
        author: "ronlynne",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/strays",
        chapterCount: 11
    },
    {
        id: "strike_from_shadow",
        title: "Strike From Shadow",
        author: "The-Arcalian",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/strike_from_shadow",
        chapterCount: 40
    },
    {
        id: "the_strongest_fencer_doesn_t_use_skills",
        title: "The Strongest Fencer Doesn't Use Skills!",
        author: "DropShotEpee",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_strongest_fencer_doesnt_use_skills",
        chapterCount: 28
    },
    {
        id: "the_struggle",
        title: "The Struggle",
        author: "awsomesawsome",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_struggle",
        chapterCount: 4
    },
    {
        id: "a_study_of_sol_and_those_who_dwell_within",
        title: "A Study Of Sol And Those Who Dwell Within",
        author: "AhrKyv",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/a_study_of_sol_and_those_who_dwell_within",
        chapterCount: 6
    },
    {
        id: "summoned_to_the_future",
        title: "Summoned To The Future",
        author: "ownzone817",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/summoned_to_the_future",
        chapterCount: 7
    },
    {
        id: "sunkillers",
        title: "Sunkillers",
        author: "apophis-pegasus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sunkillers",
        chapterCount: 3
    },
    {
        id: "supercell",
        title: "Supercell",
        author: "Traditional\\_wolf\\_007",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/supercell",
        chapterCount: 8
    },
    {
        id: "superluminal",
        title: "Superluminal",
        author: "NethanielShade",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/superluminal",
        chapterCount: 3
    },
    {
        id: "supply_and_demand",
        title: "Supply And Demand",
        author: "HarvesterFullCrumb",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/supply_and_demand",
        chapterCount: 12
    },
    {
        id: "support_your_local_deathworld_p_i",
        title: "Support Your Local Deathworld P.I.",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/support_your_local_deathworld_pi",
        chapterCount: 0
    },
    {
        id: "survey_mission",
        title: "Survey Mission",
        author: "Ekaros",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/survey_mission",
        chapterCount: 2
    },
    {
        id: "survivor_directive_zero",
        title: "Survivor: Directive Zero",
        author: "GorMartsen",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/survivor_directive_zero",
        chapterCount: 36
    },
    {
        id: "the_swarm_2",
        title: "The Swarm",
        author: "Feeling_Pea5770",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_swarm_feeling_pea5770",
        chapterCount: 143
    },
    {
        id: "sword_and_shield_2",
        title: "Sword and Shield",
        author: "Kosminhotep",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/sword_and_shield",
        chapterCount: 2
    },
    {
        id: "swordswoman_and_the_super_soldier",
        title: "Swordswoman and The Super Soldier",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/swordswoman_and_the_super_soldier",
        chapterCount: 0
    },
    {
        id: "symbiosis",
        title: "Symbiosis",
        author: "scholcombe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/symbiosis",
        chapterCount: 5
    },
    {
        id: "symbiotes",
        title: "SYMBIOTES",
        author: "Fornicious_Fogbottom",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/symbiotes",
        chapterCount: 1
    },
    {
        id: "symbiotic_parasite",
        title: "Symbiotic Parasite",
        author: "bold_cheesecake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/symbiotic_parasite",
        chapterCount: 4
    },
    {
        id: "synaptic_rank",
        title: "Synaptic Rank",
        author: "Riley\\_Kita",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/synaptic_rank",
        chapterCount: 15
    },
    {
        id: "synthetic_wings",
        title: "Synthetic Wings",
        author: "StoryTaleBooks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/synthetic_wings",
        chapterCount: 10
    },
    {
        id: "syzygy",
        title: "Syzygy",
        author: "OfficialLeeHadan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/syzygy",
        chapterCount: 10
    },
    {
        id: "the_tagata_fetu",
        title: "The Tagata Fetu",
        author: "Letos_prophet",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_tagata_fetu",
        chapterCount: 5
    },
    {
        id: "takat",
        title: "TAKAT",
        author: "grierks",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/takat",
        chapterCount: 3
    },
    {
        id: "take_back_the_sky",
        title: "Take Back The Sky",
        author: "lukeb28",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/take_back_the_sky",
        chapterCount: 0
    },
    {
        id: "tale_of_the_heavens",
        title: "Tale Of The Heavens",
        author: "Sea-Statement4750",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/tale_of_the_heavens",
        chapterCount: 67
    },
    {
        id: "tales_from_a_charcoal_moon",
        title: "Tales From A Charcoal Moon",
        author: "TheDesperateFox",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/tales_from_a_charcoal_moon",
        chapterCount: 13
    },
    {
        id: "tales_from_space_tech_support_2",
        title: "Tales From Space Tech Support",
        author: "bontrose",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_space_tech_support_bontrose",
        chapterCount: 10
    },
    {
        id: "tales_from_station_support",
        title: "Tales From Station Support",
        author: "Capt_Blackmoore",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_station_support",
        chapterCount: 2
    },
    {
        id: "tales_from_the_dead_pelican",
        title: "Tales From the Dead Pelican",
        author: "slice_of_pi",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_the_dead_pelican",
        chapterCount: 2
    },
    {
        id: "tales_from_the_edict",
        title: "Tales From The Edict",
        author: "Edict2040",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_the_edict",
        chapterCount: 10
    },
    {
        id: "tales_from_the_grand_archive",
        title: "Tales From The Grand Archive",
        author: "scribble_sun",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_the_grand_archive",
        chapterCount: 1
    },
    {
        id: "tales_from_the_wasteland",
        title: "Tales From the Wasteland",
        author: "iridael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_from_the_wasteland",
        chapterCount: 10
    },
    {
        id: "tales_of_a_mercenary",
        title: "Tales Of A Mercenary",
        author: "ChadManning1989",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_a_mercenary",
        chapterCount: 50
    },
    {
        id: "tales_of_slayer_squadron",
        title: "Tales Of Slayer Squadron",
        author: "Gwunders",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_slayer_squadron",
        chapterCount: 5
    },
    {
        id: "tales_of_station_1bei_962",
        title: "Tales Of Station 1BEI-962",
        author: "squigglestorystudios",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/station_1bei-962",
        chapterCount: 3
    },
    {
        id: "tales_of_the_lands_of_dreaming",
        title: "Tales Of The Lands Of Dreaming",
        author: "Burden-the-Quester",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tales_of_the_lands_of_dreaming",
        chapterCount: 13
    },
    {
        id: "tallah",
        title: "Tallah",
        author: "C-M-Antal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tallah",
        chapterCount: 19
    },
    {
        id: "tech_scavengers",
        title: "Tech Scavengers",
        author: "RootlessExplorer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tech_scavengers",
        chapterCount: 47
    },
    {
        id: "technically_sentient",
        title: "\"Technically\" Sentient",
        author: "Tinyprancinghorse",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/technically_sentient",
        chapterCount: 20
    },
    {
        id: "terminarch",
        title: "Terminarch",
        author: "Erichartmann352",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terminarch",
        chapterCount: 6
    },
    {
        id: "terms_and_conditions",
        title: "Terms and Conditions",
        author: "Avemetatarsalia",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terms_and_conditions",
        chapterCount: 2
    },
    {
        id: "terran_all_the_same",
        title: "Terran All The Same",
        author: "slaglicked",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terran_all_the_same",
        chapterCount: 2
    },
    {
        id: "the_terran_dominion",
        title: "The Terran Dominion",
        author: "Ball34s",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_terran_dominion",
        chapterCount: 21
    },
    {
        id: "terran_federation_universe",
        title: "Terran Federation Universe",
        author: "Jochemjong",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/terran_federation_universe",
        chapterCount: 6
    },
    {
        id: "terran_history",
        title: "Terran History",
        author: "icefire9",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terran_history",
        chapterCount: 12
    },
    {
        id: "terran_insurrection",
        title: "Terran Insurrection",
        author: "RetroInferno",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terran_insurrection",
        chapterCount: 31
    },
    {
        id: "terror_tide",
        title: "Terror-tide",
        author: "AddiBlake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terrortide",
        chapterCount: 12
    },
    {
        id: "terrorist_attack",
        title: "Terrorist Attack",
        author: "EvgeniyMart",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/terrorist_attack",
        chapterCount: 7
    },
    {
        id: "tev_tricard",
        title: "TEV Tricard",
        author: "Zephylandantus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tev_tricard",
        chapterCount: 6
    },
    {
        id: "thalasson",
        title: "Thalasson",
        author: "TeddyBearWriter",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/thalasson",
        chapterCount: 5
    },
    {
        id: "that_beautiful_terrible_day",
        title: "That beautiful, terrible day",
        author: "asimplebrowncoat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/that_beautiful__terrible_day",
        chapterCount: 2
    },
    {
        id: "that_thing_it_s_a_big_partner",
        title: "That Thing It's A Big Partner!",
        author: "ronaudii222",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/that_thing_its_a_big_partner",
        chapterCount: 13
    },
    {
        id: "that_time_i_was_isekaied_with_an_army",
        title: "That Time I Was Isekaied With An Army",
        author: "Due\\_Bodybuilder\\_1621",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/that_time_i_was_isekaied_with_an_army",
        chapterCount: 13
    },
    {
        id: "that_which_devours",
        title: "That Which Devours",
        author: "jerpatch",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/that_which_devours",
        chapterCount: 124
    },
    {
        id: "their_finest_hour",
        title: "Their Finest Hour",
        author: "GIJoeVibin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/their_finest_hour",
        chapterCount: 10
    },
    {
        id: "the_theory_of_guaranteed_bilateral_annihilation",
        title: "The Theory Of Guaranteed Bilateral Annihilation",
        author: "ThePinkWombat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_theory_of_guaranteed_bilateral_annihilation",
        chapterCount: 4
    },
    {
        id: "these_reincarnators_are_sus",
        title: "These Reincarnators Are Sus!",
        author: "Frequent\\_Repeat\\_6759",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/these_reincarnators_are_sus",
        chapterCount: 59
    },
    {
        id: "they_are_smol",
        title: "They Are Smol",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_are_smol",
        chapterCount: 0
    },
    {
        id: "they_are_war",
        title: "They Are War",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_are_war",
        chapterCount: 0
    },
    {
        id: "they_gave_him_a_countdown_he_gave_them_hell",
        title: "They Gave Him A Countdown. He Gave Them Hell",
        author: "Lightt_x",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_gave_him_a_countdown_he_gave_them_hell",
        chapterCount: 28
    },
    {
        id: "they_hit_without_warning",
        title: "They Hit Without Warning",
        author: "Pure-Shine6001",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_hit_without_warning",
        chapterCount: 12
    },
    {
        id: "they_lurk_in_the_dark",
        title: "They lurk in the dark",
        author: "pairt_2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/they_lurk_in_the_dark",
        chapterCount: 4
    },
    {
        id: "they_won_t_stop_hunting_us",
        title: "They Won't Stop Hunting Us",
        author: "OGGruntComm",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/they_wont_stop_hunting_us",
        chapterCount: 12
    },
    {
        id: "the_things_they_left_behind",
        title: "The Things They Left Behind",
        author: "Xeno-Hollow",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_things_they_left_behind",
        chapterCount: 12
    },
    {
        id: "think_fast_shoot_first",
        title: "Think Fast, Shoot First",
        author: "Shit_Buller",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/think_fast_shoot_first",
        chapterCount: 1
    },
    {
        id: "the_thirty_seventh_path",
        title: "The Thirty-Seventh Path",
        author: "No\\_Reception\\_4075",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_thirtyseventh_path",
        chapterCount: 6
    },
    {
        id: "this_is_how_the_world_ends",
        title: "This is How the World Ends",
        author: "PandaDisguise",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/this_is_how_the_world_ends",
        chapterCount: 3
    },
    {
        id: "this_is_how_the_world_ends_2",
        title: "This Is How The World Ends",
        author: "Gwunders",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/this_is_how_the_world_ends_gwunders",
        chapterCount: 11
    },
    {
        id: "this_is_not_a_dungeon",
        title: "This Is (Not) A Dungeon",
        author: "WaveOfWire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/this_is_not_a_dungeon",
        chapterCount: 11
    },
    {
        id: "thorne_s_tales",
        title: "Thorne's Tales",
        author: "ill\\_B\\_In\\_MyBunk",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/thornes_tales",
        chapterCount: 13
    },
    {
        id: "three_defenders",
        title: "Three Defenders",
        author: "horazone",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/three_defenders",
        chapterCount: 4
    },
    {
        id: "three_fleets",
        title: "Three Fleets",
        author: "AltCipher",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/three_fleets",
        chapterCount: 15
    },
    {
        id: "the_tide_of_revolution",
        title: "The Tide Of Revolution",
        author: "MWMN19",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_tide_of_revolution",
        chapterCount: 3
    },
    {
        id: "tiger",
        title: "Tiger",
        author: "TheCJK",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tiger",
        chapterCount: 11
    },
    {
        id: "tik_tok",
        title: "Tik Tok",
        author: "Writteninsanity",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tiktok",
        chapterCount: 19
    },
    {
        id: "time_and_time_again",
        title: "Time, And Time Again",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/time_and_time_again",
        chapterCount: 0
    },
    {
        id: "time_looped",
        title: "Time Looped",
        author: "LiseEclaire",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/time_looped",
        chapterCount: 183
    },
    {
        id: "time_machine_hijinks",
        title: "Time Machine Hijinks",
        author: "CarolOfTheHells",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/time_machine_hijinks",
        chapterCount: 2
    },
    {
        id: "a_tinker_s_damn",
        title: "A Tinker's Damn",
        author: "Hewholooksskyward",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_tinkers_damn",
        chapterCount: 0
    },
    {
        id: "tiny_battlefield",
        title: "Tiny Battlefield",
        author: "BlantantlyAccidental",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tiny_battlefield",
        chapterCount: 8
    },
    {
        id: "titanomachy",
        title: "Titanomachy",
        author: "SolomonHZAbraham",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/titanomachy",
        chapterCount: 13
    },
    {
        id: "to_the_stars",
        title: "To the Stars",
        author: "cazz14159",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/to_the_stars",
        chapterCount: 4
    },
    {
        id: "tome_of_mogue",
        title: "Tome Of Mogue",
        author: "pandrpachf3",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tome_of_mogue",
        chapterCount: 6
    },
    {
        id: "tomebound",
        title: "Tomebound",
        author: "justinwrite2",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tomebound",
        chapterCount: 17
    },
    {
        id: "top_lasgun_2",
        title: "Top Lasgun",
        author: "CompassWithHat",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/top_lasgun",
        chapterCount: 11
    },
    {
        id: "torth",
        title: "Torth",
        author: "AbbyBabble",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/torth",
        chapterCount: 5
    },
    {
        id: "trainwreck",
        title: "Trainwreck",
        author: "Aspiring-Owner",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trainwreck",
        chapterCount: 4
    },
    {
        id: "transcendence_2",
        title: "Transcendence",
        author: "fadingremnants",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trancendence",
        chapterCount: 2
    },
    {
        id: "transience",
        title: "Transience",
        author: "TsumiHokiro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/transience",
        chapterCount: 11
    },
    {
        id: "transliterated",
        title: "Transliterated",
        author: "perp\\_mot",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/transliterated",
        chapterCount: 15
    },
    {
        id: "trash",
        title: "TRASH",
        author: "Spookyspackles",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trash",
        chapterCount: 11
    },
    {
        id: "trauma_centre",
        title: "Trauma Centre",
        author: "DeathCondition",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trauma_centre",
        chapterCount: 12
    },
    {
        id: "the_traveler",
        title: "The Traveler",
        author: "Haenir",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_traveler",
        chapterCount: 3
    },
    {
        id: "the_travels_of_a_galactic_cowboy",
        title: "The Travels Of A Galactic Cowboy",
        author: "TheCurserHasntMoved",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_travels_of_a_galactic_cowboy",
        chapterCount: 20
    },
    {
        id: "trial_of_the_alchemist",
        title: "Trial Of The Alchemist",
        author: "Dremen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trial_of_the_alchemist",
        chapterCount: 28
    },
    {
        id: "trouble_on_tara",
        title: "Trouble On Tara",
        author: "Bhawk-11",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/trouble_on_tara",
        chapterCount: 3
    },
    {
        id: "twice_shy",
        title: "Twice Shy",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/twice_shy",
        chapterCount: 11
    },
    {
        id: "two_aliens_walk_into_a_bar",
        title: "Two Aliens Walk Into A Bar",
        author: "MrStargazer",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/two_aliens_walk_into_a_bar",
        chapterCount: 2
    },
    {
        id: "two_predators_for_hire",
        title: "Two Predators For Hire",
        author: "Soggy_Helicopter8589",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/two_predators_for_hire",
        chapterCount: 9
    },
    {
        id: "two_steps_past_tomorrow",
        title: "Two Steps Past Tomorrow",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/two_steps_past_tomorrow",
        chapterCount: 0
    },
    {
        id: "tyrannical",
        title: "Tyrannical",
        author: "vehino",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/tyrannical",
        chapterCount: 9
    },
    {
        id: "the_tyrant",
        title: "The Tyrant",
        author: "InflatedEgo13",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_tyrant",
        chapterCount: 10
    },
    {
        id: "ultimagus",
        title: "Ultimagus",
        author: "ThreeDucksInAManSuit",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/ultimagus",
        chapterCount: 52
    },
    {
        id: "the_unbranded",
        title: "The Unbranded",
        author: "JohnPaulRogers",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_unbranded",
        chapterCount: 18
    },
    {
        id: "unbreakable",
        title: "Unbreakable",
        author: "Swimming\\_Good\\_8507",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unbreakable",
        chapterCount: 9
    },
    {
        id: "an_unexpected_guest",
        title: "An Unexpected Guest",
        author: "allature",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_unexpected_guest",
        chapterCount: 22
    },
    {
        id: "unexpected_guest",
        title: "Unexpected Guest",
        author: "LgFatherAnthrocite",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unexpected_guest",
        chapterCount: 8
    },
    {
        id: "an_unexpected_trip",
        title: "An Unexpected Trip",
        author: "DustHurricane",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/an_unexpected_trip",
        chapterCount: 5
    },
    {
        id: "unforeseen_consequences",
        title: "Unforeseen Consequences",
        author: "BroomClosetJoe",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/unforeseen_consequences",
        chapterCount: 11
    },
    {
        id: "unlike_us",
        title: "Unlike Us",
        author: "Apprehensive-Bad9511",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/unlike_us",
        chapterCount: 12
    },
    {
        id: "the_unmaker",
        title: "The Unmaker",
        author: "Maradina88",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_unmaker",
        chapterCount: 9
    },
    {
        id: "unmemory",
        title: "Unmemory",
        author: "unknown-0812",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unmemory",
        chapterCount: 23
    },
    {
        id: "unnatural",
        title: "Unnatural",
        author: "MPQEG",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unnatural",
        chapterCount: 2
    },
    {
        id: "unseen",
        title: "Unseen",
        author: "Silty_Sands",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/unseen",
        chapterCount: 17
    },
    {
        id: "the_unthinkable",
        title: "The Unthinkable",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_unthinkable",
        chapterCount: 0
    },
    {
        id: "up_to_expectations",
        title: "Up to Expectations",
        author: "thePatchyBeard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/up_to_expectations",
        chapterCount: 1
    },
    {
        id: "uplift_index",
        title: "Uplift Index",
        author: "morgisboard",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/uplift_index",
        chapterCount: 3
    },
    {
        id: "uplift_protocol_castaways",
        title: "Uplift Protocol - Castaways",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/uplift_protocol__castaways",
        chapterCount: 0
    },
    {
        id: "uplifted",
        title: "Uplifted",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/uplifted",
        chapterCount: 0
    },
    {
        id: "upsetting_the_balance",
        title: "Upsetting the Balance",
        author: "GasmaskBro",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/upsetting_the_balance",
        chapterCount: 8
    },
    {
        id: "upward_bound",
        title: "Upward Bound",
        author: "squallus\\_l",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/upward_bound",
        chapterCount: 44
    },
    {
        id: "urdowyr",
        title: "Urdowyr",
        author: "Ivan_the_Unpleasant",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/urdowyr",
        chapterCount: 14
    },
    {
        id: "uss_terra",
        title: "USS Terra",
        author: "Environmental-Wish53",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/uss_terra",
        chapterCount: 7
    },
    {
        id: "vacation_from_destiny",
        title: "Vacation From Destiny",
        author: "Obsequium_Minaris",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/vacation_from_destiny",
        chapterCount: 60
    },
    {
        id: "the_vampire_s_apprentice",
        title: "The Vampire's Apprentice",
        author: "Obsequium_Minaris",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_vampires_apprentice",
        chapterCount: 145
    },
    {
        id: "verses_origins",
        title: "Verses: Origins",
        author: "guywithnolife6969",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/verses_origins",
        chapterCount: 51
    },
    {
        id: "very_random_encounters",
        title: "Very Random Encounters",
        author: "Pretzelbomber",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/very_random_encounters",
        chapterCount: 3
    },
    {
        id: "the_vespira_voyages",
        title: "The Vespira Voyages",
        author: "morbiusgreen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_vespira_voyages",
        chapterCount: 2
    },
    {
        id: "viable_systems",
        title: "Viable Systems",
        author: "PattableGreeb",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/viable_systems",
        chapterCount: 6
    },
    {
        id: "virtual_intelligence",
        title: "Virtual Intelligence",
        author: "K0r_Fe_0n",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/virtual_intelligence",
        chapterCount: 10
    },
    {
        id: "a_voice_in_the_void",
        title: "A Voice In The Void",
        author: "100Bob2020",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_voice_in_the_void",
        chapterCount: 9
    },
    {
        id: "void_hopper",
        title: "Void-Hopper",
        author: "TheFirstMillionWords",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/voidhopper",
        chapterCount: 0
    },
    {
        id: "voidborn",
        title: "Voidborn",
        author: "FieserMoep",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/voidborn",
        chapterCount: 9
    },
    {
        id: "voidsong",
        title: "Voidsong",
        author: "Lostfol",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/voidsong",
        chapterCount: 16
    },
    {
        id: "voidsong_2",
        title: "Voidsong",
        author: "Necrontyr525",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/voidsong_necrontyr525",
        chapterCount: 0
    },
    {
        id: "voyages_of_an_unholy_construct",
        title: "Voyages Of An Unholy Construct",
        author: "Just\\_Visiting\\_Sol",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/voyages_of_an_unholy_construct",
        chapterCount: 9
    },
    {
        id: "the_waffle_house_defense_militia",
        title: "The Waffle House Defense Militia",
        author: "novatheelf",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/the_waffle_house_defense_militia",
        chapterCount: 7
    },
    {
        id: "the_wager",
        title: "The Wager",
        author: "WarAdmiral2420",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_wager",
        chapterCount: 15
    },
    {
        id: "walk_me_home",
        title: "Walk Me Home",
        author: "The-Mr-E",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/walk_me_home",
        chapterCount: 15
    },
    {
        id: "walking_the_dog",
        title: "Walking The Dog",
        author: "Brokenspade1",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/walking_the_dog",
        chapterCount: 40
    },
    {
        id: "the_war_between_the_valtari_empire_and_humanity",
        title: "The War Between The Valtari Empire And Humanity",
        author: "H1n14life",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_war_between_the_valtari_empire_and_humanity",
        chapterCount: 9
    },
    {
        id: "warhawk_s_amnesty",
        title: "Warhawk's Amnesty",
        author: "AjaxLygan",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warhawks_amnesty",
        chapterCount: 5
    },
    {
        id: "warned",
        title: "Warned",
        author: "yousureimnotarobot",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warned",
        chapterCount: 12
    },
    {
        id: "warning_intruders",
        title: "Warning. Intruders",
        author: "StrageDragonShadow, Stories",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warning_intruders",
        chapterCount: 5
    },
    {
        id: "warpways_atomica",
        title: "Warpways: Atomica",
        author: "wer66",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warpways_atomica",
        chapterCount: 5
    },
    {
        id: "warrior",
        title: "Warrior",
        author: "KiriofGreen",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warrior",
        chapterCount: 3
    },
    {
        id: "warrior_cultures_are_obsolete",
        title: "Warrior Cultures Are Obsolete",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/warrior_cultures_are_obsolete",
        chapterCount: 2
    },
    {
        id: "water_world",
        title: "Water World",
        author: "KingLadislavJagiello",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/water_world",
        chapterCount: 3
    },
    {
        id: "the_way_of_ethan",
        title: "The Way Of Ethan",
        author: "Mr_hyde2000",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_way_of_ethan",
        chapterCount: 12
    },
    {
        id: "wayward",
        title: "Wayward",
        author: "Gazooonga",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wayward",
        chapterCount: 7
    },
    {
        id: "wayward_god",
        title: "Wayward God",
        author: "eCyanic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wayward_god",
        chapterCount: 16
    },
    {
        id: "we_accidentally_allied_with_a_warrior_race",
        title: "We Accidentally Allied With A Warrior Race",
        author: "ShadowDragon8685",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_accidentally_allied_with_a_warrior_race",
        chapterCount: 8
    },
    {
        id: "we_accidentally_summoned_a_human",
        title: "We Accidentally Summoned A Human",
        author: "Crafty-Ad-3993",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_accidentally_summoned_a_human",
        chapterCount: 7
    },
    {
        id: "we_are_chaos",
        title: "We Are Chaos",
        author: "Ruggi_2001",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_are_chaos",
        chapterCount: 5
    },
    {
        id: "we_are_lost",
        title: "We Are Lost",
        author: "No-Dog1094",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_are_lost",
        chapterCount: 7
    },
    {
        id: "we_are_not_alone_but_we_are_lonely",
        title: "We Are Not Alone But We Are Lonely",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_are_not_alone_but_we_are_lonely",
        chapterCount: 3
    },
    {
        id: "we_are_void",
        title: "We Are Void",
        author: "bird\\_of\\_hermes\\_",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/we_are_void",
        chapterCount: 70
    },
    {
        id: "we_follow_the_leader",
        title: "We Follow The Leader",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_follow_the_leader",
        chapterCount: 0
    },
    {
        id: "we_found_it_in_our_shed",
        title: "We Found It In Our Shed",
        author: "2weekoldpickle",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/we_found_it_in_our_shed",
        chapterCount: 12
    },
    {
        id: "we_might_just_need_to_make_our_own_federation",
        title: "We Might Just Need To Make Our Own Federation",
        author: "thatoneshotgunmain",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_might_just_need_to_make_our_own_federation",
        chapterCount: 4
    },
    {
        id: "we_outsourced_everything_to_the_humans",
        title: "We Outsourced Everything To The Humans",
        author: "Jcb112",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_outsourced_everything_to_the_humans",
        chapterCount: 7
    },
    {
        id: "we_were_sent_to_find_an_ancient_weapon_called_human",
        title: "We Were Sent To Find An Ancient Weapon Called Human",
        author: "CnRhin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_were_sent_to_find_an_ancient_weapon_called_human",
        chapterCount: 7
    },
    {
        id: "we_were_warned_not_to_bond_with_humans",
        title: "We Were Warned Not To Bond With Humans",
        author: "Obvious_Ad4159",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/we_were_warned_not_to_bond_with_humans",
        chapterCount: 8
    },
    {
        id: "we_ve_discovered_the_4th_sentient_species_in_the_galaxy",
        title: "We've discovered the 4th sentient species in the galaxy",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/weve_discovered_the_4th_sentient_species",
        chapterCount: 0
    },
    {
        id: "a_weapon_without_a_war",
        title: "A Weapon Without A War",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_weapon_without_a_war",
        chapterCount: 0
    },
    {
        id: "the_weight_of_remembrance",
        title: "The Weight Of Remembrance",
        author: "tbuljevic",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_weight_of_remembrance",
        chapterCount: 15
    },
    {
        id: "the_weight_we_carry",
        title: "The Weight We Carry",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_weight_we_carry",
        chapterCount: 0
    },
    {
        id: "the_welalict_war",
        title: "The Welalict War",
        author: "Arivael",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_welalict_war",
        chapterCount: 11
    },
    {
        id: "welcome_to_the_jungle",
        title: "Welcome To The Jungle",
        author: "bott99",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/welcome_to_the_jungle",
        chapterCount: 7
    },
    {
        id: "welcome_to_the_neighborhood",
        title: "Welcome To The Neighborhood",
        author: "jackleraid",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/welcome_to_the_neighborhood",
        chapterCount: 2
    },
    {
        id: "werewolves_wizards_witches_and_robots",
        title: "Werewolves, Wizards, Witches, And Robots",
        author: "Remote-Ad-2821",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/werewolves_wizards_witches_and_robots",
        chapterCount: 6
    },
    {
        id: "the_westmarch_war",
        title: "The Westmarch War",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_westmarch_war",
        chapterCount: 0
    },
    {
        id: "what_are_you_afraid_of",
        title: "What Are You Afraid Of?",
        author: "foolslikeme",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_are_you_afraid_of",
        chapterCount: 2
    },
    {
        id: "what_are_you_doing_here",
        title: "What Are You Doing Here?",
        author: "jailb",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_are_you_doing_here",
        chapterCount: 18
    },
    {
        id: "what_did_you_do",
        title: "What Did You Do?",
        author: "HeyL_s8_10",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_did_you_do",
        chapterCount: 6
    },
    {
        id: "what_happens_after_humans_kick_alien_ass",
        title: "What Happens After Humans Kick Alien Ass?",
        author: "LukeWasNotHere",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_happens_after_humans_kick_alien_ass",
        chapterCount: 11
    },
    {
        id: "what_it_cost_the_humans",
        title: "What It Cost The Humans",
        author: "Far-Help6106",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/what_it_cost_the_humans",
        chapterCount: 9
    },
    {
        id: "what_lurks_in_the_darkness",
        title: "What Lurks In The Darkness",
        author: "Prestigious-Wind5909",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_lurks_in_the_darkness",
        chapterCount: 7
    },
    {
        id: "what_the_bleep",
        title: "What The -Bleep- ?!?",
        author: "moh8disaster",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/what_the_bleep_",
        chapterCount: 43
    },
    {
        id: "wheels_within_wheels",
        title: "Wheels Within Wheels",
        author: "AJMansfield_",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wheels_within_wheels",
        chapterCount: 28
    },
    {
        id: "when_aliens_meet_the_supernatural",
        title: "When Aliens Meet The Supernatural",
        author: "jamescsmithLW",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_aliens_meet_the_supernatural",
        chapterCount: 5
    },
    {
        id: "when_one_becomes_two",
        title: "When One Becomes Two",
        author: "bold_cheesecake",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_one_becomes_two",
        chapterCount: 10
    },
    {
        id: "when_they_ask_where_we_were",
        title: "When They Ask Where We Were",
        author: "Effective_Cow_2174",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_they_ask_where_we_were",
        chapterCount: 16
    },
    {
        id: "when_worlds_collide",
        title: "When Worlds Collide",
        author: "Lonely_Audience",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/when_worlds_collide",
        chapterCount: 3
    },
    {
        id: "where_are_they",
        title: "Where Are They?",
        author: "FlashyPaladin",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/where_are_they",
        chapterCount: 14
    },
    {
        id: "whispers_of_the_lost",
        title: "Whispers Of The Lost",
        author: "Sohox3",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/whispers_of_the_lost",
        chapterCount: 21
    },
    {
        id: "wildversum",
        title: "Wildversum",
        author: "RealSteamlynx",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wildversum",
        chapterCount: 17
    },
    {
        id: "william_smith_informational_videos",
        title: "William Smith Informational Videos",
        author: "fred_lowe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/william_smith_informational_videos",
        chapterCount: 8
    },
    {
        id: "a_witch_at_midnight",
        title: "A Witch At Midnight",
        author: "OrlonDogger",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_witch_at_midnight",
        chapterCount: 32
    },
    {
        id: "within_them",
        title: "Within Them",
        author: "GoodLuckSuingMe",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/within_them",
        chapterCount: 7
    },
    {
        id: "without_the_bat",
        title: "Without The Bat",
        author: "ack1308",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/without_the_bat",
        chapterCount: 7
    },
    {
        id: "wizard_tournament",
        title: "Wizard Tournament",
        author: "JDFister",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wizard_tournament",
        chapterCount: 60
    },
    {
        id: "woke_up_kidnapped",
        title: "Woke Up Kidnapped",
        author: "FatedApollo",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/woke_up_kidnapped",
        chapterCount: 41
    },
    {
        id: "wolf_359",
        title: "Wolf 359",
        author: "ArenVaal",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wolf_359",
        chapterCount: 6
    },
    {
        id: "wonder",
        title: "Wonder",
        author: "MasterOfGrey",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wonder",
        chapterCount: 2
    },
    {
        id: "words_of_power",
        title: "Words Of Power",
        author: "TheDeliciousMeats",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/words_of_power",
        chapterCount: 8
    },
    {
        id: "a_world_in_the_palm_of_my_hands",
        title: "A World In The Palm Of My Hands",
        author: "thatseriouslyoddguy",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_world_in_the_palm_of_my_hands",
        chapterCount: 14
    },
    {
        id: "a_world_like_no_other",
        title: "A World Like No Other...",
        author: "ABottleofHotSauce",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_world_like_no_other",
        chapterCount: 7
    },
    {
        id: "a_world_lit_only_by_fire",
        title: "A World Lit Only By Fire",
        author: "taylorgbh",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_world_lit_only_by_fire",
        chapterCount: 2
    },
    {
        id: "world_of_karik",
        title: "World Of Karik",
        author: "DanyaWlasko",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/world_of_karik",
        chapterCount: 22
    },
    {
        id: "worlds_collide",
        title: "Worlds Collide",
        author: "RetroInferno",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/worlds_collide",
        chapterCount: 4
    },
    {
        id: "wounded_warrior_a_sense_of_self",
        title: "Wounded Warrior; A sense of self",
        author: "Dejers",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wounded_warrior_a_sense_of_self",
        chapterCount: 6
    },
    {
        id: "a_wrench_in_the_works",
        title: "A Wrench In The Works",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_wrench_in_the_works",
        chapterCount: 0
    },
    {
        id: "wunderwaffe",
        title: "Wunderwaffe",
        author: "unknown",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/wunderwaffe",
        chapterCount: 0
    },
    {
        id: "wyrmhaven",
        title: "Wyrmhaven",
        author: "EmrysAmbrosius",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/wyrmhaven",
        chapterCount: 5
    },
    {
        id: "the_x_factor",
        title: "The X Factor",
        author: "CodEnvironmental4274",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_x_factor",
        chapterCount: 71
    },
    {
        id: "a_xeno_high_school",
        title: "A Xeno High-School",
        author: "No30867",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/a_xeno_highschool",
        chapterCount: 17
    },
    {
        id: "xenopsychology_3024",
        title: "Xenopsychology 3024",
        author: "KingLadislavJagiello",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/xenopsychology_3024",
        chapterCount: 3
    },
    {
        id: "xtrrli_s_list",
        title: "Xtrrli's List",
        author: "the\\_Zet",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/xtrrlis_list",
        chapterCount: 11
    },
    {
        id: "the_yaire_exile_to_earth",
        title: "The Yaire Exile To Earth",
        author: "space_farmer_luke",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_yaire_exile_to_earth",
        chapterCount: 10
    },
    {
        id: "the_year_after_next",
        title: "The Year After Next",
        author: "j1xwnbsr",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/year_after_next",
        chapterCount: 0
    },
    {
        id: "yellow",
        title: "Yellow",
        author: "The\\_Vadami",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/yellow",
        chapterCount: 5
    },
    {
        id: "yes_i_am_a_human",
        title: "Yes, I Am A Human",
        author: "Reretak",
        wikiUrl: "https://www.reddit.com/r/HFY/wiki/series/yes_i_am_a_human",
        chapterCount: 9
    },
    {
        id: "you_and_i",
        title: "You And I",
        author: "KnightKasket",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/you_and_i",
        chapterCount: 5
    },
    {
        id: "you_human_i_android",
        title: "You human, I Android",
        author: "LeewardNitemare",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/you_human_i_android",
        chapterCount: 0
    },
    {
        id: "your_world_will_fail",
        title: "Your World Will Fail",
        author: "DionZeromus",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/your_world_will_fail",
        chapterCount: 11
    },
    {
        id: "the_ziegfried_saga",
        title: "The Ziegfried Saga",
        author: "BCS-YGO",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/the_ziegfried_saga",
        chapterCount: 10
    },
    {
        id: "zyz",
        title: "Zyz",
        author: "tsavong117",
        wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/zyz",
        chapterCount: 4
    },
    {
        id: "sexy_space_babes_2",
        title: "Sexy Space Babes",
        author: "bluefishcake",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/bluefishcake/sexy_space_babes",
        chapterCount: 55
    },
    {
        id: "insurgent_2",
        title: "Insurgent",
        author: "redditors_username",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/redditors_username/insurgent",
        chapterCount: 32
    },
    {
        id: "uss_terra_2",
        title: "USS Terra",
        author: "environmental-wish53",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/environmental-wish53/uss_terra",
        chapterCount: 7
    },
    {
        id: "the_oldest_game_among_the_stars",
        title: "The Oldest Game Among the Stars",
        author: "edwardtheking555",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/edwardtheking555/the_oldest_game_among_the_stars",
        chapterCount: 33
    },
    {
        id: "with_the_hanks",
        title: "With the Hanks",
        author: "m1chaellanz",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/m1chaellanz/with_the_hanks/",
        chapterCount: 32
    },
    {
        id: "appalachia_calling",
        title: "Appalachia Calling",
        author: "bruhmomentgee",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/bruhmomentgee/#wiki_appalachia_calling",
        chapterCount: 0
    },
    {
        id: "yeensgiving",
        title: "YeensGiving",
        author: "cocao_nibs",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/cocao_nibs/yeensgiving/",
        chapterCount: 6
    },
    {
        id: "growing_up_alien_2",
        title: "Growing Up Alien",
        author: "adventurous-map-9400",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/adventurous-map-9400/loyalist",
        chapterCount: 9
    },
    {
        id: "hunting_a_maus",
        title: "Hunting a Maus",
        author: "dog_in_boots",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/dog_in_boots/",
        chapterCount: 36
    },
    {
        id: "the_start_of_something",
        title: "The Start of...Something?",
        author: "environmental-wish53",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/environmental-wish53/the_start_of_something",
        chapterCount: 7
    },
    {
        id: "claw_of_fate",
        title: "Claw of Fate",
        author: "buchfu",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/buchfu/claw_of_fate",
        chapterCount: 7
    },
    {
        id: "the_cook",
        title: "The Cook",
        author: "carcu131",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/carcu131/the_cook",
        chapterCount: 28
    },
    {
        id: "white_tails",
        title: "White Tails",
        author: "bruhmomentgee",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/bruhmomentgee/white_tails/",
        chapterCount: 40
    },
    {
        id: "in_for_a_penny",
        title: "In For a Penny...",
        author: "cokesamurai",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/cokesamurai/in_for_a_penny",
        chapterCount: 66
    },
    {
        id: "where_love_falls",
        title: "Where Love Falls",
        author: "sp3zn4s696",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/sp3zn4s696/where_love_falls/",
        chapterCount: 6
    },
    {
        id: "final_war",
        title: "Final War",
        author: "fun-part",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/index/authors/fun-part",
        chapterCount: 7
    },
    {
        id: "semper_shil_vati_2",
        title: "Semper Shil���vati",
        author: "americanpride2814",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/americanpride2814/semper_shilvati",
        chapterCount: 22
    },
    {
        id: "alien_nation_2",
        title: "Alien-Nation",
        author: "ssbsubjugation",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/ssbsubjugation/alien_nation",
        chapterCount: 228
    },
    {
        id: "city_slickers_and_hayseeds_2",
        title: "City Slickers and Hayseeds",
        author: "randomtinkerer",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/randomtinkerer/city_slickers_and_hayseeds",
        chapterCount: 46
    },
    {
        id: "no_separate_peace_2",
        title: "No Separate Peace",
        author: "stickmaster-flex",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/stickmaster-flex/no_separate_peace",
        chapterCount: 41
    },
    {
        id: "the_marauder_2",
        title: "The Marauder",
        author: "jellybeanbazooka",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/jellybeanbazooka/the_marauder",
        chapterCount: 22
    },
    {
        id: "human_studies",
        title: "Human Studies",
        author: "rnmennell",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/rnmennell/human_studies",
        chapterCount: 7
    },
    {
        id: "going_native",
        title: "Going Native",
        author: "uncleceiling",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/uncleceiling/going_native",
        chapterCount: 89
    },
    {
        id: "cultural_exchange",
        title: "Cultural Exchange",
        author: "hollowshel",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/hollowshel/cultural_exchange",
        chapterCount: 10
    },
    {
        id: "denied_operations",
        title: "Denied Operations",
        author: "punnynfunny",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/punnynfunny/denied_operations",
        chapterCount: 8
    },
    {
        id: "ad_astra",
        title: "Ad Astra",
        author: "ransomusername",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/ransomusername/ad_astra",
        chapterCount: 2
    },
    {
        id: "awakening_2",
        title: "Awakening",
        author: "lukethedank13",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/lukethedank13/awakening",
        chapterCount: 17
    },
    {
        id: "the_duelist_in_purple_armor",
        title: "The Duelist in Purple Armor",
        author: "cocao_nibs",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/cocao_nibs/the_duelist_in_purple_armor",
        chapterCount: 8
    },
    {
        id: "the_free_navy",
        title: "The Free Navy",
        author: "faultylogicengine",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/faultylogicengine/free_navy",
        chapterCount: 51
    },
    {
        id: "once_a_rebel",
        title: "Once a Rebel",
        author: "jaydog9696",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/jaydog9696/once_a_rebel",
        chapterCount: 20
    },
    {
        id: "the_adventures_of_horok_ra",
        title: "The Adventures of Horok Ra",
        author: "cocao_nibs",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/cocao_nibs/adventures_of_horakra",
        chapterCount: 11
    },
    {
        id: "just_one_drop",
        title: "Just One Drop",
        author: "rhion-618",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/rhion-618/just_one_drop",
        chapterCount: 111
    },
    {
        id: "the_blue_blood_2",
        title: "The Blue Blood",
        author: "slime_special_681",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/slime_special_681/the_blue_blood",
        chapterCount: 7
    },
    {
        id: "we_play_human_music",
        title: "We Play Human Music",
        author: "an_insufferable_newt",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/an_insufferable_newt/we_play_human_music",
        chapterCount: 29
    },
    {
        id: "far_away",
        title: "Far Away",
        author: "robotstatic",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/robotstatic/far_away",
        chapterCount: 77
    },
    {
        id: "moral_grey_area",
        title: "Moral Grey Area",
        author: "majnabunny",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/majnabunny/",
        chapterCount: 55
    },
    {
        id: "legion_of_monsters",
        title: "Legion of Monsters",
        author: "silent_technology540",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/silent_technology540/",
        chapterCount: 2
    },
    {
        id: "eagle_springs",
        title: "Eagle Springs",
        author: "cmdr_shadowstalker",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/cmdr_shadowstalker/eagle_springs/",
        chapterCount: 69
    },
    {
        id: "failing_upwards",
        title: "Failing Upwards",
        author: "suchpig",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/suchpig/failing_upwards/",
        chapterCount: 16
    },
    {
        id: "the_cryptid_chronicle",
        title: "The Cryptid Chronicle",
        author: "kazevenikov",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/kazevenikov/the_cryptid_chronicle/",
        chapterCount: 174
    },
    {
        id: "scp",
        title: "SCP",
        author: "gadburn",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/gadburn/scp/",
        chapterCount: 0
    },
    {
        id: "the_only_thing_that_matters",
        title: "The only thing that matters",
        author: "amon-ko",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/amon-ko/the_only_thing_that_matters/",
        chapterCount: 16
    },
    {
        id: "cold_front",
        title: "Cold Front",
        author: "nerdygamer2020",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/nerdygamer2020/cold-front/",
        chapterCount: 12
    },
    {
        id: "claustrophobia_and_radiophobia",
        title: "Claustrophobia and radiophobia",
        author: "robot_tanks",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/robot_tanks/claustrophobia_and_radiophobia/",
        chapterCount: 4
    },
    {
        id: "mother_gaia_s_revenge",
        title: "Mother Gaia's Revenge",
        author: "thedude4853",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/thedude4853/mother_gaias_revenge/",
        chapterCount: 2
    },
    {
        id: "anonymous",
        title: "Anonymous",
        author: "gantron414",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/gantron414/anonymous/",
        chapterCount: 5
    },
    {
        id: "lifeguards_and_amazons",
        title: "Lifeguards And Amazons",
        author: "whitemetro",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/whitemetro/humans_and_amazons",
        chapterCount: 12
    },
    {
        id: "fire_within_2",
        title: "Fire Within",
        author: "swimming_good_8507",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/swimming_good_8507/fire_within",
        chapterCount: 16
    },
    {
        id: "semper_imperialis",
        title: "Semper Imperialis",
        author: "elyewii",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/elyewii/semper_imperialis/",
        chapterCount: 16
    },
    {
        id: "kung_fu_kid",
        title: "Kung Fu Kid",
        author: "theorrmulum",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/theorrmulum/kung_fu_kid/",
        chapterCount: 5
    },
    {
        id: "papercuts",
        title: "Papercuts",
        author: "sp3zn4s696",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/sp3zn4s696/papercuts/",
        chapterCount: 82
    },
    {
        id: "native_liaison",
        title: "Native Liaison",
        author: "disasterwhiskey",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/disasterwhiskey/native-liaison/",
        chapterCount: 8
    },
    {
        id: "green_thumb",
        title: "Green Thumb",
        author: "old-dullard",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/old-dullard/green_thumb/",
        chapterCount: 16
    },
    {
        id: "children_of_hele",
        title: "Children of Hele",
        author: "old-dullard",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/old-dullard/children_of_hele/",
        chapterCount: 4
    },
    {
        id: "exiled_2",
        title: "[ Exiled ]",
        author: "analysisiconoclast",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/analysisiconoclast/exiled/",
        chapterCount: 39
    },
    {
        id: "the_outcasts",
        title: "The Outcasts",
        author: "ravenredd65",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/ravenredd65/the_outcasts/",
        chapterCount: 14
    },
    {
        id: "a_risky_venture",
        title: "A Risky Venture",
        author: "ruste359",
        wikiUrl: "",
        ssbWikiUrl: "https://reddit.com/r/Sexyspacebabes/wiki/authors/ruste359/a_risky_venture",
        chapterCount: 6
    },
    {
        id: "the_human_condition",
        title: "The Human Condition",
        author: "spacefillingnerd",
        wikiUrl: "",
        ssbWikiUrl: "https://reddit.com/r/Sexyspacebabes/wiki/authors/spacefillingnerd/the_human_condition",
        chapterCount: 95
    },
    {
        id: "a_chance_encounter",
        title: "A Chance Encounter",
        author: "catsintrenchcoats",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/catsintrenchcoats/#wiki_a_chance_encounter.3A",
        chapterCount: 0
    },
    {
        id: "janissary_the_joy_ride",
        title: "Janissary: The Joy Ride",
        author: "hedgehog_5150",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/hedgehog_5150/janissary_the_joy_ride/",
        chapterCount: 71
    },
    {
        id: "only_human",
        title: "Only Human",
        author: "disasterwhiskey",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/disasterwhiskey/only_human",
        chapterCount: 16
    },
    {
        id: "notes_of_the_first_contact_war",
        title: "Notes of the First Contact War",
        author: "fine_ad_1918",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/fine_ad_1918/notes_of_the_fc_war",
        chapterCount: 5
    },
    {
        id: "catsintrenchcoats",
        title: "CatsInTrenchCoats",
        author: "CatsInTrenchCoats",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/sexyspacebabes/wiki/authors/catsintrenchcoats/",
        chapterCount: 14
    },
    {
        id: "deathrhodes666",
        title: "DeathRhodes666",
        author: "DeathRhodes666",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/environmental-wish53",
        chapterCount: 4
    },
    {
        id: "the_turox_and_the_leopard",
        title: "The Turox and the Leopard",
        author: "seriathus",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/seriathus/the_turox_and_the_leopard",
        chapterCount: 5
    },
    {
        id: "the_hunter_and_the_pack",
        title: "The Hunter and the Pack",
        author: "no_assumption_3373",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/No_Assumption_3373/the_hunter_and_the_pack",
        chapterCount: 12
    },
    {
        id: "does_ai_dream_of_purple_ladies",
        title: "Does AI Dream of Purple Ladies?",
        author: "antares60",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/antares60/does_ai_dream_of_purple_ladies",
        chapterCount: 2
    },
    {
        id: "rebel_studios",
        title: "Rebel Studios",
        author: "grand-sea-emperor",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/grand-sea-emperor/rebel_studios",
        chapterCount: 9
    },
    {
        id: "the_piano_man",
        title: "The Piano Man",
        author: "xaph0s",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/xaph0s/the_piano_man",
        chapterCount: 11
    },
    {
        id: "salvaged_past",
        title: "Salvaged past",
        author: "lavender-dragoness",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/lavender-dragoness/salvaged_past",
        chapterCount: 4
    },
    {
        id: "marshal",
        title: "Marshal",
        author: "daircm",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/daircm/marshal/",
        chapterCount: 3
    },
    {
        id: "contracted_human",
        title: "Contracted Human",
        author: "accidentalwordsmith",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/accidentalwordsmith/contracted_human/",
        chapterCount: 3
    },
    {
        id: "american_lord_of_psycho_spice_war_and_dragon",
        title: "American Lord of Psycho Spice War and Dragon",
        author: "green-personality784",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/green-personality784/american_lord_of_pswd/",
        chapterCount: 20
    },
    {
        id: "warhammer_40k_x_ssb",
        title: "Warhammer 40k x SSB",
        author: "idrawweirdcomic",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/idrawweirdcomic/warhammer40kxssb/",
        chapterCount: 3
    },
    {
        id: "eve_incursion",
        title: "EVE Incursion",
        author: "haidere1988",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/haidere1988/eve_incursion",
        chapterCount: 7
    },
    {
        id: "refractor",
        title: "Refractor",
        author: "nephilim_legion",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/nephilim_legion/refractor",
        chapterCount: 4
    },
    {
        id: "pax_imperia",
        title: "Pax Imperia",
        author: "crownedcrow420",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/crownedcrow420/pax_imperia",
        chapterCount: 5
    },
    {
        id: "divide_and_conquer",
        title: "Divide and Conquer",
        author: "_tiragron_",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/_tiragron_/divide_and_conquer",
        chapterCount: 1
    },
    {
        id: "blood_for_blood_paradise",
        title: "Blood for Blood Paradise",
        author: "lordhenry7898",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/lordhenry7898/blood_for_blood_paradise",
        chapterCount: 4
    },
    {
        id: "no_good_deed",
        title: "No Good Deed",
        author: "oksite966",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/oksite966/no_good_deed",
        chapterCount: 13
    },
    {
        id: "unwelcome_guest",
        title: "Unwelcome guest",
        author: "zombiejack400",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/zombiejack400/unwelcome_guest",
        chapterCount: 4
    },
    {
        id: "violet_violence_and_pale_kindness",
        title: "Violet Violence and Pale Kindness",
        author: "mother-internal8992",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/mother-internal8992/violet_violence_and_purple_kindness",
        chapterCount: 5
    },
    {
        id: "playing_with_portals",
        title: "Playing With Portals",
        author: "thatdamnpaladin",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/thatdamnpaladin/playing_with_portals",
        chapterCount: 3
    },
    {
        id: "fireteam_floofy",
        title: "FireTeam Floofy",
        author: "kerbalsanders1",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/kerbalsanders1/fireteam_floofy",
        chapterCount: 12
    },
    {
        id: "running_with_the_pack",
        title: "Running With The Pack",
        author: "r27-archer-spammer",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/r27-archer-spammer/running_with_the_pack",
        chapterCount: 3
    },
    {
        id: "tales_of_a_post_invasion_pizzaman",
        title: "Tales of a Post Invasion Pizzaman",
        author: "thatdamnpaladin",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/thatdamnpaladin/post_invasion_pizzaman",
        chapterCount: 7
    },
    {
        id: "the_stars_align",
        title: "The Stars Align",
        author: "ransomusername",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/ransomusername/the_stars_align",
        chapterCount: 2
    },
    {
        id: "shadows_in_the_berkshires",
        title: "Shadows in the Berkshires",
        author: "tworavens",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/tworavens/shadows_in_the_berkshires",
        chapterCount: 5
    },
    {
        id: "secure_2",
        title: "Secure",
        author: "scpunited",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/scpunited/secure",
        chapterCount: 3
    },
    {
        id: "crimewave_2",
        title: "Crimewave",
        author: "scpunited",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/scpunited/crimewave",
        chapterCount: 14
    },
    {
        id: "glory_is_eternal",
        title: "Glory is Eternal",
        author: "iown3cardealerships",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/iown3cardealerships/glory_is_eternal",
        chapterCount: 12
    },
    {
        id: "western_insurgency",
        title: "Western Insurgency",
        author: "a_random_guy641",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/a_random_guy641/western_insurgency",
        chapterCount: 3
    },
    {
        id: "a_tour_down_under",
        title: "A Tour Down Under",
        author: "fpsreaper124",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/fpsreaper124/a_tour_down_under",
        chapterCount: 18
    },
    {
        id: "streetfighter",
        title: "Streetfighter",
        author: "jiangrong222",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/jiangrong222/streetfighter",
        chapterCount: 25
    },
    {
        id: "untitled",
        title: "Untitled",
        author: "zxcv-alt",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/zxcv-alt/untitled",
        chapterCount: 22
    },
    {
        id: "a_cat_that_really_was_gone_2",
        title: "A Cat That Really was Gone",
        author: "big_grug",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/big_grug/a_cat_that_really_was_gone",
        chapterCount: 35
    },
    {
        id: "ghost_tales",
        title: "Ghost Tales",
        author: "big_grug",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/big_grug/ghost_tales",
        chapterCount: 4
    },
    {
        id: "status_dependent_spouse",
        title: "Status: Dependent Spouse",
        author: "kansan_in_bangkok",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/kansan_in_bangkok/dependant_spouse",
        chapterCount: 23
    },
    {
        id: "candyman",
        title: "Candyman",
        author: "shneekeythelost",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/shneekeythelost/candyman/",
        chapterCount: 9
    },
    {
        id: "fireteam_providence",
        title: "Fireteam Providence",
        author: "titansweep2022",
        wikiUrl: "",
        ssbWikiUrl: "https://www.reddit.com/r/Sexyspacebabes/wiki/authors/titansweep2022/fireteam_providence/",
        chapterCount: 23
    },
    {
        id: "audio_narration",
        title: "Audio Narration",
        author: "AgroSquerril",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1941",
        chapterCount: 860
    },
    {
        id: "audio_narration_2",
        title: "Audio Narration",
        author: "Spartawolf",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2455",
        chapterCount: 345
    },
    {
        id: "empyprean_iris_1",
        title: "Empyprean Iris 1",
        author: "maximusaemilius",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4447",
        chapterCount: 275
    },
    {
        id: "cyoa",
        title: "CYOA",
        author: "Necrontyr525",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/853",
        chapterCount: 242
    },
    {
        id: "reddit_tales_from_outer_space",
        title: "Reddit Tales from Outer Space",
        author: "AgroSquerril",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2158",
        chapterCount: 212
    },
    {
        id: "dungeon_life",
        title: "Dungeon Life",
        author: "Khenal",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3796",
        chapterCount: 195
    },
    {
        id: "thjverse",
        title: "THJVerse",
        author: "The_Fallen_1",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4764",
        chapterCount: 153
    },
    {
        id: "the_daughter_that_followed",
        title: "The Daughter that Followed",
        author: "TheSmogmonsterZX",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3481",
        chapterCount: 151
    },
    {
        id: "they_are_smol_2",
        title: "They are Smol",
        author: "Tinyprancinghorse",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1530",
        chapterCount: 130
    },
    {
        id: "galactic_social_dynamic",
        title: "Galactic Social Dynamic",
        author: "TheSmogmonsterZX",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3918",
        chapterCount: 117
    },
    {
        id: "adopted_by_humans",
        title: "Adopted By Humans",
        author: "endersgame69",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4210",
        chapterCount: 113
    },
    {
        id: "retribution_engine",
        title: "Retribution Engine",
        author: "Guncaster",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3681",
        chapterCount: 106
    },
    {
        id: "small_exploits_2",
        title: "Small Exploits",
        author: "Engr00",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3080",
        chapterCount: 104
    },
    {
        id: "mass_effect",
        title: "Mass Effect",
        author: "LittleSeraphim",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2628",
        chapterCount: 100
    },
    {
        id: "if_at_first_you_don_t_succeed",
        title: "If At First You Don't Succeed",
        author: "In_Yellow_Clad",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4655",
        chapterCount: 97
    },
    {
        id: "the_cycle_2",
        title: "The Cycle",
        author: "night_chill",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2278",
        chapterCount: 95
    },
    {
        id: "the_strongest_fencer_doesn_t_use",
        title: "The Strongest Fencer Doesn't Use",
        author: "DropShotEpee",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3116",
        chapterCount: 93
    },
    {
        id: "the_plague_doctor_2",
        title: "The Plague Doctor",
        author: "TheMaskedOne2807",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3598",
        chapterCount: 92
    },
    {
        id: "an_otherworldly_scholar",
        title: "An Otherworldly Scholar",
        author: "ralo_ramone",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4982",
        chapterCount: 91
    },
    {
        id: "troublemakers",
        title: "Troublemakers",
        author: "teller_of_tall_tales",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5141",
        chapterCount: 87
    },
    {
        id: "the_autumn_war",
        title: "The Autumn War",
        author: "Snekguy",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4115",
        chapterCount: 85
    },
    {
        id: "snow",
        title: "Snow",
        author: "iridael",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3412",
        chapterCount: 84
    },
    {
        id: "the_egixus_war_2",
        title: "The Egixus War",
        author: "Manufacture",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/58",
        chapterCount: 77
    },
    {
        id: "english_magic",
        title: "English Magic",
        author: "IvorFreyrsson",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4467",
        chapterCount: 77
    },
    {
        id: "reliquary_of_dawn",
        title: "Reliquary of Dawn",
        author: "Arceroth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2219",
        chapterCount: 76
    },
    {
        id: "the_birth_of_fantasy",
        title: "The Birth of Fantasy",
        author: "Daphonic",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3642",
        chapterCount: 74
    },
    {
        id: "a_robotic_hivemind_for_a_dungeon",
        title: "A Robotic Hivemind for a Dungeon",
        author: "Aware-Material507",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4813",
        chapterCount: 74
    },
    {
        id: "last_of_the_defenders_2",
        title: "Last of the Defenders",
        author: "PutridBite",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4768",
        chapterCount: 70
    },
    {
        id: "life_of_a_predator",
        title: "Life of a Predator",
        author: "ThatGuyBob0101",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4038",
        chapterCount: 70
    },
    {
        id: "ouroboros",
        title: "Ouroboros",
        author: "XSevenSins",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3058",
        chapterCount: 68
    },
    {
        id: "quod_olim_erat",
        title: "Quod Olim Erat",
        author: "LiseEclaire",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2577",
        chapterCount: 64
    },
    {
        id: "we_thought_the_work_was_done",
        title: "We Thought the Work Was Done",
        author: "Risesohigh33",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3824",
        chapterCount: 64
    },
    {
        id: "sins_of_the_father",
        title: "Sins of the Father",
        author: "Objective_Campaign82",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4650",
        chapterCount: 63
    },
    {
        id: "together_to_the_stars",
        title: "Together to the Stars",
        author: "In_Yellow_Clad",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4366",
        chapterCount: 63
    },
    {
        id: "chronicles_of_a_traveler",
        title: "Chronicles of a Traveler",
        author: "Arceroth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3261",
        chapterCount: 61
    },
    {
        id: "sharper_than_a_serpent_s_tooth_2",
        title: "Sharper Than A Serpent's Tooth",
        author: "Hewholooksskyward",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4840",
        chapterCount: 61
    },
    {
        id: "aris_cretu_2",
        title: "Aris Cretu",
        author: "Necrontyr525",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1116",
        chapterCount: 60
    },
    {
        id: "cryoverse",
        title: "Cryoverse",
        author: "Klokinator",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2263",
        chapterCount: 59
    },
    {
        id: "3_wishes",
        title: "3 wishes",
        author: "iridael",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4178",
        chapterCount: 59
    },
    {
        id: "nanowrimo",
        title: "NaNoWriMo",
        author: "Necrontyr525",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1218",
        chapterCount: 57
    },
    {
        id: "an_outcast_in_another_world_2",
        title: "An Outcast In Another World",
        author: "Determination7",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2796",
        chapterCount: 57
    },
    {
        id: "building_of_ashenvale",
        title: "Building of Ashenvale",
        author: "BattleSneeze",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/100",
        chapterCount: 57
    },
    {
        id: "empire_rising",
        title: "Empire Rising",
        author: "SynthoStellar",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2490",
        chapterCount: 55
    },
    {
        id: "the_cassandrian_theory",
        title: "The Cassandrian Theory",
        author: "LiseEclaire",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4050",
        chapterCount: 54
    },
    {
        id: "super_science",
        title: "Super Science",
        author: "DoctorSuperZero",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4916",
        chapterCount: 52
    },
    {
        id: "first_contact_procedures",
        title: "First Contact Procedures",
        author: "1PicklestheDrummer",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3945",
        chapterCount: 52
    },
    {
        id: "fungeoneer",
        title: "Fungeoneer",
        author: "PistolShrimpWrites",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4172",
        chapterCount: 52
    },
    {
        id: "material_differences_2",
        title: "Material Differences",
        author: "RegalLegalEagle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1357",
        chapterCount: 51
    },
    {
        id: "when_worlds_collide_2",
        title: "When Worlds Collide",
        author: "morbiusgreen",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/990",
        chapterCount: 51
    },
    {
        id: "tome_of_the_mind",
        title: "Tome of the Mind",
        author: "th3frozenpriest",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3352",
        chapterCount: 50
    },
    {
        id: "a_teenage_death_commando_goes_to_school",
        title: "A teenage death commando goes to school",
        author: "ralo_ramone",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3645",
        chapterCount: 50
    },
    {
        id: "benevolent_evil",
        title: "Benevolent Evil",
        author: "_Sky__",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2513",
        chapterCount: 49
    },
    {
        id: "fractal_contact",
        title: "Fractal Contact",
        author: "LiseEclaire",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5279",
        chapterCount: 49
    },
    {
        id: "darkrunner",
        title: "Darkrunner",
        author: "Feyfyre1",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5044",
        chapterCount: 48
    },
    {
        id: "black_sheep_family",
        title: "Black Sheep Family",
        author: "TheSmogmonsterZX",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5080",
        chapterCount: 48
    },
    {
        id: "deadlier_of_the_species_2",
        title: "Deadlier of the Species",
        author: "Hewholooksskyward",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2484",
        chapterCount: 47
    },
    {
        id: "the_big_oof",
        title: "The Big Oof!",
        author: "duddlered",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4743",
        chapterCount: 47
    },
    {
        id: "the_long_run",
        title: "The Long Run",
        author: "KingoftheRednecks",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5182",
        chapterCount: 47
    },
    {
        id: "human_integration_2",
        title: "Human Integration",
        author: "Lugbor",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4205",
        chapterCount: 46
    },
    {
        id: "a_pirate_s_life_2",
        title: "A Pirate's Life",
        author: "Hewholooksskyward",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4370",
        chapterCount: 46
    },
    {
        id: "noblebright",
        title: "Noblebright",
        author: "RavensDagger",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4631",
        chapterCount: 46
    },
    {
        id: "memories_of_creature_88_2",
        title: "Memories of Creature 88",
        author: "RegalLegalEagle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/259",
        chapterCount: 46
    },
    {
        id: "so_others_may_live_2",
        title: "So Others May Live",
        author: "Hewholooksskyward",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3855",
        chapterCount: 46
    },
    {
        id: "soulless_victories",
        title: "Soulless Victories",
        author: "Susceptive",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2655",
        chapterCount: 46
    },
    {
        id: "from_the_past_2",
        title: "From the past",
        author: "iridael",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/20",
        chapterCount: 46
    },
    {
        id: "the_war_to_end_all_wars",
        title: "The War to End All Wars",
        author: "ZakkaryGreenwell",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4380",
        chapterCount: 46
    },
    {
        id: "forged_in_valhallah",
        title: "Forged in Valhallah",
        author: "deathB4dessert",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4993",
        chapterCount: 45
    },
    {
        id: "a_curious_discovery_2",
        title: "A Curious Discovery",
        author: "RipHunterIsMyCopilot",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/938",
        chapterCount: 44
    },
    {
        id: "instinct_2",
        title: "Instinct",
        author: "Ravenredd65",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4355",
        chapterCount: 44
    },
    {
        id: "a_tinker_s_damn_2",
        title: "A Tinker's Damn",
        author: "Hewholooksskyward",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2097",
        chapterCount: 44
    },
    {
        id: "in_the_blink_of_an_eye_2",
        title: "In The Blink Of An Eye",
        author: "Hewholooksskyward",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2994",
        chapterCount: 44
    },
    {
        id: "burners_unleashed",
        title: "Burners Unleashed",
        author: "LittleSeraphim",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3764",
        chapterCount: 42
    },
    {
        id: "the_necromancer_s_bond",
        title: "The Necromancer's Bond",
        author: "IvorFreyrsson",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4679",
        chapterCount: 42
    },
    {
        id: "the_heart_of_zeforo",
        title: "The Heart of Zeforo",
        author: "Aeogeus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4634",
        chapterCount: 42
    },
    {
        id: "humans_don_t_make_good_pets_2",
        title: "Humans don't Make Good Pets",
        author: "guidosbestfriend",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/155",
        chapterCount: 41
    },
    {
        id: "we_remember",
        title: "We Remember",
        author: "Foreign-Affect7871",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4176",
        chapterCount: 41
    },
    {
        id: "the_anomalies",
        title: "the anomalies",
        author: "Shadeskira",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4654",
        chapterCount: 41
    },
    {
        id: "the_last_precursor_2",
        title: "The Last Precursor",
        author: "Klokinator",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2283",
        chapterCount: 40
    },
    {
        id: "knights_of_the_partition",
        title: "Knights of the Partition",
        author: "DestroyatronMk8",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4255",
        chapterCount: 40
    },
    {
        id: "eagle_springs_stories",
        title: "Eagle Springs Stories",
        author: "cmdr_shadowstalker",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4227",
        chapterCount: 39
    },
    {
        id: "the_spacer",
        title: "The Spacer",
        author: "Jackviator",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4842",
        chapterCount: 39
    },
    {
        id: "the_bridge_2",
        title: "The Bridge",
        author: "LeoDuhVinci",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/772",
        chapterCount: 38
    },
    {
        id: "death_by_chocolate",
        title: "Death by Chocolate",
        author: "TheDeliciousMeats",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3298",
        chapterCount: 37
    },
    {
        id: "the_burning_ones",
        title: "The Burning Ones",
        author: "-TheLostTimeLord-",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4512",
        chapterCount: 36
    },
    {
        id: "the_father_that_leads",
        title: "The Father that Leads",
        author: "TheSmogmonsterZX",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4041",
        chapterCount: 35
    },
    {
        id: "contractors_2",
        title: "Contractors",
        author: "Alpha-Sierra-Charlie",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4526",
        chapterCount: 35
    },
    {
        id: "lost_souls",
        title: "Lost Souls",
        author: "XSevenSins",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4114",
        chapterCount: 34
    },
    {
        id: "a_stranger_in_paradise",
        title: "A Stranger in Paradise",
        author: "HellsKitchenSink",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/941",
        chapterCount: 34
    },
    {
        id: "servant_of_the_dead_god",
        title: "Servant of the Dead God",
        author: "njvikesfan01",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4278",
        chapterCount: 34
    },
    {
        id: "true_colors",
        title: "True Colors",
        author: "EvilMonkeyPaw",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4581",
        chapterCount: 34
    },
    {
        id: "the_skill_thief_s_canvas",
        title: "The Skill Thief's Canvas",
        author: "Determination7",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4984",
        chapterCount: 34
    },
    {
        id: "song_of_the_elder_gods",
        title: "Song of the Elder Gods",
        author: "In_Yellow_Clad",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4296",
        chapterCount: 34
    },
    {
        id: "grimoires",
        title: "Grimoires",
        author: "duddlered",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5214",
        chapterCount: 33
    },
    {
        id: "solar_research_council_x_mass_effect",
        title: "Solar Research Council x Mass Effect",
        author: "Unternehmungen",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2604",
        chapterCount: 33
    },
    {
        id: "knighttime_audio_narration",
        title: "KnightTime audio narration",
        author: "Knight-142",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2792",
        chapterCount: 33
    },
    {
        id: "a_strange_opportunity",
        title: "A Strange Opportunity",
        author: "Khenal",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3647",
        chapterCount: 33
    },
    {
        id: "soldiers_of_sol_2",
        title: "Soldiers of Sol",
        author: "iridael",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/61",
        chapterCount: 33
    },
    {
        id: "horrors_of_the_asteria",
        title: "Horrors of the Asteria",
        author: "Ford9863",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4417",
        chapterCount: 32
    },
    {
        id: "tower_of_worlds",
        title: "Tower of Worlds",
        author: "Arceroth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4530",
        chapterCount: 32
    },
    {
        id: "jenkinsverse",
        title: "Jenkinsverse",
        author: "GoingAnywhereButHere",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/420",
        chapterCount: 31
    },
    {
        id: "men_of_sol_2",
        title: "Men of Sol",
        author: "iridael",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/301",
        chapterCount: 31
    },
    {
        id: "clint_stone",
        title: "Clint Stone",
        author: "someguynamedted",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/131",
        chapterCount: 30
    },
    {
        id: "the_last_terran",
        title: "The Last Terran",
        author: "arclightmagus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4566",
        chapterCount: 29
    },
    {
        id: "contain",
        title: "Contain",
        author: "SCPunited",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3360",
        chapterCount: 29
    },
    {
        id: "scorpion",
        title: "Scorpion",
        author: "Burden-the-Quester",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3995",
        chapterCount: 29
    },
    {
        id: "deadworlders",
        title: "Deadworlders",
        author: "Madnyth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2156",
        chapterCount: 29
    },
    {
        id: "serial",
        title: "Serial",
        author: "Downfall347",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/775",
        chapterCount: 29
    },
    {
        id: "in_the_shadows_of_silverspire",
        title: "In the Shadows of Silverspire",
        author: "jldew",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3453",
        chapterCount: 29
    },
    {
        id: "the_weight_we_carry_2",
        title: "The Weight We Carry",
        author: "RegalLegalEagle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/621",
        chapterCount: 28
    },
    {
        id: "flight_of_the_war_witch",
        title: "Flight of the War Witch",
        author: "Ethereal_Stars_7",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4547",
        chapterCount: 28
    },
    {
        id: "how_we_stopped_the_destroyers",
        title: "How We Stopped the Destroyers",
        author: "BoterBug",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4149",
        chapterCount: 28
    },
    {
        id: "halo",
        title: "Halo",
        author: "LittleSeraphim",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3508",
        chapterCount: 27
    },
    {
        id: "a_hellish_offer",
        title: "A Hellish Offer",
        author: "IvorFreyrsson",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5014",
        chapterCount: 27
    },
    {
        id: "you_only_die_twice",
        title: "You Only Die Twice",
        author: "Strong__Horse",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4074",
        chapterCount: 27
    },
    {
        id: "awaken",
        title: "Awaken",
        author: "Cool_ball999",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4528",
        chapterCount: 26
    },
    {
        id: "the_void",
        title: "The Void",
        author: "KingoftheRednecks",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5029",
        chapterCount: 26
    },
    {
        id: "molossus",
        title: "Molossus",
        author: "Frank_Leroux",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4911",
        chapterCount: 26
    },
    {
        id: "exiles_2",
        title: "Exiles",
        author: "In_sa_ni_ty",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3577",
        chapterCount: 25
    },
    {
        id: "hyperstitious",
        title: "Hyperstitious",
        author: "DoctorSuperZero",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5056",
        chapterCount: 25
    },
    {
        id: "like_rats",
        title: "Like Rats",
        author: "Ethereal_Stars_7",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4443",
        chapterCount: 24
    },
    {
        id: "jverse",
        title: "Jverse",
        author: "a_story_from_an_anon",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1151",
        chapterCount: 24
    },
    {
        id: "pacifist",
        title: "Pacifist",
        author: "PSHoffman",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4944",
        chapterCount: 24
    },
    {
        id: "rebirth_of_the_sword",
        title: "Rebirth of the Sword",
        author: "MisterCIA",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1212",
        chapterCount: 24
    },
    {
        id: "the_apartment",
        title: "The Apartment",
        author: "arclightmagus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3172",
        chapterCount: 24
    },
    {
        id: "until_the_work_is_done",
        title: "Until the Work is Done",
        author: "Risesohigh33",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3426",
        chapterCount: 23
    },
    {
        id: "dashed_glory",
        title: "Dashed Glory",
        author: "Gunnybear",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/792",
        chapterCount: 23
    },
    {
        id: "well_that_s_bad",
        title: "Well, That's Bad",
        author: "IndistinguishableLaw",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1173",
        chapterCount: 23
    },
    {
        id: "wunderwaffe_2",
        title: "Wunderwaffe",
        author: "davisao11",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1599",
        chapterCount: 22
    },
    {
        id: "the_big_yoink",
        title: "The Big Yoink",
        author: "Frank_Leroux",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1701",
        chapterCount: 22
    },
    {
        id: "only_one_road",
        title: "Only One Road",
        author: "Luckas_Buck",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1505",
        chapterCount: 21
    },
    {
        id: "sol_survivor",
        title: "Sol Survivor",
        author: "FerroMancer",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4387",
        chapterCount: 21
    },
    {
        id: "skin_hunger",
        title: "Skin Hunger",
        author: "HellsKitchenSink",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1204",
        chapterCount: 21
    },
    {
        id: "nop_fanfic",
        title: "NOP fanfic",
        author: "SavingsSyllabub7788",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4709",
        chapterCount: 21
    },
    {
        id: "skyrunner",
        title: "Skyrunner",
        author: "Rantarian",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2414",
        chapterCount: 21
    },
    {
        id: "coronation_day",
        title: "Coronation Day",
        author: "SabatonBabylon",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1864",
        chapterCount: 21
    },
    {
        id: "the_black_ship_2",
        title: "The Black Ship",
        author: "EkhidnaWritez",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5363",
        chapterCount: 20
    },
    {
        id: "yesterday",
        title: "Yesterday",
        author: "Righteous_Fury224",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4714",
        chapterCount: 20
    },
    {
        id: "the_prototype_2",
        title: "The Prototype",
        author: "retrobolic",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3612",
        chapterCount: 20
    },
    {
        id: "soldier_of_heaven",
        title: "Soldier of Heaven",
        author: "deathB4dessert",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4718",
        chapterCount: 20
    },
    {
        id: "invade_your_planet",
        title: "Invade Your Planet",
        author: "spindizzy_wizard",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2546",
        chapterCount: 20
    },
    {
        id: "humanity_s_place",
        title: "Humanity's Place",
        author: "CupOSunshine",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1105",
        chapterCount: 20
    },
    {
        id: "council_of_ages",
        title: "Council of Ages",
        author: "IvorFreyrsson",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4661",
        chapterCount: 20
    },
    {
        id: "how_did_earth_fall_2",
        title: "How did Earth fall",
        author: "iammakeing_itup",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4670",
        chapterCount: 20
    },
    {
        id: "the_builder_s_legacy",
        title: "The Builder's Legacy",
        author: "AnUnspeakableCoconut",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2553",
        chapterCount: 20
    },
    {
        id: "the_galactic_salt_road",
        title: "The Galactic Salt Road",
        author: "Soopah_Fly",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/806",
        chapterCount: 20
    },
    {
        id: "godhunter",
        title: "Godhunter",
        author: "In_Yellow_Clad",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4249",
        chapterCount: 20
    },
    {
        id: "smolive_garden",
        title: "Smolive Garden",
        author: "Tinyprancinghorse",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3636",
        chapterCount: 19
    },
    {
        id: "rise",
        title: "Rise",
        author: "FredtheFailLord",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/442",
        chapterCount: 19
    },
    {
        id: "needle_s_eye",
        title: "Needle's Eye",
        author: "PepperAntique",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5355",
        chapterCount: 19
    },
    {
        id: "phantom_of_the_revolution",
        title: "Phantom of the Revolution",
        author: "BeaverFur",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4372",
        chapterCount: 19
    },
    {
        id: "the_sorcerer_s_new_apprentice",
        title: "The Sorcerer's New Apprentice",
        author: "Jgrupe",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3434",
        chapterCount: 19
    },
    {
        id: "croatoan_earth",
        title: "Croatoan, Earth",
        author: "Turtlez_Rawck",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4019",
        chapterCount: 19
    },
    {
        id: "letters_from_the_front_2",
        title: "Letters from the front",
        author: "czs5056",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/449",
        chapterCount: 19
    },
    {
        id: "silver_scales_blue_skies",
        title: "Silver Scales, Blue Skies",
        author: "punnynfunny",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4331",
        chapterCount: 19
    },
    {
        id: "the_god_machine",
        title: "The God Machine",
        author: "LordHenry7898",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3843",
        chapterCount: 18
    },
    {
        id: "a_bestiary_of_earth",
        title: "A Bestiary of Earth",
        author: "SnooBooks1701",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2309",
        chapterCount: 18
    },
    {
        id: "a_human_scammed_the_god_of_scammers",
        title: "A human scammed the god of scammers",
        author: "Mercury_the_dealer",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3724",
        chapterCount: 18
    },
    {
        id: "enigma",
        title: "Enigma",
        author: "OpinionatedIMO",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1924",
        chapterCount: 18
    },
    {
        id: "the_winter_world",
        title: "The Winter World",
        author: "Objective_Campaign82",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3850",
        chapterCount: 18
    },
    {
        id: "smol",
        title: "SMOL",
        author: "Frank_Leroux",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2467",
        chapterCount: 18
    },
    {
        id: "vengeance",
        title: "Vengeance",
        author: "WingedDrake",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2921",
        chapterCount: 17
    },
    {
        id: "patient_zero",
        title: "Patient Zero",
        author: "NorthDT",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1317",
        chapterCount: 17
    },
    {
        id: "the_tomb_world",
        title: "The Tomb World",
        author: "Objective_Campaign82",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4730",
        chapterCount: 17
    },
    {
        id: "men_in_anti",
        title: "Men in Anti",
        author: "Petrified_Lioness",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3135",
        chapterCount: 17
    },
    {
        id: "gods_of_war_3",
        title: "Gods of War",
        author: "BattleSneeze",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/85",
        chapterCount: 17
    },
    {
        id: "principle_of_disproportionality",
        title: "Principle Of Disproportionality",
        author: "Cao_Bynes",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2741",
        chapterCount: 17
    },
    {
        id: "the_legacy_of_man",
        title: "The Legacy of Man",
        author: "SynthoStellar",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2350",
        chapterCount: 16
    },
    {
        id: "planet_obscura",
        title: "Planet Obscura",
        author: "It_s_pronounced_gif",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/857",
        chapterCount: 16
    },
    {
        id: "dragon_s_breath",
        title: "Dragon's Breath",
        author: "Alarmed-Painting-121",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3716",
        chapterCount: 16
    },
    {
        id: "endeavor_to_be_great_little_humans",
        title: "Endeavor To Be Great, Little Humans!",
        author: "Some_Guy_Existing",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5061",
        chapterCount: 16
    },
    {
        id: "old_terran_soul_2",
        title: "Old Terran Soul",
        author: "NorSec1987",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3854",
        chapterCount: 16
    },
    {
        id: "humanity",
        title: "Humanity",
        author: "resonatingfury",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/675",
        chapterCount: 16
    },
    {
        id: "flash_of_blades_rumble_of_guns",
        title: "Flash of Blades, Rumble of Guns",
        author: "radius55",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/577",
        chapterCount: 15
    },
    {
        id: "the_second_interaction",
        title: "The Second Interaction",
        author: "Hopefully_Likeable",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1266",
        chapterCount: 15
    },
    {
        id: "gnosis",
        title: "Gnosis",
        author: "Le_Grim",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2701",
        chapterCount: 15
    },
    {
        id: "the_void_hunt",
        title: "The Void Hunt",
        author: "KingoftheRednecks",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4990",
        chapterCount: 15
    },
    {
        id: "alliance",
        title: "Alliance",
        author: "PuzzleheadedCharge4",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2276",
        chapterCount: 15
    },
    {
        id: "charlatans",
        title: "Charlatans",
        author: "darkPrince010",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5367",
        chapterCount: 15
    },
    {
        id: "jverse_2",
        title: "Jverse",
        author: "qerodar",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1296",
        chapterCount: 15
    },
    {
        id: "unwilling_ambassador",
        title: "Unwilling Ambassador",
        author: "Aumnayan",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4493",
        chapterCount: 15
    },
    {
        id: "grinning_skull",
        title: "Grinning Skull",
        author: "RegalLegalEagle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/541",
        chapterCount: 15
    },
    {
        id: "human_artificer",
        title: "Human Artificer",
        author: "In_sa_ni_ty_BACK",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4276",
        chapterCount: 14
    },
    {
        id: "new_horizons_4",
        title: "New Horizons",
        author: "Zairanthia",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1913",
        chapterCount: 14
    },
    {
        id: "picking_up_the_pieces",
        title: "Picking up the Pieces",
        author: "Sypher597",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/952",
        chapterCount: 14
    },
    {
        id: "the_last_one_2",
        title: "The Last One",
        author: "Falas-Balar",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4946",
        chapterCount: 14
    },
    {
        id: "when_the_stars_died",
        title: "When The Stars Died",
        author: "Br0k3nAnth3m",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2533",
        chapterCount: 14
    },
    {
        id: "iron_and_gunnery",
        title: "Iron and Gunnery",
        author: "IncredibilisHoh",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3888",
        chapterCount: 14
    },
    {
        id: "a_starship_odyssey",
        title: "A Starship Odyssey",
        author: "FermisFolly",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3429",
        chapterCount: 14
    },
    {
        id: "stranded_4",
        title: "Stranded",
        author: "Reyorin",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2899",
        chapterCount: 14
    },
    {
        id: "we_might_just_need_to_make_our_own_federation_2",
        title: "We might just need to make our own federation",
        author: "thatoneshotgunmain",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2838",
        chapterCount: 13
    },
    {
        id: "the_lost_ranger",
        title: "The Lost Ranger",
        author: "In_sa_ni_ty",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4086",
        chapterCount: 13
    },
    {
        id: "aelios_online",
        title: "Aelios Online",
        author: "grierks",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1807",
        chapterCount: 13
    },
    {
        id: "jenkinsverse_2",
        title: "Jenkinsverse",
        author: "steampoweredfishcake",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/435",
        chapterCount: 13
    },
    {
        id: "the_history_of_humans_2",
        title: "The History of Humans",
        author: "Dotakin",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/8",
        chapterCount: 13
    },
    {
        id: "tales_from_a_stranded_hero",
        title: "Tales from a Stranded Hero",
        author: "Teulisch",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1418",
        chapterCount: 13
    },
    {
        id: "of_wolves_and_men",
        title: "Of Wolves and Men",
        author: "Zombiep00pZ",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1429",
        chapterCount: 13
    },
    {
        id: "they_saved_us",
        title: "They Saved Us",
        author: "TheNoob950",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3048",
        chapterCount: 13
    },
    {
        id: "hymn_of_elys",
        title: "Hymn of Elys'",
        author: "eutrepe",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1741",
        chapterCount: 12
    },
    {
        id: "gremlins_2",
        title: "Gremlins",
        author: "Mirikon",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2828",
        chapterCount: 12
    },
    {
        id: "monkey_man",
        title: "Monkey Man",
        author: "KronicBoom3",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3958",
        chapterCount: 12
    },
    {
        id: "humans",
        title: "Humans",
        author: "DamagediceDM",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2954",
        chapterCount: 12
    },
    {
        id: "tales_from_the_human_dominion",
        title: "Tales From the Human Dominion",
        author: "FormerCat4883",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4502",
        chapterCount: 12
    },
    {
        id: "stormjar",
        title: "Stormjar",
        author: "LeoDuhVinci",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/725",
        chapterCount: 12
    },
    {
        id: "xcom",
        title: "Xcom",
        author: "ThisIsARealAccountAP",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3173",
        chapterCount: 12
    },
    {
        id: "humanity_reborn",
        title: "Humanity Reborn",
        author: "Arceroth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2284",
        chapterCount: 12
    },
    {
        id: "evolution_cubed",
        title: "Evolution Cubed",
        author: "ThreadofFatee",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4325",
        chapterCount: 12
    },
    {
        id: "displaced",
        title: "Displaced",
        author: "ProfFartBurger",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1235",
        chapterCount: 12
    },
    {
        id: "echos",
        title: "Echos",
        author: "mechakid",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1369",
        chapterCount: 12
    },
    {
        id: "a_glitch_in_the_system",
        title: "A Glitch in the System",
        author: "crumjd",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3356",
        chapterCount: 12
    },
    {
        id: "the_undying_prince",
        title: "The Undying Prince",
        author: "londonlight56",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1190",
        chapterCount: 12
    },
    {
        id: "a_broken_machine",
        title: "A Broken Machine",
        author: "yousureimnotarobot",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4524",
        chapterCount: 12
    },
    {
        id: "gateway",
        title: "Gateway",
        author: "frisk-scp999",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1935",
        chapterCount: 12
    },
    {
        id: "untitled_story",
        title: "Untitled Story",
        author: "AllenMichaels",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1172",
        chapterCount: 12
    },
    {
        id: "payment",
        title: "Payment",
        author: "MementoMori-3",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/687",
        chapterCount: 11
    },
    {
        id: "hell_no",
        title: "Hell No!",
        author: "KronicBoom3",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4263",
        chapterCount: 11
    },
    {
        id: "human_loyalty",
        title: "Human Loyalty",
        author: "Petty_Pretorian",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4186",
        chapterCount: 11
    },
    {
        id: "unto_a_new_land",
        title: "Unto a new land",
        author: "___Jesus__Christ___",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2412",
        chapterCount: 11
    },
    {
        id: "the_phaton_war",
        title: "The Phaton War",
        author: "FivePence",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1082",
        chapterCount: 11
    },
    {
        id: "a_real_demon",
        title: "A Real Demon",
        author: "oxycleans",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3475",
        chapterCount: 11
    },
    {
        id: "the_smol_detective",
        title: "The Smol Detective",
        author: "Frank_Leroux",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1618",
        chapterCount: 11
    },
    {
        id: "stories_from_the_outer_rim",
        title: "Stories from the Outer Rim",
        author: "novatheelf",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2521",
        chapterCount: 11
    },
    {
        id: "empire_sol",
        title: "Empire Sol",
        author: "BattleSneeze",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/32",
        chapterCount: 11
    },
    {
        id: "reclamation_2",
        title: "Reclamation",
        author: "In_Yellow_Clad",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4342",
        chapterCount: 11
    },
    {
        id: "shunted",
        title: "Shunted",
        author: "TheUbiquitousDM",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2987",
        chapterCount: 11
    },
    {
        id: "stranger_among_strangers",
        title: "Stranger among Strangers",
        author: "WegianWarrior",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4591",
        chapterCount: 11
    },
    {
        id: "eden_s_promise",
        title: "Eden's Promise",
        author: "sjanevardsson",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3451",
        chapterCount: 11
    },
    {
        id: "nova_wars",
        title: "Nova Wars",
        author: "Ralts_Bloodthorne",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5579",
        chapterCount: 11
    },
    {
        id: "the_ruins_of_morkedum",
        title: "The Ruins of Morkedum",
        author: "nom_de_plumbus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2570",
        chapterCount: 11
    },
    {
        id: "the_equalizer",
        title: "The Equalizer",
        author: "potato_rocket_05",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2603",
        chapterCount: 11
    },
    {
        id: "forget_me_not",
        title: "Forget me not",
        author: "Vas_",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1769",
        chapterCount: 11
    },
    {
        id: "cafe_stardust",
        title: "Cafe Stardust",
        author: "BioBass759",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2937",
        chapterCount: 11
    },
    {
        id: "the_grey_riders",
        title: "The Grey Riders",
        author: "M59Gar",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/859",
        chapterCount: 11
    },
    {
        id: "magi",
        title: "Magi",
        author: "thedodging6",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3117",
        chapterCount: 10
    },
    {
        id: "playground_of_the_gods",
        title: "Playground of the Gods",
        author: "IndolentMess",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2805",
        chapterCount: 10
    },
    {
        id: "orion_star",
        title: "Orion Star",
        author: "x_polybius_x",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2511",
        chapterCount: 10
    },
    {
        id: "the_ones_that_don_t_fit",
        title: "The ones that don't fit",
        author: "TrulyVisceral",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3656",
        chapterCount: 10
    },
    {
        id: "sacrifices_2",
        title: "Sacrifices",
        author: "shoguncdn",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1514",
        chapterCount: 10
    },
    {
        id: "the_halfhearted_hunter",
        title: "The Halfhearted Hunter",
        author: "EpicMyth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2702",
        chapterCount: 10
    },
    {
        id: "the_encyclopedia_of_human_exceptionalism",
        title: "The Encyclopedia of Human Exceptionalism",
        author: "LordDanteHFY",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/232",
        chapterCount: 10
    },
    {
        id: "surviving_in_otherworld",
        title: "Surviving in Otherworld",
        author: "DerrylliusKlyne",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1541",
        chapterCount: 10
    },
    {
        id: "msas",
        title: "MSAS",
        author: "ExaltedAi",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5370",
        chapterCount: 10
    },
    {
        id: "pursuit_predation_2",
        title: "Pursuit Predation",
        author: "thunderbird89",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3346",
        chapterCount: 10
    },
    {
        id: "vadamund",
        title: "Vadamund",
        author: "ph3nf1x",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1093",
        chapterCount: 10
    },
    {
        id: "eve_incursion_2",
        title: "Eve Incursion",
        author: "Haidere1988",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4061",
        chapterCount: 10
    },
    {
        id: "game_of_deception",
        title: "Game of deception",
        author: "Stumpy-JIm",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3211",
        chapterCount: 10
    },
    {
        id: "the_humanist",
        title: "The Humanist",
        author: "Toaster_AssassinPope",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3847",
        chapterCount: 10
    },
    {
        id: "home_is_where_you_make_it",
        title: "Home Is Where You Make It",
        author: "fluffylizards",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2909",
        chapterCount: 10
    },
    {
        id: "bloodlines_2",
        title: "Bloodlines",
        author: "Necrontyr525",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/842",
        chapterCount: 10
    },
    {
        id: "the_old_and_the_young",
        title: "The old and the young",
        author: "sharkeyandgeorge",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2119",
        chapterCount: 10
    },
    {
        id: "augmented",
        title: "Augmented",
        author: "Iustinianus_I",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1099",
        chapterCount: 10
    },
    {
        id: "history_of_the_sol_war_audio_recording",
        title: "History of the Sol War Audio Recording",
        author: "EveryDayLazyDay",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2543",
        chapterCount: 10
    },
    {
        id: "toc_short_story",
        title: "TOC Short Story",
        author: "Frostdraken",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4045",
        chapterCount: 10
    },
    {
        id: "best_friend",
        title: "Best Friend",
        author: "BattleSneeze",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/74",
        chapterCount: 10
    },
    {
        id: "the_ones_from_beyond",
        title: "The Ones From Beyond",
        author: "General_Havan",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/901",
        chapterCount: 10
    },
    {
        id: "earth",
        title: "Earth",
        author: "Cao_Bynes",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2737",
        chapterCount: 10
    },
    {
        id: "uplift_protocol_2",
        title: "Uplift Protocol",
        author: "iamcave76",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1560",
        chapterCount: 10
    },
    {
        id: "the_horrors_of_a_desperate_species_2",
        title: "The horrors of a desperate species",
        author: "Novirtue",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/38",
        chapterCount: 10
    },
    {
        id: "the_collective_2",
        title: "The Collective",
        author: "supersonicsacha",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1332",
        chapterCount: 10
    },
    {
        id: "golden_eyes_2",
        title: "Golden Eyes 2",
        author: "Terwin3",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1730",
        chapterCount: 10
    },
    {
        id: "resurgence_of_defiance",
        title: "Resurgence of Defiance",
        author: "SophieQuirk",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5236",
        chapterCount: 9
    },
    {
        id: "hell_s_kitchen_sink",
        title: "Hell's Kitchen Sink",
        author: "HellsKitchenSink",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/922",
        chapterCount: 9
    },
    {
        id: "humans_don_t_do_magic",
        title: "Humans don't do magic",
        author: "peaceman14",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4639",
        chapterCount: 9
    },
    {
        id: "spartan_company",
        title: "Spartan Company",
        author: "one-rambling-idiot",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/550",
        chapterCount: 9
    },
    {
        id: "hard_reset",
        title: "HARD RESET",
        author: "Gumwars",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2795",
        chapterCount: 9
    },
    {
        id: "space_crusader",
        title: "Space Crusader",
        author: "D0WNGR4D3",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4831",
        chapterCount: 9
    },
    {
        id: "meeting_an_alien",
        title: "Meeting an Alien",
        author: "Massive_Upstairs_407",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4413",
        chapterCount: 9
    },
    {
        id: "assault_on_orion_i",
        title: "Assault on Orion I",
        author: "TheRealFedral",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1721",
        chapterCount: 9
    },
    {
        id: "the_last_regiment",
        title: "The Last Regiment",
        author: "radius55",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/445",
        chapterCount: 9
    },
    {
        id: "beyond_nature",
        title: "Beyond Nature",
        author: "jesterra54",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4390",
        chapterCount: 9
    },
    {
        id: "diary_of_a_bounty_hunter",
        title: "Diary of a bounty hunter",
        author: "unimportantquestitem",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5531",
        chapterCount: 9
    },
    {
        id: "sweater_weather",
        title: "Sweater Weather",
        author: "Braquen",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4717",
        chapterCount: 9
    },
    {
        id: "eodem",
        title: "Eodem",
        author: "Starmark_115",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2643",
        chapterCount: 9
    },
    {
        id: "video",
        title: "Video",
        author: "Kubrick_Fan",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/557",
        chapterCount: 9
    },
    {
        id: "the_species_that_refused_to_die_2",
        title: "The species that refused to die",
        author: "nogoodusernamesleft8",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/11",
        chapterCount: 9
    },
    {
        id: "goons_incorporated",
        title: "Goons Incorporated",
        author: "sharkeyandgeorge",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2023",
        chapterCount: 9
    },
    {
        id: "from_beyond_the_boiling_veil",
        title: "From beyond the boiling veil",
        author: "Balrog442",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3251",
        chapterCount: 9
    },
    {
        id: "galaxy_of_glass",
        title: "Galaxy of Glass",
        author: "StaceyOutThere",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1994",
        chapterCount: 9
    },
    {
        id: "why_did_it_have_to_be_a_human",
        title: "Why did it have to be a human?",
        author: "RaceHarded",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2775",
        chapterCount: 9
    },
    {
        id: "stars_apart",
        title: "Stars Apart",
        author: "Lui_Le_Diamond",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2760",
        chapterCount: 9
    },
    {
        id: "lost_soldier",
        title: "Lost Soldier",
        author: "Alinator98",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3538",
        chapterCount: 9
    },
    {
        id: "the_solar_tetrarchy",
        title: "The Solar Tetrarchy",
        author: "AClegg1",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/298",
        chapterCount: 9
    },
    {
        id: "end_of_the_line",
        title: "End Of The Line",
        author: "Upper-Mountain-5575",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4564",
        chapterCount: 9
    },
    {
        id: "journey_of_the_ytteris",
        title: "Journey of the Ytteris",
        author: "Commandermartin",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/708",
        chapterCount: 9
    },
    {
        id: "the_alien_species_that_unraveled_the_horrors_of_the_5th_dimension",
        title: "The Alien Species that unraveled the horrors of the 5th dimension",
        author: "Novirtue",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/341",
        chapterCount: 9
    },
    {
        id: "no_one_s_hero",
        title: "No One's Hero",
        author: "eraticationater",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/946",
        chapterCount: 9
    },
    {
        id: "beyond_the_rim",
        title: "Beyond the rim",
        author: "BattleSneeze",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/45",
        chapterCount: 9
    },
    {
        id: "deicide",
        title: "Deicide",
        author: "Bennykill709",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3317",
        chapterCount: 9
    },
    {
        id: "irregulars",
        title: "Irregulars",
        author: "Arivael",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2419",
        chapterCount: 9
    },
    {
        id: "nightmares_in_the_light",
        title: "Nightmares in the Light",
        author: "MackFenzie",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4943",
        chapterCount: 9
    },
    {
        id: "skin_of_the_enemy",
        title: "Skin of the enemy",
        author: "Paragon_Nostos",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2969",
        chapterCount: 9
    },
    {
        id: "dino_dommies",
        title: "Dino Dommies",
        author: "Environmental-Wish53",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4440",
        chapterCount: 9
    },
    {
        id: "tales_of_tenacity",
        title: "Tales of Tenacity",
        author: "Nusszucker",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2348",
        chapterCount: 9
    },
    {
        id: "democratization",
        title: "Democratization",
        author: "K-Robe",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1270",
        chapterCount: 9
    },
    {
        id: "to_tame_living_gods",
        title: "To tame living gods",
        author: "British_Tea_Company",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/554",
        chapterCount: 9
    },
    {
        id: "humans_are_gods",
        title: "Humans Are Gods",
        author: "TyroTurtle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5063",
        chapterCount: 9
    },
    {
        id: "the_grinning_skull_2",
        title: "The Grinning Skull",
        author: "RegalLegalEagle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/524",
        chapterCount: 9
    },
    {
        id: "the_seven",
        title: "The Seven",
        author: "filsonovic",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1862",
        chapterCount: 9
    },
    {
        id: "shiprelations",
        title: "Shiprelations",
        author: "Animakitty",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3514",
        chapterCount: 8
    },
    {
        id: "escape_velocity",
        title: "Escape Velocity",
        author: "semiloki",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2656",
        chapterCount: 8
    },
    {
        id: "when_i_was_a_child_the_ship_arrived",
        title: "When I was a child, the ship arrived",
        author: "Iaintrightthislife",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5089",
        chapterCount: 8
    },
    {
        id: "gentle_hearts_of_monstrous_creatures",
        title: "Gentle hearts of monstrous creatures",
        author: "JerrePenguin",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3932",
        chapterCount: 8
    },
    {
        id: "a_faithful_encounter",
        title: "A faithful Encounter",
        author: "Decanus_severus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/954",
        chapterCount: 8
    },
    {
        id: "inter",
        title: "Inter",
        author: "dragon_slayer97",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2956",
        chapterCount: 8
    },
    {
        id: "the_skethian",
        title: "The Skethian",
        author: "Plus_Society_9547",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2552",
        chapterCount: 8
    },
    {
        id: "mostly_harmful",
        title: "Mostly Harmful",
        author: "naraic42",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1109",
        chapterCount: 8
    },
    {
        id: "an_unexpected_mage",
        title: "An unexpected Mage",
        author: "DerpyWriting68",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2118",
        chapterCount: 8
    },
    {
        id: "the_last_angel_2",
        title: "The Last Angel",
        author: "tragicshark",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/779",
        chapterCount: 8
    },
    {
        id: "worthy",
        title: "Worthy",
        author: "ascandalia",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/908",
        chapterCount: 8
    },
    {
        id: "imagine",
        title: "Imagine",
        author: "OpinionatedIMO",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1947",
        chapterCount: 8
    },
    {
        id: "am_ende_mit_meinem_latein",
        title: "Am Ende mit meinem Latein",
        author: "PubliusDeciusMus279",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2676",
        chapterCount: 8
    },
    {
        id: "we_ve_discovered_the_4th_sentient_species_in_the_galaxy_2",
        title: "We've discovered the 4th sentient species in the galaxy",
        author: "Ninety9Balloons",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/738",
        chapterCount: 8
    },
    {
        id: "providence",
        title: "Providence",
        author: "communistred",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3380",
        chapterCount: 8
    },
    {
        id: "beauty_is_the_beast",
        title: "Beauty is the Beast",
        author: "Master-Appointment66",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2386",
        chapterCount: 8
    },
    {
        id: "nightfall",
        title: "Nightfall",
        author: "NomranaEst",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/300",
        chapterCount: 8
    },
    {
        id: "humans_those_bad",
        title: "Humans Those Bad",
        author: "LordDanteHFY",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/170",
        chapterCount: 8
    },
    {
        id: "a_routine_first_contact_operation",
        title: "A routine first contact operation",
        author: "Johnny917",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2422",
        chapterCount: 8
    },
    {
        id: "runaway",
        title: "Runaway",
        author: "HFYnewb",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/970",
        chapterCount: 8
    },
    {
        id: "pharas",
        title: "Pharas",
        author: "thalgrond",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1715",
        chapterCount: 8
    },
    {
        id: "humanity_asunder",
        title: "Humanity Asunder",
        author: "YouDoneKilledGod",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4558",
        chapterCount: 8
    },
    {
        id: "outsiders_2",
        title: "Outsiders",
        author: "codewalrus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/957",
        chapterCount: 8
    },
    {
        id: "nanoshield",
        title: "Nanoshield",
        author: "Karthinator",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/327",
        chapterCount: 8
    },
    {
        id: "family_tavern",
        title: "Family Tavern",
        author: "Sunjian54",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5359",
        chapterCount: 8
    },
    {
        id: "she_who_slays_gods",
        title: "She Who Slays Gods",
        author: "ElusiveMonty",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3769",
        chapterCount: 8
    },
    {
        id: "audio_narration_of_food_for_thought",
        title: "Audio Narration of Food For Thought",
        author: "AgroSquerril",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1908",
        chapterCount: 8
    },
    {
        id: "hwtf",
        title: "HWTF",
        author: "intellectualgulf",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1795",
        chapterCount: 8
    },
    {
        id: "earth_is_not_a_dystopian_empire",
        title: "Earth Is Not a Dystopian Empire",
        author: "Mountain_Revenue_353",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3969",
        chapterCount: 8
    },
    {
        id: "in_the_loop",
        title: "In The Loop",
        author: "rileyriles001",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2149",
        chapterCount: 8
    },
    {
        id: "ascended_2",
        title: "Ascended",
        author: "Badderlocks_",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2285",
        chapterCount: 8
    },
    {
        id: "agony_s_descent",
        title: "Agony's Descent",
        author: "BlackSunPublishing",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4720",
        chapterCount: 8
    },
    {
        id: "thingyverse",
        title: "ThingyVerse",
        author: "CaptCoe",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1133",
        chapterCount: 8
    },
    {
        id: "apocryphal_son",
        title: "Apocryphal Son",
        author: "MojaveMilkman",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1288",
        chapterCount: 8
    },
    {
        id: "we_are_coming_for_you",
        title: "We Are Coming For You",
        author: "Saiga123",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2194",
        chapterCount: 8
    },
    {
        id: "leani_s_ranger",
        title: "Leani's Ranger",
        author: "Shadeskira",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5249",
        chapterCount: 8
    },
    {
        id: "the_peregrine_adventures",
        title: "The Peregrine Adventures",
        author: "Danish_Savage",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/504",
        chapterCount: 8
    },
    {
        id: "i_woke_up_as_a_pok",
        title: "I woke up as a Pok",
        author: "Dragfie",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4194",
        chapterCount: 8
    },
    {
        id: "the_space_race_2",
        title: "The Space Race",
        author: "SoStrangeHere",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1465",
        chapterCount: 8
    },
    {
        id: "corrupt_heart_saga",
        title: "Corrupt Heart Saga",
        author: "ph3nf1x",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1168",
        chapterCount: 8
    },
    {
        id: "titans",
        title: "Titans",
        author: "Dismal_Purchase_3324",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3309",
        chapterCount: 8
    },
    {
        id: "the_pax",
        title: "The Pax",
        author: "Catullus74",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1377",
        chapterCount: 8
    },
    {
        id: "knowings",
        title: "Knowings",
        author: "mage_in_training",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4239",
        chapterCount: 8
    },
    {
        id: "conference_call",
        title: "Conference Call",
        author: "Blakfyre77",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/767",
        chapterCount: 8
    },
    {
        id: "how_to_train_your_human",
        title: "How to train your human",
        author: "Paragon_Nostos",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3022",
        chapterCount: 8
    },
    {
        id: "per_aspera_ad_astra_2",
        title: "per aspera ad astra",
        author: "jm434",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/527",
        chapterCount: 8
    },
    {
        id: "defiance_2",
        title: "Defiance",
        author: "Boss_Dude",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/55",
        chapterCount: 8
    },
    {
        id: "the_butler",
        title: "The Butler",
        author: "arclightmagus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3047",
        chapterCount: 8
    },
    {
        id: "roadblocks_to_humanitarianism",
        title: "Roadblocks to Humanitarianism",
        author: "SimulatedFamily",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/522",
        chapterCount: 8
    },
    {
        id: "the_meaning_of_monster",
        title: "The Meaning of Monster",
        author: "Aeogeus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5410",
        chapterCount: 8
    },
    {
        id: "the_phoenix_rises",
        title: "The Phoenix Rises",
        author: "0strich_Master",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4752",
        chapterCount: 7
    },
    {
        id: "pink_two",
        title: "Pink Two",
        author: "RhoZie013",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2507",
        chapterCount: 7
    },
    {
        id: "pink_three",
        title: "Pink Three",
        author: "RhoZie013",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2528",
        chapterCount: 7
    },
    {
        id: "iron_blood",
        title: "Iron Blood",
        author: "c0mlink",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5427",
        chapterCount: 7
    },
    {
        id: "running_with_wolves",
        title: "Running With Wolves",
        author: "brownoniongravy1",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/896",
        chapterCount: 7
    },
    {
        id: "solar_sunrise",
        title: "Solar Sunrise",
        author: "Hinterland-Seer",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3802",
        chapterCount: 7
    },
    {
        id: "jenkinsverse_3",
        title: "Jenkinsverse",
        author: "DumLoco",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/863",
        chapterCount: 7
    },
    {
        id: "lost_planet",
        title: "Lost Planet",
        author: "Pudutactico",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3275",
        chapterCount: 7
    },
    {
        id: "no_easy_going",
        title: "No Easy Going",
        author: "Snudwoner",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4845",
        chapterCount: 7
    },
    {
        id: "one_of_them",
        title: "One of Them",
        author: "TaintedPills",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3573",
        chapterCount: 7
    },
    {
        id: "life_of_a_normal_human_being",
        title: "Life of a normal human being",
        author: "Specific-Complex-523",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4653",
        chapterCount: 7
    },
    {
        id: "an_introduction_to_human_motorsport",
        title: "An Introduction to Human Motorsport",
        author: "ws_18",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2354",
        chapterCount: 7
    },
    {
        id: "playboy_paladin",
        title: "Playboy Paladin",
        author: "-Desolada-",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4507",
        chapterCount: 7
    },
    {
        id: "the_all_guardsmen_party",
        title: "The All Guardsmen Party",
        author: "Failer10",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/607",
        chapterCount: 7
    },
    {
        id: "the_huntsman",
        title: "The Huntsman",
        author: "Thorous_the3rd",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/670",
        chapterCount: 7
    },
    {
        id: "signals_from_space",
        title: "Signals From Space",
        author: "ColetteWhispers",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3295",
        chapterCount: 7
    },
    {
        id: "starfell",
        title: "Starfell",
        author: "AnimusDraconis",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/676",
        chapterCount: 7
    },
    {
        id: "human_collectors_war",
        title: "human collectors war",
        author: "lizardking1029",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4767",
        chapterCount: 7
    },
    {
        id: "vis_potentia",
        title: "Vis Potentia",
        author: "SandWhale88",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4854",
        chapterCount: 7
    },
    {
        id: "arcaniverse",
        title: "Arcaniverse",
        author: "highlord_fox",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/374",
        chapterCount: 7
    },
    {
        id: "the_tale_of_volund",
        title: "The Tale of Volund",
        author: "HoratiusAstur",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2801",
        chapterCount: 7
    },
    {
        id: "demon_s_run",
        title: "Demon's Run",
        author: "Legitimate_Sea_4754",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4470",
        chapterCount: 7
    },
    {
        id: "playing_at_war",
        title: "Playing at War",
        author: "foppery-andwhim",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3806",
        chapterCount: 7
    },
    {
        id: "unknown_warrior",
        title: "UNKNOWN WARRIOR",
        author: "NobleT3a",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4618",
        chapterCount: 7
    },
    {
        id: "eye_of_the_giant",
        title: "Eye of the Giant",
        author: "arclightmagus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4192",
        chapterCount: 7
    },
    {
        id: "human_exchange_student",
        title: "Human exchange student",
        author: "mouder61",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3178",
        chapterCount: 7
    },
    {
        id: "don_t_panic",
        title: "Don't panic",
        author: "Nicc-a-snacc",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3717",
        chapterCount: 7
    },
    {
        id: "welcome_to_the_wch",
        title: "Welcome to the WCH",
        author: "davidverner",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3114",
        chapterCount: 7
    },
    {
        id: "the_red_knight_of_mars",
        title: "The Red Knight of Mars",
        author: "Not_An_Ostritch",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4343",
        chapterCount: 7
    },
    {
        id: "the_unity",
        title: "The Unity",
        author: "Dodebro",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4529",
        chapterCount: 7
    },
    {
        id: "occupational_hazards_2",
        title: "Occupational Hazards",
        author: "KingLadislavJagiello",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1328",
        chapterCount: 7
    },
    {
        id: "jenkinsverse_spinnoff",
        title: "Jenkinsverse Spinnoff",
        author: "vaizard27",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1888",
        chapterCount: 7
    },
    {
        id: "running_water",
        title: "Running Water",
        author: "FriedCyanide",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1761",
        chapterCount: 7
    },
    {
        id: "for_the_sake_of_the_guilty_let_s_just_call_this_fiction",
        title: "For the sake of the guilty let's just call this fiction",
        author: "damnieldecogan",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3189",
        chapterCount: 7
    },
    {
        id: "the_epic_of_cyclos",
        title: "The Epic of Cyclos",
        author: "thetruewhitecircle",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3184",
        chapterCount: 7
    },
    {
        id: "the_crimson_brothers",
        title: "The Crimson Brothers",
        author: "rmifaabsbb",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/217",
        chapterCount: 7
    },
    {
        id: "as_natural_as_breathing",
        title: "As Natural as Breathing",
        author: "AlmightyPancake2321",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3987",
        chapterCount: 7
    },
    {
        id: "test_subject_ellerga_1",
        title: "Test Subject Ellerga 1",
        author: "S-cott",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1506",
        chapterCount: 7
    },
    {
        id: "the_wargame_of_volgograd",
        title: "The Wargame of Volgograd",
        author: "DamascusSeraph_",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2302",
        chapterCount: 7
    },
    {
        id: "story",
        title: "Story",
        author: "modiker",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4244",
        chapterCount: 7
    },
    {
        id: "fallen",
        title: "Fallen",
        author: "British_Tea_Company",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/678",
        chapterCount: 7
    },
    {
        id: "the_sword",
        title: "The Sword",
        author: "JK_Actual",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1489",
        chapterCount: 7
    },
    {
        id: "birds_of_a_feather",
        title: "Birds of a Feather",
        author: "VeronicaFoxx",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3000",
        chapterCount: 7
    },
    {
        id: "council_report",
        title: "Council report",
        author: "Half-DrunkPhilosophy",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4079",
        chapterCount: 7
    },
    {
        id: "the_lost_doctrines",
        title: "The Lost Doctrines",
        author: "RealMJNuttall",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2084",
        chapterCount: 7
    },
    {
        id: "the_last_orchid",
        title: "The Last Orchid",
        author: "Half-DrunkPhilosophy",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4105",
        chapterCount: 7
    },
    {
        id: "only_a_myth",
        title: "Only a Myth",
        author: "Oradainer",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5575",
        chapterCount: 7
    },
    {
        id: "the_former_demon_king_was_a_human",
        title: "The Former Demon King was a Human?!",
        author: "Plus_Society_9547",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2583",
        chapterCount: 7
    },
    {
        id: "shot",
        title: "Shot",
        author: "GloStickGoop",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5298",
        chapterCount: 7
    },
    {
        id: "sanctum_s_sanctuary",
        title: "Sanctum's Sanctuary",
        author: "wldwailord",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3312",
        chapterCount: 7
    },
    {
        id: "in_for_a_penny_2",
        title: "In for a penny",
        author: "CokeSamurai",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2898",
        chapterCount: 7
    },
    {
        id: "the_revenant_of_telkara",
        title: "The Revenant of Telkara",
        author: "Annual_Fennel_2871",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3736",
        chapterCount: 7
    },
    {
        id: "seafarer",
        title: "Seafarer",
        author: "yousureimnotarobot",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3859",
        chapterCount: 7
    },
    {
        id: "all_systems_science_university_2",
        title: "All Systems Science University",
        author: "apophis-pegasus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1825",
        chapterCount: 7
    },
    {
        id: "death",
        title: "Death",
        author: "Arceroth",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2575",
        chapterCount: 7
    },
    {
        id: "whatever_you_do",
        title: "Whatever you do",
        author: "Loetmichel",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2372",
        chapterCount: 7
    },
    {
        id: "a_feral_universe_story",
        title: "A Feral Universe Story",
        author: "PuzzledKitty",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3096",
        chapterCount: 7
    },
    {
        id: "the_new_and_weird_mammal",
        title: "The new and weird mammal",
        author: "The_owl_lover",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3400",
        chapterCount: 7
    },
    {
        id: "its_magic",
        title: "Its Magic!",
        author: "Loetmichel",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2857",
        chapterCount: 7
    },
    {
        id: "graveyard_tales",
        title: "Graveyard Tales",
        author: "trollopwhacker",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1334",
        chapterCount: 7
    },
    {
        id: "ignite_the_ashes",
        title: "Ignite the Ashes",
        author: "eiramired",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5000",
        chapterCount: 7
    },
    {
        id: "a_difference_in_design",
        title: "A difference in design",
        author: "Gibtsnird",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4357",
        chapterCount: 7
    },
    {
        id: "babe",
        title: "Babe",
        author: "Environmental-Wish53",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4047",
        chapterCount: 7
    },
    {
        id: "may_the_devils_rage_again",
        title: "May the Devils Rage Again",
        author: "Puzzleheaded-Sir8759",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3364",
        chapterCount: 7
    },
    {
        id: "shots_at_the_dark",
        title: "Shots at the Dark",
        author: "Gunnybear",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/682",
        chapterCount: 6
    },
    {
        id: "humanity_s_amelioration",
        title: "Humanity's Amelioration",
        author: "PrivateSnowy",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/261",
        chapterCount: 6
    },
    {
        id: "the_harlem_knight",
        title: "The Harlem Knight",
        author: "24Amadeus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4754",
        chapterCount: 6
    },
    {
        id: "humanity_2",
        title: "Humanity",
        author: "DAVID_Gamer_5698",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4438",
        chapterCount: 6
    },
    {
        id: "a_guy_s_gotta_work",
        title: "A Guy's Gotta Work",
        author: "JackFragg",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/781",
        chapterCount: 6
    },
    {
        id: "the_last_colony",
        title: "The Last Colony",
        author: "MarbleEater1",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5509",
        chapterCount: 6
    },
    {
        id: "ben_s_damn_adventure",
        title: "Ben's Damn Adventure",
        author: "Saltywaters8",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2258",
        chapterCount: 6
    },
    {
        id: "the_outpost",
        title: "The Outpost",
        author: "canuchangeusernames",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2877",
        chapterCount: 6
    },
    {
        id: "holding_out_for_a_hero",
        title: "Holding Out for a Hero",
        author: "Bloodytearsofrage",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2189",
        chapterCount: 6
    },
    {
        id: "raven_s_fall",
        title: "Raven's Fall",
        author: "In_Yellow_Clad",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4414",
        chapterCount: 6
    },
    {
        id: "insertion_prologue_arc",
        title: "Insertion Prologue Arc",
        author: "AlanharTheRiver",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4852",
        chapterCount: 6
    },
    {
        id: "strike_hard",
        title: "Strike Hard",
        author: "Rioting_Derp",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/148",
        chapterCount: 6
    },
    {
        id: "humanities_furies",
        title: "Humanities Furies",
        author: "Zoobatzjr",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4501",
        chapterCount: 6
    },
    {
        id: "from_heavens_fall",
        title: "From Heavens Fall",
        author: "PlEGUY",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4585",
        chapterCount: 6
    },
    {
        id: "detective_anais_and_the_missing_mission",
        title: "Detective Anais and the Missing Mission",
        author: "PatchworthPlus",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3285",
        chapterCount: 6
    },
    {
        id: "noah_s_ark",
        title: "Noah's ark",
        author: "professor_infinity",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2174",
        chapterCount: 6
    },
    {
        id: "the_songs_of_the_voyagers",
        title: "The Songs of the Voyagers",
        author: "Thomas_Ray_Mainstone",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3087",
        chapterCount: 6
    },
    {
        id: "unchained_hearts",
        title: "Unchained Hearts",
        author: "Cool_ball999",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5383",
        chapterCount: 6
    },
    {
        id: "human_2",
        title: "Human 2",
        author: "Radman1511",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4605",
        chapterCount: 6
    },
    {
        id: "frostpunk",
        title: "Frostpunk",
        author: "rer24",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2560",
        chapterCount: 6
    },
    {
        id: "claiming_terra",
        title: "Claiming Terra",
        author: "Nellthe",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4857",
        chapterCount: 6
    },
    {
        id: "a_guest_aboard_the_ship_2",
        title: "A guest aboard the ship",
        author: "British_Tea_Company",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/486",
        chapterCount: 6
    },
    {
        id: "resurrection",
        title: "Resurrection",
        author: "kowz1",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/260",
        chapterCount: 6
    },
    {
        id: "showcase",
        title: "Showcase",
        author: "Mc_J4K3",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/669",
        chapterCount: 6
    },
    {
        id: "the_last_gregoryo",
        title: "The Last Gregoryo",
        author: "PurplePinatta",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4018",
        chapterCount: 6
    },
    {
        id: "the_great_war_of_the_worlds",
        title: "The Great War of the Worlds",
        author: "DrunkRobot97",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/246",
        chapterCount: 6
    },
    {
        id: "i_m_not_his_pet_i_m_his_roommate",
        title: "I'm Not His Pet, I'm His Roommate!",
        author: "Darth_Hisoka",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1070",
        chapterCount: 6
    },
    {
        id: "our_creators_l",
        title: "Our Creators l",
        author: "BrotherSoap",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1527",
        chapterCount: 6
    },
    {
        id: "the_forgotten_gods",
        title: "The Forgotten Gods",
        author: "usernamechekinsout",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2920",
        chapterCount: 6
    },
    {
        id: "you_learned_nothing",
        title: "You learned nothing",
        author: "British_Tea_Company",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1241",
        chapterCount: 6
    },
    {
        id: "frozen_hunter",
        title: "Frozen Hunter",
        author: "dragonson04",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3519",
        chapterCount: 6
    },
    {
        id: "return_to_arms",
        title: "Return to Arms",
        author: "Cocao_Nibs",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3383",
        chapterCount: 6
    },
    {
        id: "the_humans",
        title: "The Humans",
        author: "FanaticXenophile11",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4377",
        chapterCount: 6
    },
    {
        id: "chasing_stars",
        title: "Chasing Stars",
        author: "coldfireknight",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4580",
        chapterCount: 6
    },
    {
        id: "the_solar_research_council_x_unification_era",
        title: "The Solar Research Council x Unification Era",
        author: "Unternehmungen",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2749",
        chapterCount: 6
    },
    {
        id: "far_too_close",
        title: "Far Too Close",
        author: "Frostdraken",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4703",
        chapterCount: 6
    },
    {
        id: "cosmic_vanguard",
        title: "Cosmic Vanguard",
        author: "ftpowerup",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5243",
        chapterCount: 6
    },
    {
        id: "for_better_or_worse",
        title: "For Better or Worse",
        author: "Caiggas",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1540",
        chapterCount: 6
    },
    {
        id: "fair_eduin_tales",
        title: "Fair Eduin Tales",
        author: "morbiusgreen",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1487",
        chapterCount: 6
    },
    {
        id: "mechanics",
        title: "Mechanics",
        author: "Raithwind",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5235",
        chapterCount: 6
    },
    {
        id: "hell_underwater",
        title: "Hell Underwater",
        author: "Unoriginal-joker",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3498",
        chapterCount: 6
    },
    {
        id: "fallen_winter",
        title: "Fallen Winter",
        author: "not-so-british-brit",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3473",
        chapterCount: 6
    },
    {
        id: "rift",
        title: "Rift",
        author: "HolyVex",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1184",
        chapterCount: 6
    },
    {
        id: "united_sapients_of_terra",
        title: "United Sapients of Terra",
        author: "Critical-Ad-1516",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4058",
        chapterCount: 6
    },
    {
        id: "armor_corps",
        title: "Armor Corps",
        author: "Glacialfury",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2131",
        chapterCount: 6
    },
    {
        id: "simon_and_the_witch",
        title: "Simon and the Witch",
        author: "DoppelgangerDelux",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2028",
        chapterCount: 6
    },
    {
        id: "hyperion_2",
        title: "Hyperion",
        author: "OpinionatedIMO",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5411",
        chapterCount: 6
    },
    {
        id: "heart_of_a_sword",
        title: "Heart of A Sword",
        author: "Gomoragor",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2036",
        chapterCount: 6
    },
    {
        id: "einstein_was_wrong",
        title: "Einstein was wrong!",
        author: "moldyjim",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2540",
        chapterCount: 6
    },
    {
        id: "fheverse",
        title: "FHEverse",
        author: "cursedhfy",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2315",
        chapterCount: 6
    },
    {
        id: "they_bleed_like_us",
        title: "They Bleed Like Us",
        author: "peacekeeper76",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1348",
        chapterCount: 6
    },
    {
        id: "uen_hood",
        title: "UEN Hood",
        author: "Tlmitf",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1396",
        chapterCount: 6
    },
    {
        id: "lords_of_terra",
        title: "Lords of Terra",
        author: "spindizzy_wizard",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2482",
        chapterCount: 6
    },
    {
        id: "untold_histories",
        title: "Untold Histories",
        author: "Thoughtful_Reader",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1138",
        chapterCount: 6
    },
    {
        id: "fringe_space_deathworlders",
        title: "Fringe Space Deathworlders",
        author: "CyberfairyfromspacE",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3371",
        chapterCount: 6
    },
    {
        id: "the_turock_work_camp_rebellion",
        title: "The Turock Work Camp Rebellion",
        author: "Glugenash",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1854",
        chapterCount: 6
    },
    {
        id: "neighbours",
        title: "Neighbours'",
        author: "ItrytoHFY",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/936",
        chapterCount: 6
    },
    {
        id: "onward_together",
        title: "Onward Together",
        author: "Steel_SAGEbrush",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5389",
        chapterCount: 6
    },
    {
        id: "relic_of_the_republic",
        title: "Relic Of The Republic",
        author: "JetScootr",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5245",
        chapterCount: 6
    },
    {
        id: "the_unknown_sector",
        title: "The Unknown Sector",
        author: "Justinrvg101",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3823",
        chapterCount: 6
    },
    {
        id: "the_deathworlder_students",
        title: "The Deathworlder Students",
        author: "Michaelbk007",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3469",
        chapterCount: 6
    },
    {
        id: "rebel",
        title: "Rebel",
        author: "FoggyBoggy",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/989",
        chapterCount: 6
    },
    {
        id: "where_we_re_going_we_don_t_need_magic",
        title: "Where we're going, we don't need magic",
        author: "MLL_Phoenix7",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2357",
        chapterCount: 6
    },
    {
        id: "golem",
        title: "Golem",
        author: "SleepPillsForSloths",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/2931",
        chapterCount: 6
    },
    {
        id: "jenkins",
        title: "Jenkins",
        author: "CWSmith1701",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/204",
        chapterCount: 6
    },
    {
        id: "cold_universe",
        title: "Cold Universe",
        author: "Salooin",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/3757",
        chapterCount: 6
    },
    {
        id: "the_void_stared_back",
        title: "The Void Stared Back",
        author: "DungeonsAndData",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5309",
        chapterCount: 6
    },
    {
        id: "a_man_amongst_the_stars",
        title: "A Man Amongst the Stars",
        author: "Twitch6r",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/5519",
        chapterCount: 6
    },
    {
        id: "trying_to_do_good",
        title: "Trying to do Good",
        author: "Vnator",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1485",
        chapterCount: 6
    },
    {
        id: "pyramid_to_the_stars_2",
        title: "Pyramid to the Stars",
        author: "semiloki",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/721",
        chapterCount: 6
    },
    {
        id: "into_the_house_of_thresher",
        title: "Into the House of Thresher",
        author: "jimmercubed",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/4188",
        chapterCount: 6
    },
    {
        id: "survivor",
        title: "Survivor",
        author: "Manufacture",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/440",
        chapterCount: 6
    },
    {
        id: "what_it_means_to_be_a_world",
        title: "What It Means to Be a World",
        author: "HypheNatioNC",
        wikiUrl: "",
        hfyFoundationUrl: "https://hfy.foundation/series/1905",
        chapterCount: 6
    },
    {
        id: "dea... [TRUNCATED - full file in webapp ZIP] ...

```

## Stores chunk

```javascript
"use strict";
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([[9365],{

/***/ 1570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   KS: () => (/* binding */ dualStorage),
/* harmony export */   _P: () => (/* binding */ restoreFromServer)
/* harmony export */ });
/* unused harmony exports tripleStorage, tripleStorageGetSync, tripleStorageGetAsync, tripleStorageSet, tripleStorageRemove, isHydrated */
// Synchronous dual storage + async server-side mirror for Zustand persist middleware.
//
// PROBLEM: Android WebView clears localStorage for non-secure origins
// (http://127.0.0.1) every time the app process is killed and restarted.
// Cookies persist but have a 4KB-per-cookie limit. IndexedDB persists but
// is async-only and was unreliable in early Capacitor builds.
//
// SOLUTION: tripleStorage — three-tier persistence:
//   1. localStorage (synchronous cache, fast first render)
//   2. Cookies (small fallback, persists across restarts, 4KB limit per cookie)
//   3. Server filesystem via /api/store/[key] (durable, unlimited size,
//      survives Android WebView restart — this is the source of truth)
//
// Reads are SYNCHRONOUS (localStorage first, then cookies) so Zustand can
// hydrate on first render. On mount, an async background fetch from the
// server restores data if localStorage was wiped. Writes go to all three
// tiers simultaneously (localStorage synchronously, server async).
//
// The server-side storage lives at process.cwd()/data/app-store/{key}.json
// which on Android is inside the app's private data directory and persists
// across app restarts.
const MAX_COOKIE_SIZE = 3800; // Leave room for cookie metadata
const MAX_TOTAL_COOKIE_SIZE = 0; // DISABLE ALL COOKIES - server is source of truth
// Above this size, skip cookies entirely — rely on localStorage + server only.
// This prevents cookie jar overflow on Android WebView which causes page load
// failures when large datasets (e.g., 1400+ chapter scores) are stored.
const CHUNK_PREFIX = "hfy-data";
// ============================================================================
// In-memory cache of server-restore state, so we don't re-fetch on every
// store read. Keyed by store name. Once we've restored from the server,
// we don't need to do it again until the page reloads.
// ============================================================================
const serverRestoreCache = new Set();
const serverRestoreInProgress = new Map();
// Track which stores have been hydrated from server at least once.
// This lets the app know when it's safe to assume localStorage is empty
// because the user genuinely has no data (vs. localStorage was wiped).
const hydrationComplete = new Set();
function setCookie(name, value, days = 365) {
    try {
        const expires = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toUTCString();
        document.cookie = `${name}=${encodeURIComponent(value)};expires=${expires};path=/;SameSite=Lax`;
    } catch  {}
}
function getCookie(name) {
    try {
        const cookies = document.cookie.split(";");
        for (const cookie of cookies){
            const [key, ...valParts] = cookie.trim().split("=");
            if (key === name) {
                return decodeURIComponent(valParts.join("="));
            }
        }
    } catch  {}
    return null;
}
function deleteCookie(name) {
    try {
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
    } catch  {}
}
// Split large data across multiple cookies.
// If the data is too large (> MAX_TOTAL_COOKIE_SIZE), skip cookies entirely
// to prevent cookie jar overflow on Android WebView.
function setMultiCookie(baseName, value) {
    // ALL cookies disabled - server is source of truth
    if (value.length > MAX_TOTAL_COOKIE_SIZE) {
        deleteMultiCookie(baseName);
        return;
    }
    const chunks = [];
    for(let i = 0; i < value.length; i += MAX_COOKIE_SIZE){
        chunks.push(value.substring(i, i + MAX_COOKIE_SIZE));
    }
    // Delete old chunks first
    let idx = 0;
    while(getCookie(`${baseName}-${idx}`) !== null){
        deleteCookie(`${baseName}-${idx}`);
        idx++;
    }
    // Set new chunks
    for(let i = 0; i < chunks.length; i++){
        setCookie(`${baseName}-${i}`, chunks[i]);
    }
    // Store chunk count
    setCookie(`${baseName}-count`, String(chunks.length));
}
function getMultiCookie(baseName) {
    const countStr = getCookie(`${baseName}-count`);
    if (!countStr) {
        // Try single cookie (old format)
        const single = getCookie(baseName);
        return single;
    }
    const count = parseInt(countStr, 10);
    if (isNaN(count) || count === 0) return null;
    let result = "";
    for(let i = 0; i < count; i++){
        const chunk = getCookie(`${baseName}-${i}`);
        if (chunk === null) return null; // Missing chunk — data corrupted
        result += chunk;
    }
    return result;
}
function deleteMultiCookie(baseName) {
    const countStr = getCookie(`${baseName}-count`);
    if (countStr) {
        const count = parseInt(countStr, 10);
        for(let i = 0; i < count; i++){
            deleteCookie(`${baseName}-${i}`);
        }
        deleteCookie(`${baseName}-count`);
    } else {
        deleteCookie(baseName);
    }
}
// ============================================================================
// Server-side storage helpers — fire-and-forget async writes that mirror
// localStorage state to the server filesystem.
// ============================================================================
// Debounce writes to avoid hammering the server on rapid state changes.
// Each key gets its own timer.
const writeTimers = new Map();
const WRITE_DEBOUNCE_MS = 800;
function serverWrite(key, value) {
    // Clear any pending write for this key
    const existing = writeTimers.get(key);
    if (existing) clearTimeout(existing);
    // Schedule a new write
    const timer = setTimeout(()=>{
        writeTimers.delete(key);
        try {
            // Parse and re-stringify to ensure valid JSON for the server
            const parsed = JSON.parse(value);
            fetch(`/api/store/${encodeURIComponent(key)}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(parsed),
                keepalive: true
            }).catch(()=>{});
        } catch  {
            // If it's not valid JSON, send as a wrapped string
            fetch(`/api/store/${encodeURIComponent(key)}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    _raw: value
                }),
                keepalive: true
            }).catch(()=>{});
        }
    }, WRITE_DEBOUNCE_MS);
    writeTimers.set(key, timer);
}
function serverDelete(key) {
    const existing = writeTimers.get(key);
    if (existing) clearTimeout(existing);
    writeTimers.delete(key);
    try {
        fetch(`/api/store/${encodeURIComponent(key)}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(null),
            keepalive: true
        }).catch(()=>{});
    } catch  {}
}
// Async restore from server — called on first read of each store.
// Returns the restored value or null. Also writes the restored value
// back to localStorage and cookies so subsequent reads are fast.
async function serverRead(key) {
    try {
        const res = await fetch(`/api/store/${encodeURIComponent(key)}`, {
            cache: "no-store"
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (!data.ok || data.data === undefined || data.data === null) return null;
        // The server stores parsed JSON, so we re-stringify
        const value = JSON.stringify(data.data);
        return value;
    } catch  {
        return null;
    }
}
// Trigger a background restore from the server for a specific key.
// If localStorage is empty, populate it with the server value so the next
// render picks it up. Returns a Promise that resolves when the restore
// attempt is complete.
// Track which stores were ACTUALLY restored from the server (vs just found
// in localStorage/cookies). This is used by page.tsx to decide whether a
// reload is needed — only reload if data was actually fetched from the server.
const restoredFromServer = new Set();
function triggerServerRestore(name) {
    if (serverRestoreCache.has(name)) {
        // Already attempted this session — return whether it was a server restore
        return Promise.resolve(restoredFromServer.has(name));
    }
    if (serverRestoreInProgress.has(name)) return serverRestoreInProgress.get(name);
    const promise = (async ()=>{
        try {
            // First check if localStorage already has data — if so, no server
            // restore needed. Return false so page.tsx does NOT reload.
            try {
                const lsValue = localStorage.getItem(name);
                if (lsValue && lsValue.length > 2 && lsValue !== "{}" && lsValue !== "[]") {
                    serverRestoreCache.add(name);
                    hydrationComplete.add(name);
                    return false;
                }
            } catch  {}
            // Also check cookies
            const cookieValue = getMultiCookie(`${CHUNK_PREFIX}-${name}`);
            if (cookieValue && cookieValue.length > 2 && cookieValue !== "{}" && cookieValue !== "[]") {
                try {
                    localStorage.setItem(name, cookieValue);
                } catch  {}
                serverRestoreCache.add(name);
                hydrationComplete.add(name);
                return false; // Data came from cookies, not server — no reload needed
            // because cookies are synchronous and Zustand already
            // read them on first render.
            }
            // Neither localStorage nor cookies have data — fetch from server
            const serverValue = await serverRead(name);
            let didRestore = false;
            if (serverValue && serverValue.length > 2 && serverValue !== "{}" && serverValue !== "[]") {
                // Try to write to localStorage — this may fail with QuotaExceededError
                // if the data is too large. In that case, we still mark as restored
                // and keep the data in memory (the server is the source of truth).
                let lsWriteOk = false;
                try {
                    localStorage.setItem(name, serverValue);
                    lsWriteOk = true;
                } catch (e) {
                    // localStorage quota exceeded — try to free up space by removing
                    // old cookie chunks and retrying
                    try {
                        // Clear all hfy-data cookies to free space
                        const allCookies = document.cookie.split(";");
                        for (const c of allCookies){
                            const cname = c.split("=")[0].trim();
                            if (cname.startsWith(CHUNK_PREFIX)) {
                                deleteCookie(cname);
                            }
                        }
                        // Retry localStorage write
                        localStorage.setItem(name, serverValue);
                        lsWriteOk = true;
                    } catch (e2) {
                        // Still failed — keep data in memory only, server is the source of truth
                        console.warn(`[tripleStorage] localStorage quota exceeded for ${name} (${serverValue.length} bytes), relying on server only`);
                    }
                }
                // Only write to cookies if data is small enough AND localStorage succeeded
                if (false) {}
                // Mark as restored regardless — the server has the data even if
                // localStorage/cookies couldn't hold it all
                didRestore = true;
                restoredFromServer.add(name);
            }
            serverRestoreCache.add(name);
            hydrationComplete.add(name);
            return didRestore;
        } catch  {
            // Best-effort — don't crash on restore failure
            return false;
        }
    })();
    serverRestoreInProgress.set(name, promise);
    promise.finally(()=>{
        serverRestoreInProgress.delete(name);
    });
    return promise;
}
// ============================================================================
// tripleStorage — Zustand-compatible StateStorage implementation.
// Reads are synchronous (localStorage → cookies). Writes go to localStorage
// + cookies + server (debounced). On first read, an async background fetch
// from the server restores data if localStorage was wiped.
// ============================================================================
const tripleStorage = {
    getItem: (name)=>{
        // Try localStorage first (fast, synchronous)
        try {
            const lsValue = localStorage.getItem(name);
            if (lsValue) return lsValue;
        } catch  {}
        // localStorage empty — try cookies (synchronous)
        const cookieValue = getMultiCookie(`${CHUNK_PREFIX}-${name}`);
        if (cookieValue) {
            // Restore to localStorage for faster access next time
            try {
                localStorage.setItem(name, cookieValue);
            } catch  {}
            return cookieValue;
        }
        // Both localStorage and cookies are empty — kick off an async restore
        // from the server. This will populate localStorage for the NEXT render.
        // The current render sees empty data, but the storage event dispatched
        // by triggerServerRestore will cause Zustand to re-hydrate.
        if (true) {
            triggerServerRestore(name).catch(()=>{});
        }
        return null;
    },
    setItem: (name, value)=>{
        // Write to localStorage (synchronous, fast cache)
        // If this fails with QuotaExceededError, try clearing old cookies first
        try {
            localStorage.setItem(name, value);
        } catch (e) {
            // localStorage quota exceeded — try to free space
            try {
                // Clear all hfy-data cookies to free space
                const allCookies = document.cookie.split(";");
                for (const c of allCookies){
                    const cname = c.split("=")[0].trim();
                    if (cname.startsWith(CHUNK_PREFIX)) {
                        deleteCookie(cname);
                    }
                }
                localStorage.setItem(name, value);
            } catch (e2) {
                console.warn(`[tripleStorage] localStorage quota exceeded for ${name} (${value.length} bytes)`);
            }
        }
        // ALL cookies disabled
        if (false) {} else {
            // Data too large for cookies — delete any old cookies for this key
            try {
                deleteMultiCookie(`${CHUNK_PREFIX}-${name}`);
            } catch  {}
        }
        // Write to server (async, durable, debounced)
        if ( true && value && value.length > 0) {
            serverWrite(name, value);
        }
    },
    removeItem: (name)=>{
        try {
            localStorage.removeItem(name);
        } catch  {}
        deleteMultiCookie(`${CHUNK_PREFIX}-${name}`);
        if (true) {
            serverDelete(name);
        }
    }
};
// Backwards-compatibility alias — old code still imports dualStorage.
// Now both names point to the same triple-storage implementation.
const dualStorage = tripleStorage;
// ============================================================================
// Public helpers for non-Zustand code that wants to use the same triple
// storage pattern (e.g. read-tracker.ts, BrowseScreen custom-series).
// ============================================================================
/**
 * Read a value from triple storage. SYNCHRONOUS — only checks localStorage
 * and cookies. If both are empty, kicks off an async server restore in the
 * background and returns null. Use tripleStorageGetAsync for the full
 * server-checked read.
 */ function tripleStorageGetSync(name) {
    return tripleStorage.getItem(name);
}
/**
 * Read a value from triple storage. ASYNC — checks localStorage, cookies,
 * AND the server. The first call is slow; subsequent calls hit the
 * in-memory cache. Use this when you need the definitive value.
 */ async function tripleStorageGetAsync(name) {
    // Try localStorage first
    try {
        const lsValue = localStorage.getItem(name);
        if (lsValue && lsValue !== "{}" && lsValue !== "[]") return lsValue;
    } catch  {}
    // Try cookies
    const cookieValue = getMultiCookie(`${CHUNK_PREFIX}-${name}`);
    if (cookieValue && cookieValue !== "{}" && cookieValue !== "[]") {
        try {
            localStorage.setItem(name, cookieValue);
        } catch  {}
        return cookieValue;
    }
    // Try server
    const serverValue = await serverRead(name);
    if (serverValue) {
        try {
            localStorage.setItem(name, serverValue);
        } catch  {}
        try {
            setMultiCookie(`${CHUNK_PREFIX}-${name}`, serverValue);
        } catch  {}
    }
    return serverValue;
}
/**
 * Write a value to triple storage (localStorage + cookies + server).
 * Synchronous for localStorage/cookies, async for server.
 */ function tripleStorageSet(name, value) {
    tripleStorage.setItem(name, value);
}
/**
 * Remove a value from all three tiers of triple storage.
 */ function tripleStorageRemove(name) {
    tripleStorage.removeItem(name);
}
/**
 * Trigger a background restore from the server for a specific key.
 * Returns a Promise<boolean> that resolves to:
 *   - true  if data was actually fetched from the server (caller may want
 *           to reload so Zustand re-reads localStorage)
 *   - false if localStorage/cookies already had data, or the server had
 *           no data, or the restore failed (no reload needed)
 */ function restoreFromServer(name) {
    return triggerServerRestore(name);
}
/**
 * Returns true if a given store has been hydrated from the server at least
 * once during this session. Useful for components that want to show a
 * loading state until hydration is complete.
 */ function isHydrated(name) {
    return hydrationComplete.has(name);
}


/***/ }),

/***/ 3782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ readTracker)
/* harmony export */ });
/* __next_internal_client_entry_do_not_use__ readTracker auto */ // Simple read tracking with TRIPLE storage (localStorage + IndexedDB + server).
//
// PROBLEM: On Android WebView, localStorage gets cleared on every restart
// for non-secure origins (http://127.0.0.1). IndexedDB sometimes survives
// but is async-only and was unreliable in early Capacitor builds.
//
// SOLUTION: Mirror read tracking to ALL THREE tiers:
//   1. localStorage (synchronous, fast)
//   2. IndexedDB (async, persists across restarts in most cases)
//   3. Server filesystem via /api/store/hfy-read-chapters (durable source of truth)
//
// Reads are SYNCHRONOUS (localStorage first, then trigger async restore
// from server if empty). Writes go to all three tiers.
const STORAGE_KEY = "hfy-read-chapters";
// IndexedDB helpers
function openIDB() {
    return new Promise((resolve)=>{
        try {
            const req = indexedDB.open("hfy-read-tracker", 1);
            req.onupgradeneeded = ()=>req.result.createObjectStore("data");
            req.onsuccess = ()=>resolve(req.result);
            req.onerror = ()=>resolve(null);
        } catch  {
            resolve(null);
        }
    });
}
async function idbGet(key) {
    try {
        const db = await openIDB();
        if (!db) return null;
        return new Promise((resolve)=>{
            const tx = db.transaction("data", "readonly");
            const req = tx.objectStore("data").get(key);
            req.onsuccess = ()=>resolve(req.result || null);
            req.onerror = ()=>resolve(null);
            tx.oncomplete = ()=>db.close();
        });
    } catch  {
        return null;
    }
}
async function idbSet(key, value) {
    try {
        const db = await openIDB();
        if (!db) return;
        return new Promise((resolve)=>{
            const tx = db.transaction("data", "readwrite");
            tx.objectStore("data").put(value, key);
            tx.oncomplete = ()=>{
                db.close();
                resolve();
            };
            tx.onerror = ()=>{
                db.close();
                resolve();
            };
        });
    } catch  {}
}
// Server-side storage — debounced write + async restore on first read
let serverWriteTimer = null;
let serverRestoreAttempted = false;
function serverWriteReadChapters(json) {
    if (serverWriteTimer) clearTimeout(serverWriteTimer);
    serverWriteTimer = setTimeout(()=>{
        serverWriteTimer = null;
        try {
            const parsed = JSON.parse(json);
            fetch(`/api/store/${encodeURIComponent(STORAGE_KEY)}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(parsed),
                keepalive: true
            }).catch(()=>{});
        } catch  {}
    }, 1000);
}
async function serverRestore() {
    if (serverRestoreAttempted) return;
    serverRestoreAttempted = true;
    try {
        const res = await fetch(`/api/store/${encodeURIComponent(STORAGE_KEY)}`, {
            cache: "no-store"
        });
        if (!res.ok) return;
        const data = await res.json();
        if (!data.ok || !data.data) return;
        const json = JSON.stringify(data.data);
        // Only restore if localStorage is empty (don't overwrite newer local data)
        const local = localStorage.getItem(STORAGE_KEY);
        if (!local || local === "{}" || local === "[]") {
            localStorage.setItem(STORAGE_KEY, json);
            // Parse and update in-memory cache
            const parsed = JSON.parse(json);
            const result = {};
            for (const [seriesId, chapters] of Object.entries(parsed)){
                result[seriesId] = new Set(chapters);
            }
            readCache = result;
            listeners.forEach((l)=>l());
        }
        // Also save to IDB for faster restore next time
        await idbSet(STORAGE_KEY, json);
    } catch  {}
}
function loadReadChapters() {
    try {
        if (false) {}
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            const data = JSON.parse(raw);
            const result = {};
            for (const [seriesId, chapters] of Object.entries(data)){
                result[seriesId] = new Set(chapters);
            }
            return result;
        }
        // localStorage empty — try IndexedDB (async, but we need sync result)
        // Start async restore for next render
        if (typeof indexedDB !== "undefined") {
            idbGet(STORAGE_KEY).then(async (idbData)=>{
                if (idbData) {
                    try {
                        localStorage.setItem(STORAGE_KEY, idbData);
                    } catch  {}
                    const data = JSON.parse(idbData);
                    const result = {};
                    for (const [seriesId, chapters] of Object.entries(data)){
                        result[seriesId] = new Set(chapters);
                    }
                    readCache = result;
                    listeners.forEach((l)=>l());
                } else {
                    // IDB also empty — try server
                    await serverRestore();
                }
            });
        } else {
            // No IDB — try server directly
            serverRestore();
        }
        return {};
    } catch  {
        return {};
    }
}
function saveReadChapters(data) {
    try {
        if (false) {}
        const serializable = {};
        for (const [seriesId, chapters] of Object.entries(data)){
            serializable[seriesId] = Array.from(chapters);
        }
        const json = JSON.stringify(serializable);
        try {
            localStorage.setItem(STORAGE_KEY, json);
        } catch  {}
        // Also save to IndexedDB for persistence across restarts
        idbSet(STORAGE_KEY, json).catch(()=>{});
        // Also write to server (debounced)
        serverWriteReadChapters(json);
    } catch  {}
}
// In-memory cache — lazy loaded on first access (not at module level)
let readCache = null;
const listeners = new Set();
function getCache() {
    if (readCache === null) {
        readCache = loadReadChapters();
    }
    return readCache;
}
function notify() {
    listeners.forEach((l)=>l());
}
const readTracker = {
    isRead (seriesId, chapterId) {
        return getCache()[seriesId]?.has(chapterId) ?? false;
    },
    markRead (seriesId, chapterId) {
        const cache = getCache();
        if (!cache[seriesId]) cache[seriesId] = new Set();
        if (cache[seriesId].has(chapterId)) return;
        cache[seriesId].add(chapterId);
        saveReadChapters(cache);
        notify();
    },
    markUnread (seriesId, chapterId) {
        const cache = getCache();
        cache[seriesId]?.delete(chapterId);
        saveReadChapters(cache);
        notify();
    },
    toggle (seriesId, chapterId) {
        if (this.isRead(seriesId, chapterId)) {
            this.markUnread(seriesId, chapterId);
        } else {
            this.markRead(seriesId, chapterId);
        }
    },
    markAllRead (seriesId, chapterIds) {
        const cache = getCache();
        if (!cache[seriesId]) cache[seriesId] = new Set();
        for (const id of chapterIds)cache[seriesId].add(id);
        saveReadChapters(cache);
        notify();
    },
    markAllUnread (seriesId) {
        const cache = getCache();
        cache[seriesId] = new Set();
        saveReadChapters(cache);
        notify();
    },
    clearSeries (seriesId) {
        const cache = getCache();
        delete cache[seriesId];
        saveReadChapters(cache);
        notify();
    },
    clearAll () {
        readCache = {};
        saveReadChapters(readCache);
        notify();
    },
    subscribe (listener) {
        listeners.add(listener);
        return ()=>{
            listeners.delete(listener);
        };
    },
    getReadCount (seriesId) {
        return getCache()[seriesId]?.size ?? 0;
    },
    /** Force a restore from the server. Returns a Promise that resolves
   *  when the restore attempt is complete. Useful for components that
   *  want to await the restore before rendering. */ async restoreFromServer () {
        await serverRestore();
    }
};


/***/ }),

/***/ 9365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Io: () => (/* binding */ useUrlOverrides),
/* harmony export */   Lp: () => (/* binding */ READER_THEMES),
/* harmony export */   Zd: () => (/* binding */ APP_THEMES),
/* harmony export */   cx: () => (/* binding */ useBrowseCache),
/* harmony export */   hI: () => (/* binding */ useNav),
/* harmony export */   kq: () => (/* binding */ useRedditAuth),
/* harmony export */   lY: () => (/* binding */ useDownloads),
/* harmony export */   ng: () => (/* binding */ useChapterUrlOverrides),
/* harmony export */   sw: () => (/* binding */ useInAppBrowser),
/* harmony export */   tF: () => (/* binding */ useLibrary),
/* harmony export */   useSeriesScores: () => (/* binding */ useSeriesScores),
/* harmony export */   useSettings: () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1934);
/* harmony import */ var _read_tracker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3782);
/* harmony import */ var zustand_middleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9311);
/* harmony import */ var _persistent_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1570);




const useSettings = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set)=>({
        appTheme: "cyber_red",
        readerTheme: "void_dark",
        readerFont: "Source Serif 4",
        customFontName: "",
        customFontUrl: "",
        readerFontSize: 18,
        readerLineHeight: 1.7,
        readerMargin: 24,
        readerPreloadChapters: 3,
        scanlineOpacity: 0.35,
        glowIntensity: 0.7,
        glitchEnabled: true,
        cornerBracketsAnim: true,
        backgroundParticles: false,
        uiDensity: "normal",
        defaultFormat: "epub",
        defaultMerge: true,
        wifiOnly: false,
        concurrentDownloads: 3,
        customPrimary: "#FF003C",
        customAccent: "#00FFF0",
        customTertiary: "#FFE600",
        customBackground: "#000000",
        customPanel: "#0D1117",
        // Background image settings
        customBgImage: "",
        customBgImages: [],
        bgChangeInterval: 0,
        bgOpacity: 0.12,
        downloadFolder: "/HFY_NEKROCODEXXX/Downloads/",
        combinedEbookFolder: "/HFY_NEKROCODEXXX/Ebooks/",
        localImportFolder: "/HFY_NEKROCODEXXX/Import/",
        autoUpdateEnabled: false,
        autoUpdateInterval: 24,
        lastAutoUpdate: 0,
        customReaderBg: "#000000",
        customReaderText: "#E0E0E0",
        customReaderAccent: "#00FFF0",
        customSearchOrder: [],
        parallelDownloads: 5,
        cFetchBatchSize: 5,
        setAppTheme: (t)=>set({
                appTheme: t
            }),
        setReaderTheme: (t)=>set({
                readerTheme: t
            }),
        setReaderFont: (f)=>set({
                readerFont: f
            }),
        setCustomFontName: (name)=>set({
                customFontName: name
            }),
        setCustomFontUrl: (url)=>set({
                customFontUrl: url
            }),
        setReaderFontSize: (n)=>set({
                readerFontSize: n
            }),
        setReaderLineHeight: (n)=>set({
                readerLineHeight: n
            }),
        setReaderMargin: (n)=>set({
                readerMargin: n
            }),
        setReaderPreloadChapters: (n)=>set({
                readerPreloadChapters: Math.max(0, Math.min(100, n))
            }),
        setScanlineOpacity: (n)=>set({
                scanlineOpacity: n
            }),
        setGlowIntensity: (n)=>set({
                glowIntensity: n
            }),
        setGlitchEnabled: (b)=>set({
                glitchEnabled: b
            }),
        setCornerBracketsAnim: (b)=>set({
                cornerBracketsAnim: b
            }),
        setBackgroundParticles: (b)=>set({
                backgroundParticles: b
            }),
        setUiDensity: (d)=>set({
                uiDensity: d
            }),
        setDefaultFormat: (f)=>set({
                defaultFormat: f
            }),
        setDefaultMerge: (b)=>set({
                defaultMerge: b
            }),
        setWifiOnly: (b)=>set({
                wifiOnly: b
            }),
        setConcurrentDownloads: (n)=>set({
                concurrentDownloads: n
            }),
        setCustomPrimary: (c)=>set({
                customPrimary: c
            }),
        setCustomAccent: (c)=>set({
                customAccent: c
            }),
        setCustomTertiary: (c)=>set({
                customTertiary: c
            }),
        setCustomBackground: (c)=>set({
                customBackground: c
            }),
        setCustomPanel: (c)=>set({
                customPanel: c
            }),
        setCustomBgImage: (url)=>set({
                customBgImage: url,
                customBgImages: url ? [
                    url
                ] : []
            }),
        setCustomBgImages: (urls)=>set({
                customBgImages: urls,
                customBgImage: urls[0] || ""
            }),
        addCustomBgImage: (url)=>set((state)=>{
                const next = [
                    ...state.customBgImages,
                    url
                ];
                return {
                    customBgImages: next,
                    customBgImage: next[0] || ""
                };
            }),
        removeCustomBgImage: (index)=>set((state)=>{
                const next = state.customBgImages.filter((_, i)=>i !== index);
                return {
                    customBgImages: next,
                    customBgImage: next[0] || ""
                };
            }),
        clearCustomBgImages: ()=>set({
                customBgImages: [],
                customBgImage: ""
            }),
        setBgChangeInterval: (n)=>set({
                bgChangeInterval: n
            }),
        setBgOpacity: (n)=>set({
                bgOpacity: n
            }),
        setDownloadFolder: (s)=>set({
                downloadFolder: s
            }),
        setCombinedEbookFolder: (s)=>set({
                combinedEbookFolder: s
            }),
        setLocalImportFolder: (s)=>set({
                localImportFolder: s
            }),
        setAutoUpdateEnabled: (b)=>set({
                autoUpdateEnabled: b
            }),
        setAutoUpdateInterval: (n)=>set({
                autoUpdateInterval: n
            }),
        setLastAutoUpdate: (n)=>set({
                lastAutoUpdate: n
            }),
        setCustomBackground: (c)=>set({
                customBgImage: c,
                customBgImages: c ? [
                    c
                ] : [],
                customBackground: c
            }),
        setCustomReaderBg: (c)=>set({
                customReaderBg: c
            }),
        setCustomReaderText: (c)=>set({
                customReaderText: c
            }),
        setCustomReaderAccent: (c)=>set({
                customReaderAccent: c
            }),
        setCustomSearchOrder: (order)=>set({
                customSearchOrder: order
            }),
        setParallelDownloads: (n)=>set({
                parallelDownloads: Math.max(1, Math.min(1000, n))
            }),
        setCFetchBatchSize: (n)=>set({
                cFetchBatchSize: Math.max(1, Math.min(500, n))
            })
    }), {
    name: "hfy-nekrocodexxx-settings",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                try {
                    localStorage.setItem(name, value);
                } catch  {}
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                _raw: value
                            }),
                            keepalive: true
                        }).catch(()=>{});
                    }
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        }))
}));
// ====== Reader themes mapping ======
const READER_THEMES = {
    void_dark: {
        bg: "#000000",
        text: "#E0E0E0",
        accent: "#00FFF0",
        name: "VOID"
    },
    night_red: {
        bg: "#0D0000",
        text: "#FF9999",
        accent: "#FF003C",
        name: "BLOOD"
    },
    neo_teal: {
        bg: "#001A1A",
        text: "#00FFF0",
        accent: "#9D00FF",
        name: "MATRIX"
    },
    paper_burn: {
        bg: "#1A1208",
        text: "#D4B896",
        accent: "#FF7700",
        name: "ANALOG"
    },
    ice_white: {
        bg: "#F0F4F8",
        text: "#1A2332",
        accent: "#4FC3F7",
        name: "ICE"
    },
    amoled_black: {
        bg: "#000000",
        text: "#FFFFFF",
        accent: "#FF003C",
        name: "AMOLED"
    },
    arasaka_red: {
        bg: "#0A0001",
        text: "#FFCCCC",
        accent: "#CC0035",
        name: "ARASAKA"
    },
    netrunner_purple: {
        bg: "#08000F",
        text: "#C0B0FF",
        accent: "#9B30FF",
        name: "NETRUN"
    },
    militech_orange: {
        bg: "#0A0800",
        text: "#FFD9B0",
        accent: "#FF6B00",
        name: "MILITECH"
    },
    trauma_green: {
        bg: "#000A04",
        text: "#B0FFCC",
        accent: "#00FF88",
        name: "TRAUMA"
    },
    blackwall_teal: {
        bg: "#000A08",
        text: "#B0F0E8",
        accent: "#00E5D4",
        name: "BLACKWALL"
    },
    solar_amber: {
        bg: "#0F0A00",
        text: "#FFE8B0",
        accent: "#FFB000",
        name: "SOLAR"
    },
    deep_space: {
        bg: "#020208",
        text: "#B0B0D0",
        accent: "#4FC3F7",
        name: "DEEP SPACE"
    },
    terminal_green: {
        bg: "#000800",
        text: "#00FF00",
        accent: "#00FF00",
        name: "TERMINAL"
    },
    cyber_blue: {
        bg: "#000A14",
        text: "#B0D0FF",
        accent: "#00BFFF",
        name: "CYBER BLUE"
    },
    blood_moon: {
        bg: "#1A0000",
        text: "#FFB0B0",
        accent: "#FF0040",
        name: "BLOOD MOON"
    },
    toxic_green: {
        bg: "#001400",
        text: "#B0FFB0",
        accent: "#39FF14",
        name: "TOXIC"
    },
    sunset_burn: {
        bg: "#1A0A00",
        text: "#FFD0A0",
        accent: "#FF4500",
        name: "SUNSET"
    },
    midnight_violet: {
        bg: "#080014",
        text: "#D0B0FF",
        accent: "#8A2BE2",
        name: "MIDNIGHT"
    },
    crt_amber: {
        bg: "#0A0800",
        text: "#FFB000",
        accent: "#FF8C00",
        name: "CRT AMBER"
    },
    neon_pink: {
        bg: "#0A0008",
        text: "#FFB0D0",
        accent: "#FF1493",
        name: "NEON PINK"
    },
    frozen_steel: {
        bg: "#000A0A",
        text: "#B0D0D8",
        accent: "#4682B4",
        name: "FROZEN"
    },
    reader_custom: {
        bg: "#000000",
        text: "#E0E0E0",
        accent: "#00FFF0",
        name: "CUSTOM"
    }
};
const APP_THEMES = {
    cyber_red: {
        name: "NIGHT CITY",
        primary: "#FF003C",
        accent: "#00FFF0",
        bg: "#000000"
    },
    cyber_teal: {
        name: "ARASAKA NET",
        primary: "#00FFF0",
        accent: "#FF003C",
        bg: "#050A14"
    },
    cyber_yellow: {
        name: "CORPO GOLD",
        primary: "#FFE600",
        accent: "#FF7700",
        bg: "#0D0A00"
    },
    cyber_purple: {
        name: "NETRUNNER",
        primary: "#9D00FF",
        accent: "#00FFF0",
        bg: "#080014"
    },
    cyber_orange: {
        name: "MAELSTROM",
        primary: "#FF7700",
        accent: "#FF003C",
        bg: "#0D0600"
    },
    cyber_mono: {
        name: "GHOST DATA",
        primary: "#FFFFFF",
        accent: "#888888",
        bg: "#000000"
    },
    stellaris_blue: {
        name: "STELLARIS",
        primary: "#4FC3F7",
        accent: "#FFD54F",
        bg: "#050B14"
    },
    trauma_team: {
        name: "TRAUMA TEAM",
        primary: "#FF0000",
        accent: "#FFFFFF",
        bg: "#0A0004"
    },
    militech: {
        name: "MILITECH",
        primary: "#FFE000",
        accent: "#FF6B00",
        bg: "#0A0800"
    },
    blackwall: {
        name: "BLACKWALL",
        primary: "#00E5D4",
        accent: "#F0F0F0",
        bg: "#000A08"
    },
    biotechnica: {
        name: "BIOTECHNICA",
        primary: "#00FF88",
        accent: "#00BFFF",
        bg: "#000A04"
    },
    kang_tao: {
        name: "KANG TAO",
        primary: "#FF4500",
        accent: "#FFD700",
        bg: "#0A0200"
    },
    delamain: {
        name: "DELAMAIN",
        primary: "#FFD700",
        accent: "#00FFF0",
        bg: "#0A0A00"
    },
    placide: {
        name: "PLACIDE",
        primary: "#8B0000",
        accent: "#FF8C00",
        bg: "#050000"
    },
    neon_pink_app: {
        name: "NEON PINK",
        primary: "#FF1493",
        accent: "#00FFF0",
        bg: "#0A0008"
    },
    acid_green: {
        name: "ACID GREEN",
        primary: "#39FF14",
        accent: "#FF00FF",
        bg: "#001400"
    },
    ice_blue: {
        name: "ICE BLUE",
        primary: "#00BFFF",
        accent: "#FFFFFF",
        bg: "#000A14"
    },
    crimson_tide: {
        name: "CRIMSON TIDE",
        primary: "#DC143C",
        accent: "#FFD700",
        bg: "#0A0002"
    },
    void_purple: {
        name: "VOID PURPLE",
        primary: "#8A2BE2",
        accent: "#FF00FF",
        bg: "#04000A"
    },
    solar_flare: {
        name: "SOLAR FLARE",
        primary: "#FF6B00",
        accent: "#FFE000",
        bg: "#0A0500"
    },
    ghost_white: {
        name: "GHOST WHITE",
        primary: "#F0F0F0",
        accent: "#00FFF0",
        bg: "#0A0A0A"
    },
    dark_ember: {
        name: "DARK EMBER",
        primary: "#FF4500",
        accent: "#FFD700",
        bg: "#0A0200"
    },
    toxic_waste: {
        name: "TOXIC WASTE",
        primary: "#ADFF2F",
        accent: "#FF00FF",
        bg: "#0A0A00"
    },
    synthwave: {
        name: "SYNTHWAVE",
        primary: "#FF00FF",
        accent: "#00FFFF",
        bg: "#0A0014"
    },
    vaporwave: {
        name: "VAPORWAVE",
        primary: "#FF71CE",
        accent: "#01CDFE",
        bg: "#0A0014"
    },
    custom: {
        name: "CUSTOM",
        primary: "#FF003C",
        accent: "#00FFF0",
        bg: "#000000"
    }
};
const useLibrary = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set)=>({
        items: {},
        addToLibrary: (item)=>set((s)=>({
                    items: {
                        ...s.items,
                        [item.seriesId]: {
                            seriesId: item.seriesId,
                            title: item.title,
                            author: item.author,
                            coverAccent: item.coverAccent || "#00FFF0",
                            isFavorite: item.isFavorite ?? false,
                            lastReadChapterId: item.lastReadChapterId ?? null,
                            lastReadChapterTitle: item.lastReadChapterTitle ?? null,
                            lastReadPosition: item.lastReadPosition ?? 0,
                            lastReadTimestamp: item.lastReadTimestamp ?? 0,
                            dateAdded: Date.now(),
                            progress: item.progress ?? 0,
                            chapterCount: item.chapterCount,
                            score: item.score,
                            readChapters: item.readChapters ?? []
                        }
                    }
                })),
        toggleFavorite: (seriesId)=>set((s)=>{
                const item = s.items[seriesId];
                if (!item) return s;
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            isFavorite: !item.isFavorite
                        }
                    }
                };
            }),
        updateProgress: (seriesId, chapterId, chapterTitle, position, progress)=>set((s)=>{
                const item = s.items[seriesId];
                if (!item) return s;
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            lastReadChapterId: chapterId,
                            lastReadChapterTitle: chapterTitle,
                            lastReadPosition: position,
                            lastReadTimestamp: Date.now(),
                            progress: Math.max(item.progress, progress)
                        }
                    }
                };
            }),
        removeFromLibrary: (seriesId)=>set((s)=>{
                const { [seriesId]: _, ...rest } = s.items;
                return {
                    items: rest
                };
            }),
        markUnread: (seriesId)=>set((s)=>{
                const item = s.items[seriesId];
                if (!item) return s;
                // Also clear the readChapters array so ALL chapters show as unread
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            lastReadChapterId: null,
                            lastReadChapterTitle: null,
                            lastReadPosition: 0,
                            lastReadTimestamp: 0,
                            progress: 0,
                            readChapters: []
                        }
                    }
                };
            }),
        markRead: (seriesId)=>set((s)=>{
                const item = s.items[seriesId];
                if (!item) return s;
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            progress: 1,
                            lastReadTimestamp: Date.now()
                        }
                    }
                };
            }),
        updateSeriesStats: (seriesId, chapterCount, score)=>set((s)=>{
                const item = s.items[seriesId];
                if (!item) return s;
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            chapterCount,
                            score: score ?? item.score
                        }
                    }
                };
            }),
        toggleChapterRead: (seriesId, chapterId)=>set((s)=>{
                // Auto-add to library if not present
                if (!s.items[seriesId]) {
                    return {
                        items: {
                            ...s.items,
                            [seriesId]: {
                                seriesId,
                                title: seriesId.replace(/_/g, " "),
                                author: "unknown",
                                coverAccent: "#00FFF0",
                                isFavorite: false,
                                lastReadChapterId: chapterId,
                                lastReadChapterTitle: null,
                                lastReadPosition: 0,
                                lastReadTimestamp: Date.now(),
                                dateAdded: Date.now(),
                                progress: 0,
                                readChapters: [
                                    chapterId
                                ]
                            }
                        }
                    };
                }
                const item = s.items[seriesId];
                const readChapters = item.readChapters || [];
                const isRead = readChapters.includes(chapterId);
                // Also check readTracker for true read state
                let trackerRead = false;
                try {
                    trackerRead = _read_tracker__WEBPACK_IMPORTED_MODULE_0__/* .readTracker */ .T.isRead(seriesId, chapterId);
                } catch  {}
                const actuallyRead = isRead || trackerRead;
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            readChapters: actuallyRead ? readChapters.filter((id)=>id !== chapterId) : [
                                ...readChapters,
                                chapterId
                            ]
                        }
                    }
                };
            }),
        markChapterRead: (seriesId, chapterId)=>set((s)=>{
                if (!s.items[seriesId]) {
                    return {
                        items: {
                            ...s.items,
                            [seriesId]: {
                                seriesId,
                                title: seriesId.replace(/_/g, " "),
                                author: "unknown",
                                coverAccent: "#00FFF0",
                                isFavorite: false,
                                lastReadChapterId: null,
                                lastReadChapterTitle: null,
                                lastReadPosition: 0,
                                lastReadTimestamp: 0,
                                dateAdded: Date.now(),
                                progress: 0,
                                readChapters: [
                                    chapterId
                                ]
                            }
                        }
                    };
                }
                const item = s.items[seriesId];
                const current = new Set(item.readChapters ?? []);
                current.add(chapterId);
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            readChapters: Array.from(current)
                        }
                    }
                };
            }),
        markChapterUnread: (seriesId, chapterId)=>set((s)=>{
                if (!s.items[seriesId]) return s;
                const item = s.items[seriesId];
                const current = new Set(item.readChapters ?? []);
                current.delete(chapterId);
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            readChapters: Array.from(current)
                        }
                    }
                };
            }),
        markChaptersBulk: (seriesId, chapterIds, read)=>set((s)=>{
                if (!s.items[seriesId]) {
                    return {
                        items: {
                            ...s.items,
                            [seriesId]: {
                                seriesId,
                                title: seriesId.replace(/_/g, " "),
                                author: "unknown",
                                coverAccent: "#00FFF0",
                                isFavorite: false,
                                lastReadChapterId: null,
                                lastReadChapterTitle: null,
                                lastReadPosition: 0,
                                lastReadTimestamp: 0,
                                dateAdded: Date.now(),
                                progress: 0,
                                readChapters: read ? chapterIds : []
                            }
                        }
                    };
                }
                const item = s.items[seriesId];
                const current = new Set(item.readChapters ?? []);
                if (read) {
                    for (const id of chapterIds)current.add(id);
                } else {
                    for (const id of chapterIds)current.delete(id);
                }
                return {
                    items: {
                        ...s.items,
                        [seriesId]: {
                            ...item,
                            readChapters: Array.from(current)
                        }
                    }
                };
            })
    }), {
    name: "hfy-nekrocodexxx-library",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                try {
                    localStorage.setItem(name, value);
                } catch  {}
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                _raw: value
                            }),
                            keepalive: true
                        }).catch(()=>{});
                    }
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        })),
    // Migrate: ensure all existing items have readChapters array
    migrate: (persisted)=>{
        if (persisted?.items) {
            for(const key in persisted.items){
                if (!persisted.items[key].readChapters) {
                    persisted.items[key].readChapters = [];
                }
            }
        }
        return persisted;
    },
    version: 2
}));
const useDownloads = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set)=>({
        jobs: [],
        addJob: (job)=>{
            const id = job.id || `job_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
            set((s)=>({
                    jobs: [
                        {
                            ...job,
                            id,
                            status: "pending",
                            progress: 0,
                            completedChapters: 0,
                            createdAt: Date.now()
                        },
                        ...s.jobs
                    ]
                }));
            return id;
        },
        updateJob: (id, patch)=>set((s)=>({
                    jobs: s.jobs.map((j)=>j.id === id ? {
                            ...j,
                            ...patch
                        } : j)
                })),
        removeJob: (id)=>set((s)=>({
                    jobs: s.jobs.filter((j)=>j.id !== id)
                })),
        clearAll: ()=>set({
                jobs: []
            }),
        pauseJob: (id)=>set((s)=>({
                    jobs: s.jobs.map((j)=>j.id === id ? {
                            ...j,
                            status: "paused"
                        } : j)
                })),
        resumeJob: (id)=>set((s)=>({
                    jobs: s.jobs.map((j)=>j.id === id ? {
                            ...j,
                            status: "running"
                        } : j)
                }))
    }), {
    name: "hfy-nekrocodexxx-downloads",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                try {
                    localStorage.setItem(name, value);
                } catch  {}
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                _raw: value
                            }),
                            keepalive: true
                        }).catch(()=>{});
                    }
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        }))
}));
const useInAppBrowser = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)((set)=>({
        url: null,
        open: (url)=>set({
                url
            }),
        close: ()=>set({
                url: null
            })
    }));
const useRedditAuth = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set)=>({
        appAccessToken: null,
        appTokenExpiresAt: null,
        setAppToken: (token, expiresIn)=>set({
                appAccessToken: token,
                appTokenExpiresAt: Date.now() + expiresIn * 1000,
                isAuthenticated: true
            }),
        clientId: null,
        accessToken: null,
        refreshToken: null,
        username: null,
        isAuthenticated: false,
        setAuth: (clientId, accessToken, refreshToken)=>set({
                clientId,
                accessToken,
                refreshToken,
                isAuthenticated: true
            }),
        setUsername: (username)=>set({
                username
            }),
        logout: ()=>set({
                appAccessToken: null,
                appTokenExpiresAt: null,
                clientId: null,
                accessToken: null,
                refreshToken: null,
                username: null,
                isAuthenticated: false
            })
    }), {
    name: "hfy-nekrocodexxx-reddit-auth",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>{
        return _persistent_storage__WEBPACK_IMPORTED_MODULE_1__/* .dualStorage */ .KS;
    })
}));
const useBrowseCache = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set)=>({
        items: [],
        lastFetched: 0,
        hasFetched: false,
        setItems: (items)=>set({
                items,
                lastFetched: Date.now(),
                hasFetched: true
            }),
        mergeItems: (newItems)=>set((s)=>{
                const existingIds = new Set(s.items.map((i)=>i.id));
                const toAdd = newItems.filter((i)=>!existingIds.has(i.id));
                return {
                    items: [
                        ...s.items,
                        ...toAdd
                    ],
                    lastFetched: Date.now()
                };
            }),
        clear: ()=>set({
                items: [],
                lastFetched: 0,
                hasFetched: false
            })
    }), {
    name: "hfy-nekrocodexxx-browse-cache",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                try {
                    localStorage.setItem(name, value);
                } catch  {}
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                _raw: value
                            }),
                            keepalive: true
                        }).catch(()=>{});
                    }
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        }))
}));
const useUrlOverrides = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set, get)=>({
        overrides: {},
        setUrlOverride: (seriesId, type, url)=>set((s)=>({
                    overrides: {
                        ...s.overrides,
                        [seriesId]: {
                            ...s.overrides[seriesId],
                            [type]: url
                        }
                    }
                })),
        clearUrlOverride: (seriesId)=>set((s)=>{
                const newOverrides = {
                    ...s.overrides
                };
                delete newOverrides[seriesId];
                return {
                    overrides: newOverrides
                };
            }),
        clearUrlOverrideType: (seriesId, type)=>set((s)=>{
                const existing = s.overrides[seriesId];
                if (!existing) return s;
                const updated = {
                    ...existing
                };
                delete updated[type];
                // If no overrides remain for this series, remove the entry entirely
                if (Object.keys(updated).length === 0) {
                    const newOverrides = {
                        ...s.overrides
                    };
                    delete newOverrides[seriesId];
                    return {
                        overrides: newOverrides
                    };
                }
                return {
                    overrides: {
                        ...s.overrides,
                        [seriesId]: updated
                    }
                };
            }),
        getOverride: (seriesId, type, fallback)=>{
            const v = get().overrides[seriesId]?.[type];
            if (v && v.trim().length > 0) return v;
            return fallback;
        }
    }), {
    name: "hfy-nekrocodexxx-url-overrides",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                try {
                    localStorage.setItem(name, value);
                } catch  {}
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                _raw: value
                            }),
                            keepalive: true
                        }).catch(()=>{});
                    }
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        }))
}));
const useChapterUrlOverrides = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set, get)=>({
        overrides: {},
        setOverride: (postId, url)=>set((s)=>({
                    overrides: {
                        ...s.overrides,
                        [postId]: url
                    }
                })),
        clearOverride: (postId)=>set((s)=>{
                if (!s.overrides[postId]) return s;
                const newOverrides = {
                    ...s.overrides
                };
                delete newOverrides[postId];
                return {
                    overrides: newOverrides
                };
            }),
        getOverride: (postId, fallback)=>{
            const v = get().overrides[postId];
            if (v && v.trim().length > 0) return v;
            return fallback;
        },
        clearMany: (postIds)=>set((s)=>{
                const newOverrides = {
                    ...s.overrides
                };
                for (const id of postIds)delete newOverrides[id];
                return {
                    overrides: newOverrides
                };
            })
    }), {
    name: "hfy-nekrocodexxx-chapter-url-overrides",
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                try {
                    localStorage.setItem(name, value);
                } catch  {}
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                _raw: value
                            }),
                            keepalive: true
                        }).catch(()=>{});
                    }
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        }))
}));
const useSeriesScores = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)()((0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .persist */ .Zr)((set, get)=>({
        scores: {},
        setChapterScore: (seriesId, postId, score)=>set((state)=>{
                const seriesScores = state.scores[seriesId] || {};
                if (seriesScores[postId] === score) return state;
                return {
                    scores: {
                        ...state.scores,
                        [seriesId]: {
                            ...seriesScores,
                            [postId]: score
                        }
                    }
                };
            }),
        setSeriesScores: (seriesId, chapterScores)=>set((state)=>({
                    scores: {
                        ...state.scores,
                        [seriesId]: chapterScores
                    }
                })),
        getSeriesTotal: (seriesId)=>{
            const seriesScores = get().scores[seriesId];
            if (!seriesScores) return 0;
            return Object.values(seriesScores).reduce((sum, s)=>sum + (s || 0), 0);
        },
        getChapterScore: (seriesId, postId)=>{
            const seriesScores = get().scores[seriesId];
            return seriesScores?.[postId] ?? 0;
        },
        clearSeries: (seriesId)=>set((state)=>{
                const { [seriesId]: _, ...rest } = state.scores;
                return {
                    scores: rest
                };
            }),
        loadAllScoresFromServer: async ()=>{
            // Fetch all cached chapter scores from the server in one shot.
            // The server stores these as hfy-scores-<seriesId>.json files.
            // This populates the store so the BrowseScreen can show total upvotes
            // per series at startup without entering each series.
            try {
                if (false) {}
                // 1. Fetch per-series scores from hfy-scores-<seriesId>.json files
                const res = await fetch("/api/store-scores-all", {
                    cache: "no-store"
                });
                if (res.ok) {
                    const data = await res.json();
                    if (data.ok && data.scores) {
                        set((state)=>{
                            const next = {
                                ...state.scores
                            };
                            for (const [seriesId, serverScores] of Object.entries(data.scores)){
                                if (!next[seriesId] || Object.keys(next[seriesId]).length === 0) {
                                    next[seriesId] = serverScores;
                                }
                            }
                            return {
                                scores: next
                            };
                        });
                    }
                }
                // 2. Also fetch the legacy whole-map file (hfy-series-scores-v1.json)
                //    that ReaderScreen writes to via the persist adapter. This file
                //    contains scores for chapters read via the ReaderScreen that may
                //    not have a per-series file yet.
                try {
                    const legacyRes = await fetch("/api/store/hfy-series-scores-v1", {
                        cache: "no-store"
                    });
                    if (legacyRes.ok) {
                        const legacyData = await legacyRes.json();
                        if (legacyData.ok && legacyData.data && typeof legacyData.data === "object") {
                            set((state)=>{
                                const next = {
                                    ...state.scores
                                };
                                for (const [seriesId, serverScores] of Object.entries(legacyData.data)){
                                    if (!next[seriesId] || Object.keys(next[seriesId]).length === 0) {
                                        next[seriesId] = serverScores;
                                    }
                                }
                                return {
                                    scores: next
                                };
                            });
                        }
                    }
                } catch  {}
            } catch  {
            // Network failure or server not ready — silently ignore
            }
        }
    }), {
    name: "hfy-series-scores-v1",
    version: 1,
    // Use a server-only storage adapter for scores — this data can be
    // very large (80,000+ chapters) and would overflow localStorage
    // and cookies. The server is the source of truth.
    // Scores are loaded per-series on demand in SeriesDetailScreen.
    storage: (0,zustand_middleware__WEBPACK_IMPORTED_MODULE_3__/* .createJSONStorage */ .KU)(()=>({
            getItem: (name)=>{
                // Only try localStorage — don't trigger server restore
                // (scores are loaded per-series, not all at once)
                try {
                    return localStorage.getItem(name);
                } catch  {
                    return null;
                }
            },
            setItem: (name, value)=>{
                // Only write to localStorage if small enough, otherwise skip
                // (server is the source of truth for large datasets)
                if (value.length < 100000) {
                    try {
                        localStorage.setItem(name, value);
                    } catch  {}
                }
                // Always write to server (debounced via fetch)
                if ( true && value && value.length > 0) {
                    try {
                        const parsed = JSON.parse(value);
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify(parsed),
                            keepalive: true
                        }).catch(()=>{});
                    } catch  {}
                }
            },
            removeItem: (name)=>{
                try {
                    localStorage.removeItem(name);
                } catch  {}
                if (true) {
                    fetch(`/api/store/${encodeURIComponent(name)}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(null),
                        keepalive: true
                    }).catch(()=>{});
                }
            }
        }))
}));
const useNav = (0,zustand__WEBPACK_IMPORTED_MODULE_2__/* .create */ .v)((set, get)=>({
        screen: "browse",
        previousScreen: "browse",
        seriesId: null,
        chapterId: null,
        browseSeriesId: null,
        browseChapterId: null,
        chapterList: null,
        goTo: (screen)=>set({
                screen
            }),
        openSeries: (seriesId)=>{
            const current = get().screen;
            const prev = current === "seriesDetail" || current === "reader" ? get().previousScreen : current;
            set({
                screen: "seriesDetail",
                browseSeriesId: seriesId,
                previousScreen: prev
            });
        },
        openChapter: (seriesId, chapterId, chapterList)=>set({
                screen: "reader",
                browseSeriesId: seriesId,
                browseChapterId: chapterId,
                chapterList: chapterList ?? get().chapterList
            }),
        goBack: ()=>{
            const s = get().screen;
            if (s === "reader") {
                set({
                    screen: "seriesDetail"
                });
            } else if (s === "seriesDetail") {
                // Return to the tab we were on before opening the series
                const prev = get().previousScreen;
                set({
                    screen: prev
                });
            } else {
                set({
                    screen: "browse"
                });
            }
        }
    }));


/***/ })

}]);
```


---

END OF APK MANUAL
