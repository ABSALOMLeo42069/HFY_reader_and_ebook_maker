# HFY NEKROCODEXXX — How GitHub Repositories Were Used

**Version:** FX45 v31  
**Last Updated:** 2026-07-30

---

## Table of Contents

1. [Overview of Reference Repositories](#1-overview-of-reference-repositories)
2. [easy-reddit-downloader (josephrcox)](#2-easy-reddit-downloader-josephrcox)
3. [hfy2epub (hacst)](#3-hfy2epub-hacst)
4. [arctic_shift (ArthurHeitmann)](#4-arctic_shift-arthurheitmann)
5. [ArcticZim (IMayBeABitShy)](#5-arcticzim-imaybeabitshy)
6. [How Each Repository Was Integrated](#6-how-each-repository-was-integrated)
7. [Code Comparison: Original vs. Adapted](#7-code-comparison-original-vs-adapted)
8. [Attribution and Licensing](#8-attribution-and-licensing)

---

## 1. Overview of Reference Repositories

HFY NEKROCODEXXX is built upon the foundations of four open-source GitHub repositories. Each repository contributed specific concepts, code patterns, or architectural decisions that were adapted and integrated into the application. This document explains in detail how each repository was used, what code was borrowed or adapted, and how the integration works.

The four reference repositories are:

1. **easy-reddit-downloader** by josephrcox — A Node.js Reddit post downloader that uses the public Reddit JSON API without OAuth. This repository contributed the authless .json fetch pattern, the post type classification system, and the file naming/sanitization logic.

2. **hfy2epub** by hacst — A browser-based tool that converts r/HFY post series into EPUB files. This repository contributed the chapter chain following algorithm (first-match next-link following), the URL shortener handling, the comment content collection heuristic, and the author opt-out ([NOEPUB]) concept.

3. **arctic_shift** by ArthurHeitmann — A Reddit data archive project that provides JSONL dumps and an API. This repository contributed the data format (JSONL with specific fields), the API endpoints for searching posts and comments, and the file stream parsing utilities for .zst compressed files.

4. **ArcticZim** by IMayBeABitShy — A tool for converting Arctic Shift data into ZIM files (offline web archives). This repository contributed the post card UI pattern, the author browser concept, the pagination approach, and the Jinja2 template rendering patterns that inspired the Archive tab layout.

---

## 2. easy-reddit-downloader (josephrcox)

### Repository Overview

**URL:** https://github.com/josephrcox/easy-reddit-downloader  
**License:** MIT  
**Language:** Node.js  
**Purpose:** Download posts from Reddit subreddits without OAuth

easy-reddit-downloader is a command-line tool that downloads posts from any public subreddit. It requires no OAuth or login — it simply appends `.json` to Reddit URLs to access the public JSON API. The tool supports downloading self posts (as markdown), media posts (images/videos), link posts (as HTML redirects), and YouTube videos (via ytdl-core + ffmpeg).

### What Was Borrowed

#### 2.1 Authless JSON Fetch Pattern

The core concept of appending `.json` to Reddit URLs to access public data without authentication was borrowed directly from easy-reddit-downloader. The original code in `lib/api.js`:

```javascript
// From easy-reddit-downloader/lib/api.js
async function downloadSubredditPosts(target, lastPostId = '', onComplete) {
    const isUser = isUserProfile(target);
    const name = extractName(target);
    
    const reqUrl = buildRedditApiUrl({
        target: name,
        isUser,
        sorting: state.sorting,
        time: state.time,
        limit: postsRemaining,
        after: lastPostId,
    });
    
    const response = await axios.get(reqUrl, {
        timeout: DEFAULT_REQUEST_TIMEOUT,
    });
    const data = response.data;
    // ... process data
}
```

This pattern was adapted in HFY NEKROCODEXXX's reddit-scraper (4034.js) as the "Strategy 3: Direct .json fallback" and "Strategy R: Authless .json with browser UA" fetch strategies. The adapted code:

```javascript
// In HFY NEKROCODEXXX's 4034.js (adapted)
// Strategy R: Authless .json with browser UA (RedDownloader)
try {
    const rd = await fetchWithRedDownloader(`${REDDIT_BASE}/r/HFY/wiki/series.json`, 12000);
    if (rd.ok) {
        const data = JSON.parse(rd.text);
        const md = data?.data?.content_md ?? "";
        const series = parseSeriesIndexMarkdown(md);
        if (series.length > 100) {
            return { series, proxyId: "reddownloader", ... };
        }
    }
} catch {}
```

#### 2.2 URL Building Pattern

The `buildRedditApiUrl` function from easy-reddit-downloader was adapted for building Reddit API URLs:

```javascript
// From easy-reddit-downloader/lib/utils.js
function buildRedditApiUrl({ target, isUser, isSearch, sorting, time, limit, after = '' }) {
    if (isUser) {
        return `https://www.reddit.com/user/${target}/submitted/.json?limit=${limit}&after=${after}`;
    } else if (isSearch) {
        target = target.replaceAll(':', '%3A');
        return `https://www.reddit.com/search/.json?q=${target}&type=post&include_over_18=on&sort=${sorting}&limit=${limit}&after=${after}`;
    }
    return `https://www.reddit.com/r/${target}/${sorting}/.json?sort=${sorting}&t=${time}&limit=${limit}&after=${after}`;
}
```

This was adapted for the `/api/search` and `/api/fetch-all-posts` routes in HFY NEKROCODEXXX.

#### 2.3 Post Type Classification

The `getPostType` function from easy-reddit-downloader was adapted for classifying Reddit posts:

```javascript
// From easy-reddit-downloader/lib/utils.js
function getPostType(post) {
    if (post.post_hint === 'self' || post.is_self) return 0;  // self/text post
    if (post.post_hint === 'image' || ...) return 1;            // media post
    if (post.poll_data !== undefined) return 3;                  // poll
    if (post.domain.includes('reddit.com') && post.is_gallery) return 4; // gallery
    return 2; // link post
}
```

This classification system was used in the Archive tab to display post type badges and filter posts by type.

#### 2.4 File Name Sanitization

The `sanitizeFileName` function was adapted for creating filesystem-safe filenames:

```javascript
// From easy-reddit-downloader/lib/utils.js
function sanitizeFileName(fileName) {
    return fileName
        .replace(/[/\?%*:|"<>]/g, '-')
        .replace(/([^/])\/([^/])/g, '$1_$2');
}
```

This was used in the download/merge system to ensure EPUB and TXT files have valid names on all platforms.

#### 2.5 MAX_POSTS_PER_REQUEST Constant

The constant `MAX_POSTS_PER_REQUEST = 100` (Reddit's maximum per-request limit) was borrowed directly. This is used in the C-FETCH and auto-discover systems to paginate through Reddit results.

### What Was NOT Borrowed

- The interactive prompt system (HFY NEKROCODEXXX uses a web UI, not CLI prompts)
- The YouTube video download feature (not needed for a text story reader)
- The gallery post download feature (not needed for text stories)
- The `download_post_list.txt` file-based post list (HFY NEKROCODEXXX uses a web-based chapter search)
- The `repeatForever` interval system (HFY NEKROCODEXXX has its own auto-update system)

### Attribution

The Settings → About section of HFY NEKROCODEXXX explicitly credits easy-reddit-downloader:

```
FALLBACK: easy-reddit-downloader port (josephrcox) + Wayback Machine + hfy.foundation
```

The "Tier R: Authless .json" in the Downloader Cascade settings section also credits easy-reddit-downloader:

```
TIER R · AUTHLESS .JSON
No OAuth · browser UA · no rate limit
easy-reddit-downloader + RedDownloader + reddit-json-scraper
```

---

## 3. hfy2epub (hacst)

### Repository Overview

**URL:** https://github.com/hacst/hfy2epub  
**License:** MIT  
**Language:** JavaScript (browser-based)  
**Purpose:** Convert r/HFY post series into EPUB files

hfy2epub is a pure browser-based tool that converts HFY post series into EPUB files. It requires no server component — all work is done in the browser. The tool can retrieve series information from HFY wiki pages or by following "next" links starting from an initial post.

### What Was Borrowed

#### 3.1 Chapter Chain Following Algorithm

The most significant contribution from hfy2epub is the chapter chain following algorithm. The `findSeriesParts` function recursively follows "next" links to discover all chapters in a series:

```javascript
// From hfy2epub/js/hfy2epub.js
function findSeriesParts(startUrl, callbacks) {
    var collectedPosts = [];
    var previousNames = [];
    var collectPostRecurse = function(url) {
        collectPost(url, function(collectedPost) {
            collectedPosts.push(collectedPost);
            if (callbacks.collectedPost) {
                if (callbacks.collectedPost(collectedPost) === false) return;
            }
            previousNames.push(nameFromURL(url));
            var nextUrl = findNextURL(collectedPost.content, previousNames);
            if (nextUrl) {
                if (callbacks.foundUrl) {
                    if (callbacks.foundUrl(nextUrl) === false) return;
                }
                collectPostRecurse(nextUrl);
            } else {
                if (callbacks.done) {
                    if (callbacks.done(collectedPosts) === false) return;
                }
            }
        }, function(error) {
            if (callbacks.error) {
                if (callbacks.error(error) === false) return;
            }
        });
    };
    collectPostRecurse(startUrl);
}
```

This algorithm was adapted in HFY NEKROCODEXXX's crawl engine (in 4034.js) as the BFS crawl function. The adapted version:

```javascript
// In HFY NEKROCODEXXX's 4034.js (adapted)
async function crawlAllChapters(startPostId, options) {
    const visited = new Set();
    const queue = [startPostId];
    const results = [];
    
    while (queue.length > 0) {
        const postId = queue.shift();
        if (visited.has(postId)) continue;
        visited.add(postId);
        
        const content = await fetchPostContent(postId);
        if (!content) continue;
        
        results.push(content);
        
        // Find next chapter links (hfy2epub approach: first match)
        const nextLinks = findChapterLinks(
            content.selftext,
            content.selftextHtml,
            getActiveLinkPatterns()
        );
        
        for (const link of nextLinks) {
            if (!visited.has(link.postId)) {
                queue.push(link.postId);
            }
        }
    }
    
    return results;
}
```

#### 3.2 Next Link Detection Heuristic

The `findNextURL` function uses a regex to detect "next" links in post content:

```javascript
// From hfy2epub/js/hfy2epub.js
function findNextURL(content, previousNames) {
    var parser = new DOMParser();
    var regex = new RegExp(document.getElementById("nextPostRegex").value, "i");
    var doc = parser.parseFromString(content, "text/html");
    var links = doc.getElementsByTagName("a");
    for (var i = 0; i < links.length; i++) {
        var link = links[i];
        if (link.textContent.match(regex)) {
            var potentialNextLink = link.getAttribute('href');
            if (!previousNames.includes(nameFromURL(potentialNextLink))) {
                return potentialNextLink;
            }
        }
    }
    return null;
}
```

This was adapted into the `findChapterLinks` function in HFY NEKROCODEXXX, which uses a set of built-in patterns:

```javascript
// In HFY NEKROCODEXXX's 4034.js (adapted)
const BUILT_IN_PATTERNS = [
    { regex: /next\s*(chapter|part|episode)?/i, name: "next" },
    { regex: /epilogue/i, name: "epilogue" },
    { regex: /part\s*\d+/i, name: "part N" },
    { regex: /chapter\s*\d+/i, name: "chapter N" },
    { regex: /episode\s*\d+/i, name: "episode N" },
    { regex: /^>/i, name: "arrow >" },
    { regex: /book\s*\d+/i, name: "book N" },
];

function findChapterLinks(selftext, selftextHtml, patterns) {
    // Parse HTML content for links
    // Match link text against patterns
    // Return array of { postId, url, text }
}
```

Users can toggle these patterns on/off in Settings and add custom regex patterns.

#### 3.3 URL Shortener Handling

The `unshorten` function from hfy2epub handles Reddit's URL shortener (redd.it):

```javascript
// From hfy2epub/js/hfy2epub.js
function unshorten(url) {
    if (!isWikiLink(url)) {
        return urlFromName(nameFromURL(url));
    } else {
        return url.replace(/^http:\/\//i, 'https://');
    }
}

function nameFromURL(url) {
    var match = url.match(/redd\.it\/([A-Za-z0-9]+)/i);
    if (match) return match[1].toLowerCase();
    match = url.match(/r\/HFY\/comments\/([A-Za-z0-9]+)/i);
    if (match) return match[1].toLowerCase();
    return undefined;
}
```

This was adapted for URL normalization in HFY NEKROCODEXXX's chapter deduplication system. When checking if a chapter already exists in a series, URLs are normalized (shortened URLs are expanded, trailing slashes are removed, case is lowered) before comparison.

#### 3.4 Comment Content Collection

The `collectPostContentInComments` function detects when an author continues the story in the comments:

```javascript
// From hfy2epub/js/hfy2epub.js
function collectPostContentInComments(post, children, successCallback, errorCallback) {
    var isContentComment = function(comment, depthOffset) {
        var authorReplyingToHimself = comment.depth + depthOffset > 1;
        var contentIsKindaLengthy = comment.body_html.length > 2048;
        return authorReplyingToHimself || contentIsKindaLengthy;
    };
    // ... recursively collect comments by the same author
}
```

This heuristic was adapted in HFY NEKROCODEXXX's fetchPostContent function. When a post's selftext is shorter than expected, the system checks comments for additional content by the same author.

#### 3.5 Author Opt-Out ([NOEPUB] tag)

hfy2epub respects an author opt-out mechanism where authors can include `[NOEPUB]` in their post title or content to prevent the tool from processing it. HFY NEKROCODEXXX adapted this concept — while the app doesn't refuse to process tagged posts, it does display a warning when a post contains `[NOEPUB]` and reminds the user not to distribute the content.

### What Was NOT Borrowed

- The EPUB generation library (hfy2epub uses js-epub-maker; HFY NEKROCODEXXX uses JSZip directly)
- The Bootstrap 3 UI (HFY NEKROCODEXXX uses Tailwind CSS 4 + custom cyberpunk components)
- The Handlebars templating (HFY NEKROCODEXXX uses React)
- The Sortable.js drag-and-drop (HFY NEKROCODEXXX uses @dnd-kit)

### Attribution

The Settings → About section credits hfy2epub as part of the fallback system. The crawl engine's approach is documented as "based on hfy2epub's first-match next-link following."

---

## 4. arctic_shift (ArthurHeitmann)

### Repository Overview

**URL:** https://github.com/ArthurHeitmann/arctic_shift  
**License:** Open source  
**Language:** Python (scripts), JSON (data schemas)  
**Purpose:** Reddit data archive with dumps, API, and web interface

Arctic Shift is a project that makes Reddit data accessible to researchers, moderators, and everyone else. It provides large data dumps (via Academic Torrents), a REST API, and a web search interface. The data spans from 2005 to the present, with monthly dumps available.

### What Was Borrowed

#### 4.1 JSONL Data Format

Arctic Shift's JSONL format became the basis for HFY NEKROCODEXXX's JSONL archive integration. Each line in the JSONL file is a JSON object representing a Reddit post:

```json
{
  "id": "ciqsdj",
  "title": "[Zyz] Translocation",
  "author": "tsavong117",
  "score": 424,
  "created_utc": 1564320000,
  "permalink": "/r/HFY/comments/ciqsdj/zyz_translocation/",
  "subreddit": "HFY",
  "num_comments": 15,
  "over_18": false,
  "is_self": true,
  "selftext": "To say Zyz was frustrated...",
  "selftext_html": "...",
  "url": "https://www.reddit.com/r/HFY/comments/ciqsdj/zyz_translocation/",
  "link_flair_text": null,
  "upvote_ratio": 0.95,
  "retrieved_on": 1620000000,
  "_meta": {
    "retrieved_2nd_on": 1620000000,
    "was_deleted_later": false,
    "is_edited": false
  }
}
```

The `_meta` field (introduced in Arctic Shift's November 2023+ dumps) tracks whether a post was deleted, edited, or initially unavailable. HFY NEKROCODEXXX's JSONL indexer parses these fields and uses them for display (e.g., showing a "deleted" badge for posts that were deleted after archiving).

#### 4.2 API Endpoints

Arctic Shift's API at `https://arctic-shift.photon-reddit.com` provides several endpoints that HFY NEKROCODEXXX calls as part of its fetch cascade:

**Post Search:**
```
GET /api/posts/search?subreddit=HFY&author=username&after=2024-01-01&limit=100&sort=asc
```

This is used in the "Fetch Missing" and "Continue Fetch" routes to find chapters that aren't in the JSONL archive.

**Post ID Lookup:**
```
GET /api/posts/ids?ids=ciqsdj,eitwb3&md2html=true
```

This is used to batch-fetch specific posts by ID.

**Comment Tree:**
```
GET /api/comments/tree?link_id=t3_ciqsdj&limit=9999&md2html=true
```

This is used to fetch comments for posts that continue the story in comments (hfy2epub approach).

#### 4.3 File Stream Parsing

Arctic Shift's `fileStreams.py` provides utilities for parsing different file formats:

```python
# From arctic_shift/scripts/fileStreams.py
def getFileJsonStream(path, f):
    if path.endswith('.jsonl') or path.endswith('.ndjson'):
        return getJsonLinesFileJsonStream(f)
    elif path.endswith('.zst'):
        return getZstFileJsonStream(f)
    elif path.endswith('.zst_blocks'):
        return getZstBlocksFileJsonStream(f)
    elif path.endswith('.json'):
        return getJsonFileStream(f)
    else:
        return None

def getZstFileJsonStream(f, chunk_size=1024*1024*10):
    decompressor = zstandard.ZstdDecompressor(max_window_size=2**31)
    currentString = ""
    zstReader = decompressor.stream_reader(f)
    while True:
        chunk = zstReader.read(chunk_size)
        if not chunk:
            break
        currentString += chunk.decode('utf-8', 'replace')
        lines = currentString.split('\n')
        currentString = lines[-1]
        for line in lines[:-1]:
            yield json.loads(line)
```

This pattern was adapted in HFY NEKROCODEXXX's JSONL indexing engine. The JavaScript version uses the File System Access API's stream reader:

```javascript
// In HFY NEKROCODEXXX's page chunk (adapted)
const file = await fileEntry.getFile();
const stream = file.stream();
const reader = stream.getReader();
const decoder = new TextDecoder();
let buffer = '';

while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop(); // Keep incomplete line in buffer
    
    for (const line of lines) {
        if (!line.trim()) continue;
        try {
            const post = JSON.parse(line);
            // Add to index
        } catch {}
    }
}
```

#### 4.4 Data Modification Notes

Arctic Shift's documentation describes how data is modified from the raw Reddit API:

- All objects are sorted by `created_utc`, `id` (secondary) in ascending order
- Text is encoded as UTF-8
- JSON keys are sorted
- The `body_html` field is removed (to save space)
- `retrieved_on` is added to indicate when the object was retrieved
- In November 2023+ dumps, content is retrieved twice with a 36-hour delay, and `_meta` tracks changes

These modifications were taken into account when designing HFY NEKROCODEXXX's JSONL indexer. The indexer handles the absence of `body_html` by generating it from `selftext` using a markdown-to-HTML converter if needed.

### What Was NOT Borrowed

- The Python helper scripts (HFY NEKROCODEXXX is JavaScript-based)
- The `.zst` compression support (HFY NEKROCODEXXX works with uncompressed JSONL files)
- The `.zst_blocks` format support (legacy format)
- The web search interface (HFY NEKROCODEXXX has its own Archive tab)
- The removal request form (not applicable to a local reader app)

### Attribution

Arctic Shift is credited in the Settings → Downloader Cascade section and in the JSONL integration documentation. The JSONL archive integration is described as "powered by Arctic Shift data dumps."

---

## 5. ArcticZim (IMayBeABitShy)

### Repository Overview

**URL:** https://github.com/IMayBeABitShy/ArcticZim  
**License:** Open source  
**Language:** Python  
**Purpose:** Convert Arctic Shift data into ZIM files (offline web archives)

ArcticZim is a tool for converting Arctic Shift Reddit data into ZIM files, which are highly compressed offline versions of websites readable by the Kiwix software. While HFY NEKROCODEXXX does not produce ZIM files, several UI patterns and architectural concepts from ArcticZim were adapted.

### What Was Borrowed

#### 5.1 Post Card UI Pattern

ArcticZim's `postsummary.html.jinja` template defines a post card that shows:
- Score
- Title (clickable)
- Author (clickable to filter)
- Subreddit (clickable to filter)
- Date
- Content preview
- Comment count
- NSFW badge

This pattern was directly adapted for HFY NEKROCODEXXX's Archive tab post cards. The adapted version uses React instead of Jinja2 templates, but the layout and information hierarchy are the same.

#### 5.2 Author Browser Concept

ArcticZim includes an author browser that shows:
- Author name
- Post count
- Total score
- Latest post date

This was adapted for HFY NEKROCODEXXX's Archive tab "Authors" quick access section, which shows the same information in a sortable table.

#### 5.3 Pagination Approach

ArcticZim uses page-based pagination with a configurable number of posts per page. The template includes:
- Previous/Next buttons
- Current page number
- Total page count
- Page skip buttons

This was adapted for HFY NEKROCODEXXX's Archive tab, which uses 20 posts per page with Previous/Next buttons and page number display.

#### 5.4 Database-Driven Architecture

ArcticZim uses SQLAlchemy ORM models (Post, User, Comment, Subreddit) to store parsed data. While HFY NEKROCODEXXX doesn't use a database, the concept of structured data models influenced the design of the JSONL index structures (__jsonlIndex, __jsonlAuthors, __jsonlSubreddits).

#### 5.5 Batch Processing

ArcticZim's importer uses batch processing to improve performance:

```python
# From ArcticZim/arcticzim/importer.py
def import_posts_from_file(session, path, batch_size=1000):
    n = 0
    for post_batch in chunked(process_jsonl(path, desc="Importing posts"), batch_size):
        import_posts(session, post_batch)
        n += len(post_batch)
    print("Imported {} posts.".format(n))
```

This batch processing pattern was adapted for HFY NEKROCODEXXX's JSONL batch handler (jsonl-handler.js), which accepts batch POST requests for scores and chapter content.

#### 5.6 JSONL Processing Utilities

ArcticZim's `jsonl.py` module provides utilities for reading and analyzing JSONL files:

```python
# From ArcticZim/arcticzim/jsonl.py
def process_jsonl(path, desc="Reading file"):
    with open(path, "r") as fin:
        total_size = fin.seek(0, os.SEEK_END)
        fin.seek(0, os.SEEK_SET)
        entry = 0
        with tqdm(desc=desc, total=total_size, unit="B", unit_scale=True) as t:
            for line in fin:
                entry += 1
                t.set_postfix(entry=entry, refresh=False)
                t.update(len(line))
                sline = line.strip()
                if sline:
                    yield json.loads(sline)
```

This pattern (reading JSONL line by line with progress tracking) was adapted for HFY NEKROCODEXXX's JSONL indexing engine, which reports progress every 1000 posts.

### What Was NOT Borrowed

- The ZIM file generation (HFY NEKROCODEXXX doesn't produce ZIM files)
- The Jinja2 template system (HFY NEKROCODEXXX uses React)
- The SQLAlchemy ORM (HFY NEKROCODEXXX uses in-memory Maps)
- The media downloader (HFY NEKROCODEXXX is text-only)
- The Kiwix integration (not applicable)

### Attribution

ArcticZim is credited in the JSONL integration documentation. The Archive tab's layout is described as "adapted from ArcticZim's postsummary pattern."

---

## 6. How Each Repository Was Integrated

### Integration Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    HFY NEKROCODEXXX                               │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Client (page-94aba2608e3f02d1.js)           │    │
│  │                                                           │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │    │
│  │  │ Archive Tab  │  │ Discover Tab │  │ Reader       │  │    │
│  │  │ (ArcticZim   │  │ (arctic_shift│  │ (hfy2epub    │  │    │
│  │  │  UI pattern) │  │  data format)│  │  chain follow)│  │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  │    │
│  │                                                           │    │
│  │  ┌──────────────────────────────────────────────────┐   │    │
│  │  │         JSONL Engine (window.__jsonlEngine)        │   │    │
│  │  │  ┌──────────────────────────────────────────┐     │   │    │
│  │  │  │  Indexing (arctic_shift fileStreams.py   │     │   │    │
│  │  │  │  pattern adapted to JavaScript)           │     │   │    │
│  │  │  └──────────────────────────────────────────┘     │   │    │
│  │  └──────────────────────────────────────────────────┘   │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Server (4034.js + API routes)               │    │
│  │                                                           │    │
│  │  ┌──────────────────────────────────────────────────┐   │    │
│  │  │         Reddit Scraper (9 strategies)              │   │    │
│  │  │                                                      │   │    │
│  │  │  Strategy -1: JSONL local (arctic_shift data)      │   │    │
│  │  │  Strategy 0: OAuth JSON                             │   │    │
│  │  │  Strategy 0.5: Cookies                              │   │    │
│  │  │  Strategy 0.7: Browser simulation                   │   │    │
│  │  │  Strategy 1: RSS                                    │   │    │
│  │  │  Strategy 2: CORS proxy pool                        │   │    │
│  │  │  Strategy 3: .json fallback (easy-reddit-downloader)│   │    │
│  │  │  Wayback Machine                                    │   │    │
│  │  │  hfy.foundation                                     │   │    │
│  │  └──────────────────────────────────────────────────┘   │    │
│  │                                                           │    │
│  │  ┌──────────────────────────────────────────────────┐   │    │
│  │  │    Crawl Engine (hfy2epub findSeriesParts         │   │    │
│  │  │    adapted with BFS + pattern matching)            │   │    │
│  │  └──────────────────────────────────────────────────┘   │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### Data Flow with Reference Repositories

1. **Data Source:** Arctic Shift provides JSONL dumps → user downloads them → user selects folder in Settings → JSONL engine indexes them (adapted from fileStreams.py pattern)

2. **Content Retrieval:** When a chapter is opened, the fetch cascade tries:
   - JSONL local archive first (Arctic Shift data)
   - Arctic Shift API (for posts not in JSONL)
   - Reddit OAuth/RSS/proxies (using easy-reddit-downloader's .json pattern)
   - Wayback Machine (archived content)
   - hfy.foundation (community index)

3. **Chapter Discovery:** When discovering missing chapters, the crawl engine follows "next" links (hfy2epub's findSeriesParts algorithm) through content fetched from the above sources.

4. **UI Display:** The Archive tab displays posts using ArcticZim's post card pattern, with data from the JSONL index (Arctic Shift format).

---

## 7. Code Comparison: Original vs. Adapted

### 7.1 JSONL Stream Parsing

**Original (Arctic Shift, Python):**
```python
def getZstFileJsonStream(f, chunk_size=1024*1024*10):
    decompressor = zstandard.ZstdDecompressor(max_window_size=2**31)
    currentString = ""
    zstReader = decompressor.stream_reader(f)
    while True:
        chunk = zstReader.read(chunk_size)
        if not chunk:
            break
        currentString += chunk.decode('utf-8', 'replace')
        lines = currentString.split('\n')
        currentString = lines[-1]
        for line in lines[:-1]:
            yield json.loads(line)
```

**Adapted (HFY NEKROCODEXXX, JavaScript):**
```javascript
const file = await fileEntry.getFile();
const stream = file.stream();
const reader = stream.getReader();
const decoder = new TextDecoder();
let buffer = '';

while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
        if (!line.trim()) continue;
        const post = JSON.parse(line);
        // Add to index
    }
}
```

Key differences:
- Python uses zstandard decompression; JavaScript works with uncompressed JSONL
- Python uses generators (yield); JavaScript uses async/await with reader
- Both handle incomplete lines at chunk boundaries (buffer pattern)

### 7.2 Chapter Chain Following

**Original (hfy2epub, callback-based):**
```javascript
function findSeriesParts(startUrl, callbacks) {
    var collectedPosts = [];
    var previousNames = [];
    var collectPostRecurse = function(url) {
        collectPost(url, function(collectedPost) {
            collectedPosts.push(collectedPost);
            previousNames.push(nameFromURL(url));
            var nextUrl = findNextURL(collectedPost.content, previousNames);
            if (nextUrl) {
                collectPostRecurse(nextUrl);
            } else {
                callbacks.done(collectedPosts);
            }
        });
    };
    collectPostRecurse(startUrl);
}
```

**Adapted (HFY NEKROCODEXXX, async/await with BFS):**
```javascript
async function crawlAllChapters(startPostId, options) {
    const visited = new Set();
    const queue = [startPostId];
    const results = [];
    
    while (queue.length > 0) {
        const postId = queue.shift();
        if (visited.has(postId)) continue;
        visited.add(postId);
        
        const content = await fetchPostContent(postId);
        if (!content) continue;
        results.push(content);
        
        const nextLinks = findChapterLinks(content.selftext, content.selftextHtml, patterns);
        for (const link of nextLinks) {
            if (!visited.has(link.postId)) {
                queue.push(link.postId);
            }
        }
    }
    return results;
}
```

Key differences:
- hfy2epub uses recursion with callbacks; HFY NEKROCODEXXX uses BFS with async/await
- hfy2epub follows first match only; HFY NEKROCODEXXX follows all matches (BFS)
- HFY NEKROCODEXXX uses a visited Set to prevent infinite loops
- Both use the same "find next URL" heuristic

### 7.3 Authless JSON Fetch

**Original (easy-reddit-downloader, axios):**
```javascript
const response = await axios.get(reqUrl, {
    timeout: DEFAULT_REQUEST_TIMEOUT,
});
const data = response.data;
```

**Adapted (HFY NEKROCODEXXX, fetch with OAuth fallback):**
```javascript
const oauthAuth = await getRedditOAuthToken();
const hdrs = { "User-Agent": getRandomUA(), Accept: "application/json" };
if (oauthAuth) hdrs["Authorization"] = `Bearer ${oauthAuth.token}`;
const res = await fetch(url, {
    headers: hdrs,
    signal: AbortSignal.timeout(8000),
    cache: "no-store"
});
const data = await res.json();
```

Key differences:
- easy-reddit-downloader uses axios; HFY NEKROCODEXXX uses native fetch
- easy-reddit-downloader has no auth; HFY NEKROCODEXXX adds OAuth token if available
- HFY NEKROCODEXXX rotates User-Agents (8 profiles) to reduce fingerprinting
- HFY NEKROCODEXXX uses AbortSignal.timeout instead of axios timeout

---

## 8. Attribution and Licensing

All four reference repositories are open source and their contributions are properly attributed:

### easy-reddit-downloader
- **License:** MIT
- **Attribution:** Settings → About → "FALLBACK: easy-reddit-downloader port (josephrcox)"
- **Usage:** Authless .json fetch pattern, URL building, post type classification, file name sanitization

### hfy2epub
- **License:** MIT
- **Attribution:** Settings → About → crawl engine documentation
- **Usage:** Chapter chain following algorithm, next link detection, URL shortener handling, comment content collection

### arctic_shift
- **License:** Open source
- **Attribution:** Settings → Downloader Cascade → JSONL integration documentation
- **Usage:** JSONL data format, API endpoints, file stream parsing pattern, data modification notes

### ArcticZim
- **License:** Open source
- **Attribution:** JSONL integration documentation → Archive tab UI
- **Usage:** Post card UI pattern, author browser concept, pagination approach, batch processing pattern

All adapted code is substantially modified from the original. The adaptations change the language (Python → JavaScript), the paradigm (callbacks → async/await), the architecture (standalone tool → integrated web app), and the UI (CLI/Jinja2 → React/Tailwind). The core concepts and algorithms are preserved, but the implementation is original.

---

*End of How GitHub Repositories Were Used*
