# HFY NEKROCODEXXX — Complete Recreation Documentation

**Version:** FX45 v31  
**Last Updated:** 2026-07-30  
**Developer:** Mahmudul Hossain

---

## Master Index

This archive contains all documentation and source code needed to recreate the HFY NEKROCODEXXX application from scratch. The files are organized as follows:

### Documentation Files

| File | Title | Words |
|------|-------|-------|
| 01-OVERVIEW-AND-INTRODUCTION.md | What the app is, features, platform support, UI overview | ~6,800 |
| 02-ARCHITECTURE-AND-HOW-IT-WORKS.md | Architecture, tech stack, data flow, state management, API reference | ~6,700 |
| 03-HOW-GITHUB-REPOS-WERE-USED.md | How easy-reddit-downloader, hfy2epub, arctic_shift, ArcticZim were used | ~4,000 |
| 04-SERVER-SIDE-SOURCE-CODE.md | server.js, aggregate-counts.js, jsonl-handler.js with explanations | ~2,800 |
| 05-API-ROUTES-SOURCE-CODE.md | Complete source code for all 41 API routes | ~128,500 |
| 06-REDDIT-SCRAPER-SOURCE-CODE.md | Complete source code for 4034.js (Reddit scraper) | ~12,000 |
| 07-CLIENT-SIDE-SOURCE-CODE.md | Complete source code for page chunk (all React components) | ~180,400 |
| 08-JSONL-INTEGRATION-MASTER-PLAN.md | The 14-part JSONL integration plan | ~7,200 |
| 09-BUILD-AND-DEPLOYMENT-GUIDE.md | FX43 complete build manual | ~25,200 |
| 10-COMPLETE-RECREATION-GUIDE.md | Complete recreation guide (v13) | ~10,100 |
| 11-TECHNICAL-DOCUMENTATION.md | Complete technical documentation (v2.0.0) | ~4,300 |
| 12-WINDOWS-STANDALONE-MANUAL.md | Windows standalone recreation manual (v250fx13) | ~2,200 |
| 13-APK-RECREATION-MANUAL.md | Android APK recreation manual (v250fx13) | ~2,000 |
| 14-WEBAPP-RECREATION-MANUAL.md | Webapp recreation manual (v250fx13) | ~3,100 |
| 15-ORIGINAL-BUILD-PROMPT-AND-SPECS.md | Original build prompts and specifications | ~25,400 |
| 16-PACKAGE-CONFIGURATION-AND-SCRIPTS.md | package.json, start.bat, stop.bat, sw.js, manifest.json | ~1,100 |
| 17-v250fx4-WEBAPP-MANUAL-FULL-SOURCE.md | v250fx4 webapp manual with full source code | ~29,000 |
| 18-v250fx4-APK-MANUAL-FULL-SOURCE.md | v250fx4 APK manual with full source code | ~27,000 |
| 19-v250fx4-WINDOWS-EXE-MANUAL-FULL-SOURCE.md | v250fx4 Windows EXE manual with full source code | ~27,000 |
| 20-v250fx3-WEBAPP-MANUAL.md | v250fx3 webapp manual | ~28,000 |
| 21-v250fx3-APK-MANUAL.md | v250fx3 APK manual | ~26,000 |
| 22-v250fx3-WINDOWS-EXE-MANUAL.md | v250fx3 Windows EXE manual | ~26,000 |
| 23-APK-BUILD-GUIDE.md | APK build guide | ~8,500 |
| 24-BUILD-APK-INSTRUCTIONS.md | Build APK instructions | ~200 |

### Source Code Files (in source-code/ directory)

| File | Description |
|------|-------------|
| source-code/server.js | Next.js standalone server entry point |
| source-code/aggregate-counts.js | Periodic aggregation script |
| source-code/jsonl-handler.js | JSONL batch handler (port 3001) |
| source-code/package.json | Node.js package configuration |
| source-code/page-chunk.js | Client-side React app (2.7 MB) |
| source-code/reddit-scraper-4034.js | Reddit scraper with 9 fetch strategies |
| source-code/api-routes/ | All 41 API route files |
| source-code/start.bat | Windows launcher script |
| source-code/stop.bat | Windows stop script |
| source-code/README-FIRST.txt | Quick start guide |
| source-code/sw.js | Service worker for PWA |
| source-code/manifest.json | PWA manifest |

### How to Use This Archive

1. **Read the Overview first** (01-OVERVIEW-AND-INTRODUCTION.md) to understand what the app is and what it does.

2. **Read the Architecture document** (02-ARCHITECTURE-AND-HOW-IT-WORKS.md) to understand how the app is structured.

3. **Read the GitHub Repositories document** (03-HOW-GITHUB-REPOS-WERE-USED.md) to understand how the reference repositories were integrated.

4. **Read the JSONL Integration Master Plan** (08-JSONL-INTEGRATION-MASTER-PLAN.md) to understand the 14-part JSONL integration.

5. **Use the Build and Deployment Guide** (09-BUILD-AND-DEPLOYMENT-GUIDE.md) to build the app from source.

6. **Use the Complete Recreation Guide** (10-COMPLETE-RECREATION-GUIDE.md) for step-by-step recreation instructions.

7. **Reference the Source Code files** (05, 06, 07, and source-code/ directory) for the actual implementation.

8. **Use the platform-specific manuals** (12, 13, 14, 17, 18, 19) for Windows, Android, and webapp builds.

### Total Documentation

- **24 documentation files**
- **421,000+ words** of documentation
- **52 source code files** included
- **Complete coverage** of all features, APIs, and implementation details

---

*HFY NEKROCODEXXX — Complete Recreation Documentation*
