# HFY NEKROCODEXXX — Package Configuration and Scripts

**Version:** FX45 v31

This document contains all configuration files, launcher scripts, and packaging information needed to build and distribute the HFY NEKROCODEXXX application.

---

## package.json

```json
{
  "name": "nextjs_tailwind_shadcn_ts",
  "version": "fx45v31",
  "private": true,
  "scripts": {
    "dev": "next dev -p 3000 2>&1 | tee dev.log",
    "build": "next build && cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/",
    "start": "NODE_ENV=production bun .next/standalone/server.js 2>&1 | tee server.log",
    "lint": "eslint .",
    "db:push": "prisma db push",
    "db:generate": "prisma generate",
    "db:migrate": "prisma migrate dev",
    "db:reset": "prisma migrate reset"
  },
  "dependencies": {
    "@capacitor/android": "^8.4.1",
    "@dnd-kit/core": "^6.3.1",
    "@dnd-kit/sortable": "^10.0.0",
    "@dnd-kit/utilities": "^3.2.2",
    "@hookform/resolvers": "^5.1.1",
    "@mdxeditor/editor": "^3.39.1",
    "@prisma/client": "^6.11.1",
    "@radix-ui/react-accordion": "^1.2.11",
    "@radix-ui/react-alert-dialog": "^1.1.14",
    "@radix-ui/react-aspect-ratio": "^1.1.7",
    "@radix-ui/react-avatar": "^1.1.10",
    "@radix-ui/react-checkbox": "^1.3.2",
    "@radix-ui/react-collapsible": "^1.1.11",
    "@radix-ui/react-context-menu": "^2.2.15",
    "@radix-ui/react-dialog": "^1.1.14",
    "@radix-ui/react-dropdown-menu": "^2.1.15",
    "@radix-ui/react-hover-card": "^1.1.14",
    "@radix-ui/react-label": "^2.1.7",
    "@radix-ui/react-menubar": "^1.1.15",
    "@radix-ui/react-navigation-menu": "^1.2.13",
    "@radix-ui/react-popover": "^1.1.14",
    "@radix-ui/react-progress": "^1.1.7",
    "@radix-ui/react-radio-group": "^1.3.7",
    "@radix-ui/react-scroll-area": "^1.2.9",
    "@radix-ui/react-select": "^2.2.5",
    "@radix-ui/react-separator": "^1.1.7",
    "@radix-ui/react-slider": "^1.3.5",
    "@radix-ui/react-slot": "^1.2.3",
    "@radix-ui/react-switch": "^1.2.5",
    "@radix-ui/react-tabs": "^1.1.12",
    "@radix-ui/react-toast": "^1.2.14",
    "@radix-ui/react-toggle": "^1.1.9",
    "@radix-ui/react-toggle-group": "^1.1.10",
    "@radix-ui/react-tooltip": "^1.2.7",
    "@reactuses/core": "^6.0.5",
    "@tanstack/react-query": "^5.82.0",
    "@tanstack/react-table": "^8.21.3",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "cmdk": "^1.1.1",
    "date-fns": "^4.1.0",
    "embla-carousel-react": "^8.6.0",
    "file-saver": "^2.0.5",
    "framer-motion": "^12.23.2",
    "input-otp": "^1.4.2",
    "jsdom": "^29.1.1",
    "jszip": "^3.10.1",
    "lucide-react": "^0.525.0",
    "next": "^16.1.1",
    "next-auth": "^4.24.11",
    "next-intl": "^4.3.4",
    "next-themes": "^0.4.6",
    "prisma": "^6.11.1",
    "puppeteer-core": "^25.3.0",
    "react": "^19.0.0",
    "react-day-picker": "^9.8.0",
    "react-dom": "^19.0.0",
    "react-hook-form": "^7.60.0",
    "react-markdown": "^10.1.0",
    "react-resizable-panels": "^3.0.3",
    "react-syntax-highlighter": "^15.6.1",
    "recharts": "^2.15.4",
    "sharp": "^0.34.3",
    "socket.io-client": "^4.8.3",
    "sonner": "^2.0.6",
    "tailwind-merge": "^3.3.1",
    "tailwindcss-animate": "^1.0.7",
    "uuid": "^11.1.0",
    "vaul": "^1.1.2",
    "z-ai-web-dev-sdk": "^0.0.18",
    "zod": "^4.0.2",
    "zustand": "^5.0.6"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "^4",
    "@types/file-saver": "^2.0.7",
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "bun-types": "^1.3.4",
    "eslint": "^9",
    "eslint-config-next": "^16.1.1",
    "tailwindcss": "^4",
    "tw-animate-css": "^1.3.5",
    "typescript": "^5"
  }
}
```

---

## start.bat (Windows Launcher)

```batch
@echo off
title HFY NEKROCODEXXX
setlocal
set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"
set "NODE_EXE=%APP_DIR%\node\node.exe"
set "SERVER_DIR=%APP_DIR%\server"
set "PORT=3000"
set "URL=http://localhost:%PORT%"
if not exist "%NODE_EXE%" (echo Node.js not found & pause & exit /b 1)
if not exist "%SERVER_DIR%\server.js" (echo Server not found & pause & exit /b 1)
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (taskkill /F /PID %%a >nul 2>&1)
taskkill /FI "WINDOWTITLE eq HFY-NEKRO-Server*" /F >nul 2>&1
set "NODE_ENV=production"
set "PORT=%PORT%"
set "HOSTNAME=127.0.0.1"
echo Starting server...
start "HFY-NEKRO-Server" /min cmd /c ""%NODE_EXE%" "%SERVER_DIR%\server.js" > "%APP_DIR%\server.log" 2>&1"
echo Waiting 5 seconds...
timeout /t 5 /nobreak >nul
echo Opening app...
set "BROWSER="
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" set "BROWSER=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" set "BROWSER=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set "BROWSER=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" set "BROWSER=C:\Program Files\Microsoft\Edge\Application\msedge.exe"
if defined BROWSER (start "" "%BROWSER%" --app="%URL%" --new-window) else (start "" "%URL%")
echo HFY NEKROCODEXXX is running. Run stop.bat to stop.
exit /b 0

```

---

## stop.bat (Windows Stop Script)

```batch
@echo off
setlocal
set "PORT=3000"
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (taskkill /F /PID %%a >nul 2>&1)
taskkill /FI "WINDOWTITLE eq HFY-NEKRO-Server*" /F >nul 2>&1
for /f "tokens=2" %%i in ('tasklist /FI "IMAGENAME eq node.exe" /FO LIST 2^>nul ^| findstr "PID:"') do (taskkill /F /PID %%i >nul 2>&1)
echo Stopped.
timeout /t 2 /nobreak >nul
exit /b 0

```

---

## README-FIRST.txt

```
HFY NEKROCODEXXX — Windows Standalone App
==========================================

WHAT THIS IS:
A Reddit r/HFY (and other subreddit) novel/story reader with offline JSONL archive support.
Includes all 14 parts of the JSONL reader integration:
  - Folder access for JSONL files
  - Indexing of 200K+ posts
  - Chapter discovery (follows Next/Previous links)
  - Custom series creation
  - Download/merge to HTML
  - Persistence audit and repair
  - Performance optimization (trigram search)
  - File replacement at runtime
  - Cross-subreddit search
  - RSS feed engine for new posts

HOW TO USE:
1. Download JSONL dump files from:
   https://gofile.io/d/PZH1xo
   (Files: r_hfy_posts.jsonl, r_natureofpredators_posts.jsonl,
    r_sexyspacebabes_posts.jsonl, r_TheCryopodToHell_posts.jsonl)

2. Put the JSONL files in a folder on your computer (e.g., C:\HFY-Data\)

3. Double-click start.bat

4. The app will open in Chrome/Edge automatically

5. Go to Settings → SUBREDDIT JSONL DATA → SELECT FOLDER
   Select the folder where you put the JSONL files

6. Wait for indexing (162K posts takes ~30 seconds)

7. Use the Archive tab to browse posts, Discover tab for auto-discovered series

SYSTEM REQUIREMENTS:
  - Windows 10/11 (64-bit)
  - 2GB RAM (4GB recommended for all 4 JSONL files)
  - 5GB disk space (for app + JSONL files)
  - Chrome or Edge browser

INCLUDED:
  - node/node.exe — Node.js runtime (no installation needed)
  - server/ — The Next.js app (pre-built)
  - start.bat — Starts the server and opens the browser
  - stop.bat — Stops the server

TROUBLESHOOTING:
  - If the app doesn't open: check server.log for errors
  - If indexing is slow: use SSD storage for JSONL files
  - If port 3000 is in use: edit start.bat and change PORT=3000 to another port

VERSION: FX45 v31 + Parts 1-14 JSONL Integration (Audited)
DATE: 2026-07-30

```

---

## sw.js (Service Worker)

```javascript
// HFY NEKROCODEXXX Service Worker
// Enables PWA install + offline caching

const CACHE_NAME = "hfy-nekrocodexxx-v1";
const STATIC_ASSETS = ["/", "/manifest.json", "/icon-192.png", "/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Only cache GET requests
  if (event.request.method !== "GET") return;

  // Don't cache API requests (they need fresh data)
  if (event.request.url.includes("/api/")) return;
  if (event.request.url.includes("/socket.io/")) return;

  // Cache-first for static assets, network-first for pages
  if (event.request.destination === "image" || event.request.url.includes("/_next/static/")) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        return cached || fetch(event.request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return res;
        });
      })
    );
  } else {
    // Network-first for pages (with cache fallback)
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          if (res.ok && event.request.destination === "document") {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return res;
        })
        .catch(() => caches.match(event.request).then((cached) => cached || caches.match("/")))
    );
  }
});

```

---

## manifest.json (PWA Manifest)

```json
{
  "name": "HFY NEKROCODEXXX",
  "short_name": "HFY NEKRO",
  "description": "Cyberpunk r/HFY Series Reader & Downloader",
  "start_url": "/",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#050608",
  "theme_color": "#FF003C",
  "categories": ["books", "entertainment"],
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}

```

---

## node_modules (Minimal Dependencies)

The distribution package includes a minimal node_modules (45 MB) created using @vercel/nft (Node File Tracing). Only the 17 packages actually required by the server at runtime are included:

- @next/env
- @swc/helpers
- baseline-browser-mapping
- caniuse-lite
- client-only
- detect-libc
- nanoid
- next
- picocolors
- react
- react-dom
- semvir
- source-map-js
- styled-jsx

.map files, .d.ts files, README/LICENSE files, and platform-specific native binaries (sharp, @img) are excluded to reduce size.

---

*End of Package Configuration and Scripts*
