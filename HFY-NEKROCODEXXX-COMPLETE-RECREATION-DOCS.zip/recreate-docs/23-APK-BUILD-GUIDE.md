# HFY NEKROCODEXXX — Complete Webapp-to-APK Build Guide

**Version:** v6.0.4 (2026-06-26)
**Purpose:** Exhaustive technical reference for converting the HFY NEKROCODEXXX Next.js 16 webapp into a standalone Android APK that runs the full Next.js server locally on the device using a bundled Termux Node.js runtime. This document contains every architectural decision, every file's contents, every bug encountered and its fix, and every exact command needed to reproduce the APK from scratch.

If you give this document to another AI assistant along with the v13 webapp source zip and the two skull images, it should be able to produce a byte-identical (or functionally identical) APK.

---

## Table of Contents

1. [Project Identity & Goal](#1-project-identity--goal)
2. [The Core Innovation: Running Node.js on Android](#2-the-core-innovation-running-nodejs-on-android)
3. [Prerequisites & Environment](#3-prerequisites--environment)
4. [The v13 Webapp Source](#4-the-v13-webapp-source)
5. [Required Fixes to the Webapp Before Building](#5-required-fixes-to-the-webapp-before-building)
6. [Building the Next.js Standalone Server](#6-building-the-nextjs-standalone-server)
7. [The Node.js Runtime (Termux)](#7-the-nodejs-runtime-termux)
8. [Library Dependencies](#8-library-dependencies)
9. [Compiling libsqlite3.so from Source](#9-compiling-libsqlite3so-from-source)
10. [Android Project Structure](#10-android-project-structure)
11. [NodeRunner.java — The Core Class](#11-noderunnerjava--the-core-class)
12. [LogServer.java — Debug Server](#12-logserverjava--debug-server)
13. [MainActivity.java](#13-mainactivityjava)
14. [AndroidManifest.xml](#14-androidmanifestxml)
15. [build.gradle Configuration](#15-buildgradle-configuration)
16. [capacitor.config.ts](#16-capacitorconfigts)
17. [Splash Screen HTML](#17-splash-screen-html)
18. [App Icon Generation](#18-app-icon-generation)
19. [All Bugs Encountered and Their Fixes](#19-all-bugs-encountered-and-their-fixes)
20. [Build and Sign Commands](#20-build-and-sign-commands)
21. [Upload Instructions](#21-upload-instructions)
22. [Key Lessons Learned](#22-key-lessons-learned)
23. [Verification Checklist](#23-verification-checklist)

---

## 1. Project Identity & Goal

**HFY NEKROCODEXXX** is a Cyberpunk 2077-styled Next.js 16 web app for browsing, reading, and downloading Reddit `r/HFY` serialized fiction. It features:
- 2,472 built-in series catalog
- 8-stage chapter discovery pipeline (cache → Wayback Machine → hfy.foundation → RSS crawler → Reddit JSON → Reddit search → WebSocket parser)
- 386 CORS proxy pool with health-checking
- 28 cyberpunk fonts, 25 app themes, 22 reader themes
- EPUB/TXT export
- PWA support
- Capacitor Android APK wrapping

### The Goal

Build an Android APK that:
1. Contains a real Node.js runtime (from Termux packages)
2. Contains the full Next.js standalone server (all 22 API routes, 498 compiled `.next` files)
3. Starts the Node.js server on `http://127.0.0.1:3000` when the app opens
4. The WebView loads `http://127.0.0.1:3000` to display the full app
5. All scraping (Reddit RSS, Wayback Machine, hfy.foundation) happens server-side on localhost — no CORS issues
6. Works on Android 15 (API 35) on arm64-v8a devices (OnePlus 13R, Snapdragon 8 Gen 3)
7. Has the front-facing skull image as the app icon
8. Has the side-facing skull image on the splash screen
9. Loads the server URL inside the app's WebView (not the system browser)

**Size does not matter** — the APK is 186 MB. Never reduce size, never compress resources, never edit the webapp's source code (only the minimum fixes documented in section 5).

---

## 2. The Core Innovation: Running Node.js on Android

### The Problem

Android 10+ enforces two security mechanisms that prevent running native binaries from an app:

1. **W^X (Write XOR Execute) policy**: Files in app-writable directories (`codeCacheDir`, `filesDir`) cannot be executed. Only `nativeLibraryDir` (where Android extracts `.so` files from jniLibs) is executable.

2. **Linker Namespace Restrictions**: Even when a binary is in `nativeLibraryDir`, the Android linker uses "namespaces" that restrict which libraries can be loaded. `LD_LIBRARY_PATH` is partially ignored — the linker won't search arbitrary paths for libraries it doesn't already know about.

This caused these errors in sequence during development:
- `Permission denied` executing the node binary from `codeCacheDir`
- `libz.so.1 not found` — version suffix stripped by Android's package installer
- `libsqlite3.so not found` — Android's linker namespace won't find it even in `nativeLibraryDir`
- `cannot locate symbol "sqlite3session_delete"` — libsqlite3.so compiled without session extension

### The Solution: Termux's linker64 Trick

Termux (the Android terminal emulator) uses a clever workaround: **invoke `/system/bin/linker64` directly as the executable**, passing the node binary as an argument.

```java
// Instead of:
ProcessBuilder pb = new ProcessBuilder(nodeBin.getAbsolutePath(), mainJs.getAbsolutePath());

// Use:
ProcessBuilder pb = new ProcessBuilder(
    "/system/bin/linker64",        // The system linker (in executable /system/bin/)
    nodeBin.getAbsolutePath(),     // Node binary (loaded as data, not exec'd)
    mainJs.getAbsolutePath()       // Argument to node
);
```

**Why this works:**
1. `/system/bin/linker64` is in `/system/bin/` which IS executable
2. The kernel sees `linker64` being exec'd — SELinux is happy
3. The linker loads `libnode.so` as a data file via `mmap()` (not `execve()`)
4. The linker respects `LD_LIBRARY_PATH` for finding shared libraries
5. All libraries in `codeCacheDir/libs/` are found correctly

### The Version Suffix Problem

Android's package installer strips version suffixes from `.so` files in jniLibs. A file named `libz.so.1` in `jniLibs/arm64-v8a/` gets extracted as just `libz.so`. But the node binary's ELF headers reference the versioned names (`libz.so.1`, `libcrypto.so.3`, etc.).

**Solution:** Store versioned `.so` files in `assets/libs/` (Android doesn't touch assets). At runtime, extract them to `codeCacheDir/libs/` where the original names are preserved. Set `LD_LIBRARY_PATH` to include this directory.

---

## 3. Prerequisites & Environment

### Build Machine Requirements
- Linux x86_64 (tested on Debian 13)
- ~10 GB free disk space
- 4+ CPU cores, 8+ GB RAM
- Internet access (for downloading SDK, NDK, Termux packages, SQLite source)

### Software Required

| Software | Version | Purpose |
|----------|---------|---------|
| bun | 1.3.14+ | Package manager for the webapp |
| curl | any | Downloading SDK/NDK/Termux packages |
| unzip | any | Extracting zips |
| Python 3 | 3.11+ | Icon generation script |
| PIL/Pillow | any | Image processing for icons |
| Java JDK 21 | 21.0.5+ (Eclipse Temurin) | Gradle build (must include `javac` and `lib/server/libjvm.so`) |

### Android SDK Components

```bash
export ANDROID_HOME=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk-21
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH

# Accept licenses
yes | sdkmanager --licenses

# Install required packages
yes | sdkmanager --install \
  "platform-tools" \
  "platforms;android-36" \
  "build-tools;36.0.0" \
  "ndk;27.0.12077973" \
  "cmake;3.22.1"
```

### JDK Installation (Critical)

The system JRE is NOT sufficient — it lacks `javac` (the Java compiler) and the server JVM. Install a full JDK:

```bash
mkdir -p /path/to/jdk && cd /path/to/jdk
curl -fsSL -o jdk21.tar.gz "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.5%2B11/OpenJDK21U-jdk_x64_linux_hotspot_21.0.5_11.tar.gz"
tar xzf jdk21.tar.gz && rm jdk21.tar.gz
# JDK is at /path/to/jdk/jdk-21.0.5+11
```

Verify:
```bash
$JAVA_HOME/bin/java -version
# openjdk version "21.0.5" 2024-10-15 LTS

$JAVA_HOME/bin/javac -version
# javac 21.0.5

ls $JAVA_HOME/lib/server/libjvm.so
# Must exist — Gradle needs the server JVM
```

### Environment Variables (set before every build)

```bash
export ANDROID_HOME=/home/z/my-project/work/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export JAVA_HOME=/home/z/my-project/work/jdk/jdk-21.0.5+11
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/build-tools/36.0.0:$ANDROID_HOME/platform-tools:$PATH
export JAVA_OPTS="-Xmx4g -XX:MaxMetaspaceSize=1g"
```

---

## 4. The v13 Webapp Source

The v13 zip (`hfy-nekrocodexxx-v13.zip`, ~5.5 MB) contains:

```
hfy-nekrocodexxx-v13/
├── .env                          # DATABASE_URL="file:./db/dev.db"
├── .gitignore
├── capacitor.config.ts           # Capacitor config
├── components.json               # shadcn/ui config
├── eslint.config.mjs
├── next.config.ts                # output: "standalone"
├── package.json                  # All dependencies
├── postcss.config.mjs
├── tailwind.config.ts
├── tsconfig.json
├── prisma/
│   └── schema.prisma             # SQLite (unused, but needed for build)
├── public/
│   ├── icon-192.png              # PWA icons
│   ├── icon-512.png
│   ├── icon-32.png
│   ├── manifest.json
│   ├── sw.js                     # Service worker
│   └── bg-images/                # Cyberpunk backgrounds
├── src/
│   ├── app/
│   │   ├── globals.css
│   │   ├── layout.tsx            # 28 fonts, SW registration
│   │   ├── page.tsx              # Screen router, splash, nav
│   │   ├── reddit-callback/
│   │   │   └── page.tsx
│   │   └── api/                  # 22 API routes
│   │       ├── auto-discover/    # 8-stage discovery pipeline
│   │       ├── chapter/[id]/     # Fetch chapter content
│   │       ├── series/[slug]/    # Series detail + chapters
│   │       ├── crawl/            # BFS chapter crawler
│   │       ├── download/         # EPUB/TXT export
│   │       ├── mass-import/      # Bulk URL import
│   │       ├── search/           # Reddit search
│   │       ├── live-wiki/        # Wiki series index
│   │       ├── proxy-stats/      # CORS proxy pool stats
│   │       └── ... (12 more)
│   ├── components/
│   │   ├── screens/              # 6 screens (Browse, Library, Reader, etc)
│   │   ├── cyber/                # Cyberpunk UI components
│   │   ├── ui/                   # shadcn/ui primitives
│   │   └── InAppBrowser.tsx
│   ├── lib/
│   │   ├── reddit-scraper.ts     # Primary RSS scraper
│   │   ├── easy-reddit-downloader.ts  # JSON fallback
│   │   ├── wayback.ts            # Wayback Machine integration
│   │   ├── hfy-foundation.ts     # hfy.foundation API
│   │   ├── chapter-crawler.ts    # BFS crawler
│   │   ├── user-chapters.ts      # Filesystem cache (Node.js fs/path)
│   │   ├── cors-proxies.ts       # 386-proxy pool
│   │   ├── hfy-data.ts           # 2,472 series catalog
│   │   ├── stores.ts             # 6 Zustand stores
│   │   ├── colors.ts             # 16-color hash
│   │   ├── db.ts                 # Prisma client
│   │   └── utils.ts              # cn() helper
│   └── hooks/
├── mini-services/
│   ├── ws-parser/                # WebSocket parser (port 3003)
│   └── praw-scraper/             # Python PRAW bridge (port 3004)
└── android/                      # Capacitor Android project
```

### Provided Images

Two skull images are provided:
- **`cyberpunk-retro-futuristic-poster-digital-design-elements-hud-style-trendy-shapes-cyberpunk-style_122058-1794.jpg`** (523×740) — **front-facing skull** → app icon
- **`HD-wallpaper-cyberpunk-2077-cyber-game-gears-samurai-skulls-war-wear.jpg`** (800×1644) — **side-facing skull** → splash screen

Use VLM (vision language model) to verify which is which if uncertain:
```bash
z-ai vision -p "Is this skull facing FORWARD or SIDEWAYS? Answer in one word." -i "image.jpg"
```

---

## 5. Required Fixes to the Webapp Before Building

**CRITICAL:** Only make these two fixes. Do NOT edit any other webapp files — the webapp already works, and editing it risks breaking things.

### Fix 1: Browser-safe chapter-utils.ts

**Problem:** `SeriesDetailScreen.tsx` (a client component) imports `extractChapterNumber` from `user-chapters.ts`, which uses `import { promises as fs } from "fs"` and `import path from "path"`. These Node.js modules break the client-side bundle.

**Fix:** Create `src/lib/chapter-utils.ts` with pure browser-safe functions:

```typescript
// src/lib/chapter-utils.ts
// HFY NEKROCODEXXX — Browser-safe chapter utilities
// Pure functions only — no fs/path/Node.js modules.
// Safe to import from client components.

export interface ImportedChapter {
  title: string;
  url: string;
  postId: string;
}

export function extractChapterNumber(title: string): number {
  let m = title.match(/[Cc]hapter\s+(\d+\.?\d*)/);
  if (m) return parseFloat(m[1]);
  m = title.match(/[Pp]art\s+(\d+\.?\d*)/);
  if (m) return parseFloat(m[1]);
  m = title.match(/[Ee]pisode\s+(\d+\.?\d*)/);
  if (m) return parseFloat(m[1]);
  if (/interlude/i.test(title)) {
    m = title.match(/[Ii]nterlude\s+(\d+)/);
    if (m) return parseFloat(m[1]) + 0.5;
    return 999;
  }
  return 999;
}

export function sortChaptersByNumber(chapters: ImportedChapter[]): ImportedChapter[] {
  return [...chapters].sort((a, b) => extractChapterNumber(a.title) - extractChapterNumber(b.title));
}

export function normalizeUrlForDedup(url: string): string {
  return url
    .replace(/^https?:\/\//, "")
    .replace(/^(www\.|old\.|new\.|np\.)?reddit\.com/i, "reddit.com")
    .replace(/[?#].*$/, "")
    .replace(/\/$/, "")
    .toLowerCase();
}
```

**Then change the import in `src/components/screens/SeriesDetailScreen.tsx`:**

```typescript
// Change this:
import { extractChapterNumber } from "@/lib/user-chapters";
// To this:
import { extractChapterNumber } from "@/lib/chapter-utils";
```

### Fix 2: next.config.ts — disable image optimization

**Problem:** Next.js standalone build includes `sharp` (native image processing library) which crashes on Android arm64.

**Fix:** Set `images.unoptimized: true` in `next.config.ts`:

```typescript
// next.config.ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
  images: { unoptimized: true },
};

export default nextConfig;
```

### Fix 3 (After Build): Remove sharp from standalone build

After building, remove sharp and its dependencies:
```bash
rm -rf .next/standalone/node_modules/sharp
rm -rf .next/standalone/node_modules/@img
rm -rf .next/standalone/node_modules/detect-libc
```

---

## 6. Building the Next.js Standalone Server

```bash
cd /path/to/hfy-nekrocodexxx-v13

# 1. Install dependencies
bun install

# 2. Build standalone server
bun run build
# This creates .next/standalone/ with server.js, node_modules, etc.

# 3. Remove native deps that crash on Android
rm -rf .next/standalone/node_modules/sharp
rm -rf .next/standalone/node_modules/@img
rm -rf .next/standalone/node_modules/detect-libc

# 4. Create nodejs-server directory
mkdir -p nodejs-server
cp -r .next/standalone/. nodejs-server/
# CRITICAL: Use "/." to include hidden files like .next

# 5. Create package.json
cat > nodejs-server/package.json << 'EOF'
{"name":"hfy-server","version":"1.0.0","main":"main.js"}
EOF

# 6. Create main.js (Node.js entry point with diagnostics)
cat > nodejs-server/main.js << 'ENDJS'
const { join } = require('path');
const fs = require('fs');
const serverDir = __dirname;
process.env.NODE_ENV = 'production';
process.env.PORT = process.env.PORT || '3000';
process.env.HOSTNAME = process.env.HOSTNAME || '127.0.0.1';
console.log('[HFY-Server] Starting...');
console.log('[HFY-Server] __dirname =', serverDir);
console.log('[HFY-Server] cwd =', process.cwd());
console.log('[HFY-Server] .next exists =', fs.existsSync(join(serverDir, '.next')));
console.log('[HFY-Server] routes-manifest =', fs.existsSync(join(serverDir, '.next', 'routes-manifest.json')));
console.log('[HFY-Server] server.js exists =', fs.existsSync(join(serverDir, 'server.js')));
try {
  process.chdir(serverDir);
  require(join(serverDir, 'server.js'));
  console.log('[HFY-Server] Started on http://127.0.0.1:' + process.env.PORT);
} catch (err) {
  console.error('[HFY-Server] FATAL:', err.message);
  console.error(err.stack);
  process.exit(1);
}
ENDJS

# 7. Verify server works locally
cd nodejs-server && node main.js
# Should print "Started on http://127.0.0.1:3000" and "✓ Ready in Xms"
# Test: curl http://localhost:3000/api/proxy-stats
```

### CRITICAL: The .next directory

The `.next` directory contains all compiled routes (498 files). It MUST be included in the APK.

**Common bug:** Android's `ignoreAssetsPattern` in `build.gradle` must NOT contain `.*` (which excludes all dot-directories including `.next`):
```gradle
// WRONG — excludes .next:
ignoreAssetsPattern = '!.svn:!.git:!.ds_store:!*.scc:.*:!CVS:!thumbs.db:!picasa.ini:!*~'
// CORRECT — .next is preserved:
ignoreAssetsPattern = '!.svn:!.git:!.ds_store:!*.scc:!CVS:!thumbs.db:!picasa.ini:!*~'
```

### Verification

After building, verify:
```bash
ls .next/standalone/.next/routes-manifest.json   # must exist
ls .next/standalone/.next/server/app/index.html  # must exist
find .next/standalone/.next -type f | wc -l      # should be ~498
du -sh nodejs-server/                             # should be ~51 MB
```

---

## 7. The Node.js Runtime (Termux)

The node binary is a real Android arm64 ELF from Termux packages. It's compiled natively with the Android NDK against Android's bionic libc.

### Downloading

```bash
# Download Termux Node.js v26.3.1 for aarch64
curl -fsSL -o termux-nodejs.deb "https://packages.termux.dev/apt/termux-main/pool/main/n/nodejs/nodejs_26.3.1_aarch64.deb"

# Verify size — should be ~10 MB (NOT 1.2 MB — that's a truncated download)
ls -la termux-nodejs.deb
# -rw-r--r-- 1 z z 10268488 termux-nodejs.deb

# Extract
mkdir termux-node && cd termux-node
cp ../termux-nodejs.deb .
ar x nodejs.deb
xz -dc data.tar.xz > data.tar
tar xf data.tar
# Node binary is at: data/data/com.termux/files/usr/bin/node
```

### Properties
- **File type:** ELF 64-bit LSB shared object, ARM aarch64
- **Interpreter:** `/system/bin/linker64` (Android's dynamic linker)
- **Built for:** Android 24+ (NDK r29)
- **16KB aligned:** Yes (Align: 0x4000) — required for Android 15
- **Size:** 49 MB

### ELF Dependencies (readelf -d)
```
NEEDED: libz.so.1
NEEDED: libcares.so
NEEDED: libsqlite3.so
NEEDED: libffi.so
NEEDED: libcrypto.so.3
NEEDED: libssl.so.3
NEEDED: libicui18n.so.78
NEEDED: libicuuc.so.78
NEEDED: libc.so          (Android system)
NEEDED: libm.so          (Android system)
NEEDED: libdl.so         (Android system)
NEEDED: libc++_shared.so
```

**IMPORTANT:** If the nodejs.deb download is only ~1.2 MB, it was truncated. Re-download it — it should be ~10 MB.

---

## 8. Library Dependencies

### Downloading from Termux

```bash
# c-ares
curl -fsSL -o cares.deb "https://packages.termux.dev/apt/termux-main/pool/main/c/c-ares/c-ares_1.34.6_aarch64.deb"

# libffi
curl -fsSL -o ffi.deb "https://packages.termux.dev/apt/termux-main/pool/main/libf/libffi/libffi_3.5.2_aarch64.deb"

# zlib
curl -fsSL -o zlib.deb "https://packages.termux.dev/apt/termux-main/pool/main/z/zlib/zlib_1.3.2_aarch64.deb"

# libc++
curl -fsSL -o libcxx.deb "https://packages.termux.dev/apt/termux-main/pool/main/libc/libc%2b%2b/libc++_29_aarch64.deb"

# OpenSSL (provides libcrypto.so.3 and libssl.so.3)
curl -fsSL -o openssl.deb "https://packages.termux.dev/apt/termux-main/pool/main/o/openssl/openssl_1:3.6.3_aarch64.deb"

# ICU (provides libicudata.so.78, libicui18n.so.78, libicuuc.so.78)
curl -fsSL -o icu.deb "https://packages.termux.dev/apt/termux-main/pool/main/libi/libicu/libicu_78.3_aarch64.deb"

# Extract each
for deb in cares.deb ffi.deb zlib.deb libcxx.deb openssl.deb icu.deb; do
  mkdir -p extract-${deb%.deb} && cd extract-${deb%.deb}
  cp ../$deb .
  ar x $(basename $deb)
  xz -dc data.tar.xz > data.tar
  tar xf data.tar
  cd ..
done
```

### Library File Locations (after extraction)

| Library | Path in extracted deb |
|---------|----------------------|
| libcares.so | `extract-cares/data/data/com.termux/files/usr/lib/libcares.so` |
| libffi.so | `extract-ffi/data/data/com.termux/files/usr/lib/libffi.so` |
| libz.so.1 | `extract-zlib/data/data/com.termux/files/usr/lib/libz.so.1` |
| libc++_shared.so | `extract-libcxx/data/data/com.termux/files/usr/lib/libc++_shared.so` |
| libcrypto.so.3 | `extract-openssl/data/data/com.termux/files/usr/lib/libcrypto.so.3` |
| libssl.so.3 | `extract-openssl/data/data/com.termux/files/usr/lib/libssl.so.3` |
| libicudata.so.78 | `extract-icu/data/data/com.termux/files/usr/lib/libicudata.so.78` |
| libicui18n.so.78 | `extract-icu/data/data/com.termux/files/usr/lib/libicui18n.so.78` |
| libicuuc.so.78 | `extract-icu/data/data/com.termux/files/usr/lib/libicuuc.so.78` |

### Complete Library List

| Library | Source | Size | Purpose |
|---------|--------|------|---------|
| libnode.so | Termux nodejs deb (renamed from `node`) | 49 MB | Node.js runtime |
| libsqlite3.so | Compiled from SQLite source (see §9) | 1.6 MB | SQLite (Node.js dependency) |
| libc++_shared.so | Termux libc++ deb | 1.3 MB | C++ standard library |
| libffi.so | Termux libffi deb | 86 KB | Foreign function interface |
| libz.so | Termux zlib deb (as libz.so.1) | 73 KB | Compression |
| libcares.so | Termux c-ares deb (as libcares.so.2) | 253 KB | DNS resolution |
| libcrypto.so | Termux openssl deb (as libcrypto.so.3) | 5.2 MB | Cryptography |
| libssl.so | Termux openssl deb (as libssl.so.3) | 875 KB | TLS/SSL |
| libicudata.so | Termux icu deb (as libicudata.so.78) | 33 MB | ICU data |
| libicui18n.so | Termux icu deb (as libicui18n.so.78) | 3.4 MB | ICU internationalization |
| libicuuc.so | Termux icu deb (as libicuuc.so.78) | 2 MB | ICU utility |

### 16KB Alignment Verification

All `.so` files MUST be 16KB-aligned (0x4000) for Android 15. Verify:
```bash
for lib in libnode.so libsqlite3.so libcrypto.so.3 libssl.so.3 libicudata.so.78 libicui18n.so.78 libicuuc.so.78 libc++_shared.so libz.so.1 libffi.so libcares.so; do
  align=$(readelf -W -l "$lib" 2>/dev/null | grep LOAD | head -1 | awk '{print $NF}')
  echo "$lib: align=$align"
  # All should show 0x4000
done
```

---

## 9. Compiling libsqlite3.so from Source

The Termux `sqlite` package only contains the `sqlite3` binary, not `libsqlite3.so`. We must compile it from source.

### CRITICAL: Required Compile Flags

Node.js's built-in `node:sqlite` module requires several SQLite extensions. Without them, you'll get errors like:
- `cannot locate symbol "sqlite3session_delete"` → needs `-DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK`
- `cannot locate symbol "sqlite3_column_database_name"` → needs `-DSQLITE_ENABLE_COLUMN_METADATA`

### Download SQLite Amalgamation

```bash
curl -fsSL -o sqlite-src.zip "https://www.sqlite.org/2024/sqlite-amalgamation-3460000.zip"
unzip -q sqlite-src.zip
cd sqlite-amalgamation-3460000
```

### Compile with NDK

```bash
export ANDROID_NDK=/path/to/android-sdk/ndk/27.0.12077973
export CC=$ANDROID_NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android24-clang

$CC -shared -fPIC -O2 -o libsqlite3.so sqlite3.c \
  -DSQLITE_ENABLE_FTS5 \
  -DSQLITE_ENABLE_RTREE \
  -DSQLITE_ENABLE_JSON1 \
  -DSQLITE_THREADSAFE=1 \
  -DSQLITE_ENABLE_SESSION \
  -DSQLITE_ENABLE_PREUPDATE_HOOK \
  -DSQLITE_ENABLE_COLUMN_METADATA \
  -DSQLITE_ENABLE_NORMALIZE \
  -DSQLITE_ENABLE_DBSTAT_VTAB \
  -DSQLITE_ENABLE_STMTVTAB \
  -DSQLITE_ENABLE_API_ARMOR \
  -Wl,-z,max-page-size=16384
```

### Verification

```bash
# Check alignment (must be 0x4000 = 16KB)
readelf -W -l libsqlite3.so | grep LOAD | head -1
# LOAD ... R ... 0x4000

# Check that ALL symbols node needs are provided
NODE_SYMS=$(nm -D /path/to/node/binary | grep " U " | grep -i sqlite | awk '{print $2}' | sort -u)
LIB_SYMS=$(nm -D libsqlite3.so | grep " T " | awk '{print $3}' | sort -u)
MISSING=$(comm -23 <(echo "$NODE_SYMS") <(echo "$LIB_SYMS"))
if [ -z "$MISSING" ]; then
  echo "✅ ALL $(echo "$NODE_SYMS" | wc -l) sqlite symbols provided"
else
  echo "❌ Missing: $MISSING"
fi
```

The libsqlite3.so should export 80+ symbols including:
- `sqlite3session_create`, `sqlite3session_delete` (from SESSION)
- `sqlite3_preupdate_hook`, `sqlite3_preupdate_count` (from PREUPDATE_HOOK)
- `sqlite3_column_database_name`, `sqlite3_column_table_name`, `sqlite3_column_origin_name` (from COLUMN_METADATA)

---

## 10. Android Project Structure

```
android/
├── app/
│   ├── build.gradle                    # App build config
│   ├── src/
│   │   └── main/
│   │       ├── AndroidManifest.xml     # Permissions, extractNativeLibs
│   │       ├── java/com/nekro/hfycyberdeck/
│   │       │   ├── MainActivity.java   # Starts NodeRunner + LogServer
│   │       │   ├── NodeRunner.java     # Extracts libs, starts node
│   │       │   └── LogServer.java      # Serves log on port 3001
│   │       ├── jniLibs/arm64-v8a/      # .so files (auto-extracted to nativeLibraryDir)
│   │       │   ├── libnode.so          (49 MB)
│   │       │   ├── libsqlite3.so       (1.6 MB)
│   │       │   ├── libc++_shared.so    (1.3 MB)
│   │       │   ├── libffi.so           (86 KB)
│   │       │   ├── libz.so             (73 KB)
│   │       │   ├── libcares.so         (253 KB)
│   │       │   ├── libcrypto.so        (5.2 MB)
│   │       │   ├── libssl.so           (875 KB)
│   │       │   ├── libicudata.so       (33 MB)
│   │       │   ├── libicui18n.so       (3.4 MB)
│   │       │   └── libicuuc.so         (2 MB)
│   │       ├── assets/
│   │       │   ├── libs/               # Versioned .so files (preserved at runtime)
│   │       │   │   ├── libz.so.1
│   │       │   │   ├── libcares.so
│   │       │   │   ├── libcrypto.so.3
│   │       │   │   ├── libssl.so.3
│   │       │   │   ├── libicudata.so.78
│   │       │   │   ├── libicui18n.so.78
│   │       │   │   ├── libicuuc.so.78
│   │       │   │   ├── libsqlite3.so
│   │       │   │   ├── libc++_shared.so
│   │       │   │   └── libffi.so
│   │       │   ├── server/             # Next.js standalone (51 MB)
│   │       │   │   ├── main.js
│   │       │   │   ├── server.js
│   │       │   │   ├── package.json
│   │       │   │   ├── .next/          # 498 compiled route files
│   │       │   │   ├── node_modules/
│   │       │   │   └── public/
│   │       │   ├── public/             # Capacitor web dir
│   │       │   │   └── index.html      # Splash screen (with embedded skull base64)
│   │       │   ├── capacitor.config.json
│   │       │   └── capacitor.plugins.json
│   │       └── res/                    # Icons, themes, etc
│   │           ├── mipmap-*/           # App icons (all densities)
│   │           ├── drawable-*/         # Splash PNGs (all densities)
│   │           ├── values/
│   │           │   ├── colors.xml
│   │           │   ├── ic_launcher_background.xml  # #050608
│   │           │   ├── strings.xml
│   │           │   └── styles.xml
│   │           └── xml/
│   │               ├── network_security_config.xml
│   │               └── file_paths.xml
│   └── capacitor.build.gradle
├── settings.gradle
├── build.gradle
├── variables.gradle
├── gradle/
├── gradlew
├── local.properties                    # SDK paths
├── keystore.properties                 # Signing config
└── keystore/
    └── hfy-nekro-release.keystore      # Signing keystore
```

### Setting up jniLibs and assets/libs

```bash
JNILIBS=android/app/src/main/jniLibs/arm64-v8a
ASSETS_LIBS=android/app/src/main/assets/libs
mkdir -p "$JNILIBS" "$ASSETS_LIBS"

# jniLibs (unversioned names — Android auto-strips version suffixes anyway)
cp /path/to/termux-node/data/data/com.termux/files/usr/bin/node "$JNILIBS/libnode.so"
cp /path/to/sqlite-amalgamation-3460000/libsqlite3.so                 "$JNILIBS/libsqlite3.so"
cp /path/to/extract-cares/.../libcares.so                             "$JNILIBS/libcares.so"
cp /path/to/extract-ffi/.../libffi.so                                 "$JNILIBS/libffi.so"
cp /path/to/extract-zlib/.../libz.so.1                                "$JNILIBS/libz.so"
cp /path/to/extract-libcxx/.../libc++_shared.so                       "$JNILIBS/libc++_shared.so"
cp /path/to/extract-openssl/.../libcrypto.so.3                        "$JNILIBS/libcrypto.so"
cp /path/to/extract-openssl/.../libssl.so.3                           "$JNILIBS/libssl.so"
cp /path/to/extract-icu/.../libicudata.so.78                          "$JNILIBS/libicudata.so"
cp /path/to/extract-icu/.../libicui18n.so.78                          "$JNILIBS/libicui18n.so"
cp /path/to/extract-icu/.../libicuuc.so.78                            "$JNILIBS/libicuuc.so"

# assets/libs (versioned names — preserved at runtime)
cp /path/to/sqlite-amalgamation-3460000/libsqlite3.so                 "$ASSETS_LIBS/libsqlite3.so"
cp /path/to/extract-cares/.../libcares.so                             "$ASSETS_LIBS/libcares.so"
cp /path/to/extract-ffi/.../libffi.so                                 "$ASSETS_LIBS/libffi.so"
cp /path/to/extract-zlib/.../libz.so.1                                "$ASSETS_LIBS/libz.so.1"
cp /path/to/extract-libcxx/.../libc++_shared.so                       "$ASSETS_LIBS/libc++_shared.so"
cp /path/to/extract-openssl/.../libcrypto.so.3                        "$ASSETS_LIBS/libcrypto.so.3"
cp /path/to/extract-openssl/.../libssl.so.3                           "$ASSETS_LIBS/libssl.so.3"
cp /path/to/extract-icu/.../libicudata.so.78                          "$ASSETS_LIBS/libicudata.so.78"
cp /path/to/extract-icu/.../libicui18n.so.78                          "$ASSETS_LIBS/libicui18n.so.78"
cp /path/to/extract-icu/.../libicuuc.so.78                            "$ASSETS_LIBS/libicuuc.so.78"

# Fix permissions (some .so files come with mode 600)
chmod 644 "$JNILIBS"/*.so "$ASSETS_LIBS"/*
```

### Setting up assets/server

```bash
DST=android/app/src/main/assets/server
mkdir -p "$DST"
cp -r /path/to/nodejs-server/. "$DST/"
# Verify .next is included (498 files)
find "$DST/.next" -type f | wc -l   # should be 498
```

---

## 11. NodeRunner.java — The Core Class

**File:** `android/app/src/main/java/com/nekro/hfycyberdeck/NodeRunner.java`

This is the most critical file. It extracts all libraries, sets up the environment, and starts the Node.js server using the `/system/bin/linker64` approach.

```java
package com.nekro.hfycyberdeck;

import android.content.Context;
import android.util.Log;
import java.io.*;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * NodeRunner — extracts the bundled Node.js runtime + Next.js standalone server
 * from the APK assets, then launches the server on http://127.0.0.1:3000 using
 * /system/bin/linker64 to load libnode.so (the Termux approach).
 *
 * Why linker64: Android 10+ enforces W^X (codeCacheDir is non-executable) and
 * linker-namespace restrictions (LD_LIBRARY_PATH is partially ignored for paths
 * the linker doesn't already know about). Invoking /system/bin/linker64 directly
 * as the executable — passing libnode.so as an argument — sidesteps both: the
 * kernel sees linker64 (in /system/bin, executable) being exec'd, and the
 * linker then mmap()s libnode.so as data and resolves its dependencies through
 * LD_LIBRARY_PATH normally.
 */
public class NodeRunner {
    private static final String TAG = "HFY-NodeRunner";
    // Bump this on every change — forces re-extraction of server files
    private static final String VERSION = "6.0.4";
    private final Context context;
    private Process nodeProcess;
    private final File serverDir;
    private final File logFile;
    private final File nodeBin;
    private final File libDir;
    private final File libLinkDir;

    public NodeRunner(Context context) {
        this.context = context;
        this.serverDir = new File(context.getCodeCacheDir(), "server");
        this.logFile = new File(context.getFilesDir(), "node-server.log");
        this.libDir = new File(context.getApplicationInfo().nativeLibraryDir);
        this.nodeBin = new File(libDir, "libnode.so");
        this.libLinkDir = new File(context.getCodeCacheDir(), "libs");
    }

    public File getLogFile() { return logFile; }

    public void startServer() {
        try {
            // APPEND to log (MainActivity already wrote the early header)
            appendLog(logFile, "\n=== NodeRunner.startServer() ===\nStarted: " + new java.util.Date() + "\nVersion: " + VERSION + "\n\n");
            logMsg("nativeLibraryDir: " + libDir.getAbsolutePath());
            logMsg("codeCacheDir: " + context.getCodeCacheDir().getAbsolutePath());
            logMsg("nodeBin exists: " + nodeBin.exists());
            logMsg("nodeBin canExecute: " + nodeBin.canExecute());

            if (!nodeBin.exists()) {
                logMsg("ERROR: libnode.so NOT FOUND in nativeLibraryDir!");
                String[] files = libDir.list();
                if (files != null) {
                    for (String f : files) logMsg("  " + f);
                } else {
                    logMsg("  (directory empty or doesn't exist)");
                }
                return;
            }

            // Step 1: Copy ALL .so files from nativeLibraryDir to libLinkDir
            logMsg("\n=== Setting up libraries ===");
            libLinkDir.mkdirs();
            File[] nativeLibs = libDir.listFiles();
            if (nativeLibs != null) {
                for (File lib : nativeLibs) {
                    if (lib.getName().endsWith(".so")) {
                        File target = new File(libLinkDir, lib.getName());
                        if (!target.exists() || target.length() != lib.length()) {
                            copyFile(lib, target);
                            logMsg("  Copied " + lib.getName() + " (" + lib.length() + " bytes)");
                        }
                    }
                }
            }

            // Step 2: Extract versioned libs from assets/libs/ (preserves libz.so.1, libcrypto.so.3, etc.)
            File apkFile = new File(context.getApplicationInfo().sourceDir);
            ZipFile zipFile = new ZipFile(apkFile);
            int libCount = extractZipEntries(zipFile, "assets/libs/", libLinkDir);
            logMsg("  Extracted " + libCount + " versioned libs from assets/libs");
            zipFile.close();

            String[] libFiles = libLinkDir.list();
            if (libFiles != null) {
                logMsg("\nLibraries in libLinkDir (" + libFiles.length + " total):");
                for (String lf : libFiles) logMsg("  " + lf + " (" + new File(libLinkDir, lf).length() + ")");
            }

            // Step 3: Extract server files (Next.js standalone + .next)
            File versionFile = new File(serverDir, ".version");
            boolean needsExtraction = true;
            if (serverDir.exists() && versionFile.exists()) {
                if (VERSION.equals(readFile(versionFile).trim())) {
                    needsExtraction = false;
                    logMsg("\nServer already extracted (version match)");
                }
            }
            if (needsExtraction) {
                logMsg("\nExtracting server files...");
                zipFile = new ZipFile(apkFile);
                long start = System.currentTimeMillis();
                int count = extractZipEntries(zipFile, "assets/server/", serverDir);
                logMsg("Extracted " + count + " files in " + (System.currentTimeMillis() - start) + "ms");
                zipFile.close();
                writeFile(versionFile, VERSION);
            }

            File nextDir = new File(serverDir, ".next");
            logMsg("\n.next exists: " + nextDir.exists());
            if (nextDir.exists()) {
                logMsg("  routes-manifest: " + new File(nextDir, "routes-manifest.json").exists());
                File idx = new File(nextDir, "server/app/index.html");
                logMsg("  server/app/index.html: " + idx.exists());
            }

            File mainJs = new File(serverDir, "main.js");
            if (!mainJs.exists()) { logMsg("ERROR: main.js not found at " + mainJs); return; }

            // LD_LIBRARY_PATH: libLinkDir (everything) + nativeLibraryDir + system paths
            String ldPath = libLinkDir.getAbsolutePath() + ":" + libDir.getAbsolutePath() + ":/system/lib64:/vendor/lib64";

            File linker = new File("/system/bin/linker64");
            logMsg("\nLinker /system/bin/linker64 exists: " + linker.exists());

            // Test 1: linker64 approach
            logMsg("\n=== Testing node (via linker64) ===");
            boolean linkerOk = false;
            try {
                ProcessBuilder tp = new ProcessBuilder(
                    linker.getAbsolutePath(),
                    nodeBin.getAbsolutePath(),
                    "-e",
                    "console.log('NODE_OK_'+process.version)"
                );
                tp.directory(libLinkDir);
                Map<String,String> env = tp.environment();
                env.put("LD_LIBRARY_PATH", ldPath);
                env.put("PATH", libDir.getAbsolutePath() + ":/system/bin:/vendor/bin");
                tp.redirectErrorStream(true);
                Process tproc = tp.start();
                BufferedReader r = new BufferedReader(new InputStreamReader(tproc.getInputStream()));
                String l; while ((l = r.readLine()) != null) logMsg("[test-linker] " + l);
                int code = tproc.waitFor();
                logMsg("Test-linker exit: " + code);
                if (code == 0) linkerOk = true;
            } catch (Exception e) {
                logMsg("Test-linker exception: " + e.getMessage());
            }

            // Test 2: direct exec fallback
            if (!linkerOk) {
                logMsg("\nlinker64 failed; trying direct exec from nativeLibraryDir...");
                try {
                    ProcessBuilder tp2 = new ProcessBuilder(
                        nodeBin.getAbsolutePath(),
                        "-e",
                        "console.log('NODE_OK_'+process.version)"
                    );
                    tp2.directory(libLinkDir);
                    Map<String,String> env2 = tp2.environment();
                    env2.put("LD_LIBRARY_PATH", ldPath);
                    env2.put("PATH", libDir.getAbsolutePath() + ":/system/bin:/vendor/bin");
                    tp2.redirectErrorStream(true);
                    Process tproc2 = tp2.start();
                    BufferedReader r2 = new BufferedReader(new InputStreamReader(tproc2.getInputStream()));
                    String l2; while ((l2 = r2.readLine()) != null) logMsg("[test-direct] " + l2);
                    int code2 = tproc2.waitFor();
                    logMsg("Test-direct exit: " + code2);
                    if (code2 != 0) {
                        logMsg("ERROR: both linker64 and direct exec failed");
                        return;
                    }
                } catch (Exception e) {
                    logMsg("Test-direct exception: " + e.getMessage());
                    logMsg(Log.getStackTraceString(e));
                    return;
                }
            }

            // Start the actual server
            logMsg("\n=== Starting server ===");
            ProcessBuilder pb;
            if (linkerOk) {
                pb = new ProcessBuilder(
                    linker.getAbsolutePath(),
                    nodeBin.getAbsolutePath(),
                    mainJs.getAbsolutePath()
                );
                logMsg("Using linker64 approach");
            } else {
                pb = new ProcessBuilder(
                    nodeBin.getAbsolutePath(),
                    mainJs.getAbsolutePath()
                );
                logMsg("Using direct exec approach");
            }
            pb.directory(serverDir);
            Map<String,String> env = pb.environment();
            env.put("NODE_ENV", "production");
            env.put("PORT", "3000");
            env.put("HOSTNAME", "127.0.0.1");
            env.put("LD_LIBRARY_PATH", ldPath);
            env.put("PATH", libDir.getAbsolutePath() + ":/system/bin:/vendor/bin");
            env.put("NODE_NO_WARNINGS", "1");
            pb.redirectErrorStream(true);
            nodeProcess = pb.start();

            // Read node's stdout/stderr in background
            final InputStream is = nodeProcess.getInputStream();
            new Thread(() -> {
                byte[] buf = new byte[8192]; int n;
                try {
                    while ((n = is.read(buf)) != -1) {
                        String chunk = new String(buf, 0, n);
                        for (String l : chunk.split("\n")) {
                            l = l.trim();
                            if (!l.isEmpty()) {
                                Log.i(TAG, "[node] " + l);
                                appendLog(logFile, "[node] " + l + "\n");
                            }
                        }
                    }
                } catch (IOException e) { Log.e(TAG, "read error", e); }
                try { logMsg("Node exited: " + nodeProcess.exitValue()); }
                catch (Exception e) { logMsg("Node ended"); }
            }, "node-out").start();

            logMsg("Server started (alive: " + nodeProcess.isAlive() + ")");
        } catch (Exception e) {
            Log.e(TAG, "Failed", e);
            appendLog(logFile, "FATAL: " + e.getMessage() + "\n" + Log.getStackTraceString(e) + "\n");
        }
    }

    public void stopServer() {
        if (nodeProcess != null && nodeProcess.isAlive()) {
            logMsg("Stopping...");
            nodeProcess.destroy();
            nodeProcess = null;
        }
    }

    // === Helpers ===

    private void logMsg(String m) {
        Log.i(TAG, m);
        appendLog(logFile, m + "\n");
    }

    private int extractZipEntries(ZipFile zf, String prefix, File dest) throws IOException {
        int count = 0;
        var entries = zf.entries();
        byte[] buf = new byte[65536];
        while (entries.hasMoreElements()) {
            ZipEntry e = entries.nextElement();
            String name = e.getName();
            if (!name.startsWith(prefix)) continue;
            String rel = name.substring(prefix.length());
            if (rel.isEmpty()) continue;
            File f = new File(dest, rel);
            if (e.isDirectory()) { f.mkdirs(); continue; }
            f.getParentFile().mkdirs();
            InputStream in = null; OutputStream out = null;
            try {
                in = zf.getInputStream(e);
                out = new FileOutputStream(f);
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                out.flush();
                count++;
            } finally {
                if (in != null) try { in.close(); } catch (IOException ex) {}
                if (out != null) try { out.close(); } catch (IOException ex) {}
            }
        }
        return count;
    }

    private String readFile(File f) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l);
            r.close();
            return sb.toString();
        } catch (IOException e) { return ""; }
    }

    private void writeFile(File f, String c) {
        try {
            f.getParentFile().mkdirs();
            FileWriter w = new FileWriter(f, false);
            w.write(c);
            w.close();
        } catch (IOException e) { Log.e(TAG, "write fail", e); }
    }

    private void appendLog(File f, String c) {
        try {
            f.getParentFile().mkdirs();
            FileWriter w = new FileWriter(f, true);
            w.write(c);
            w.close();
        } catch (IOException e) { Log.e(TAG, "append fail", e); }
    }

    private void copyFile(File src, File dst) throws IOException {
        dst.getParentFile().mkdirs();
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream(src);
            out = new FileOutputStream(dst);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.flush();
        } finally {
            if (in != null) try { in.close(); } catch (IOException e) {}
            if (out != null) try { out.close(); } catch (IOException e) {}
        }
    }
}
```

---

## 12. LogServer.java — Debug Server

**File:** `android/app/src/main/java/com/nekro/hfycyberdeck/LogServer.java`

A tiny HTTP server on port 3001 that serves `node-server.log` as JSON. Lets the splash screen display the server log for debugging without `adb logcat`.

### CRITICAL: Byte-accurate Content-Length

The most common bug in LogServer is using `jsonStr.length()` (character count) for `Content-Length`. When the log contains non-ASCII characters (Unicode, box-drawing chars from Node.js output), the UTF-8 byte count is LARGER than the character count. The HTTP response gets truncated, and the splash's JSON parser fails with "Unterminated string in JSON".

**The fix:** Escape ALL non-ASCII characters as `\uXXXX` (backslash-u + 4 hex digits) so the JSON is pure ASCII (byte length == char length), and calculate `Content-Length` from the actual byte array.

```java
package com.nekro.hfycyberdeck;

import android.util.Log;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * LogServer — tiny HTTP server on port 3001 that serves node-server.log as JSON.
 *
 * CRITICAL: Content-Length must be the BYTE count, not the character count.
 * Non-ASCII characters in the log (Unicode, box-drawing chars, etc.) are
 * escaped as backslash-u-hexhexhexhex to ensure the JSON string is pure ASCII, so
 * byte length == char length and the response is never truncated.
 */
public class LogServer {
    private static final String TAG = "HFY-LogServer";
    private static final int PORT = 3001;
    private final File logFile;
    private ServerSocket serverSocket;
    private Thread serverThread;
    private volatile boolean running = false;

    public LogServer(File logFile) { this.logFile = logFile; }

    public void start() {
        running = true;
        serverThread = new Thread(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                Log.i(TAG, "Log server on port " + PORT);
                while (running) {
                    try {
                        Socket client = serverSocket.accept();
                        handleClient(client);
                    } catch (IOException e) {
                        if (running) Log.e(TAG, "accept error", e);
                    }
                }
            } catch (IOException e) { Log.e(TAG, "start fail", e); }
        }, "log-server");
        serverThread.start();
    }

    public void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException e) {}
    }

    private void handleClient(Socket client) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
            String req = reader.readLine();
            if (req == null) { client.close(); return; }
            String h;
            while ((h = reader.readLine()) != null && !h.isEmpty()) {}
            String[] parts = req.split(" ");
            String path = parts.length > 1 ? parts[1] : "/";
            OutputStream out = client.getOutputStream();

            if (path.equals("/log") || path.equals("/")) {
                String logContent = readLog();
                // Build JSON with ALL non-ASCII chars escaped as backslash-u + 4 hex digits
                // This guarantees the JSON is pure ASCII, so byte length == char length
                StringBuilder json = new StringBuilder();
                json.append("{\"ok\":true,\"log\":\"");
                for (int i = 0; i < logContent.length(); i++) {
                    char c = logContent.charAt(i);
                    switch (c) {
                        case '"':  json.append("\\\""); break;
                        case '\\': json.append("\\\\"); break;
                        case '\n': json.append("\\n"); break;
                        case '\r': break; // skip
                        case '\t': json.append("\\t"); break;
                        default:
                            if (c >= 32 && c <= 126) {
                                // Printable ASCII — safe to append directly
                                json.append(c);
                            } else if (c > 126) {
                                // Non-ASCII — escape as backslash-u + 4 hex digits
                                json.append(String.format("\\u%04x", (int) c));
                            }
                            // Skip control chars 0-31 (except \n \t handled above) and DEL (127)
                    }
                }
                json.append("\"}");
                byte[] jsonBytes = json.toString().getBytes("UTF-8");

                // Use byte-accurate Content-Length
                String header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/json; charset=utf-8\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Content-Length: " + jsonBytes.length + "\r\n" +
                    "Connection: close\r\n" +
                    "\r\n";
                out.write(header.getBytes("UTF-8"));
                out.write(jsonBytes);
                out.flush();
            } else if (path.equals("/health")) {
                String json = "{\"ok\":true}";
                byte[] jsonBytes = json.getBytes("UTF-8");
                String header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/json\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Content-Length: " + jsonBytes.length + "\r\n" +
                    "Connection: close\r\n" +
                    "\r\n";
                out.write(header.getBytes("UTF-8"));
                out.write(jsonBytes);
                out.flush();
            } else {
                String body = "404 Not Found";
                byte[] bodyBytes = body.getBytes("UTF-8");
                String header = "HTTP/1.1 404 Not Found\r\n" +
                    "Content-Length: " + bodyBytes.length + "\r\n" +
                    "Connection: close\r\n" +
                    "\r\n";
                out.write(header.getBytes("UTF-8"));
                out.write(bodyBytes);
                out.flush();
            }
            client.close();
        } catch (IOException e) { Log.e(TAG, "client error", e); }
    }

    private String readLog() {
        if (logFile == null || !logFile.exists()) return "Log file not found.";
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(logFile), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l).append("\n");
            r.close();
            return sb.toString();
        } catch (IOException e) { return "Error: " + e.getMessage(); }
    }
}
```

### IMPORTANT: Java Unicode Escape in Comments

Java treats `\u` followed by 4 hex digits as a unicode escape **even in comments**. This causes a compilation error:
```java
// ❌ This will NOT compile:
// Non-ASCII — escape as \uXXXX

// ✅ This is safe:
// Non-ASCII — escape as backslash-u + 4 hex digits
```

---

## 13. MainActivity.java

**File:** `android/app/src/main/java/com/nekro/hfycyberdeck/MainActivity.java`

**CRITICAL:** Write to the log file IMMEDIATELY at thread start — before any object construction that could fail. This guarantees the log always has content for the splash screen to display, even if NodeRunner construction throws.

```java
package com.nekro.hfycyberdeck;

import android.os.Bundle;
import android.util.Log;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileWriter;

public class MainActivity extends BridgeActivity {
    private static final String TAG = "HFY-MainActivity";
    private NodeRunner nodeRunner;
    private LogServer logServer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new Thread(() -> {
            // Write to the log file IMMEDIATELY — before any object construction that could fail.
            // This guarantees there's always something in the log for the splash to display.
            File earlyLog = new File(getFilesDir(), "node-server.log");
            try {
                earlyLog.getParentFile().mkdirs();
                FileWriter w = new FileWriter(earlyLog, false);
                w.write("=== HFY Server Log ===\n");
                w.write("Thread started: " + new java.util.Date() + "\n");
                w.write("filesDir: " + getFilesDir() + "\n");
                w.write("codeCacheDir: " + getCodeCacheDir() + "\n");
                w.write("nativeLibraryDir: " + getApplicationInfo().nativeLibraryDir + "\n");
                w.write("About to construct NodeRunner...\n\n");
                w.flush();
                w.close();
            } catch (Exception e) {
                Log.e(TAG, "Early log write failed", e);
            }

            try {
                Log.i(TAG, "Starting Node.js server...");
                nodeRunner = new NodeRunner(getApplicationContext());
                logServer = new LogServer(nodeRunner.getLogFile());
                logServer.start();
                Log.i(TAG, "Log server on port 3001");
                nodeRunner.startServer();
            } catch (Exception e) {
                Log.e(TAG, "Failed", e);
                // Also write the exception to the log file so the splash can show it
                try {
                    FileWriter w = new FileWriter(earlyLog, true);
                    w.write("\nFATAL in MainActivity thread: " + e.getMessage() + "\n");
                    w.write(Log.getStackTraceString(e) + "\n");
                    w.flush();
                    w.close();
                } catch (Exception ex) { Log.e(TAG, "Can't write error to log", ex); }
            }
        }, "node-starter").start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (nodeRunner != null) nodeRunner.stopServer();
        if (logServer != null) logServer.stop();
    }
}
```

---

## 14. AndroidManifest.xml

**File:** `android/app/src/main/AndroidManifest.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />
    <uses-feature android:name="android.hardware.wifi" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:requestLegacyExternalStorage="true"
        android:usesCleartextTraffic="true"
        android:extractNativeLibs="true"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode|navigation|density"
            android:name=".MainActivity"
            android:label="@string/title_activity_main"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
    </application>
</manifest>
```

**Key settings:**
- `android:extractNativeLibs="true"` — Forces Android to extract .so files to nativeLibraryDir
- `android:usesCleartextTraffic="true"` — Allows HTTP to localhost
- `android:networkSecurityConfig="@xml/network_security_config"` — Permissive network config

### res/xml/network_security_config.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system" />
            <certificates src="user" />
        </trust-anchors>
    </base-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="true">localhost</domain>
        <domain includeSubdomains="true">127.0.0.1</domain>
    </domain-config>
</network-security-config>
```

### res/values/colors.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">#FF003C</color>
    <color name="colorPrimaryDark">#050608</color>
    <color name="colorAccent">#00FFF0</color>
    <color name="background">#050608</color>
</resources>
```

### res/values/ic_launcher_background.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#050608</color>
</resources>
```

### res/values/strings.xml

```xml
<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">HFY NEKROCODEXXX</string>
    <string name="title_activity_main">HFY NEKROCODEXXX</string>
    <string name="package_name">com.nekro.hfycyberdeck</string>
    <string name="custom_url_scheme">com.nekro.hfycyberdeck</string>
</resources>
```

### res/values/styles.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.Light.DarkActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
        <item name="colorAccent">@color/colorAccent</item>
    </style>
    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
        <item name="android:background">@null</item>
    </style>
    <style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">
        <item name="android:background">@drawable/splash</item>
    </style>
</resources>
```

---

## 15. build.gradle Configuration

### android/app/build.gradle

```gradle
apply plugin: 'com.android.application'

def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
try {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
} catch (Exception e) { logger.warn("keystore.properties not found: ${e.getMessage()}") }

android {
    namespace = "com.nekro.hfycyberdeck"
    compileSdk = rootProject.ext.compileSdkVersion
    defaultConfig {
        applicationId "com.nekro.hfycyberdeck"
        minSdkVersion rootProject.ext.minSdkVersion
        targetSdkVersion rootProject.ext.targetSdkVersion
        versionCode 54
        versionName "6.0.4"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
        // CRITICAL: do NOT include ".*" — it excludes the .next directory!
        aaptOptions {
            ignoreAssetsPattern = '!.svn:!.git:!.ds_store:!*.scc:!CVS:!thumbs.db:!picasa.ini:!*~'
        }
        ndk { abiFilters 'arm64-v8a' }
    }

    // Force Android to extract native libs to nativeLibraryDir (executable)
    packagingOptions {
        jniLibs { useLegacyPackaging = true }
    }

    signingConfigs {
        release {
            if (keystoreProperties['storeFile']) {
                storeFile rootProject.file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
            debuggable false
            zipAlignEnabled true
        }
        debug { debuggable true }
    }

    buildFeatures { buildConfig true }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    packagingOptions {
        resources {
            excludes += ['META-INF/DEPENDENCIES', 'META-INF/LICENSE', 'META-INF/LICENSE.txt', 'META-INF/license.txt', 'META-INF/NOTICE', 'META-INF/NOTICE.txt', 'META-INF/notice.txt', 'META-INF/ASL2.0', 'META-INF/*.kotlin_module']
        }
    }

    // Don't compress these file types (faster extraction at runtime)
    aaptOptions {
        noCompress 'node', 'so', 'js', 'json', 'css', 'html', 'wasm', 'mjs', 'cjs'
    }
}

repositories {
    flatDir { dirs '../capacitor-cordova-android-plugins/src/main/libs', 'libs' }
}

dependencies {
    implementation fileTree(include: ['*.jar'], dir: 'libs')
    implementation "androidx.appcompat:appcompat:$androidxAppCompatVersion"
    implementation "androidx.coordinatorlayout:coordinatorlayout:$androidxCoordinatorLayoutVersion"
    implementation "androidx.core:core-splashscreen:$coreSplashScreenVersion"
    implementation "androidx.webkit:webkit:$androidxWebkitVersion"
    implementation project(':capacitor-android')
    testImplementation "junit:junit:$junitVersion"
    androidTestImplementation "androidx.test.ext:junit:$androidxJunitVersion"
    androidTestImplementation "androidx.test.espresso:espresso-core:$androidxEspressoCoreVersion"
    implementation project(':capacitor-cordova-android-plugins')
}

apply from: 'capacitor.build.gradle'
try {
    def servicesJSON = file('google-services.json')
    if (servicesJSON.text) { apply plugin: 'com.google.gms.google-services' }
} catch(Exception e) {}
```

### android/variables.gradle

```gradle
ext {
    minSdkVersion = 24
    compileSdkVersion = 36
    targetSdkVersion = 35
    androidxActivityVersion = '1.11.0'
    androidxAppCompatVersion = '1.7.1'
    androidxCoordinatorLayoutVersion = '1.3.0'
    androidxCoreVersion = '1.17.0'
    androidxFragmentVersion = '1.8.9'
    coreSplashScreenVersion = '1.2.0'
    androidxWebkitVersion = '1.14.0'
    junitVersion = '4.13.2'
    androidxJunitVersion = '1.3.0'
    androidxEspressoCoreVersion = '3.7.0'
    cordovaAndroidVersion = '14.0.1'
}
```

### android/keystore.properties

```properties
storeFile=keystore/hfy-nekro-release.keystore
storePassword=nekrocodexxx2026
keyAlias=hfy-nekro-key
keyPassword=nekrocodexxx2026
```

### android/local.properties

```properties
sdk.dir=/path/to/android-sdk
```

---

## 16. capacitor.config.ts

**CRITICAL:** The `allowNavigation` array is REQUIRED. Without it, when the splash screen redirects to `http://127.0.0.1:3000`, Capacitor's `BridgeWebViewClient.shouldOverrideUrlLoading()` sees that `127.0.0.1` doesn't match the app's origin (`localhost`) and isn't in the allowNavigation list, so it launches the URL in the system browser instead of the WebView.

### capacitor.config.ts (source)

```typescript
import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nekro.hfycyberdeck',
  appName: 'HFY NEKROCODEXXX',
  webDir: 'mobile-web',
  android: {
    backgroundColor: '#050608',
    allowMixedContent: true,
  },
  server: {
    // NO server.url — Capacitor serves the local splash screen.
    // The splash polls http://localhost:3000 and redirects when ready.
    androidScheme: 'http',
    cleartext: true,
    // CRITICAL: allow WebView navigation to 127.0.0.1 and localhost
    // Without this, Capacitor opens http://127.0.0.1:3000 in the system
    // browser instead of loading it in the app's WebView.
    allowNavigation: ['127.0.0.1', 'localhost'],
  },
};

export default config;
```

### assets/capacitor.config.json (runtime — must be manually updated if not running `npx cap sync`)

```json
{
	"appId": "com.nekro.hfycyberdeck",
	"appName": "HFY NEKROCODEXXX",
	"webDir": "mobile-web",
	"server": {
		"androidScheme": "http",
		"cleartext": true,
		"allowNavigation": ["127.0.0.1", "localhost"]
	},
	"android": {
		"backgroundColor": "#050608",
		"allowMixedContent": true
	}
}
```

**Critical:** Do NOT set `server.url` to `http://localhost:3000`. This makes Capacitor load that URL immediately (before Node.js starts), causing `ERR_CONNECTION_REFUSED`. Instead, load the local splash screen and redirect when the server is ready.

### How Capacitor's allowNavigation Works

When the WebView tries to navigate to a URL, `BridgeWebViewClient.shouldOverrideUrlLoading()` calls `Bridge.launchIntent(url)`. This method:

1. Checks if any plugin wants to override the load
2. Checks if the URL scheme is `data` or `blob` (returns false = don't override)
3. Compares the URL's host/scheme with the app's origin (`appUrl`)
4. If they DON'T match, checks `appAllowNavigationMask.matches(url.getHost())`
5. If the host is NOT in allowNavigation, launches `Intent.ACTION_VIEW` (system browser) and returns `true` (override)
6. If the host IS in allowNavigation, returns `false` (don't override — let WebView handle it)

The `HostMask` matcher splits both the mask and host by `.` and compares parts. `127.0.0.1` matches `127.0.0.1` exactly.

---

## 17. Splash Screen HTML

**File:** `mobile-web/index.html` (also copied to `android/app/src/main/assets/public/index.html`)

The splash screen:
1. Shows the side-facing skull (embedded as base64 PNG, full resolution)
2. Shows progress bar and status messages
3. Polls `http://127.0.0.1:3000/` every 1.5 seconds using `mode: 'no-cors'`
4. Auto-fetches `http://127.0.0.1:3001/log` every 2 seconds and displays it
5. When server responds, redirects to it
6. Fallback: if the log contains "Ready", forces redirect even if fetch fails

### CRITICAL: Use `mode: 'no-cors'` for Server Check

The splash's `fetch('http://127.0.0.1:3000/')` must use `mode: 'no-cors'`. With `mode: 'cors'` (the default), the browser blocks the response because Next.js doesn't send `Access-Control-Allow-Origin` headers. The fetch throws, and the splash never redirects — even though the server is ready.

With `mode: 'no-cors'`:
- If the server responds (any HTTP response), the fetch **resolves** (opaque response)
- If the server is down, the fetch **throws**
- We don't need to read the response — just knowing it's up is enough to redirect

### Splash HTML Template

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#050608">
<title>HFY NEKROCODEXXX</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
html, body { background: #050608; color: #FF003C; font-family: 'Courier New', monospace; height: 100vh; overflow: hidden; }
body { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 16px; }

/* Logo box — portrait aspect ratio (taller than wide) to match the skull image */
.logo-box {
  width: 180px; height: 270px;
  border: 2px solid #FF003C;
  box-shadow: 0 0 30px #FF003C, inset 0 0 20px #FF003C44;
  clip-path: polygon(0 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%);
  overflow: hidden;
  animation: pulse 1.5s ease-in-out infinite;
  position: relative;
}
.logo-box::before {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(180deg, transparent 0%, #FF003C22 100%);
  pointer-events: none; z-index: 2;
}
.logo-box img {
  width: 100%; height: 100%;
  object-fit: cover;
  object-position: center center;
  display: block;
}
.title { color: #FF003C; font-size: 18px; letter-spacing: 0.3em; margin-top: 20px; text-shadow: 0 0 12px #FF003C; font-weight: bold; }
.sub { color: #00FFF0; font-size: 10px; letter-spacing: 0.4em; margin-top: 6px; text-shadow: 0 0 8px #00FFF0; }
.status { color: #FFE600; font-size: 10px; letter-spacing: 0.2em; margin-top: 24px; text-align: center; padding: 0 16px; min-height: 16px; max-width: 90%; }
.progress-bar { width: 200px; height: 3px; background: #1a1a2e; margin-top: 10px; overflow: hidden; position: relative; }
.progress-fill { position: absolute; top: 0; left: 0; height: 100%; width: 0%; background: linear-gradient(90deg, #FF003C, #00FFF0); box-shadow: 0 0 8px #FF003C; transition: width 0.5s ease; }
.show-log-btn { margin-top: 10px; background: transparent; border: 1px solid #00FFF055; color: #00FFF0; padding: 3px 10px; font-family: inherit; font-size: 8px; letter-spacing: 0.2em; cursor: pointer; }
.show-log-btn:active { background: #00FFF022; }
.log-container { margin-top: 8px; width: 92%; height: 180px; background: #0a0d12; border: 1px solid #FF003C33; padding: 6px; overflow-y: auto; font-size: 7px; line-height: 1.3; color: #00FF88; white-space: pre-wrap; word-break: break-all; display: none; }
.log-container.show { display: block; }
.log-container.error { color: #FF4444; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.65; } }
</style>
</head>
<body>
  <div class="logo-box"><img src="data:image/png;base64,SPLASH_SKULL_BASE64_HERE" alt="HFY"></div>
  <div class="title">HFY NEKROCODEXXX</div>
  <div class="sub" id="sub">STARTING SERVER...</div>
  <div class="progress-bar"><div class="progress-fill" id="progress"></div></div>
  <div class="status" id="status">INITIALIZING...</div>
  <button class="show-log-btn" id="showLogBtn" onclick="toggleLog()">HIDE SERVER LOG</button>
  <div class="log-container show" id="logContainer"></div>

<script>
const SERVER_URL = 'http://127.0.0.1:3000';
const LOG_URL = 'http://127.0.0.1:3001/log';
let elapsed = 0;
let logVisible = true;
let serverReady = false;
let readySeenInLog = false;
const startedAt = Date.now();
const statusEl = document.getElementById('status');
const subEl = document.getElementById('sub');
const progressEl = document.getElementById('progress');
const logEl = document.getElementById('logContainer');

function setStatus(msg, pct) {
  statusEl.textContent = msg;
  if (typeof pct === 'number') progressEl.style.width = pct + '%';
}
function setSub(msg) { subEl.textContent = msg; }

function redirectToServer() {
  if (serverReady) return;
  serverReady = true;
  setStatus('SERVER READY — LOADING APP', 100);
  setSub('REDIRECTING...');
  setTimeout(() => { window.location.href = SERVER_URL; }, 500);
}

// Server-ready check using no-cors mode.
// With no-cors: if server responds (any response), fetch RESOLVES with an opaque response.
//              if server is down/unreachable, fetch THROWS.
// This bypasses CORS entirely — we don't need to read the response, just know it's up.
async function checkServer() {
  elapsed = Math.floor((Date.now() - startedAt) / 1000);
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3000);
    await fetch(SERVER_URL + '/', {
      mode: 'no-cors',
      signal: ctrl.signal,
      cache: 'no-store'
    });
    clearTimeout(t);
    redirectToServer();
    return true;
  } catch (e) {
    // Server not responding yet — check if log says Ready (fallback)
    if (readySeenInLog && elapsed > 3) {
      setStatus('LOG SHOWS READY — REDIRECTING', 100);
      setSub('FORCING REDIRECT...');
      redirectToServer();
      return true;
    }
  }
  if (elapsed < 5)        setStatus('INITIALIZING NODE.JS RUNTIME...', 10);
  else if (elapsed < 15)  setStatus('LOADING NEXT.JS SERVER...', 30);
  else if (elapsed < 30)  setStatus('COMPILING API ROUTES...', 60);
  else if (elapsed < 60)  setStatus('STARTING HTTP LISTENER...', 80);
  else if (elapsed < 120) setStatus('STILL STARTING... (' + elapsed + 's)', 90);
  else { setStatus('TAKING TOO LONG — CHECK LOG BELOW', 95); setSub('SERVER NOT RESPONDING'); }
  return false;
}

async function fetchLog() {
  try {
    const r = await fetch(LOG_URL, { cache: 'no-store' });
    if (!r.ok) {
      logEl.classList.add('error');
      logEl.textContent = 'LogServer responded: HTTP ' + r.status;
      return;
    }
    const j = await r.json();
    if (j && j.log) {
      logEl.classList.remove('error');
      logEl.textContent = j.log;
      logEl.scrollTop = logEl.scrollHeight;
      if (j.log.indexOf('Ready') !== -1 || j.log.indexOf('✓ Ready') !== -1) {
        readySeenInLog = true;
      }
    } else {
      logEl.classList.add('error');
      logEl.textContent = 'LogServer returned empty log';
    }
  } catch (e) {
    logEl.classList.add('error');
    logEl.textContent = 'Cannot reach LogServer on port 3001: ' + e.message;
  }
}

function toggleLog() {
  logVisible = !logVisible;
  logEl.classList.toggle('show', logVisible);
  document.getElementById('showLogBtn').textContent = logVisible ? 'HIDE SERVER LOG' : 'SHOW SERVER LOG';
}

setStatus('INITIALIZING...', 5);
checkServer();
setInterval(() => { if (!serverReady) checkServer(); }, 1500);
fetchLog();
setInterval(() => { fetchLog(); }, 2000);
</script>
</body>
</html>
```

### Generating the Splash Skull Base64

```bash
# Full-resolution PNG (no downscaling) — embed as base64
python3 << 'PYEOF'
import base64
from PIL import Image
src = Image.open("HD-wallpaper-cyberpunk-2077-cyber-game-gears-samurai-skulls-war-wear.jpg").convert("RGB")
src.save("splash-skull-full.png", "PNG")
with open("splash-skull-full.png", "rb") as f:
    b64 = base64.b64encode(f.read()).decode()
with open("splash-skull.b64", "w") as f:
    f.write(b64)
print(f"Base64 length: {len(b64)} chars")
PYEOF

# Then embed in the HTML:
B64=$(cat splash-skull.b64)
sed -i "s|SPLASH_SKULL_BASE64_HERE|$B64|" mobile-web/index.html
```

The splash HTML will be ~1.95 MB (the base64 PNG is ~1.9 MB). This is intentional — never reduce image quality or size.

---

## 18. App Icon Generation

### Icon Source Images

- **Front-facing skull** (for app icon): `cyberpunk-retro-futuristic-poster-digital-design-elements-hud-style-trendy-shapes-cyberpunk-style_122058-1794.jpg` (523×740)
- **Side-facing skull** (for splash): `HD-wallpaper-cyberpunk-2077-cyber-game-gears-samurai-skulls-war-wear.jpg` (800×1644)

### Icon Generation Script

**File:** `gen-icons.py`

```python
#!/usr/bin/env python3
"""Generate app icons from the front-facing skull image at FULL resolution.
Skull is fit-by-height: the top of the skull touches the top border and the
chin touches the bottom border. Skull is horizontally centered. Black (#050608)
bars appear on the left/right sides where the skull is narrower than the canvas."""

import os
from PIL import Image, ImageDraw

# Front-facing skull → app icon
ICON_SRC = "cyberpunk-retro-futuristic-poster-digital-design-elements-hud-style-trendy-shapes-cyberpunk-style_122058-1794.jpg"

OUT = "android/app/src/main/res"
BG_COLOR = (5, 6, 8, 255)  # #050608

os.makedirs(OUT, exist_ok=True)

src_icon = Image.open(ICON_SRC).convert("RGBA")
print(f"Icon source: {src_icon.size}")

def fit_by_height(src, size):
    """Scale src so its HEIGHT fills the canvas (size×size).
    The skull will touch the top and bottom borders.
    Horizontally centered, with black bars on the sides if src is narrower than tall."""
    src_w, src_h = src.size
    scale = size / src_h
    new_w = int(src_w * scale)
    new_h = size
    resized = src.resize((new_w, new_h), Image.LANCZOS)
    canvas = Image.new("RGBA", (size, size), BG_COLOR)
    left = (size - new_w) // 2
    canvas.paste(resized, (left, 0))
    return canvas

def make_icon(size, out_path, round_icon=False):
    bg = fit_by_height(src_icon, size)
    if round_icon:
        mask = Image.new("L", (size, size), 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse([0, 0, size - 1, size - 1], fill=255)
        rounded = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        rounded.paste(bg, (0, 0), mask)
        rounded.save(out_path, "PNG")
    else:
        bg.save(out_path, "PNG")

# Standard launcher icon sizes (mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi)
for folder, size in {
    "mipmap-mdpi": 48, "mipmap-hdpi": 72, "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144, "mipmap-xxxhdpi": 192
}.items():
    out_dir = f"{OUT}/{folder}"
    os.makedirs(out_dir, exist_ok=True)
    make_icon(size, f"{out_dir}/ic_launcher.png", round_icon=False)
    make_icon(size, f"{out_dir}/ic_launcher_round.png", round_icon=True)
    print(f"  {folder}: {size}x{size}")

# Adaptive icon foregrounds — fit-by-height on transparent canvas
for folder, size in {
    "mipmap-mdpi": 108, "mipmap-hdpi": 162, "mipmap-xhdpi": 216,
    "mipmap-xxhdpi": 324, "mipmap-xxxhdpi": 432
}.items():
    out_dir = f"{OUT}/{folder}"
    os.makedirs(out_dir, exist_ok=True)
    src_w, src_h = src_icon.size
    scale = size / src_h
    new_w = int(src_w * scale)
    new_h = size
    resized = src_icon.resize((new_w, new_h), Image.LANCZOS)
    fg = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    left = (size - new_w) // 2
    fg.paste(resized, (left, 0))
    fg.save(f"{out_dir}/ic_launcher_foreground.png", "PNG")

# Adaptive icon XMLs
anydpi = f"{OUT}/mipmap-anydpi-v26"
os.makedirs(anydpi, exist_ok=True)
with open(f"{anydpi}/ic_launcher.xml", "w") as f:
    f.write("""<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
""")
with open(f"{anydpi}/ic_launcher_round.xml", "w") as f:
    f.write("""<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
""")

print("All launcher icons generated — skull fills vertical extent, centered horizontally")
```

### Splash PNG Generation (for Android SplashScreen API)

```python
from PIL import Image
import os

SRC = "HD-wallpaper-cyberpunk-2077-cyber-game-gears-samurai-skulls-war-wear.jpg"
OUT = "android/app/src/main/res"
BG = (5, 6, 8, 255)

src = Image.open(SRC).convert("RGBA")
sw, sh = src.size

densities = {
    "drawable-mdpi":    (320, 480),
    "drawable-hdpi":    (480, 800),
    "drawable-xhdpi":   (720, 1280),
    "drawable-xxhdpi":  (1080, 1920),
    "drawable-xxxhdpi": (1440, 2560),
    "drawable-port-mdpi":    (320, 480),
    "drawable-port-hdpi":    (480, 800),
    "drawable-port-xhdpi":   (720, 1280),
    "drawable-port-xxhdpi":  (1080, 1920),
    "drawable-port-xxxhdpi": (1440, 2560),
    "drawable-land-mdpi":    (480, 320),
    "drawable-land-hdpi":    (800, 480),
    "drawable-land-xhdpi":   (1280, 720),
    "drawable-land-xxhdpi":  (1920, 1080),
    "drawable-land-xxxhdpi": (2560, 1440),
}

def fit_by_height(src, w, h):
    src_w, src_h = src.size
    scale = h / src_h
    new_w = int(src_w * scale)
    new_h = h
    resized = src.resize((new_w, new_h), Image.LANCZOS)
    canvas = Image.new("RGBA", (w, h), BG)
    left = (w - new_w) // 2
    canvas.paste(resized, (left, 0))
    return canvas

for folder, (w, h) in densities.items():
    out_dir = f"{OUT}/{folder}"
    os.makedirs(out_dir, exist_ok=True)
    bg = fit_by_height(src, w, h)
    bg.save(f"{out_dir}/splash.png", "PNG")

# Default drawable (fallback)
bg = fit_by_height(src, 480, 800)
bg.save(f"{OUT}/drawable/splash.png", "PNG")
```

---

## 19. All Bugs Encountered and Their Fixes

### Bug 1: Build fails — "Module not found: fs/path"
**Cause:** Client component imports `extractChapterNumber` from `user-chapters.ts` which uses Node.js `fs`/`path`.
**Fix:** Created `chapter-utils.ts` with pure browser-safe functions, changed import in `SeriesDetailScreen.tsx`. (See §5, Fix 1)

### Bug 2: 404 "page not found"
**Cause:** `.next` directory excluded from APK by `ignoreAssetsPattern` containing `.*`.
**Fix:** Removed `.*` from pattern. Now 498 `.next` files included.

### Bug 3: capacitor.config.ts server.url pointing to dead remote URL
**Cause:** `server.url: "https://preview-...space-z.ai"` made WebView load remote URL instead of local splash.
**Fix:** Removed `server.url`, set `androidScheme: 'http'`.

### Bug 4: "Permission denied" executing node binary
**Cause:** Android 10+ W^X policy blocks exec() from `codeCacheDir`/`filesDir`.
**Fix:** Package node as `libnode.so` in `jniLibs/` — Android extracts to `nativeLibraryDir` which IS executable. Plus use `/system/bin/linker64` to load it.

### Bug 5: "libnode.so NOT FOUND in nativeLibraryDir" (empty directory)
**Cause:** `useLegacyPackaging` not set, or `extractNativeLibs` not set in manifest.
**Fix:** Added `useLegacyPackaging = true` in build.gradle AND `android:extractNativeLibs="true"` in manifest.

### Bug 6: "libz.so.1 not found"
**Cause:** Android strips version suffixes from jniLibs .so files (`libz.so.1` → `libz.so`), but node's ELF headers reference `libz.so.1`.
**Fix:** Store versioned .so files in `assets/libs/`, extract to `codeCacheDir/libs/` at runtime (preserves names).

### Bug 7: "libsqlite3.so not found"
**Cause:** Termux sqlite package only has the binary, not the library. Android system has it at `/system/lib64/` but linker ignores `LD_LIBRARY_PATH` for system paths.
**Fix:** Compiled `libsqlite3.so` from SQLite amalgamation source using Android NDK. Bundled in jniLibs AND assets/libs.

### Bug 8: "Unterminated string in JSON" in log viewer
**Cause:** LogServer's `Content-Length` used `jsonStr.length()` (character count), but non-ASCII characters in the log made the UTF-8 byte count larger. The HTTP response was truncated.
**Fix:** Escape ALL non-ASCII characters as `\uXXXX` (pure ASCII JSON), calculate `Content-Length` from `jsonBytes.length`. (See §12)

### Bug 9: Sharp crashes on Android
**Cause:** `sharp` is a native image processing library with linux-x64 binaries that don't work on Android arm64.
**Fix:** Set `images.unoptimized: true` in next.config.ts, remove sharp from standalone build.

### Bug 10: App icon shows white square
**Cause:** `ic_launcher_background.xml` had `#FFFFFF` (white).
**Fix:** Changed to `#050608` (black).

### Bug 11: Logo not showing on splash screen
**Cause:** Image path `./icon-192.png` not loading in WebView.
**Fix:** Embed skull image as base64 data URL directly in HTML.

### Bug 12: Splash screen stuck forever
**Cause:** Node.js server not starting — various library loading errors.
**Fix:** Each library error fixed in sequence (see bugs 4-8). Added LogServer for debugging.

### Bug 13: "cannot locate symbol sqlite3session_delete"
**Cause:** libsqlite3.so was compiled without `-DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK`.
**Fix:** Recompiled with `-DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK -DSQLITE_ENABLE_COLUMN_METADATA` (and other extensions). Verified all 80 sqlite symbols node needs are exported. (See §9)

### Bug 14: "Cannot reach LogServer" / empty log
**Cause:** MainActivity wrote to the log AFTER constructing NodeRunner, which could fail before any log content was written.
**Fix:** MainActivity writes to the log file IMMEDIATELY at thread start, before any object construction. (See §13)

### Bug 15: Server running but splash couldn't detect it
**Cause:** Splash used `fetch(url, {mode: 'cors'})` but Next.js doesn't send CORS headers. The fetch threw, splash never redirected.
**Fix:** Use `mode: 'no-cors'` — if server responds (any response), fetch resolves. Added log-based fallback: if log contains "Ready", force redirect. (See §17)

### Bug 16: App opens in system browser instead of in-app
**Cause:** `capacitor.config.json` didn't have `allowNavigation: ["127.0.0.1", "localhost"]`. Capacitor's `Bridge.launchIntent()` saw `127.0.0.1` didn't match the app origin (`localhost`) and wasn't in allowNavigation, so it launched the URL via `Intent.ACTION_VIEW` (system browser).
**Fix:** Added `allowNavigation: ["127.0.0.1", "localhost"]` to server config. (See §16)

### Bug 17: Nodejs.deb download truncated
**Cause:** curl sometimes truncated the nodejs.deb download (1.2 MB instead of 10 MB).
**Fix:** Re-download and verify size is ~10 MB before extracting.

### Bug 18: Java compilation error "illegal unicode escape" in comments
**Cause:** Java treats `\u` followed by 4 hex digits as a unicode escape even in comments.
**Fix:** Don't use `\uXXXX` in Java comments — write "backslash-u + 4 hex digits" instead.

### Bug 19: Duplicate resources "drawable/splash"
**Cause:** Both `drawable/splash.xml` and `drawable/splash.png` existed.
**Fix:** Delete `splash.xml`, keep only `splash.png`.

### Bug 20: Build fails on "baselineProfiles/0/app-release.dm"
**Cause:** Gradle's baseline profile generation can fail but the APK is still built.
**Fix:** Ignore the error — the APK at `app/build/outputs/apk/release/app-release.apk` is valid. Verify with `unzip -t`.

---

## 20. Build and Sign Commands

### Step 1: Install Android SDK + NDK + JDK

```bash
# JDK 21 (Eclipse Temurin)
mkdir -p /path/to/jdk && cd /path/to/jdk
curl -fsSL -o jdk21.tar.gz "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.5%2B11/OpenJDK21U-jdk_x64_linux_hotspot_21.0.5_11.tar.gz"
tar xzf jdk21.tar.gz && rm jdk21.tar.gz

# Android SDK commandline tools
mkdir -p /path/to/android-sdk/cmdline-tools && cd /path/to/android-sdk/cmdline-tools
curl -fsSL -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
unzip -q cmdtools.zip && mv cmdline-tools latest && rm cmdtools.zip

# Install SDK packages
export ANDROID_HOME=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk/jdk-21.0.5+11
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH
yes | sdkmanager --licenses > /dev/null 2>&1
yes | sdkmanager --install "platform-tools" "platforms;android-36" "build-tools;36.0.0" "ndk;27.0.12077973" "cmake;3.22.1"
```

### Step 2: Build Next.js standalone server

```bash
cd /path/to/hfy-nekrocodexxx-v13
bun install
bun run build
rm -rf .next/standalone/node_modules/sharp .next/standalone/node_modules/@img .next/standalone/node_modules/detect-libc
mkdir -p nodejs-server
cp -r .next/standalone/. nodejs-server/
# Create main.js and package.json (see §6)
```

### Step 3: Download Termux node + libraries + compile libsqlite3.so

See §7, §8, §9.

### Step 4: Set up jniLibs, assets/libs, assets/server

See §10.

### Step 5: Generate keystore

```bash
KDIR=android/keystore
mkdir -p "$KDIR"
keytool -genkeypair -v \
  -keystore "$KDIR/hfy-nekro-release.keystore" \
  -alias hfy-nekro-key \
  -keyalg RSA -keysize 2048 \
  -validity 10000 \
  -storepass nekrocodexxx2026 \
  -keypass nekrocodexxx2026 \
  -dname "CN=HFY NEKROCODEXXX, OU=Cyberdeck, O=NEKRO, L=NightCity, ST=NC, C=US"
```

### Step 6: Install Capacitor dependencies

```bash
cd /path/to/hfy-nekrocodexxx-v13
bun add @capacitor/android @capacitor/core
bun add -D @capacitor/cli
```

### Step 7: Build APK

```bash
cd android
export ANDROID_HOME=/path/to/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export JAVA_HOME=/path/to/jdk/jdk-21.0.5+11
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/build-tools/36.0.0:$ANDROID_HOME/platform-tools:$PATH
export JAVA_OPTS="-Xmx4g -XX:MaxMetaspaceSize=1g"

chmod +x gradlew
./gradlew assembleRelease --no-daemon --console=plain
```

### Step 8: Sign APK

```bash
APK_IN=app/build/outputs/apk/release/app-release.apk
APK_OUT=/path/to/output/HFY-NEKROCODEXXX-v6.0.4.apk

apksigner sign \
  --ks keystore/hfy-nekro-release.keystore \
  --ks-key-alias hfy-nekro-key \
  --ks-pass pass:nekrocodexxx2026 \
  --key-pass pass:nekrocodexxx2026 \
  --v1-signing-enabled true \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --out "$APK_OUT" \
  "$APK_IN"
```

### Step 9: Verify

```bash
# Verify signature
apksigner verify --verbose "$APK_OUT"
# Should show: Verified using v2 scheme: true, v3 scheme: true

# Check .next is in APK
unzip -l "$APK_OUT" | grep "assets/server/.next" | wc -l
# Should be 498

# Check libnode.so is in APK
unzip -l "$APK_OUT" | grep "libnode"
# Should show lib/arm64-v8a/libnode.so (~49 MB)

# Check capacitor.config.json has allowNavigation
unzip -p "$APK_OUT" assets/capacitor.config.json | grep allowNavigation

# Verify APK is a valid zip
unzip -t "$APK_OUT" > /dev/null && echo "Valid zip"
```

---

## 21. Upload Instructions

### Option 1: gofile.io (recommended — no size limit, no splitting)

```bash
# Get a server
SERVER=$(curl -s "https://api.gofile.io/servers" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['data']['servers'][0]['name'])")

# Upload full APK
RESP=$(curl -s --max-time 540 -F "file=@HFY-NEKROCODEXXX-v6.0.4.apk" "https://$SERVER.gofile.io/contents/uploadfile")
echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print('URL:', d['data']['downloadPage']); print('MD5:', d['data']['md5'])"
```

### Option 2: tmpfiles.org (backup — 100 MB limit per file, requires splitting)

```bash
# Split into 3 parts
split -n 3 -d -a 1 HFY-NEKROCODEXXX-v6.0.4.apk hfy-apk-part-
for f in hfy-apk-part-*; do mv "$f" "${f}.bin"; done

# Upload each part
for i in 0 1 2; do
  curl -s --max-time 540 -F "file=@hfy-apk-part-$i.bin" "https://tmpfiles.org/api/v1/upload" | \
    python3 -c "import sys,json; print(json.load(sys.stdin)['data']['url'])" | \
    sed 's|tmpfiles.org/|tmpfiles.org/dl/|'
done
```

### Reassembly (for split parts)

```bash
wget 'URL_PART_0' -O p0.bin
wget 'URL_PART_1' -O p1.bin
wget 'URL_PART_2' -O p2.bin
cat p0.bin p1.bin p2.bin > HFY-NEKROCODEXXX-v6.0.4.apk
md5sum HFY-NEKROCODEXXX-v6.0.4.apk
```

---

## 22. Key Lessons Learned

1. **Android 10+ W^X policy** — Cannot exec() from app-writable dirs. Use `nativeLibraryDir` (via jniLibs) or `/system/bin/linker64`.

2. **Android strips version suffixes** — `libz.so.1` in jniLibs becomes `libz.so`. Store versioned names in assets, extract at runtime.

3. **Android linker namespaces** — Even with correct `LD_LIBRARY_PATH`, the linker won't find libraries it doesn't know about. The `linker64` trick bypasses this.

4. **`.next` directory** — Must be included in APK. Don't use `.*` in `ignoreAssetsPattern`.

5. **sharp crashes on Android** — Set `images.unoptimized: true`, remove sharp from standalone.

6. **capacitor.config.ts** — Don't set `server.url` to localhost. Use local splash screen that redirects. MUST set `allowNavigation: ["127.0.0.1", "localhost"]` or the app opens in system browser.

7. **LogServer** — Essential for debugging without adb access. Serves node-server.log on port 3001. MUST use byte-accurate Content-Length (escape non-ASCII as \uXXXX).

8. **libsqlite3.so** — Not available from Termux as .so. Must compile from SQLite amalgamation source. MUST include `-DSQLITE_ENABLE_SESSION -DSQLITE_ENABLE_PREUPDATE_HOOK -DSQLITE_ENABLE_COLUMN_METADATA` or node:sqlite symbols will be missing.

9. **16KB page alignment** — Android 15 requires `.so` files aligned at 16KB (0x4000). Termux node binary is already aligned. When compiling libsqlite3.so, use `-Wl,-z,max-page-size=16384`.

10. **Splash server check** — Use `mode: 'no-cors'` for the fetch. With `mode: 'cors'`, Next.js doesn't send CORS headers and the fetch is blocked. With `no-cors`, any HTTP response means the server is up.

11. **Java unicode escapes** — Java treats `\u` followed by 4 hex digits as a unicode escape even in comments. Never write `\uXXXX` in Java comments.

12. **Early logging** — Write to the log file IMMEDIATELY at thread start, before any object construction. This guarantees the log always has content for debugging.

13. **nodejs.deb download** — Verify the download size is ~10 MB. A truncated 1.2 MB download will silently fail to extract the node binary.

14. **JDK requirements** — The system JRE is NOT sufficient. Need a full JDK with `javac` and `lib/server/libjvm.so`. Eclipse Temurin JDK 21 works.

15. **Disk space** — The build process needs ~10 GB free disk space. node_modules (1.2 GB), Android SDK (2.6 GB), JDK (345 MB), Termux packages (207 MB), build outputs (741 MB) all add up.

---

## 23. Verification Checklist

Before shipping the APK, verify ALL of the following:

### APK Contents
- [ ] `lib/arm64-v8a/libnode.so` present (~49 MB)
- [ ] All 11 `.so` files in `lib/arm64-v8a/`
- [ ] All 10 versioned `.so` files in `assets/libs/`
- [ ] `assets/server/main.js` present
- [ ] `assets/server/server.js` present
- [ ] `assets/server/.next/` contains 498 files
- [ ] `assets/server/.next/routes-manifest.json` present
- [ ] `assets/server/.next/server/app/index.html` present
- [ ] `assets/public/index.html` present (splash screen, ~1.95 MB)
- [ ] `assets/capacitor.config.json` contains `allowNavigation: ["127.0.0.1", "localhost"]`
- [ ] App icons present in all mipmap densities
- [ ] Splash PNGs present in all drawable densities

### libsqlite3.so Symbols
- [ ] `sqlite3session_delete` exported
- [ ] `sqlite3session_create` exported
- [ ] `sqlite3_preupdate_hook` exported
- [ ] `sqlite3_column_database_name` exported
- [ ] All 80 sqlite symbols node needs are provided (run the verification script in §9)

### 16KB Alignment
- [ ] All `.so` files have `Align: 0x4000` (verify with `readelf -W -l`)

### Signature
- [ ] `apksigner verify --verbose` shows v2: true, v3: true
- [ ] APK is a valid zip (`unzip -t` succeeds)

### Runtime Behavior
- [ ] App opens to splash screen with side-facing skull
- [ ] Log appears in splash screen within 2 seconds
- [ ] Log shows "NODE_OK_v26.3.1" (node binary loads correctly)
- [ ] Log shows "✓ Ready in Xms" (Next.js server started)
- [ ] Splash redirects to app (not system browser)
- [ ] Full HFY NEKROCODEXXX app loads in WebView

---

**End of guide.** Follow sections 3-20 in order to build a working standalone APK from the v13 webapp source.
