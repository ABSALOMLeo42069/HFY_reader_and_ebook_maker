# HFY NEKROCODEXXX — JSONL Integration Master Plan (Parts 1-14)

**Version:** FX45 v31

This document is the complete master plan for the JSONL archive integration. It describes how the app was transformed from a network-dependent Reddit fiction reader into a fully offline-capable archive reader that can serve all chapter content, scores, and metadata from local JSONL dump files.

---

## Complete Master Plan



# COMPLETE MASTER PLAN — HFY NEKROCODEXXX JSONL INTEGRATION

---

## PART 1: PROJECT OVERVIEW

### Goal
Transform the HFY NEKROCODEXXX app from a network-dependent Reddit fiction reader into a **fully offline-capable archive reader** that can serve all chapter content, scores, and metadata from local JSONL dump files — while maintaining all existing functionality (Arctic Shift, cookies, RSS, CORS proxy as fallbacks).

### Current State
- Next.js 16 standalone app, runs on Node.js server on port 3000
- 5,393 hardcoded series with 72,248 chapters
- Content fetched from Arctic Shift API (primary) → cookies → RSS → CORS proxy (fallbacks)
- Scores fetched from Arctic Shift
- Search uses Arctic Shift `title` parameter first, `query` fallback
- Crawl engine uses hfy2epub approach (first-match next-link following)
- Android APK, Windows standalone, and webapp versions

### After Implementation
- JSONL files become the ULTIMATE primary source for all content, scores, and metadata
- Arctic Shift becomes fallback (only used for posts NOT in JSONL)
- New Archive tab for browsing all JSONL posts like Reddit
- New Discovered Series tab for auto-detected new series
- Instant C-FETCH, instant merge, instant search — all from local files
- Supports any number of JSONL files from any subreddits
- File replacement detection and automatic re-indexing

---

## PART 2: FOLDER ACCESS — 4TH FOLDER TYPE

### Current Folder System
The app has 3 folder types in `file-saver-utils.ts`:
1. `download` — where chapter downloads are saved
2. `ebook` — where merged ebooks are saved
3. `import` — where local files are imported from

Each uses `FileSystemDirectoryHandle` persisted in IndexedDB (`hfy-dir-handles` database, `handles` store). The handle persists across restarts — user sets it once and never again.

### New 4th Folder: `jsonl`

**Implementation:**
- Add `"jsonl"` to the folder type list in `file-saver-utils.ts`
- `getDirHandle("jsonl")` — returns the FileSystemDirectoryHandle for the JSONL folder
- `setDirHandle("jsonl", handle)` — saves to IndexedDB
- `restoreDirHandles()` — already restores all handles on startup; add "jsonl" to the list
- User selects a folder on their system containing `.jsonl` files
- The handle persists — on next startup, the app automatically re-scans the folder

**Default path (in useSettings):**
- `jsonlFolder: "/HFY_NEKROCODEXXX/JsonlDumps/"` — default folder name
- User can change this in Settings

**Settings UI — "SUBREDDIT JSONL DATA" card:**
```
┌─────────────────────────────────────────────────────────┐
│  📁 SUBREDDIT JSONL DATA                                 │
│                                                          │
│  Folder: C:\Users\Me\RedditDumps                        │
│  [SELECT FOLDER]  [RE-INDEX]  [CLEAR INDEX]            │
│                                                          │
│  Files detected:                                         │
│    ✅ r_hfy_posts.jsonl (162,206 posts, 2.3 GB)         │
│    ✅ r_sexyspacebabes_posts.jsonl (9,771 posts)         │
│    ✅ r_natureofpredators_posts.jsonl (41,783 posts)     │
│    ✅ r_TheCryopodToHell_posts.jsonl (2,523 posts)       │
│                                                          │
│  Total: 216,283 posts indexed                            │
│  Authors: 4,521 | Subreddits: 4                          │
│                                                          │
│  Indexing: [████████████████░░░░░] 80%                   │
│  Status: Indexing r_hfy_posts.jsonl... 129,765/162,206   │
│                                                          │
│  Auto-scan on startup: [ON]                              │
└─────────────────────────────────────────────────────────┘
```
**File detection:**
- On startup and on manual "RE-INDEX", scan the folder using `directoryHandle.values()`
- For each entry, check if it's a file with `.jsonl` extension
- List all detected files with their post counts and sizes
- Start indexing each file (or re-index if changed)

---

## PART 3: JSONL INDEXING ENGINE

### 3.1 Index Data Structures

**Primary index (in memory):**
```javascript
globalThis.__jsonlIndex = new Map();
// Key: postId (string, lowercase)
// Value: {
//     fileName: string,           // "r_hfy_posts.jsonl"
//     fileHandle: FileSystemFileHandle,
//     byteOffset: number,         // byte position of this post's line start
//     lineLength: number,         // byte length of this line
//     id: string,                 // Reddit post ID
//     title: string,              // Post title
//     author: string,             // Author username
//     score: number,              // Upvote score
//     created_utc: number,        // Unix timestamp
//     permalink: string,          // Reddit permalink
//     subreddit: string,          // Subreddit name
//     num_comments: number,       // Comment count
//     over_18: boolean,           // NSFW flag
//     is_self: boolean,           // Is text post
//     selftextLength: number,     // Character count of selftext
//     url: string,                // Post URL
//     link_flair_text: string|null,
//     upvote_ratio: number|null,
// }
```

**Author index:**
```javascript
globalThis.__jsonlAuthors = new Map();
// Key: author (string, lowercase)
// Value: {
//     name: string,
//     postCount: number,
//     totalScore: number,
//     firstPostDate: number,     // earliest created_utc
//     lastPostDate: number,      // latest created_utc
//     postIds: string[],         // all post IDs by this author
//     subreddits: Set<string>,   // subreddits this author posted in
// }
```

**Subreddit index:**
```javascript
globalThis.__jsonlSubreddits = new Map();
// Key: subreddit (string, lowercase)
// Value: {
//     name: string,
//     postCount: number,
//     totalScore: number,
//     postIds: string[],
//     firstPostDate: number,
//     lastPostDate: number,
// }
```

**File metadata (for change detection):**
```javascript
globalThis.__jsonlFiles = new Map();
// Key: fileName (string)
// Value: {
//     fileHandle: FileSystemFileHandle,
//     fileSize: number,          // bytes — for change detection
//     lastModified: number,      // timestamp — for change detection
//     postCount: number,         // posts indexed from this file
//     subreddit: string,         // detected subreddit (from posts)
// }
```

**Memory estimation:**
- 216,283 posts × ~250 bytes per entry = ~54 MB for primary index
- 4,521 authors × ~500 bytes = ~2.3 MB for author index
- 4 subreddits × ~100 bytes = negligible
- Total: ~56 MB in memory — well within browser limits

### 3.2 Indexing Process

**Step 1: Folder scan**
1. Get `jsonl` directory handle from IndexedDB
2. If no handle set, skip indexing (app works normally without JSONL)
3. Iterate `for await (const entry of directoryHandle.values())`
4. For each entry that is a file with `.jsonl` extension:
   - Get `File` object: `const file = await entry.getFile()`
   - Check if already indexed (compare `file.size` and `file.lastModified` with `__jsonlFiles`)
   - If unchanged: skip (already indexed)
   - If new or changed: add to indexing queue

**Step 2: Stream-parse each file**
```javascript
async function indexJsonlFile(fileHandle, fileName) {
    const file = await fileHandle.getFile();
    const stream = file.stream();
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    
    let buffer = '';
    let byteOffset = 0;
    let postCount = 0;
    let detectedSubreddit = null;
    
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop(); // Keep incomplete line in buffer
        
        for (const line of lines) {
            if (!line.trim()) continue;
            try {
                const post = JSON.parse(line);
                const lineByteLength = Buffer.byteLength(line) + 1; // +1 for \n
                
                // Store in primary index
                globalThis.__jsonlIndex.set(post.id.toLowerCase(), {
                    fileName: fileName,
                    fileHandle: fileHandle,
                    byteOffset: byteOffset,
                    lineLength: lineByteLength,
                    id: post.id,
                    title: post.title || '',
                    author: (post.author || '').toLowerCase(),
                    score: post.score || 0,
                    created_utc: post.created_utc || 0,
                    permalink: post.permalink || '',
                    subreddit: (post.subreddit || '').toLowerCase(),
                    num_comments: post.num_comments || 0,
                    over_18: !!post.over_18,
                    is_self: post.is_self !== false,
                    selftextLength: (post.selftext || '').length,
                    url: post.url || '',
                    link_flair_text: post.link_flair_text || null,
                    upvote_ratio: post.upvote_ratio || null,
                });
                
                // Update author index
                const authorKey = (post.author || '').toLowerCase();
                if (authorKey && authorKey !== '[deleted]' && authorKey !== 'null') {
                    if (!globalThis.__jsonlAuthors.has(authorKey)) {
                        globalThis.__jsonlAuthors.set(authorKey, {
                            name: post.author,
                            postCount: 0,
                            totalScore: 0,
                            firstPostDate: post.created_utc || 0,
                            lastPostDate: post.created_utc || 0,
                            postIds: [],
                            subreddits: new Set(),
                        });
                    }
                    const author = globalThis.__jsonlAuthors.get(authorKey);
                    author.postCount++;
                    author.totalScore += (post.score || 0);
                    author.firstPostDate = Math.min(author.firstPostDate, post.created_utc || 0);
                    author.lastPostDate = Math.max(author.lastPostDate, post.created_utc || 0);
                    author.postIds.push(post.id);
                    author.subreddits.add((post.subreddit || '').toLowerCase());
                }
                
                // Update subreddit index
                const subKey = (post.subreddit || '').toLowerCase();
                if (subKey) {
                    if (!globalThis.__jsonlSubreddits.has(subKey)) {
                        globalThis.__jsonlSubreddits.set(subKey, {
                            name: post.subreddit,
                            postCount: 0,
                            totalScore: 0,
                            postIds: [],
                            firstPostDate: post.created_utc || 0,
                            lastPostDate: post.created_utc || 0,
                        });
                    }
                    const sub = globalThis.__jsonlSubreddits.get(subKey);
                    sub.postCount++;
                    sub.totalScore += (post.score || 0);
                    sub.postIds.push(post.id);
                    sub.firstPostDate = Math.min(sub.firstPostDate, post.created_utc || 0);
                    sub.lastPostDate = Math.max(sub.lastPostDate, post.created_utc || 0);
                }
                
                if (!detectedSubreddit) detectedSubreddit = subKey;
                byteOffset += lineByteLength;
                postCount++;
                
                // Send progress update every 1000 posts
                if (postCount % 1000 === 0) {
                    updateIndexingProgress(fileName, postCount);
                    // Yield to event loop to keep UI responsive
                    await new Promise(r => setTimeout(r, 0));
                }
            } catch (e) {
                // Skip malformed lines
            }
        }
    }
    
    // Store file metadata
    globalThis.__jsonlFiles.set(fileName, {
        fileHandle: fileHandle,
        fileSize: file.size,
        lastModified: file.lastModified,
        postCount: postCount,
        subreddit: detectedSubreddit,
    });
    
    return postCount;
}
```
**Step 3: Post-indexing actions**
After all files are indexed:
1. Run score pre-loading (Part 5)
2. Run PostId matching (Part 7.3)
3. Run chapter chain building (Part 7.2)
4. Run auto-detect new series (Part 8.3)
5. Save lightweight index to IndexedDB for faster startup on next launch

### 3.3 File Replacement Detection

**On every startup and manual re-index:**
1. Scan the `jsonl` folder for current `.jsonl` files
2. For each file in the folder:
   - If it's in `__jsonlFiles` with same size and lastModified → skip (unchanged)
   - If it's in `__jsonlFiles` but size or lastModified differs → **file was replaced**
     - Remove all index entries where `fileName` matches this file
     - Remove from author and subreddit indices (decrement counts, remove postIds)
     - Re-index the new file
   - If it's NOT in `__jsonlFiles` → **new file added**
     - Index it normally
3. For each file in `__jsonlFiles` but NOT in the folder → **file was removed**
   - Remove all index entries where `fileName` matches
   - Remove from author and subreddit indices
   - Remove from `__jsonlFiles`

**This handles:**
- ✅ User replaces old JSONL with newer version → re-index that file
- ✅ User removes a JSONL file → clean up index
- ✅ User adds a new subreddit's JSONL → index alongside existing
- ✅ User adds JSONL from r/nosleep, r/WritingPrompts, etc. → works automatically

### 3.4 Incremental Indexing with Progress

**During indexing:**
- App remains fully usable
- Lookups that miss the JSONL index fall through to Arctic Shift (existing behavior)
- Progress bar in Settings card: "Indexing r_hfy_posts.jsonl: 45% — 73,000 / 162,206 posts"
- Progress updates every 1,000 posts (yield to event loop)
- When complete: toast notification "JSONL indexing complete: 216,283 posts from 4 files"

**On subsequent startups:**
- If files unchanged: index is rebuilt from scratch but fast (~30-60 seconds for 216K posts)
- Future optimization: save lightweight index to IndexedDB for instant startup (postId → {fileName, byteOffset, title, author, score})

### 3.5 Content Retrieval from JSONL

When a post's full content is needed (for reading, C-FETCH, download, merge):

```javascript
async function getJsonlPostContent(postId) {
    const meta = globalThis.__jsonlIndex.get(postId.toLowerCase());
    if (!meta) return null;
    
    const file = await meta.fileHandle.getFile();
    
    // Read the specific line at byteOffset
    // For files up to 2GB, we can use slice()
    const chunk = file.slice(meta.byteOffset, meta.byteOffset + meta.lineLength);
    const text = await chunk.text();
    
    const post = JSON.parse(text);
    return {
        postId: post.id,
        title: post.title,
        author: post.author,
        createdUtc: post.created_utc,
        score: post.score,
        selftext: post.selftext || '',
        selftextHtml: post.selftext_html || '',
        url: post.url || `https://www.reddit.com${post.permalink}`,
        permalink: `https://www.reddit.com${post.permalink}`,
        subreddit: post.subreddit,
        flair: post.link_flair_text,
        numComments: post.num_comments || 0,
        over_18: post.over_18 || false,
        upvote_ratio: post.upvote_ratio || null,
        nextChapterLinks: [], // populated by caller using findChapterLinks()
        prevChapterLinks: [],
        source: 'jsonl-local'
    };
}
```

**Performance:**
- `file.slice(byteOffset, byteOffset + lineLength)` reads ONLY the needed bytes
- Average line: ~15 KB (a chapter's selftext)
- Read time: < 1ms (local disk random access)
- No network calls, no rate limits, no timeouts

---

## PART 4: CONTENT FETCHING — JSONL AS PRIMARY SOURCE

### 4.1 Modify `fetchPostContent` in 4034.js

Add JSONL check as **Strategy -1** (before Arctic Shift Strategy 0):

```javascript
async function fetchPostContent(postIdOrUrl) {
    // ... existing postId extraction code ...
    
    // ========== STRATEGY -1 (ULTIMATE PRIMARY): JSONL local archive ==========
    // If the post exists in the JSONL index, return it instantly — no network calls
    try {
        const jsonlPost = await getJsonlPostContent(postId);
        if (jsonlPost) {
            // Extract next chapter links from the content
            jsonlPost.nextChapterLinks = findChapterLinks(
                jsonlPost.selftext || '',
                jsonlPost.selftextHtml || '',
                getActiveLinkPatterns()
            );
            console.log(`[reddit-scraper] JSONL LOCAL hit for ${postId} (score=${jsonlPost.score}, ${jsonlPost.selftext.length} chars)`);
            return jsonlPost;
        }
    } catch (e) {
        console.log(`[reddit-scraper] JSONL lookup failed for ${postId}: ${e.message}`);
    }
    
    // ========== STRATEGY 0 (FALLBACK): Arctic Shift API ==========
    // ... existing Arctic Shift code ...
}
```

**Fetch order after JSONL integration:**
1. **JSONL local archive** (Strategy -1) — instant, offline, real scores
2. **Arctic Shift API** (Strategy 0) — for posts not in JSONL
3. **Cookies** (Strategy 0.5) — Reddit session cookies
4. **Browser simulation** (Strategy 0.7) — full Chrome headers
5. **RSS direct** (Strategy 1) — Reddit RSS feed
6. **CORS proxy pool** (Strategy 2) — 250+ proxies
7. **easy-reddit-downloader JSON** (Strategy 3) — .json fallback


### 4.2 Impact on existing routes

All routes that call `fetchPostContent` automatically benefit:
- `/api/chapter/[id]` — reading a chapter
- `/api/series/[slug]/fetch-cache` — C-FETCH (REHASH/CONTINUE)
- `/api/download` — downloading chapters
- `/api/crawl` — RSS crawl from chapter
- `/api/series/[slug]/continue-fetch` — continue crawl

No changes needed to these routes — they all call `fetchPostContent` which now checks JSONL first.

---

## PART 5: SCORE PRE-LOADING

### 5.1 Auto-C-Fetch from JSONL

After indexing completes, run a score pre-loading pass:

```javascript
async function preloadScoresFromJsonl() {
    // Get all hardcoded series chapters
    const hardcodedSeries = HARDCODED_SERIES; // from module 1781
    
    for (const [seriesId, series] of Object.entries(hardcodedSeries)) {
        const scores = {};
        let fetchedCount = 0;
        
        for (const chapter of series.chapters) {
            const postId = chapter.postId.toLowerCase();
            const jsonlMeta = globalThis.__jsonlIndex.get(postId);
            
            if (jsonlMeta) {
                // This chapter exists in JSONL — it's automatically C-FETCHED
                scores[postId] = jsonlMeta.score;
                fetchedCount++;
            }
        }
        
        if (Object.keys(scores).length > 0) {
            // Update the scores store
            stores.useSeriesScores.getState().setSeriesScores(seriesId, scores);
            
            // Persist to server
            await fetch(`/api/store/hfy-scores-${encodeURIComponent(seriesId)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(scores)
            });
            
            // Also persist chapter-scores (fetched status)
            const chapterScores = {};
            for (const [pid, score] of Object.entries(scores)) {
                chapterScores[pid] = { score, fetched: true };
            }
            await fetch(`/api/store/hfy-chapter-scores-${encodeURIComponent(seriesId)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(chapterScores)
            });
        }
    }
}
```

### 5.2 What this means for the user

**On Browse tab:**
- Every series card shows the **real total upvote count** (sum of all chapter scores from JSONL)
- Every series card shows the **real C-FETCHED count** (all chapters in JSONL = fetched)
- No need to manually C-FETCH — it's already done

**On Library tab:**
- Same — all series show correct totals
- Upvote sorting works correctly for the first time

**On Series Detail page:**
- Every chapter shows its **real upvote score** (▲ 424)
- Every chapter is marked as **fetched** (no skull icon)
- Opening any chapter shows content **instantly** from JSONL

**On Series Cards:**
- `C-FETCHED: 925/925` (all chapters fetched from JSONL)
- `▲ 45,231` (total upvotes from JSONL scores)
- `💾 CACHED` indicator shown

### 5.3 Fill Missing Metadata (Idea 22)

During score pre-loading, also enrich chapters with:
- `createdUtc` — from JSONL `created_utc` field
- `numComments` — from JSONL `num_comments` field
- `wordCount` — calculated from JSONL `selftext` length
- `author` — from JSONL `author` (if app's chapter has "unknown")
- `over_18` — NSFW flag from JSONL

This data is persisted to:
- IndexedDB (`hfy-series-cache-v3-{seriesId}`)
- Server filesystem (`user-chapters/{seriesId}.json`)

### 5.4 Dead Link Recovery (Idea 23)

Automatically handled by the JSONL check in `fetchPostContent`:
- If a Reddit post is deleted but exists in JSONL → content served from local file
- If Arctic Shift doesn't have it but JSONL does → content served from local file
- The JSONL is a permanent archive that doesn't depend on Reddit keeping the post alive

---

## PART 6: CHAPTER DISCOVERY

### 6.1 Local Gap Filling (Idea 4)

**Modify `fetch-missing` route:**

Before searching Arctic Shift, search the JSONL index:

```javascript
// In fetch-missing route, for each missing chapter number:
for (const missingNum of missing) {
    let found = false;
    
    // STRATEGY 1: Search JSONL index locally (instant)
    if (globalThis.__jsonlIndex) {
        // Build search patterns
        const patterns = [
            new RegExp(`\\bpart\\s+0*${missingNum}\\b`, 'i'),
            new RegExp(`\\bchapter\\s+0*${missingNum}\\b`, 'i'),
            new RegExp(`\\bepisode\\s+0*${missingNum}\\b`, 'i'),
        ];
        
        for (const [postId, meta] of globalThis.__jsonlIndex) {
            const title = meta.title || '';
            const titleLower = title.toLowerCase();
            
            // Check if title matches the missing chapter number
            if (patterns.some(p => p.test(title))) {
                // Check if title contains the series name
                const hasSeriesName = titleLower.includes(seriesNameLower) 
                    || titleLower.includes(slugWords)
                    || titleLower.includes('oocs');
                
                if (hasSeriesName) {
                    foundChapters.push({
                        title: title,
                        url: `https://www.reddit.com${meta.permalink}`,
                        postId: postId
                    });
                    found = true;
                    break;
                }
            }
        }
    }
    
    // STRATEGY 2: Fall back to Arctic Shift search if JSONL didn't find it
    if (!found) {
        // ... existing Arctic Shift search code ...
    }
}
```

**Advantages:**
- Instant — no network calls for gap filling
- More comprehensive — searches ALL 162K+ posts, not just 25 results from Arctic Shift
- More accurate — full-text title matching, not API keyword search limitations

### 6.2 Full Chapter Chain Building (Idea 5 + 10)

**New function: `buildChapterChainsFromJsonl()`**

Runs once after indexing completes:

```javascript
async function buildChapterChainsFromJsonl() {
    // Step 1: Parse all "next" links from all JSONL posts
    const nextLinkGraph = new Map(); // postId → [nextPostId, ...]
    
    for (const [postId, meta] of globalThis.__jsonlIndex) {
        // Only parse posts that have selftext (text posts)
        if (meta.selftextLength > 0) {
            // Read the full post content
            const post = await getJsonlPostContent(postId);
            if (post && post.selftext) {
                const links = findChapterLinks(
                    post.selftext,
                    post.selftextHtml || '',
                    getActiveLinkPatterns()
                );
                if (links.length > 0) {
                    nextLinkGraph.set(postId, links.map(l => l.postId));
                }
            }
        }
        
        // Yield every 1000 posts to keep UI responsive
        if (nextLinkGraph.size % 1000 === 0) {
            await new Promise(r => setTimeout(r, 0));
        }
    }
    
    // Step 2: Build chains starting from known chapter 1s
    const chains = new Map(); // seriesId → [postId1, postId2, ...]
    
    for (const [seriesId, series] of Object.entries(HARDCODED_SERIES)) {
        if (series.chapters.length === 0) continue;
        
        const chain = [];
        const visited = new Set();
        let currentPostId = series.chapters[0].postId.toLowerCase();
        
        while (currentPostId && !visited.has(currentPostId)) {
            visited.add(currentPostId);
            chain.push(currentPostId);
            
            const nextLinks = nextLinkGraph.get(currentPostId);
            if (nextLinks && nextLinks.length > 0) {
                // Follow first unvisited next link (hfy2epub approach)
                const next = nextLinks.find(id => !visited.has(id));
                currentPostId = next ? next.toLowerCase() : null;
            } else {
                currentPostId = null;
            }
        }
        
        chains.set(seriesId, chain);
    }
    
    // Step 3: Find missing chapters (in chain but not in app)
    for (const [seriesId, chain] of chains) {
        const existing = HARDCODED_SERIES[seriesId]?.chapters || [];
        const existingIds = new Set(existing.map(c => c.postId.toLowerCase()));
        
        const missing = chain.filter(postId => !existingIds.has(postId));
        
        if (missing.length > 0) {
            // These are chapters that exist in JSONL but not in the app
            // Add them to the series
            for (const postId of missing) {
                const meta = globalThis.__jsonlIndex.get(postId);
                if (meta) {
                    // Add chapter to series via API
                    await fetch(`/api/series/${encodeURIComponent(seriesId)}/add-chapter`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            postId: postId,
                            title: meta.title,
                            url: `https://www.reddit.com${meta.permalink}`
                        })
                    });
                }
            }
        }
    }
    
    return chains;
}
```

**Performance:**
- Parsing 162K posts for next-links: ~10-30 seconds (reading from JSONL files)
- Building chains from graph: < 1 second
- Total: discover ALL missing chapters for ALL series in ~30 seconds

### 6.3 PostId Matching (Idea 8)

After indexing, cross-reference JSONL postIds with app's existing chapters:

```javascript
async function findMissingChaptersViaPostIdMatching() {
    // Build set of all known postIds
    const knownPostIds = new Set();
    for (const [seriesId, series] of Object.entries(HARDCODED_SERIES)) {
        for (const chapter of series.chapters) {
            knownPostIds.add(chapter.postId.toLowerCase());
        }
    }
    // Also include user-imported chapters
    // ... load from user-chapters directory ...
    
    // Find JSONL posts NOT in the known set
    const missingPosts = [];
    for (const [postId, meta] of globalThis.__jsonlIndex) {
        if (!knownPostIds.has(postId)) {
            missingPosts.push({ postId, ...meta });
        }
    }
    
    // Group missing posts by likely series (author + title pattern)
    const grouped = new Map(); // seriesId → [missingPosts]
    
    for (const post of missingPosts) {
        // Try to match to an existing series by author
        for (const [seriesId, series] of Object.entries(HARDCODED_SERIES)) {
            if (series.author && series.author.toLowerCase() === post.author) {
                // Same author — likely belongs to this series
                if (!grouped.has(seriesId)) grouped.set(seriesId, []);
                grouped.get(seriesId).push(post);
            }
        }
    }
    
    return grouped;
}
```
### 6.4 Local Search (Idea 6)

**Modify `searchSeries` in 4034.js:**

Add JSONL local search before Arctic Shift:

```javascript
async function searchSeries(query, sort = "relevance") {
    // STRATEGY 0 (ULTIMATE PRIMARY): JSONL local search (instant)
    if (globalThis.__jsonlIndex && globalThis.__jsonlIndex.size > 0) {
        const queryLower = query.toLowerCase();
        const results = [];
        
        for (const [postId, meta] of globalThis.__jsonlIndex) {
            const titleLower = (meta.title || '').toLowerCase();
            if (titleLower.includes(queryLower)) {
                results.push({
                    id: postId,
                    title: meta.title,
                    wikiUrl: meta.permalink 
                        ? `https://www.reddit.com${meta.permalink}` 
                        : `https://www.reddit.com/r/HFY/comments/${postId}/`,
                    author: meta.author,
                    score: meta.score,
                    subreddit: meta.subreddit,
                    created_utc: meta.created_utc,
                });
            }
        }
        
        // Sort by score (highest first) — or by date if sort === "new"
        if (sort === "new") {
            results.sort((a, b) => (b.created_utc || 0) - (a.created_utc || 0));
        } else {
            results.sort((a, b) => (b.score || 0) - (a.score || 0));
        }
        
        // Return up to 100 results
        if (results.length > 0) {
            console.log(`[reddit-scraper] JSONL local search OK for "${query}" (${results.length} results)`);
            return results.slice(0, 100);
        }
    }
    
    // STRATEGY 1: Arctic Shift title search (fallback)
    // ... existing Arctic Shift code ...
}
```

**This is used by:**
- Reddit Chapter Search (in series detail page) — searches JSONL first
- Browse tab "Add Custom Series" search — searches JSONL first
- Any other search functionality in the app

---

## PART 7: NEW TABS — ARCHIVE AND DISCOVERED SERIES

### 7.1 Bottom Navigation Bar Layout

**Current (5 tabs):**
```
[BROWSE] [LIBRARY] [QUEUE] [SETTINGS]
```

**New (7 tabs):**
```
[BROWSE] [LIBRARY] [DISCOVERED] [ARCHIVE] [QUEUE] [SETTINGS]
```

**Tab details:**

| Position | Tab Name | Icon | Text Label | Icon File |
|----------|----------|------|------------|-----------|
| 1 | Browse | Compass (lucide) | "BROWSE" | (existing) |
| 2 | Library | Library (lucide) | "LIBRARY" | (existing) |
| 3 | **Discovered Series** | **Continue C-Fetch.png** | **None (icon only)** | `Continue C-Fetch.png` (1166×1349) |
| 4 | **Archive** | **Rehash C-Fetch.png** | **None (icon only)** | `Rehash C-Fetch.png` (512×512) |
| 5 | Queue | Download (lucide) | "QUEUE" | (existing) |
| 6 | Settings | Settings (lucide) | "SETTINGS" | (existing) |

**Implementation in page chunk:**
- Add `archive` and `discovered` to the `useNav` store's screen enum
- Add two new buttons in the bottom navigation bar
- Both new buttons use PNG icons (not lucide SVG icons)
- No text label — just the icon
- Icons copied to `server/public/` as `icon-archive.png` and `icon-discovered.png`

### 7.2 Archive Tab (Subreddit Browser)

**Purpose:** Browse ALL posts from ALL JSONL files like browsing Reddit offline.

**Layout:**
```
┌────────────────────────────────────────────────────────────────────┐
│  HFY NEKROCODEXXX                                                   │
│                                                                     │
│  ┌─ Filters ────────────────────────────────────────────────────┐  │
│  │  Subreddit: [All ▼]  Sort: [Top ▼]  Search: [_________]     │  │
│  │  Author: [All ▼]    Date: [All ▼]    Min Score: [0]         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌─ Quick Access ───────────────────────────────────────────────┐  │
│  │  👤 Authors (4,521)                                          │  │
│  │  📁 r/HFY (162,206 posts)                                    │  │
│  │  📁 r/Sexyspacebabes (9,771 posts)                           │  │
│  │  📁 r/NatureofPredators (41,783 posts)                       │  │
│  │  📁 r/TheCryopodToHell (2,523 posts)                         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌─ Posts (Page 1 of 8,114) ───────────────────────────────────┐  │
│  │                                                              │  │
│  │  ▲ 424  [Zyz] Translocation                                 │  │
│  │  Posted 2019-07-28 by u/tsavong117 in r/HFY                 │  │
│  │  8,183 chars · 15 comments · Text post                      │  │
│  │  [📖 READ]  [➕ ADD TO SERIES ▼]                            │  │
│  │  ─────────────────────────────────────────────────────────── │  │
│  │                                                              │  │
│  │  ▲ 388  Out of Cruel Space, Part 999                        │  │
│  │  Posted 2024-05-11 by u/KyleKKent in r/HFY                  │  │
│  │  13,642 chars · 89 comments · Text post                     │  │
│  │  [📖 READ]  [➕ ADD TO SERIES ▼]                            │  │
│  │  ─────────────────────────────────────────────────────────── │  │
│  │                                                              │  │
│  │  ▲ 376  OOCS, Into A Wider Galaxy, Part 001                 │  │
│  │  Posted 2024-05-12 by u/KyleKKent in r/HFY                  │  │
│  │  14,395 chars · 67 comments · NSFW · Text post              │  │
│  │  [📖 READ]  [➕ ADD TO SERIES ▼]                            │  │
│  │  ─────────────────────────────────────────────────────────── │  │
│  │  ...                                                         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  [◀ PREV]  Page 1 of 8,114  [NEXT ▶]                              │
│                                                                     │
│  ┌─ Selection Mode (when active) ───────────────────────────────┐  │
│  │  3 posts selected                                            │  │
│  │  [ADD SELECTED TO SERIES ▼]  [CREATE NEW SERIES]  [CANCEL]  │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────┘
```

**Post Card component (adapted from ArcticZim's postsummary pattern):**

Each post card shows:
- **Score** (▲ 424) — real upvote score from JSONL, color: orange/red
- **Title** — clickable to read full post content
- **Author** — clickable to filter by that author
- **Subreddit** — clickable to filter by that subreddit
- **Date** — formatted from `created_utc`
- **Content length** — "8,183 chars"
- **Comment count** — "15 comments"
- **NSFW badge** — red "NSFW" tag if `over_18` is true
- **Flair** — post flair text if present
- **[📖 READ]** button — opens full post view
- **[➕ ADD TO SERIES ▼]** dropdown — add to existing or create new series

**Filters:**
- **Subreddit dropdown:** "All Subreddits" + dynamically populated from `__jsonlSubreddits` map
- **Sort dropdown:** "Top" (by score), "Newest" (by date), "Oldest" (by date)
- **Search input:** filters posts by title (client-side, instant)
- **Author dropdown:** "All Authors" + top 100 authors by post count
- **Date filter:** "All Time", "Last Year", "Last Month", "Last Week"
- **Min Score filter:** only show posts with score >= N

**Pagination:**
- 20 posts per page (matching ArcticZim's POSTS_PER_PAGE)
- Page buttons at bottom: [◀ PREV] Page X of Y [NEXT ▶]
- All data comes from in-memory index — pagination is instant

**Full Post View (when user clicks READ):**
```
┌────────────────────────────────────────────────────────────────────┐
│  [◀ BACK TO ARCHIVE]                                               │
│                                                                     │
│  ▲ 424  [Zyz] Translocation                                        │
│  Posted 2019-07-28 by u/tsavong117 in r/HFY                        │
│  15 comments · 8,183 chars                                         │
│                                                                     │
│  ┌─ Post Content ──────────────────────────────────────────────┐  │
│  │                                                              │  │
│  │  [Next](https://www.reddit.com/r/HFY/comments/cj0km0/...)   │  │
│  │                                                              │  │
│  │  To say Zyz was frustrated at the situation he found        │  │
│  │  himself in would be akin to someone informing you that     │  │
│  │  a 15 meter tsunami was about to hit and you would get      │  │
│  │  slightly damp.                                              │  │
│  │                                                              │  │
│  │  He had been taking a wonderfully pleasant sh...            │  │
│  │  ...                                                         │  │
│  │                                                              │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  [➕ ADD TO SERIES ▼]  [⭐ ADD TO LIBRARY]                        │
└────────────────────────────────────────────────────────────────────┘
```

- Content rendered as markdown using `react-markdown` (already a dependency)
- "Next chapter" links are highlighted and clickable (opens next post from JSONL)
- [ADD TO SERIES] button at top and bottom

**Author Browser (when user clicks an author or "Authors" quick access):**
```
┌────────────────────────────────────────────────────────────────┐
│  AUTHORS IN JSONL ARCHIVE                                       │
│                                                                 │
│  Search: [____________]   Sort: [Post Count ▼]                 │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Author              Posts    Total Score   Latest Post   │  │
│  │  ──────────────────────────────────────────────────────── │  │
│  │  KyleKKent           1,730    45,231        2024-05-12    │  │
│  │  Raltar234           1,200    38,000        2023-12-15    │  │
│  │  SpacePaladin15      850      52,000        2024-01-20    │  │
│  │  Klokinator          600      28,000        2023-08-10    │  │
│  │  ...                                                     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  [Click an author to see all their posts]                      │
└────────────────────────────────────────────────────────────────┘
```

Clicking an author shows all their posts in the standard post list UI, filtered by that author. Sorted by date (newest first) or score (highest first).


### 7.3 Discovered Series Tab

**Purpose:** Show series auto-detected from JSONL that aren't in the app's 5,393 hardcoded series.

**Layout:**
```
┌────────────────────────────────────────────────────────────────┐
│  DISCOVERED SERIES                                              │
│                                                                 │
│  Search: [____________]   Sort: [Chapter Count ▼]             │
│                                                                 │
│  ┌─ Series Cards ──────────────────────────────────────────┐  │
│  │                                                          │  │
│  │  📖 The Deathworlders                                    │  │
│  │  by Raltar234                                            │  │
│  │  120 chapters · 45,000 total upvotes                    │  │
│  │  r/HFY · First: 2020-01-15 · Last: 2024-03-20           │  │
│  │  [➕ CREATE SERIES]  [👁 VIEW POSTS]  [📖 READ FIRST]   │  │
│  │  ─────────────────────────────────────────────────────── │  │
│  │                                                          │  │
│  │  📖 Dungeon Engineer                                     │  │
│  │  by LithosMaitre                                         │  │
│  │  85 chapters · 23,000 total upvotes                     │  │
│  │  r/HFY · First: 2021-06-01 · Last: 2023-11-30           │  │
│  │  [➕ CREATE SERIES]  [👁 VIEW POSTS]  [📖 READ FIRST]   │  │
│  │  ─────────────────────────────────────────────────────── │  │
│  │  ...                                                     │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

**Auto-detect logic (Idea 12):**

After indexing, run series detection:
1. Group all JSONL posts by author
2. For each author, look for title patterns:
   - "Series Name Part N" / "Series Name Chapter N" / "Series Name Episode N"
   - "[Series Name] Chapter N" / "[Series Name] Part N"
   - "Series Name Bk N Ch N"
3. Extract the "series name" portion from the title (everything before "Part/Chapter/Episode N")
4. Group posts by detected series name
5. Any group with 3+ posts is likely a series
6. Compare detected series names with the app's 5,393 hardcoded series
7. New series = detected groups that don't match any existing series

**Actions:**
- **[CREATE SERIES]** — Creates a new custom series in the app:
  - Generates a slug from the series name
  - Adds all detected chapters to the series (sorted by part number)
  - Series appears in Browse tab with a "CUSTOM" badge
  - All chapter scores are loaded from JSONL
- **[VIEW POSTS]** — Opens the Archive tab filtered to this series's posts
- **[READ FIRST]** — Opens the first chapter in the reader

### 7.4 Cross-Subreddit Support (Idea 20 + 21)

**Cross-subreddit series detection:**
- The unified JSONL index covers ALL files from ALL subreddits
- When building chapter chains, if a "next" link points to a post in a different subreddit, follow it
- Post cards show which subreddit each post came from
- User can create a series that contains chapters from multiple subreddits

**Subreddit-specific browse:**
- Subreddit filter dropdown in Archive tab: "All" / "r/HFY" / "r/Sexyspacebabes" / etc.
- Dynamically populated from `__jsonlSubreddits` map
- Selecting a subreddit filters posts to only that subreddit
- Each subreddit shows its post count and total score

---

## PART 8: ADDING POSTS TO SERIES / CREATING CUSTOM SERIES

### 8.1 Add Post to Existing Series

From the Archive tab:
1. User clicks [➕ ADD TO SERIES ▼] on a post card
2. Dropdown shows all 5,393 existing series (searchable, with type-ahead)
3. User selects a series
4. Post is added via `/api/series/{slug}/add-chapter`:
   ```json
   {
     "postId": "ciqsdj",
     "title": "[Zyz] Translocation",
     "url": "https://www.reddit.com/r/HFY/comments/ciqsdj/zyz_translocation/"
   }
   ```
5. Chapter appears at the end of the series's chapter list
6. User can reorder manually (no auto-sort)
7. Chapter is immediately readable (content from JSONL)
8. Chapter's score is immediately shown (from JSONL)

### 8.2 Create New Custom Series

From the Archive tab:
1. User clicks [➕ ADD TO SERIES ▼] → "Create New Series"
2. Prompt for series name: "Enter series name:"
3. App generates a slug: `"The Deathworlders" → "the_deathworlders"`
4. Creates a new series entry:
   - Stored in `user-chapters/the_deathworlders.json` on server
   - Not in hardcoded data — marked as "CUSTOM" source
5. Post is added as the first chapter
6. New series appears in Browse tab with a "CUSTOM" badge
7. User can add more posts to this series from the Archive tab

### 8.3 Multi-Select Mode

Like the existing chapter selection mode in series detail:
1. Long-press a post card to enter selection mode
2. Select multiple posts by tapping checkboxes
3. Bottom bar appears: "3 posts selected"
4. [ADD SELECTED TO SERIES ▼] → choose existing or create new
5. All selected posts are added in one batch (preserving their order from the Archive list)

### 8.4 Browse Tab Custom Series → Reddit Chapter Search Uses JSONL

The "Add Custom Series" function on the Browse tab has a Reddit Chapter Search menu. This search must check the JSONL index FIRST:

1. User types "out of cruel space part 100" in the search box
2. `searchSeries("out of cruel space part 100")` is called
3. Function checks JSONL index first (Part 6.4):
   - Filters all 216K+ posts where title contains "out of cruel space part 100"
   - Returns matching results instantly
4. If JSONL has results → user selects posts → adds to custom series
5. If JSONL has no results → falls back to Arctic Shift title search → query search → cookies → CORS proxy

---

## PART 9: DOWNLOAD & MERGE FROM JSONL

### 9.1 Instant Merge (Idea 18)

**Current merge flow:**
1. For each chapter, check IndexedDB cache → if not cached, fetch from `/api/download`
2. `/api/download` calls `fetchPostContent` → Arctic Shift API call per chapter
3. 1,000 chapters = 1,000 API calls = 10+ minutes

**New merge flow with JSONL:**
1. For each chapter, `fetchPostContent` checks JSONL index FIRST
2. If postId is in JSONL → read from local file (instant, < 1ms)
3. If not in JSONL → check IndexedDB cache → Arctic Shift
4. 1,000 chapters = 1,000 local file reads = **< 10 seconds**

**No code changes needed to the merge function itself** — it already calls `fetchPostContent` which now checks JSONL first. The speedup is automatic and transparent.

### 9.2 Bulk Pre-Cache (Idea 19)

New "Cache All from JSONL" button on series detail page:

```
┌─────────────────────────────────────────────────────┐
│  Out of Cruel Space                                  │
│  925 chapters · 45,231 total upvotes · 925 c-fetched│
│                                                      │
│  [📥 REHASH] [▶ CONTINUE] [📊 GAPS] [🔍 SEARCH]    │
│  [💾 CACHE ALL FROM JSONL]  ← NEW BUTTON            │
│                                                      │
│  Caching: [████████████░░░░░] 60%                   │
│  555/925 chapters cached                             │
└─────────────────────────────────────────────────────┘
```

**Flow:**
1. For each chapter in the series, look up postId in JSONL index
2. Read full post content from JSONL file
3. Save to IndexedDB (`hfy-chapter-cache-{postId}`)
4. Save to server (`/api/chapter-cache/{postId}` via POST)
5. Set `chapter.fetched = true` and `chapter.score = jsonlScore`
6. Update progress bar: "Caching: 555/925 chapters"
7. After completion: entire series is available offline — even if JSONL file is removed later

---

## PART 10: PERSISTENCE — ALL CHANGES MUST BE PERMANENT

### 10.1 What Must Persist

| Data | Storage Location | Persists Across |
|------|-----------------|-----------------|
| Chapter content (C-FETCH results) | IndexedDB + server `chapter-cache/` | Restart, refresh |
| Chapter scores | Server `app-store/hfy-scores-{seriesId}` + `hfy-chapter-scores-{seriesId}` | Restart, refresh |
| Downloaded chapter markers | localStorage + IndexedDB + server `app-store/hfy-downloaded-{seriesId}` | Restart, refresh |
| Merged file content | IndexedDB + server `app-store/hfy-merged-content-{seriesId}` | Restart, refresh |
| Merged file flag | localStorage + server `app-store/hfy-merged-flag-{seriesId}` | Restart, refresh |
| New chapters (added via search/archive) | Server `user-chapters/{seriesId}.json` | Restart, refresh |
| New custom series | Server `user-chapters/{seriesId}.json` | Restart, refresh |
| Renamed/reordered chapters | Server `user-chapters/{seriesId}.json` + IndexedDB | Restart, refresh |
| Read tracking | localStorage + IndexedDB + server `app-store/hfy-read-chapters` | Restart, refresh |
| Library items + favorites | localStorage + server `app-store/hfy-nekrocodexxx-library` | Restart, refresh |
| JSONL folder handle | IndexedDB `hfy-dir-handles` | Restart, refresh |
| JSONL index | Rebuilt from files on startup (not persisted — ~30-60 seconds) | N/A |
| Scores loaded FROM JSONL | Persisted to server scores store during pre-loading | Restart, refresh |

### 10.2 Persistence Audit Checklist

Before marking implementation complete, verify:
1. ✅ New chapters added via Reddit Chapter Search → persist to `user-chapters/` on server
2. ✅ New chapters added via Archive tab → persist to `user-chapters/` on server
3. ✅ New custom series created from Archive tab → persist to `user-chapters/` on server
4. ✅ C-FETCH results (content + scores) → persist to `chapter-cache/` and `app-store/` on server
5. ✅ Scores loaded from JSONL → persist to `app-store/hfy-scores-{seriesId}` on server
6. ✅ Downloaded chapter markers → persist to localStorage + IndexedDB + server
7. ✅ Merged file → persist to IndexedDB + server
8. ✅ Merged file deletion → clear from IndexedDB + server + set deletion flag in localStorage
9. ✅ After leaving and returning to series → all state correct (no stale data)
10. ✅ After app restart → all data restored from server filesystem
11. ✅ Chapter reorder/rename → persist to `user-chapters/` on server
12. ✅ Read tracking → persist to server `app-store/hfy-read-chapters`

---

## PART 11: RSS CRAWL ENGINE — STAYS AS-IS

### 11.1 What Stays Unchanged

The existing RSS crawl engine (based on hfy2epub's approach) stays completely unchanged:
- `findChapterLinks()` function in `4034.js` — uses `BUILT_IN_PATTERNS` (next, epilogue, part N, chapter N, episode N, arrow >, book N)
- `crawlAllChapters()` in crawl route — BFS with first-match next-link following
- `continue-fetch` route — streaming crawl with Arctic Shift bulk search for no-link chapters
- Settings card for crawl keywords — user can add custom regex patterns
- `startCrawl()` client function — called from long-press "RSS CRAWL" button

### 11.2 How JSONL Integrates with Crawl (Transparently)

The crawl engine calls `fetchPostContent()` for each chapter. Since `fetchPostContent` now checks JSONL first:
- If the chapter is in JSONL → content served from local file (instant)
- `findChapterLinks()` runs on the JSONL content → extracts next-chapter links
- Crawl follows the next link → calls `fetchPostContent()` again → checks JSONL again
- The crawl engine doesn't know or care where the content came from — it just works faster

**No changes to crawl engine code.** The speedup is automatic and transparent.

### 11.3 Settings Card for Crawl Keywords

The existing settings card for crawl link patterns stays unchanged:
- User can toggle built-in patterns on/off
- User can add custom regex patterns
- These patterns are used by `findChapterLinks()` which is called by:
  - Crawl engine
  - Continue-fetch engine
  - Chapter chain building from JSONL (new — uses same function)

---

## PART 12: PERFORMANCE CONSIDERATIONS

### 12.1 Performance Comparison

| Operation | Without JSONL | With JSONL | Improvement |
|-----------|-------------|------------|-------------|
| Fetch 1 chapter | 1-3s (Arctic Shift API) | < 1ms (local file read) | 1000x+ |
| C-FETCH 100 chapters | 5-10 min | < 1 second | 300x+ |
| C-FETCH 1,000 chapters | 1-2 hours | < 5 seconds | 500x+ |
| Search "oocs" | 2-5s (Arctic Shift API) | < 100ms (in-memory filter) | 20x+ |
| Gap filling 10 chapters | 30-60s (Arctic Shift search) | < 1 second | 30x+ |
| Merge 1,000 chapters | 10+ min | < 10 seconds | 60x+ |
| Discover all sequel chapters | Hours (crawling one by one) | < 1 second (chain building) | 3600x+ |
| Open Browse tab | Shows 0 upvotes | Shows real upvotes | Instant |
| Open chapter for reading | 1-3s (API call) | Instant (local read) | 1000x+ |

### 12.2 Memory Usage

| Component | Memory | Notes |
|-----------|--------|-------|
| Primary index (216K posts) | ~54 MB | postId → metadata Map |
| Author index (4.5K authors) | ~2.3 MB | author → posts Map |
| Subreddit index (4-10 subreddits) | ~1 KB | subreddit → posts Map |
| File metadata | ~1 KB | fileName → file info Map |
| Individual content lookup | ~15 KB | one line from JSONL file |
| **Total** | **~56 MB** | Well within browser limits |

### 12.3 Disk Usage

| Component | Disk | Notes |
|-----------|------|-------|
| JSONL files (user-provided) | 2.9 GB | On user's disk, in "jsonl" folder |
| IndexedDB (handles + caches) | ~50 MB | Folder handles, chapter cache, scores |
| Server filesystem (data dir) | ~100 MB | Chapter cache, scores, user chapters |
| **Total additional** | **~150 MB** | (excluding user's JSONL files) |

---

## PART 13: FILE REPLACEMENT & MULTI-SUBREDDIT SUPPORT

### 13.1 File Replacement Flow

1. User removes old `r_hfy_posts.jsonl` from the "jsonl" folder
2. User puts new `r_hfy_posts.jsonl` (updated dump) in the folder
3. On next startup or manual "RE-INDEX":
   - Scan folder for `.jsonl` files
   - Compare file size and lastModified with `__jsonlFiles` metadata
   - Detect that `r_hfy_posts.jsonl` has changed (different size or date)
   - Remove all index entries where `fileName === "r_hfy_posts.jsonl"`
   - Decrement author and subreddit counts for removed posts
   - Re-index the new file (stream-parse, add to index)
   - Re-run score pre-loading (scores may have changed)
   - Re-run chain building (new chapters may have been added)

### 13.2 Adding New Subreddit JSONL Files

1. User adds `r_nosleep_posts.jsonl` to the "jsonl" folder
2. On next startup or manual "RE-INDEX":
   - Detect new file (not in `__jsonlFiles`)
   - Index it alongside existing files
   - New subreddit appears in Archive tab filter
   - New authors appear in Author Browser
   - New series are detected by auto-detect
   - Any cross-subreddit links are followed during chain building

### 13.3 Removing JSONL Files

1. User removes `r_TheCryopodToHell_posts.jsonl` from the folder
2. On next startup or manual "RE-INDEX":
   - Detect that the file is no longer in the folder
   - Remove all index entries where `fileName === "r_TheCryopodToHell_posts.jsonl"`
   - Remove from `__jsonlFiles`
   - Decrement author and subreddit counts
   - Any chapters that were ONLY available from this file will now fall back to Arctic Shift

**Important:** Chapters that were previously C-FETCHED from JSONL and cached to IndexedDB/server remain available even after the JSONL file is removed. The JSONL is the source, but the cache is permanent.

---

## PART 14: IMPLEMENTATION ORDER

### Phase 1: Foundation (folder access + indexing engine)
1. Add "jsonl" folder type to `file-saver-utils.ts`
2. Create `jsonl-index.ts` module with indexing engine
3. Add Settings card "SUBREDDIT JSONL DATA"
4. Add icons to `public/` (`icon-archive.png`, `icon-discovered.png`)

### Phase 2: Content Fetching (JSONL as primary)
5. Add `getJsonlPostContent()` function
6. Modify `fetchPostContent` in `4034.js` — add JSONL check as Strategy -1
7. Run score pre-loading after indexing
8. Run metadata enrichment (fill missing fields)

### Phase 3: Chapter Discovery
9. Modify `searchSeries` in `4034.js` — add JSONL local search
10. Modify `fetch-missing` route — add JSONL gap filling
11. Add chapter chain building from JSONL
12. Add PostId matching for missing chapters

### Phase 4: New Tabs
13. Add `archive` and `discovered` screens to `useNav` store
14. Add Archive and Discovered Series buttons to bottom navigation bar
15. Build Archive tab (post list, filters, pagination)
16. Build Author Browser sub-component
17. Build post card component
18. Build full post view component
19. Build Discovered Series tab (auto-detect, series cards)
20. Add "Add to Series" / "Create Custom Series" functionality

### Phase 5: Download & Merge
21. Add "Cache All from JSONL" button to series detail page
22. Verify instant merge works (transparent via fetchPostContent)

### Phase 6: Persistence Audit
23. Audit all persistence paths
24. Test: add chapters → restart → verify chapters persist
25. Test: create custom series → restart → verify series persists
26. Test: C-FETCH → restart → verify scores and content persist
27. Test: merge → delete merge → leave → return → verify no stale state

### Phase 7: File Replacement Testing
28. Test: replace JSONL file → re-index → verify updated content
29. Test: remove JSONL file → verify clean index
30. Test: add new subreddit JSONL → verify multi-file index




---

*End of JSONL Integration Master Plan*
