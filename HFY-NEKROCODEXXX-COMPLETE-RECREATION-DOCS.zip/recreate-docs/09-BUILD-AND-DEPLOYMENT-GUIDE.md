# HFY NEKROCODEXXX — Build and Deployment Guide

**Version:** FX45 v31

This document provides comprehensive instructions for building, packaging, and deploying the HFY NEKROCODEXXX application on Windows, Android, and web platforms.

---

## FX43 Complete Build Manual

The following is the complete build manual from FX43 v9, which covers all aspects of building, deploying, and troubleshooting the application.

# HFY NEKROCODEXXX — Complete Build Manual & Documentation

**Version:** FX43 v9  
**Build Date:** 2026-07-23  
**Platform:** Windows (standalone Node.js bundle)  
**Author:** Mahmudul Hossain  
**Documentation Version:** 1.0

---

## TABLE OF CONTENTS

1. [Introduction](#1-introduction)
2. [What Is HFY NEKROCODEXXX?](#2-what-is-hfy-nekrocodexxx)
3. [App Architecture Overview](#3-app-architecture-overview)
4. [Technology Stack](#4-technology-stack)
5. [Project Structure](#5-project-structure)
6. [Prerequisites](#6-prerequisites)
7. [Step-by-Step Build Guide](#7-step-by-step-build-guide)
8. [Source Code Structure](#8-source-code-structure)
9. [Server-Side Code](#9-server-side-code)
10. [Client-Side Code](#10-client-side-code)
11. [API Reference](#11-api-reference)
12. [Zustand Stores](#12-zustand-stores)
13. [React Components](#13-react-components)
14. [C-Fetch System](#14-c-fetch-system)
15. [Download Queue System](#15-download-queue-system)
16. [Reddit Scraping Pipeline](#16-reddit-scraping-pipeline)
17. [CORS Proxy Pool](#17-cors-proxy-pool)
18. [Service Worker](#18-service-worker)
19. [Data Storage](#19-data-storage)
20. [Themes & Customization](#20-themes-customization)
21. [Reader Features](#21-reader-features)
22. [Auto-Discover System](#22-auto-discover-system)
23. [IP Display Feature](#23-ip-display-feature)
24. [Hosting & Deployment](#24-hosting-deployment)
25. [Bug Fix History](#25-bug-fix-history)
26. [Troubleshooting](#26-troubleshooting)
27. [Configuration Reference](#27-configuration-reference)
28. [Security Considerations](#28-security-considerations)
29. [Performance Optimization](#29-performance-optimization)
30. [Future Enhancements](#30-future-enhancements)
31. [Appendix A: Complete File Inventory](#appendix-a-complete-file-inventory)
32. [Appendix B: All API Endpoints](#appendix-b-all-api-endpoints)
33. [Appendix C: Theme Reference](#appendix-c-theme-reference)

---

## 1. Introduction

This document is a comprehensive manual for building, understanding, and deploying the HFY NEKROCODEXXX application. It covers every aspect of the application from the high-level architecture down to individual function implementations. Whether you are a developer looking to modify the codebase, a user wanting to understand how the app works, or an administrator deploying it for others to use, this manual provides the complete reference.

The HFY NEKROCODEXXX application is a sophisticated web-based reader and downloader for the r/HFY (Humanity, Fuck Yeah!) subreddit's creative writing community. It allows users to browse thousands of science fiction story series, read individual chapters, download them as EPUB files, and cache content for offline reading. The app features a cyberpunk-themed UI with neon aesthetics, multiple theme options, a powerful search system, and an intelligent multi-tier Reddit scraping pipeline that can fetch content even when Reddit rate-limits direct access.

This manual documents the FX43 v9 build, which represents the culmination of 43 iterative releases (FX1 through FX43), each adding features, fixing bugs, and improving stability. The app is built as a Next.js 16 standalone production bundle, meaning it can be run on any Windows machine with Node.js without requiring a build step — simply extract and run.

---

## 2. What Is HFY NEKROCODEXXX?

HFY NEKROCODEXXX is a self-hosted web application designed specifically for the r/HFY subreddit community. The r/HFY subreddit is a popular creative writing community where authors post science fiction stories, typically featuring humanity as a powerful, competent, or inspiring force in a universe full of alien species. These stories are organized into "series" — multi-chapter narratives that can range from a few chapters to hundreds of chapters spanning months or years of writing.

### What the App Does

The app serves as a dedicated reader and content manager for these HFY series. Its primary functions include:

**Browsing Series:** The app ships with a hardcoded catalog of 5,533 HFY series, each with metadata including title, author, wiki URL, HFY Foundation URL, and chapter count. Users can browse this catalog, sort by various criteria (newest, score, chapter count, alphabetical), and search for specific series by name.

**Reading Chapters:** Once a series is selected, the app displays its chapter list. Users can click any chapter to read it in a full-featured reader with customizable fonts, themes, text sizes, line heights, and background images. The reader supports chapter navigation (previous/next), bookmarking, and preload-ahead for smooth reading.

**Downloading Content:** Users can download individual chapters as EPUB files or merge all chapters into a single EPUB file. The app supports batch downloads with parallel fetching, retry logic for failed chapters, and progress tracking via a download queue.

**C-Fetch (Content Fetch):** The app's signature feature is "C-Fetch" — a system for pre-fetching chapter content (body text + upvote scores) from Reddit and caching it locally. This makes reading faster (content loads instantly from cache instead of hitting Reddit) and enables offline reading. C-Fetch operates in two modes: Rehash (re-fetch all chapters in a series) and Continue (fetch only unfetched chapters, then stop).

**Multi-Tier Scraping:** Reddit aggressively rate-limits API access. The app implements an 8-tier scraping cascade that tries multiple methods in order: user OAuth (600 QPM), app OAuth (100 QPM), authless JSON, CORS proxy pool (386 proxies), RSS feeds (always available), Wayback Machine archives, HFY Foundation index, and Reddit search. This ensures content can always be fetched even under heavy rate limiting.

**Auto-Discover:** For series with incomplete chapter lists, the app can automatically discover missing chapters by crawling Reddit, Wayback Machine, HFY Foundation, and performing Reddit searches. This uses a configurable multi-stage pipeline with resume capability.

**Library Management:** Users can add series to their personal library for quick access. The library tracks reading progress, favorited series, downloaded chapters, and merged files. Library data persists across sessions via localStorage, IndexedDB, and server-side storage (for Android restart survival).

**Queue System:** All long-running operations (downloads, C-Fetch) appear in a unified queue with progress bars, status indicators (WAIT/ACTIVE/PAUSE/OK/FAIL), and STOP buttons. The queue processes one job at a time per series, preventing resource exhaustion.

### Who Is It For?

The app is designed for:
- **HFY fans** who want a dedicated reader with offline capability
- **Mobile users** (Android via APK or PWA) who need cached content for reading on the go
- **Power users** who want to download entire series as EPUB files
- **Community members** who want to discover new chapters in ongoing series
- **Self-hosters** who want to run their own reader instance accessible from any device

---

## 3. App Architecture Overview

The app follows a client-server architecture within a single Node.js process:

```
┌─────────────────────────────────────────────────────┐
│                    User's Browser                     │
│                                                       │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────┐ │
│  │  Browse Tab  │  │  Series     │  │   Reader     │ │
│  │              │  │  Detail Tab │  │   Screen     │ │
│  │  - Series    │  │             │  │              │ │
│  │    cards     │  │  - Chapter  │  │  - Custom    │ │
│  │  - Sort      │  │    list     │  │    themes    │ │
│  │  - Search    │  │  - C-Fetch  │  │  - Font size │ │
│  │  - IP display │  │  - Download │  │  - Preload   │ │
│  └──────┬───────┘  └──────┬──────┘  └──────┬───────┘ │
│         │                  │                  │       │
│  ┌──────┴──────────────────┴──────────────────┴────┐ │
│  │              Zustand Stores (State)              │ │
│  │  useBrowseCache │ useLibrary │ useDownloads │     │ │
│  │  useSettings │ useSeriesScores │ useNav │        │ │
│  └──────────────────────┬──────────────────────────┘ │
│                         │                             │
│  ┌──────────────────────┴──────────────────────────┐ │
│  │           IndexedDB + localStorage               │ │
│  │  Chapter cache │ Series cache │ Scores │         │ │
│  └──────────────────────┬──────────────────────────┘ │
└─────────────────────────┼───────────────────────────┘
                          │ HTTP (fetch API)
┌─────────────────────────┼───────────────────────────┐
│                    Node.js Server                     │
│                         │                             │
│  ┌──────────────────────┴──────────────────────────┐ │
│  │            Next.js 16 (Standalone)               │ │
│  │                                                  │ │
│  │  ┌──────────────────────────────────────────┐   │ │
│  │  │           41 API Route Handlers           │   │ │
│  │  │                                          │   │ │
│  │  │  /api/series      /api/download          │   │ │
│  │  │  /api/store       /api/chapter-cache     │   │ │
│  │  │  /api/proxy-browser  /api/reddit-*       │   │ │
│  │  │  /api/auto-discover  /api/crawl          │   │ │
│  │  │  ... (32 more)                          │   │ │
│  │  └──────────────────────────────────────────┘   │ │
│  └──────────────────────────────────────────────────┘ │
│                         │                             │
│  ┌──────────────────────┴──────────────────────────┐ │
│  │            File System (data/)                   │ │
│  │  app-store/ │ chapter-cache/ │ user-chapters/   │ │
│  └──────────────────────────────────────────────────┘ │
│                         │                             │
│  ┌──────────────────────┴──────────────────────────┐ │
│  │         Reddit API (via 8-tier cascade)          │ │
│  │  OAuth │ JSON │ CORS Proxy │ RSS │ Wayback │     │ │
│  └──────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────┘
```

### Key Design Decisions

**Single-Process Architecture:** The entire app runs in a single Node.js process. Next.js handles both serving static assets and API routes. This simplifies deployment — no separate frontend/backend servers needed.

**Standalone Build:** The app is built with `output: "standalone"` in Next.js config, which bundles everything needed (including node_modules) into a single portable directory. This means the app can be run on any Windows machine with the bundled `node.exe` — no installation required.

**Client-Heavy Architecture:** Most logic runs in the browser. The server primarily acts as a proxy to Reddit (bypassing CORS), a file system for persistent storage, and an OAuth token manager. State management is entirely client-side via Zustand stores.

**Module-Level State for Background Tasks:** C-Fetch operations use `moduleFetchState` (a module-level object) rather than React state, so they survive tab switches. The polling effect syncs module-level state to React state for UI updates.

**Multi-Storage Persistence:** Data is stored in three layers: localStorage (fast, synchronous, limited size), IndexedDB (async, larger capacity, structured data), and server filesystem (survives Android WebView restarts where localStorage is cleared). All writes go to all three layers; reads check localStorage first, then IDB, then server.

---

## 4. Technology Stack

### Frontend
- **React 19** — UI library
- **Next.js 16** — React framework (app router, standalone output)
- **Zustand 5** — State management (7 stores)
- **Framer Motion 12** — Animations
- **Tailwind CSS 4** — Styling
- **Radix UI** — Accessible components (dialogs, dropdowns, etc.)
- **Lucide React** — Icon library
- **Sonner** — Toast notifications
- **react-syntax-highlighter** — Code rendering in reader

### Backend
- **Node.js** — JavaScript runtime (bundled v24 for Windows)
- **Next.js 16 API Routes** — 41 REST endpoints
- **puppeteer-core** — Headless Chrome for Reddit cookie capture
- **socket.io-client** — WebSocket for crawl progress streaming

### Data Storage
- **Filesystem** — JSON files for persistent storage (app-store/, chapter-cache/, user-chapters/)
- **IndexedDB** — Browser-side structured storage for chapter content and series caches
- **localStorage** — Browser-side key-value storage for settings, scores, and flags
- **Cookies** — Backup storage for chapter scores (4KB limit, survives some Android restarts)

### External Services
- **Reddit API** — Content source (OAuth, JSON, RSS endpoints)
- **HFY Foundation** — Community-maintained series index (hfy.foundation)
- **Wayback Machine** — Archived Reddit snapshots (web.archive.org)
- **CORS Proxy Pool** — 386 community-maintained proxy servers for bypassing CORS
- **ipify.org** — Public IP detection for the IP display feature

### Build Tools
- **TypeScript** — Type safety (with `ignoreBuildErrors: true` for standalone build)
- **SWC** — Rust-based JavaScript/TypeScript compiler
- **Webpack** — Module bundler (via Next.js)
- **Turbopack** — Next.js development bundler (not used in production)

---

## 5. Project Structure

```
HFY-NEKROCODEX-Windows-FX43/
├── node/                           # Bundled Node.js runtime
│   ├── node.exe                    # Node.js v24 for Windows
│   ├── npm                         # npm wrapper
│   ├── npx                         # npx wrapper
│   └── ...
├── server/                         # Application server
│   ├── server.js                   # Entry point (starts Next.js)
│   ├── aggregate-counts.js         # Background count aggregation
│   ├── package.json                # Dependencies & scripts
│   ├── public/                     # Static assets
│   │   ├── sw.js                   # Service worker
│   │   ├── manifest.json           # PWA manifest
│   │   ├── icon-192.png            # App icon (192x192)
│   │   ├── icon-512.png            # App icon (512x512)
│   │   ├── rehash-c-fetch.png      # Rehash button icon
│   │   ├── continue-c-fetch.png    # Continue button icon
│   │   ├── bg-images/              # 48 background images (cyber/stellaris/user)
│   │   └── ...
│   ├── data/                       # Persistent data storage
│   │   ├── app-store/              # Key-value JSON store
│   │   │   ├── hfy-nekrocodexxx-library.json
│   │   │   ├── hfy-nekrocodexxx-downloads.json
│   │   │   ├── hfy-nekrocodexxx-settings.json
│   │   │   ├── hfy-chapter-counts.json
│   │   │   ├── hfy-downloaded-counts.json
│   │   │   ├── hfy-scores-*.json
│   │   │   └── ...
│   │   ├── chapter-cache/          # Cached chapter content (~270 files)
│   │   │   ├── abc123.json
│   │   │   ├── def456.json
│   │   │   └── ...
│   │   └── user-chapters/          # User-discovered chapters
│   │       └── series_slug.json
│   ├── .next/                      # Next.js build output
│   │   ├── static/                 # Client-side bundles
│   │   │   └── chunks/
│   │   │       ├── app/
│   │   │       │   ├── page-94aba2608e3f02d1.js  # Main bundle (2.4MB)
│   │   │       │   └── layout-b5e5154b30604d87.js
│   │   │       ├── 9365-*.js        # Zustand stores chunk
│   │   │       ├── 6609-*.js        # Sonner toast chunk
│   │   │       ├── 8697.*.js        # Hardcoded series data (475K lines)
│   │   │       └── ...
│   │   └── server/                  # Server-side bundles
│   │       └── app/api/            # 41 API route handlers
│   │           ├── series/
│   │           ├── store/
│   │           ├── chapter-cache/
│   │           ├── download/
│   │           ├── proxy-browser/
│   │           └── ...
│   └── node_modules/               # Dependencies (~93MB)
│       ├── next/
│       ├── react/
│       ├── react-dom/
│       ├── zustand/
│       ├── puppeteer-core/
│       └── ...
├── start.bat                       # Windows start script
└── stop.bat                        # Windows stop script
```

---

## 6. Prerequisites

### For Running the Pre-Built Bundle (Windows)

- **Windows 7 or later** (64-bit)
- **No installation required** — Node.js is bundled in the `node/` directory
- **Network access** — The app fetches content from Reddit, HFY Foundation, and Wayback Machine
- **Port 3000** available (or set custom PORT env var)
- **~300MB disk space** for the extracted bundle

### For Building from Source

- **Node.js 18+** (for running Next.js build)
- **npm** or **bun** package manager
- **~2GB disk space** for node_modules
- **TypeScript 5+** (optional, `ignoreBuildErrors` is enabled)

### For Android APK Build (Optional)

- **Android Studio** with SDK
- **Capacitor 8** (for Android wrapper)
- **Java 17+** (for Android build)

### For Internet Hosting

- **Router with port forwarding capability**
- **Public IP address** (dynamic is OK — the app displays the current IP)
- **Windows Firewall** allowing inbound TCP on port 3000 (or custom port)

---

## 7. Step-by-Step Build Guide

### Option A: Using the Pre-Built Bundle (Recommended)

1. **Download** the `HFY-NEKROCODEX-Windows-FX43.zip` file (281MB)
2. **Extract** the zip to any directory (e.g., `C:\HFY\`)
3. **Run** `start.bat` by double-clicking
4. **Open** `http://localhost:3000` in your browser
5. **Done!** The app is ready to use

### Option B: Building from Source

#### Step 1: Clone the Source Repository

```bash
git clone <repository-url> hfy-nekrocodex
cd hfy-nekrocodex
```

#### Step 2: Install Dependencies

```bash
npm install
# or
bun install
```

This installs ~500 packages including Next.js, React, Zustand, Radix UI, Framer Motion, Tailwind CSS, puppeteer-core, and all other dependencies listed in `package.json`.

#### Step 3: Configure Next.js

Create or edit `next.config.ts`:

```typescript
import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  output: 'standalone',          // Bundle everything for portable deployment
  typescript: {
    ignoreBuildErrors: true,     // Allow build even with TS errors
  },
  experimental: {
    optimizePackageImports: [
      'lucide-react', 'date-fns', 'lodash-es', 'ramda',
      // ... (30+ packages for tree-shaking optimization)
    ],
  },
  images: {
    unoptimized: true,           // No server-side image optimization
  },
};

export default nextConfig;
```

#### Step 4: Define the Series Catalog

The app ships with a hardcoded catalog of 5,533 HFY series. This is defined in `src/lib/hfy-data.ts`:

```typescript
const REAL_SERIES = [
  {
    id: "10_mistakes_to_kill_the_universe",
    title: "10 Mistakes to Kill the Universe",
    author: "Drakenwing",
    wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/10_mistakes_to_kill_the_universe",
    hfyFoundationUrl: "https://hfy.foundation/series/947",
    chapterCount: 6
  },
  // ... 5,532 more entries
];
```

This catalog is auto-generated from the r/HFY wiki and the HFY Foundation index. To regenerate it, run the wiki scraper (not included in the build — it's a separate utility script).

#### Step 5: Define Hardcoded Chapters

For each series, the app has a hardcoded chapter list in `src/lib/hfy-hardcoded-chapters.ts`:

```typescript
const HARDCODED_SERIES = {
  "zyz": {
    title: "Zyz",
    wikiUrl: "https://www.reddit.com/r/hfy/wiki/series/zyz",
    chapters: [
      {
        title: "Zyz Translocation",
        url: "https://www.reddit.com/r/HFY/comments/ciqsdj/zyz_translocation/",
        postId: "ciqsdj",
        chapterNumber: 1
      },
      // ... more chapters
    ]
  },
  // ... more series
};
```

This data is baked into the client bundle (chunk 8697, ~475K lines) so it's available instantly without network requests.

#### Step 6: Build the Production Bundle

```bash
npm run build
# or
bun run build
```

This runs `next build` which:
1. Compiles all TypeScript/JavaScript
2. Bundles client-side code into webpack chunks
3. Compiles server-side API routes
4. Outputs to `.next/standalone/` directory

The build script in `package.json`:
```json
{
  "scripts": {
    "build": "next build && cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/"
  }
}
```

This copies the static assets and public files into the standalone directory.

#### Step 7: Create the Standalone Server

The `server.js` entry point:

```javascript
process.env.NODE_ENV = 'production';
const path = require('path');
const dir = __dirname;
process.chdir(__dirname);

const currentPort = parseInt(process.env.PORT, 10) || 3000;
const hostname = process.env.HOSTNAME || '127.0.0.1';

// ... nextConfig (large JSON object)

process.env.__NEXT_PRIVATE_STANDALONE_CONFIG = JSON.stringify(nextConfig);

require('next');
const { startServer } = require('next/dist/server/lib/start-server');

startServer({
  dir,
  isDev: false,
  config: nextConfig,
  hostname,
  port: currentPort,
  allowRetry: false,
}).then(() => {
  try { require('./aggregate-counts.js'); } catch (e) { console.error('[aggregate] Failed:', e.message); }
}).catch((err) => {
  console.error("[server error]", err);
  process.exit(1);
});

// Single set of error handlers
process.on('uncaughtException', (err) => {
    console.error('[uncaughtException]', err?.message || String(err));
});
process.on('unhandledRejection', (reason, promise) => {
    console.error('[unhandledRejection]', reason?.message || String(reason));
});
```

#### Step 8: Bundle Node.js

For the Windows distribution, bundle the Node.js binary:

1. Download Node.js v24 for Windows (node.exe)
2. Place it in the `node/` directory alongside `server/`
3. Create `start.bat` and `stop.bat` scripts

#### Step 9: Create start.bat

```bat
@echo off
title HFY-NEKRO-Server
setlocal
set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"
set "NODE_EXE=%APP_DIR%\node\node.exe"
set "SERVER_DIR=%APP_DIR%\server"
if not defined PORT set "PORT=3000"
set "URL=http://localhost:%PORT%"
if not exist "%NODE_EXE%" (echo Node.js not found & pause & exit /b 1)
if not exist "%SERVER_DIR%\server.js" (echo Server not found & pause & exit /b 1)
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr /C:":%PORT% " ^| findstr "LISTENING"') do (taskkill /F /PID %%a >nul 2>&1)
taskkill /FI "WINDOWTITLE eq HFY-NEKRO-Server*" /F >nul 2>&1
set "NODE_ENV=production"
set "HOSTNAME=0.0.0.0"
echo ========================================
echo   HFY NEKROCODEXXX - Server Starting...
echo ========================================
echo   URL: http://localhost:%PORT%
echo   Network: http://[YOUR-PC-IP]:%PORT%
echo ========================================
echo.
echo Server log (this window must stay open):
echo.
"%NODE_EXE%" "%SERVER_DIR%\server.js"
```

#### Step 10: Create stop.bat

```bat
@echo off
setlocal
if not defined PORT set "PORT=3000"
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr /C:":%PORT% " ^| findstr "LISTENING"') do (taskkill /F /PID %%a >nul 2>&1)
echo Stopped.
timeout /t 2 /nobreak >nul
exit /b 0
```

#### Step 11: Package the Distribution

```bash
cd standalone
zip -0 -r HFY-NEKROCODEX-Windows-FX43.zip node/ server/ start.bat stop.bat
```

The `-0` flag stores files without compression (the originals use this format, keeping the zip at ~281MB).

#### Step 12: Test the Build

1. Extract the zip to a test directory
2. Run `start.bat`
3. Open `http://localhost:3000` in a browser
4. Verify:
   - Browse tab loads 5,533 series
   - Series detail shows chapters
   - C-Fetch buttons create queue jobs
   - STOP button aborts operations
   - Download queue shows progress
   - All 4 tabs work (Browse, Library, Queue, Settings)
   - IP display shows current public IP

---

## 8. Source Code Structure

The source code is organized into the following structure (before compilation):

```
src/
├── app/                           # Next.js App Router
│   ├── layout.tsx                 # Root layout
│   ├── page.tsx                   # Main page (renders all screens)
│   ├── reddit-callback/
│   │   └── page.tsx               # OAuth callback handler
│   └── api/                       # API Route Handlers
│       ├── series/
│       │   ├── route.ts           # GET /api/series
│       │   └── [slug]/
│       │       ├── route.ts       # GET /api/series/[slug]
│       │       ├── chapters/route.ts
│       │       ├── continue-fetch/route.ts
│       │       ├── fetch-cache/route.ts
│       │       ├── detect-gaps/route.ts
│       │       ├── fetch-missing/route.ts
│       │       ├── reparse/route.ts
│       │       └── add-chapter/route.ts
│       ├── store/
│       │   └── [key]/route.ts     # Generic key-value store
│       ├── chapter-cache/
│       │   └── [postId]/route.ts  # Chapter content cache
│       ├── chapter/
│       │   └── [id]/route.ts      # Single chapter fetch
│       ├── download/route.ts      # Batch chapter download
│       ├── crawl/route.ts         # Wiki page crawler
│       ├── proxy-browser/route.ts # Headless browser proxy
│       ├── proxy-stats/route.ts   # Proxy pool statistics
│       ├── reddit-app-token/route.ts
│       ├── reddit-auth/route.ts
│       ├── reddit-cookies/route.ts
│       ├── reddit-multi-token/route.ts
│       ├── reddit-password-login/route.ts
│       ├── reddit-token/route.ts
│       ├── reddit-user-token/route.ts
│       ├── reddit-logout/route.ts
│       ├── browser-session/route.ts
│       ├── auto-discover/
│       │   ├── route.ts           # Start auto-discover job
│       │   └── [jobId]/route.ts   # Poll job status
│       ├── fetch-all-posts/route.ts
│       ├── hardcoded-chapters/
│       │   └── [slug]/route.ts
│       ├── hfy-foundation-search/route.ts
│       ├── live-wiki/route.ts
│       ├── mass-import/route.ts
│       ├── purge-cache/route.ts
│       ├── search/route.ts
│       ├── search-series/route.ts
│       ├── store-scores-all/route.ts
│       ├── store-chapter-counts-all/route.ts
│       ├── store-downloaded-all/route.ts
│       ├── sync-version/route.ts
│       ├── wayback-sync/route.ts
│       └── route.ts               # API root
├── components/
│   ├── screens/
│   │   ├── BrowseScreen.tsx       # Series browse tab
│   │   ├── SeriesDetailScreen.tsx # Series detail + chapters
│   │   ├── ReaderScreen.tsx       # Chapter reader
│   │   ├── QueueScreen.tsx        # Download/C-Fetch queue
│   │   ├── LibraryScreen.tsx      # User's library
│   │   └── SettingsScreen.tsx     # Settings panel
│   ├── UnifiedSeriesCard.tsx      # Series card component
│   ├── LibrarySeriesCard.tsx      # Library series card
│   ├── AppHeader.tsx              # Top header bar
│   ├── CyberButton.tsx            # Themed button
│   ├── CyberPanel.tsx             # Themed panel
│   ├── CyberProgress.tsx          # Progress bar
│   ├── IPDisplay.tsx              # IP address display
│   ├── CustomSeriesAdder.tsx      # Add custom series dialog
│   └── ... (30+ more components)
├── lib/
│   ├── hfy-data.ts                # 5,533 series catalog
│   ├── hfy-hardcoded-chapters.ts  # Hardcoded chapter lists
│   ├── reddit-scraper.ts          # Multi-tier Reddit scraper
│   ├── cors-proxies.ts            # CORS proxy pool manager
│   ├── user-chapters.ts           # User chapter storage
│   ├── idb-cache.ts               # IndexedDB helpers
│   ├── file-saver-utils.ts        # File save utilities
│   ├── epub-generator.ts          # EPUB file generator
│   ├── wayback-scraper.ts         # Wayback Machine scraper
│   ├── hfy-foundation.ts          # HFY Foundation API client
│   └── ...
├── stores/
│   ├── useBrowseCache.ts          # Browse tab cache store
│   ├── useLibrary.ts              # User library store
│   ├── useDownloads.ts            # Download queue store
│   ├── useSettings.ts             # Settings store
│   ├── useSeriesScores.ts         # Series upvote scores store
│   ├── useNav.ts                  # Navigation store
│   ├── useUrlOverrides.ts         # URL override store
│   ├── useChapterUrlOverrides.ts  # Chapter URL override store
│   └── useRedditAuth.ts           # Reddit auth store
└── styles/
    └── globals.css                # Global styles + Tailwind
```

---

## 9. Server-Side Code

### server.js

The entry point for the standalone Node.js server. Its responsibilities:

1. **Set NODE_ENV to 'production'** — This is the very first line, ensuring all modules see the correct environment.
2. **Configure Next.js** — Passes the large `nextConfig` JSON object (compiled from `next.config.ts`).
3. **Start the server** — Calls `startServer()` from Next.js's internal modules.
4. **Start aggregation** — After the server starts, requires `aggregate-counts.js` which begins background count aggregation.
5. **Error handlers** — Registers `uncaughtException` and `unhandledRejection` handlers to prevent crashes.

Key configuration in `nextConfig`:
- `output: "standalone"` — Bundles everything for portable deployment
- `cacheMaxMemorySize: 52428800` — 50MB in-memory cache
- `compress: true` — Enable gzip compression
- `images.unoptimized: true` — No server-side image processing
- `experimental.optimizePackageImports` — Tree-shaking for 30+ icon/utility libraries
- `experimental.preloadEntriesOnStart: true` — Preload route handlers on startup

### aggregate-counts.js

A background script that runs every 60 seconds to aggregate counts from the filesystem:

1. **Downloaded counts** — Reads all `hfy-downloaded-*.json` files in `app-store/`, counts the array length in each, and stores the result in `hfy-downloaded-counts.json`.
2. **Chapter counts** — Reads all `.json` files in `user-chapters/`, counts the `chapters` array length, and stores in `hfy-chapter-counts.json`.
3. **Chapter cache total** — Counts `.json` files in `chapter-cache/` directory and adds as `__chapterCacheTotal` key.

Key features:
- **isRunning guard** — Prevents concurrent runs if the previous run takes >60s.
- **unref timers** — `setTimeout` and `setInterval` are `.unref()`'d so they don't block process shutdown.
- **Parallel POSTs** — Uses `Promise.all` to send both count files to the store API simultaneously.
- **res.on('error')** — Handles response stream errors to prevent promise hangs.
- **Excludes own output** — The regex explicitly excludes `hfy-downloaded-counts.json` to prevent reading its own output.

### public/sw.js

The service worker provides offline capability:

1. **Install** — Pre-caches static assets (`/`, `/manifest.json`, `/icon-192.png`, `/icon-512.png`) using `Promise.allSettled` (non-atomic — one failure doesn't block install).
2. **Activate** — Deletes old caches with different `CACHE_NAME` versions.
3. **Fetch handler** — Two strategies:
   - **Cache-first** for static assets (images, CSS, JS, fonts) — Try cache, fall back to network, cache the response.
   - **Network-first** for documents (HTML pages) — Try network first, fall back to cache, then cached `/` for documents only (returns 504 for non-document requests to avoid serving HTML for JS/CSS).

Key fixes in FX43:
- `cache.addAll` → `Promise.allSettled` with individual catches (non-atomic install)
- `cache.put` has `.catch(() => {})` to prevent unhandled rejections
- Offline fallback returns `new Response('Offline', { status: 503 })` instead of `undefined`
- `skipWaiting()` and `clients.claim()` called inside `event.waitUntil()`

---

## 10. Client-Side Code

The entire client-side codebase is bundled into a single 2.4MB JavaScript file (`page-94aba2608e3f02d1.js`). This file contains all React components, Zustand stores, utility functions, and the hardcoded series catalog.

### Main Bundle Structure

The bundle is organized into the following sections (by line number):

- **Lines 1-900:** Utility functions (hashing, ID normalization, accent color generation)
- **Lines 900-44000:** Data definitions (5,533 series, hardcoded chapters, HFY Foundation mappings)
- **Lines 44000-44600:** Helper functions (getDownloadedCount, IPDisplay component)
- **Lines 44600-45100:** BrowseScreen component (series browsing, sort, search, C-Fetch buttons)
- **Lines 45100-45600:** UnifiedSeriesCard component (series card rendering)
- **Lines 45600-47000:** SeriesDetailScreen component (chapter list, C-Fetch, downloads)
- **Lines 47000-48000:** Series detail utilities (URL overrides, score loading, chapter loading)
- **Lines 48000-49600:** C-Fetch implementation (Rehash, Continue, module-level state)
- **Lines 49600-50200:** Download implementation (batch fetch, EPUB generation, file save)
- **Lines 50200-51000:** Series detail UI (buttons, crawl options, auto-discover)
- **Lines 51000-52000:** Reader screen (chapter display, navigation, settings)
- **Lines 52000-54000:** Reader utilities (text processing, markdown stripping, bookmarks)
- **Lines 54000-56000:** Library screen (series cards, filters, sort)
- **Lines 56000-57000:** Library card component, queue screen
- **Lines 57000-58000:** Queue screen, settings screen (themes, fonts, Reddit auth)
- **Lines 58000-59000:** Settings screen (CORS proxies, folders, cookies, auto-update)
- **Lines 59000-60000:** Custom components (CustomSeriesAdder, font picker, etc.)
- **Lines 60000-64000:** App root (layout, navigation, screen routing, toasts)

### Key Module-Level State

The `moduleFetchState` object survives tab switches:

```javascript
const moduleFetchState = {
    rehashRunning: false,       // Is Rehash C-Fetch currently running?
    rehashAbort: false,         // Should Rehash abort?
    continueRunning: false,     // Is Continue C-Fetch running?
    continueAbort: false,       // Should Continue abort?
    rehashProgress: null,       // { done, total, fetched, changed, errors }
    continueProgress: null,     // { discovered, fetched, errors }
    activeFetchSeries: null,    // Which series is being fetched?
    rehashAbortController: null,// AbortController for fetch abort
    continueAbortController: null,
    rehashJobId: null,          // Queue job ID for Rehash
    continueJobId: null         // Queue job ID for Continue
};
```

This is critical for the C-Fetch feature — when a user switches tabs during a C-Fetch, the fetch continues in the background. When they return, the polling effect syncs `moduleFetchState` back to React state for UI updates.

### Browse-Tab C-Fetch State

The browse-tab C-Fetch uses `window.__hfy*` variables for the same purpose:

```javascript
window.__hfyRehashRunning       // Is browse Rehash running?
window.__hfyRehashAbort          // Should it abort?
window.__hfyRehashProgress       // { current, total, status, fetched, errors }
window.__hfyRehashSeriesList     // [{ title, id, total, done, fetched, errors, status }]
window.__hfyRehashAbortController // AbortController
window.__hfyContinueRunning      // Is browse Continue running?
window.__hfyContinueAbort
window.__hfyContinueProgress
window.__hfyContinueSeriesList
window.__hfyContinueAbortController
```

---

## 11. API Reference

The app exposes 41 API endpoints. Here's a comprehensive reference:

### Series Endpoints

#### GET /api/series
Fetches the series index (5,533 series with metadata).

**Response:**
```json
{
  "ok": true,
  "source": "baked",
  "count": 5533,
  "series": [
    {
      "id": "10_mistakes_to_kill_the_universe",
      "title": "10 Mistakes to Kill the Universe",
      "author": "Drakenwing",
      "wikiUrl": "https://www.reddit.com/r/hfy/wiki/series/...",
      "hfyFoundationUrl": "https://hfy.foundation/series/947",
      "chapterCount": 6
    }
  ]
}
```

#### GET /api/series/[slug]
Fetches series detail by slug. Returns 404 if not found in REAL_SERIES.

#### GET /api/hardcoded-chapters/[slug]
Returns the hardcoded chapter list for a series.

**Response:**
```json
{
  "ok": true,
  "title": "Zyz",
  "chapters": [
    {
      "title": "Zyz Translocation",
      "url": "https://www.reddit.com/r/HFY/comments/ciqsdj/...",
      "postId": "ciqsdj",
      "chapterNumber": 1
    }
  ]
}
```

#### POST /api/series/[slug]/fetch-cache
Streams chapter content via NDJSON. Fetches body text + upvote score for provided chapters.

**Request:**
```json
{
  "chapters": [
    { "id": "ciqsdj", "url": "https://www.reddit.com/r/HFY/comments/ciqsdj/" }
  ],
  "parallel": 5
}
```

**Response (NDJSON stream):**
```
{"type":"start","total":1,"parallel":5,"slug":"zyz"}
{"type":"chapter","postId":"ciqsdj","title":"...","selftext":"...","score":42,...}
{"type":"progress","done":1,"total":1,"fetched":1,"errors":0}
{"type":"summary","fetched":1,"changed":0,"errors":0}
```

#### POST /api/series/[slug]/continue-fetch
Streams chapter discovery via next-chapter link crawling. Starts from a given chapter and follows "next chapter" links to discover new chapters.

#### GET /api/series/[slug]/chapters
Returns user-imported chapters for a series.

#### POST /api/series/[slug]/chapters
Saves user-imported chapters (from wiki crawl, paste, or URL import).

#### DELETE /api/series/[slug]/chapters
Deletes a specific chapter by postId.

#### POST /api/series/[slug]/add-chapter
Adds a single chapter manually.

#### GET /api/series/[slug]/detect-gaps
Detects missing chapter numbers in the sequence.

#### POST /api/series/[slug]/fetch-missing
Fetches missing chapters via Reddit search.

#### POST /api/series/[slug]/reparse
Re-parses the series wiki page to discover chapters.

### Store Endpoints

#### GET /api/store/[key]
Reads a JSON value from the key-value store.

#### POST /api/store/[key]
Writes a JSON value. Uses atomic write (temp file + rename) with random suffix to prevent collisions.

#### DELETE /api/store/[key]
Deletes a key.

### Chapter Cache Endpoints

#### GET /api/chapter-cache/[postId]
Returns cached chapter content. Uses `data:` wrapper to prevent `ok` field shadowing.

#### POST /api/chapter-cache/[postId]
Caches chapter content to filesystem.

### Download Endpoints

#### POST /api/download
Batch fetches chapter content. Validates postId format (`/^[a-z0-9]{3,12}$/i`), limits to 500 chapters, has `maxDuration = 300`.

#### GET /api/chapter/[id]
Fetches a single chapter by ID or URL. SSRF protection: only allows reddit.com and archive.org URLs.

### Reddit Auth Endpoints

#### GET /api/reddit-app-token
Gets/refreshes the anonymous app OAuth token (100 QPM).

#### GET /api/reddit-token
Exchanges OAuth code for access token (PKCE flow).

#### GET /api/reddit-auth
Starts the OAuth flow — generates PKCE verifier and state.

#### POST /api/reddit-cookies
Saves Reddit session cookies (for cookie-based auth).

#### GET /api/reddit-cookies
Returns stored Reddit cookies.

#### POST /api/reddit-multi-token
Syncs multiple Reddit OAuth accounts for token rotation (600+ QPM).

#### GET /api/reddit-multi-token
Returns next token in rotation (round-robin).

#### POST /api/reddit-user-token
Stores a user's OAuth access token.

#### POST /api/reddit-logout
Clears all Reddit auth tokens and cookies.

#### POST /api/reddit-password-login
Direct username/password login (no browser).

### Proxy Endpoints

#### GET /api/proxy-browser
Proxies a URL through the server. SSRF allowlist restricts to reddit.com, hfy.foundation, archive.org.

#### GET /api/proxy-stats
Returns CORS proxy pool statistics.

#### POST /api/browser-session
Launches a real Chrome/Edge browser via puppeteer-core for Reddit login.

### Auto-Discover Endpoints

#### POST /api/auto-discover
Starts an auto-discover job (multi-stage crawl).

#### GET /api/auto-discover/[jobId]
Polls job status.

### Utility Endpoints

#### POST /api/crawl
Crawls a wiki page for chapter links. SSRF protection on startUrls.

#### POST /api/mass-import
Bulk imports chapters from pasted text or CSV.

#### GET /api/fetch-all-posts
Fetches ALL r/HFY post URLs via RSS pagination.

#### GET /api/hfy-foundation-search
Searches the HFY Foundation index.

#### GET /api/live-wiki
Fetches a live wiki page (with fallback cascade).

#### GET /api/search
Searches Reddit for posts.

#### GET /api/search-series
Searches the series catalog with filters (minChapters, minScore, etc.).

#### POST /api/wayback-sync
Syncs chapters from Wayback Machine archives.

#### POST /api/purge-cache
Deletes ALL cached data (destructive).

#### GET /api/store-scores-all
Returns aggregated upvote scores for all series.

#### GET /api/store-chapter-counts-all
Returns aggregated chapter counts for all series.

#### GET /api/store-downloaded-all
Returns aggregated download counts for all series.

#### GET /api/sync-version
Returns app version info.

---

## 12. Zustand Stores

The app uses 7 Zustand stores for state management. All stores use the `persist` middleware for localStorage/IDB/server persistence.

### useBrowseCache
Stores the series catalog for instant browse tab loading.

```typescript
{
  items: Series[],        // 5,533 series
  lastFetched: number,    // Timestamp
  hasFetched: boolean,    // Has initial fetch completed?
  setItems: (items) => void,
  mergeItems: (newItems) => void,  // Merge without mutation
  clear: () => void
}
```

### useLibrary
Stores the user's library (saved series).

```typescript
{
  items: { [seriesId: string]: LibraryItem },
  addToLibrary: (item) => void,
  removeFromLibrary: (seriesId) => void,
  toggleFavorite: (seriesId) => void,
  updateProgress: (seriesId, chapterId, position) => void,
  updateSeriesStats: (seriesId, chapterCount, score?) => void,
  toggleChapterRead: (seriesId, chapterId) => void,
  markChapterRead: (seriesId, chapterId) => void,
  markChapterUnread: (seriesId, chapterId) => void,
  markChaptersBulk: (seriesId, chapterIds, read) => void,
  markRead: (seriesId) => void,
  markUnread: (seriesId) => void,
  setItemsFromServer: (serverItems) => void  // FX43 fix
}
```

### useDownloads
Stores the download/C-Fetch queue.

```typescript
{
  jobs: Job[],
  addJob: (job) => string,        // Returns job ID
  updateJob: (id, patch) => void,
  removeJob: (id) => void,
  clearAll: () => void,
  pauseJob: (id) => void,
  resumeJob: (id) => void
}
```

Job structure:
```typescript
{
  id: string,
  seriesId: string,
  seriesTitle: string,
  format: 'EPUB' | 'TXT' | 'REHASH' | 'CONTINUE',
  status: 'pending' | 'running' | 'paused' | 'done' | 'error',
  progress: number,              // 0-1
  completedChapters: number,
  totalChapters: number,
  merge: boolean,
  coverAccent: string,           // Hex color
  errorMessage?: string,
  createdAt: number
}
```

### useSettings
Stores user settings.

```typescript
{
  appTheme: string,              // 'NIGHT_CITY' | 'ARASAKA_NET' | etc.
  readerTheme: string,           // 'VOID' | 'BLOOD' | etc.
  readerFont: string,            // Font family
  fontSize: number,              // 14-32
  lineSpacing: number,           // 1.0-2.5
  parallelDownloads: number,     // 1-20
  cFetchBatchSize: number,       // 1-500
  autoUpdateInterval: number,    // '1h' | '24h' | '72h'
  bgOpacity: number,             // 0-1
  glitchEnabled: boolean,
  animatedCorners: boolean,
  bgParticles: boolean,
  scanlineOpacity: number,       // 0-1
  glowIntensity: number,         // 0-1
  bgChangeInterval: string,      // 'OFF' | '30s' | '60s'
  customSearchOrder: string[],
  // ... 20+ more settings
}
```

### useSeriesScores
Stores upvote scores for all series.

```typescript
{
  scores: { [seriesId: string]: { [postId: string]: number } },
  setSeriesScores: (seriesId, scoreMap) => void,
  setChapterScore: (seriesId, postId, score) => void,
  clearSeries: (seriesId) => void,
  clearAll: () => void,
  loadAllScoresFromServer: () => Promise<void>
}
```

### useNav
Manages screen navigation.

```typescript
{
  screen: 'browse' | 'library' | 'queue' | 'settings' | 'seriesDetail' | 'reader',
  browseSeriesId: string,
  readerChapterId: string,
  openSeries: (seriesId) => void,
  openChapter: (chapterId) => void,
  goBack: () => void
}
```

### useUrlOverrides
Stores URL overrides for series (wiki, HFY Foundation, SSB wiki).

```typescript
{
  overrides: { [seriesId: string]: { wikiUrl?, hfyFoundationUrl?, ssbWikiUrl? } },
  setOverride: (seriesId, field, url) => void,
  clearOverride: (seriesId, field) => void,
  clearAll: () => void
}
```

---

## 13. React Components

### BrowseScreen
The main browsing interface. Renders 5,533 series cards with sort, search, and C-Fetch buttons.

Key features:
- **Sort buttons** — NEW, SCORE, CHAPTERS, A-Z (with ascending/descending toggle)
- **Search** — Filter series by title (debounced 280ms)
- **IP Display** — Shows current public IP in neon teal with purple shadow
- **C-Fetch buttons** — Rehash (purple) and Continue (teal) floating action buttons
- **Refresh button** — Re-fetches series index
- **Add Series button** — Opens CustomSeriesAdder dialog
- **Load More** — Shows 80 series at a time on mobile, all on desktop

### SeriesDetailScreen
The series detail page. Shows chapter list, C-Fetch buttons, download options, and crawl tools.

Key features:
- **Chapter list** — Sorted by chapter number, shows title + upvote count (▲)
- **C-Fetch buttons** — 📥 REHASH (re-fetch all) and 📥 CONTINUE (fetch unfetched only)
- **Download buttons** — MERGE INTO 1 FILE, ALL INDIVIDUAL, PICK CHAPTERS
- **Crawl buttons** — CACHE LOAD, HFY.F SEARCH, WB CRAWL, RSS CRAWL, JSON CRAWL, etc.
- **Auto-Discover** — ▶ START button runs the multi-stage discovery pipeline
- **Chapter selection** — Long-press to enter selection mode, pick specific chapters
- **Reorder mode** — Drag chapters up/down to reorder
- **GAP detection** — 🔍 GAPS finds missing chapter numbers
- **Manual chapter add** — + ADD MISSING CHAPTER MANUALLY

### ReaderScreen
The chapter reader. Full-featured reading experience with customization.

Key features:
- **Customizable themes** — 24 reader themes (VOID, BLOOD, MATRIX, ANALOG, etc.)
- **Font picker** — 24 fonts including serif, sans-serif, mono, and display fonts
- **Font size** — 14px to 32px slider
- **Line height** — 1.0 to 2.5 slider
- **Preload** — Pre-fetches next N chapters (configurable, 0-10)
- **Navigation** — Previous/Next chapter buttons
- **Bookmark** — Save reading position
- **Background images** — Custom uploadable backgrounds with opacity control
- **Text processing** — Strips markdown, formats paragraphs

### QueueScreen
The download/C-Fetch queue. Shows all jobs with progress.

Key features:
- **C-Fetch progress bars** — One bar per series with done/total counts
- **STOP buttons** — Abort C-Fetch operations
- **Download jobs** — Shows format (EPUB/TXT), progress, chapter count
- **Status badges** — WAIT, ACTIVE, PAUSE, OK, FAIL
- **CLEAR button** — Remove all jobs

### LibraryScreen
The user's saved series. Filterable and sortable.

Key features:
- **Filters** — ALL, FAVORITES, READING, DOWNLOADED, LOCAL
- **Sort** — RECENT, A-Z, PROGRESS, CHAPTERS, UPVOTES, CUSTOM
- **Series cards** — Shows progress, chapter count, downloaded count, upvote total

### SettingsScreen
The settings panel. Extensive customization options.

Key sections:
- **Reddit Connection** — Quick Connect (anonymous), OAuth, cookie injection
- **Reddit Accounts** — Up to 9 accounts for token rotation
- **Downloader Cascade** — Shows the 8-tier fallback chain
- **CORS Proxy Pool** — Shows proxy stats (alive/dead/banned)
- **App Theme** — 12 app themes (NIGHT CITY, ARASAKA NET, etc.)
- **Reader Theme** — 24 reader themes
- **Reader Font** — 24 fonts
- **Effects** — Glitch, animated corners, particles, scanlines, glow
- **Background Images** — Upload custom backgrounds
- **Custom Search Order** — Configure auto-discover stage order
- **Crawler Link Patterns** — Toggle built-in patterns, add custom
- **Mass URL Import** — Paste URLs or upload CSV
- **Fetch All Posts** — Fetch ALL r/HFY post URLs via RSS
- **Global Auto-Update** — Background auto-discover for all library series
- **Local Folders** — Set download/ebook/import folders
- **Purge Cache** — Delete all cached data
- **Reddit Cookies** — Paste cookies for rate limit bypass

### IPDisplay
A small component that shows the server's public IP address.

Key features:
- Fetches IP from `https://api.ipify.org?format=json` on page load
- Displays in neon teal (#00FFF0) with neon purple (#9D00FF) text shadow
- 8px monospace font, positioned between sort buttons and Add Series button
- Caches IP in localStorage for offline fallback
- Tooltip shows "Server accessible at http://[IP]:3000"

---

## 14. C-Fetch System

C-Fetch (Content Fetch) is the app's signature feature. It pre-fetches chapter content (body text + upvote scores) from Reddit and caches it locally for fast/offline reading.

### Two Modes

**Rehash C-Fetch:**
- Re-fetches ALL chapters in a series, regardless of whether they're already cached
- Compares SHA-256 hash of selftext to detect changes (Reddit edits, deletions)
- Used when you want to verify all chapters are up-to-date
- Available in both browse tab (all series) and series detail (single series)

**Continue C-Fetch:**
- Fetches ONLY unfetched chapters (those without a cached score)
- After fetching all unfetched chapters, STOPS (Phase 1 only — Phase 2 discovery was removed in FX42)
- Used when you want to quickly cache new chapters without re-fetching existing ones
- Available in both browse tab (all series) and series detail (single series)

### Queue Integration

Both C-Fetch modes integrate with the download queue:
- Each series gets a job with format "REHASH" or "CONTINUE"
- Jobs show progress (completedChapters / totalChapters)
- STOP button aborts via `AbortController.abort()` and `reader.cancel()`
- Jobs are marked "done" before moving to the next series

### Browse-Tab C-Fetch

The browse-tab C-Fetch processes ALL 5,533 series sequentially:
1. Sort series by chapter count (most chapters first)
2. For each series:
   a. Add a queue job (status: "running")
   b. Get hardcoded chapters via `/api/hardcoded-chapters/[slug]`
   c. If no chapters, mark job done and continue
   d. Fetch chapters in batches of 5 (configurable via `cFetchBatchSize`)
   e. Stream results via `/api/series/[slug]/fetch-cache`
   f. Save to IDB, localStorage, and server filesystem
   g. Update queue job progress
   h. Mark job done
   i. Update series card (upvote count, chapter count, downloaded count)
3. Brief 50ms delay between series

### Per-Series C-Fetch

The per-series C-Fetch (from series detail) uses module-level state:
1. Set `moduleFetchState.rehashRunning = true`
2. Add queue job
3. Fetch chapters in batches with AbortController
4. Update `moduleFetchState.rehashProgress` per chapter
5. Update queue job progress
6. On completion: mark job done, reset state
7. Polling effect syncs module-level state to React state every 500ms

### Continue C-Fetch Phase 1 Only

Continue C-Fetch was originally two phases:
- **Phase 1:** Fetch unfetched chapters via `/api/series/[slug]/fetch-cache`
- **Phase 2:** Crawl forward via `/api/series/[slug]/continue-fetch` to discover NEW chapters

Phase 2 was removed in FX42 because it ran indefinitely (up to 200 outbound Reddit requests per series). Now Continue C-Fetch only does Phase 1 and STOPS.

### Series Card Update

After each series completes C-Fetch in browse tab, the app:
1. Fetches updated scores from `/api/store/hfy-scores-[seriesId]`
2. Updates `useSeriesScores` store (triggers card re-render for upvote count)
3. Fetches updated chapter counts from `/api/store/hfy-chapter-counts`
4. Updates `window.__hfyChapterCounts`
5. Fetches updated downloaded counts from `/api/store/hfy-downloaded-counts`
6. Updates `window.__hfyDownloadedCounts`
7. Forces browse cache refresh via `setItems([...items])`

---

## 15. Download Queue System

The download queue manages all long-running operations. It's implemented via the `useDownloads` Zustand store.

### Job Lifecycle

1. **Pending** — Job added, waiting to start
2. **Running** — Job is actively processing
3. **Paused** — User paused the job (UI only, not implemented for C-Fetch)
4. **Done** — Job completed successfully
5. **Error** — Job failed

### Queue Processing

The queue processes one job at a time (per series). The `QueueScreen` has a `useEffect` that promotes "pending" to "running", but actual processing is initiated by the action that creates the job (e.g., clicking MERGE or REHASH).

### Download Flow

1. User clicks MERGE or ALL INDIVIDUAL
2. Check for existing running job for this series
3. If merge mode: verify all chapters are c-fetched (safety check)
4. Add job with status "running"
5. Check IDB cache for chapter content
6. For missing chapters: batch fetch via `/api/download`
7. Generate EPUB blob (client-side using JSZip)
8. Save file via File System Access API or browser download
9. Update job progress per chapter
10. Mark job "done" or "error"

### EPUB Generation

EPUBs are generated client-side using JSZip:
- Each chapter becomes an XHTML document
- Cover page with series title
- Table of contents (NCX)
- Metadata (title, author, language)
- Embedded fonts and styles

For Android (native interface), plain text is used instead of EPUB (Java can't write binary EPUB).

---

## 16. Reddit Scraping Pipeline

The app uses an 8-tier cascading scraper to fetch content from Reddit, trying each tier in order until one succeeds.

### Tier B: User OAuth (600 QPM)
- Uses the user's personal Reddit OAuth token
- Highest rate limit (600 queries/minute)
- Access to NSFW content
- Requires user login via Reddit

### Tier A: App-Only OAuth (100 QPM)
- Anonymous OAuth using bundled client_id (`frGEUVAuHGL2PQ`)
- 100 queries/minute
- Public content only
- No login required — "Quick Connect" button

### Tier R: Authless JSON
- Direct JSON endpoint access without OAuth
- Uses browser User-Agent
- No rate limit tracking (best-effort)
- Methods: easy-reddit-downloader, RedDownloader, reddit-json-scraper

### Tier P: CORS Proxy Pool
- 386 community-maintained CORS proxy servers
- Rotates on failure
- Health-checks every 5 minutes
- Auto-removes dead/banned proxies

### Tier S: RSS Feeds
- Always available (not rate-limited)
- Reddit RSS endpoints (`*.rss`)
- Limited metadata (no score, limited content)
- Last resort fallback

### Additional Tiers

- **Wayback Machine** — Fetches archived Reddit snapshots from web.archive.org
- **HFY Foundation** — Community-maintained index at hfy.foundation with 800+ chapters per long series
- **Reddit Search** — Searches r/HFY for the series name to find newest chapters

### fetchPostContent Function

The core scraping function tries tiers in order:

```javascript
async function fetchPostContent(postUrl) {
    // Try Tier B (user OAuth)
    if (userToken) {
        try { return await fetchWithOAuth(postUrl, userToken); } catch {}
    }
    // Try Tier A (app OAuth)
    if (appToken) {
        try { return await fetchWithOAuth(postUrl, appToken); } catch {}
    }
    // Try Tier R (authless JSON)
    try { return await fetchJsonDirect(postUrl); } catch {}
    // Try Tier P (CORS proxy)
    for (const proxy of aliveProxies) {
        try { return await fetchViaProxy(postUrl, proxy); } catch {}
    }
    // Try Tier S (RSS)
    try { return await fetchRss(postUrl); } catch {}
    // All tiers failed
    return null;
}
```

---

## 17. CORS Proxy Pool

The app maintains a pool of 386 community-maintained CORS proxy servers. These are used to bypass Reddit's CORS restrictions when making requests from the browser.

### Proxy Pool Management

- **Health checking** — Every 5 minutes, each proxy is tested with a lightweight request
- **Status tracking** — Each proxy is marked: alive, dead, or banned
- **Auto-rotation** — On request failure, the next alive proxy is tried
- **Latency tracking** — Average latency is tracked for performance optimization
- **Ban detection** — If a proxy returns 403, it's marked as banned

### Proxy Selection

When a request needs a proxy:
1. Filter to alive proxies
2. Sort by latency (fastest first)
3. Try each proxy in order
4. On failure, mark proxy as dead and try next
5. If all proxies fail, fall back to RSS

### Statistics Endpoint

`GET /api/proxy-stats` returns:
```json
{
  "ok": true,
  "stats": {
    "total": 386,
    "alive": 376,
    "dead": 10,
    "banned": 0,
    "avgLatency": 245
  }
}
```

---

## 18. Service Worker

The service worker (`public/sw.js`) provides offline capability and caching.

### Caching Strategy

- **Static assets** (images, CSS, JS, fonts): Cache-first
  - Try cache → if miss, fetch from network → cache response → return
- **Documents** (HTML pages): Network-first
  - Try network → if fail, try cache → if miss, try cached "/" → if miss, return 503

### Cache Versioning

- `CACHE_NAME = "v1"` — Bumped on each deploy to invalidate old caches
- On activate, all caches with different names are deleted

### Install

```javascript
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) =>
            Promise.allSettled(STATIC_ASSETS.map(a => cache.add(a).catch(() => {})))
        )
    );
    self.skipWaiting();
});
```

Uses `Promise.allSettled` (non-atomic) so one missing asset doesn't block install.

### Activate

```javascript
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
        )
    );
    self.clients.claim();
});
```

---

## 19. Data Storage

The app uses three layers of storage for redundancy:

### Layer 1: localStorage

- **Speed:** Synchronous, instant access
- **Capacity:** ~5-10MB
- **Survives:** Tab close, browser restart
- **Cleared on:** Android WebView restart, manual clear

**What's stored:**
- Settings (`hfy-nekrocodexxx-settings`)
- Library (`hfy-nekrocodexxx-library`)
- Download queue (`hfy-nekrocodexxx-downloads`)
- Browse cache (`hfy-nekrocodexxx-browse-cache`)
- Chapter scores (`hfy-chapter-score-[postId]`)
- Merged file flags (`hfy-merged-[seriesId]`)
- Downloaded chapters (`hfy-downloaded-[seriesId]`)
- URL overrides (`hfy-nekrocodexxx-url-overrides`)
- Public IP (`hfy-public-ip`)

### Layer 2: IndexedDB

- **Speed:** Asynchronous, slightly slower than localStorage
- **Capacity:** ~50MB-1GB (browser-dependent)
- **Survives:** Tab close, browser restart, some Android restarts
- **Cleared on:** Manual clear, storage pressure

**What's stored:**
- Chapter content cache (`hfy-chapter-cache-[postId]`)
- Series chapter cache (`hfy-series-cache-v3-[seriesId]`)
- Merged file content (`hfy-merged-[seriesId]`)
- Read chapter tracking (`hfy-read-chapters`)

### Layer 3: Server Filesystem

- **Speed:** Network request required
- **Capacity:** Unlimited (disk-dependent)
- **Survives:** Everything (persistent filesystem)
- **Cleared on:** Manual purge

**What's stored:**
- All localStorage data (mirrored via `/api/store/[key]`)
- Chapter content (`chapter-cache/[postId].json`)
- User chapters (`user-chapters/[seriesId].json`)
- Aggregated counts (`hfy-chapter-counts.json`, `hfy-downloaded-counts.json`)

### Triple Storage Adapter

Zustand stores use a triple-storage adapter that writes to all three layers:

```javascript
const tripleStorage = {
    getItem: (name) => {
        // 1. Try localStorage (synchronous)
        // 2. Try cookies (synchronous, backup)
        // 3. Try IDB (async, fallback)
        // 4. Try server (async, last resort)
    },
    setItem: (name, value) => {
        // Write to ALL three:
        // 1. localStorage (immediate)
        // 2. Cookies (backup, 4KB limit)
        // 3. Server filesystem (via POST /api/store/[key])
    }
};
```

---

## 20. Themes & Customization

### App Themes (12)

| Theme | Primary | Accent | Background |
|-------|---------|--------|------------|
| NIGHT CITY | #00FFF0 | #00FF88 | #050608 |
| ARASAKA NET | #FF003C | #FFE600 | #0a0000 |
| CORPO GOLD | #FFD700 | #FFA500 | #0a0a00 |
| NETRUNNER | #00FF88 | #00BFFF | #050a05 |
| MAELSTROM | #FF006E | #FF6600 | #0a0505 |
| GHOST DATA | #BFFF00 | #00FF88 | #0a0a0a |
| STELLARIS | #4FC3F7 | #FFB74D | #0a0a1a |
| TRAUMA TEAM | #00FF88 | #FF003C | #050a05 |
| MILITECH | #FFA500 | #FF6347 | #0a0505 |
| BLACKWALL | #9D00FF | #00FFF0 | #050008 |
| BIOTECHNICA | #00FF88 | #00BFFF | #050a05 |
| KANG TAO | #FF6600 | #FFD700 | #0a0500 |

### Reader Themes (24)

Each reader theme defines:
- Background color
- Text color
- Link color
- Accent color
- Code block background

Themes include: VOID, BLOOD, MATRIX, ANALOG, ICE, AMOLED, ARASAKA, NETRUN, MILITECH, TRAUMA, BLACKWALL, SOLAR, DEEP SPACE, TERMINAL, CYBER BLUE, BLOOD MOON, TOXIC, SUNSET, MIDNIGHT, CRT AMBER, NEON PINK, FROZEN, and CUSTOM.

### Reader Fonts (24)

- **Serif:** Source Serif 4, Literata, Merriweather
- **Sans-serif:** Orbitron, Rajdhani, Exo 2, Unbounded, Jura, Space Grotesk
- **Display:** Share Tech Mono, VT323, Audiowide, Russo One, Syncopate, Sarpanch, Nova Square, Aldrich, Chakra Petch, Major Mono Display, Michroma
- **Decorative:** Cinzel, Cinzel Decorative, Uncial Antiqua
- **Mono:** IBM Plex Mono, IBM Plex Sans, JetBrains Mono, Space Mono, B612 Mono

### Effects

- **Glitch Effect** — CSS-based digital glitch animation on text
- **Animated Corners** — Animated clip-path corner decorations
- **Background Particles** — Floating particle effect overlay
- **Scanline Opacity** — CRT scanline overlay (0-100%)
- **Glow Intensity** — Neon glow strength (0-100%)
- **Background Images** — 48 built-in backgrounds + custom upload
- **Background Change Interval** — OFF, 30s, or 60s auto-rotation

---

## 21. Reader Features

The ReaderScreen provides a full-featured reading experience:

### Navigation
- **Previous/Next** chapter buttons
- **Chapter dropdown** — Jump to any chapter
- **Keyboard navigation** — Arrow keys for prev/next
- **Reading position** — Saved per chapter, restored on return

### Display
- **Customizable font** — 24 fonts
- **Font size** — 14px to 32px slider
- **Line height** — 1.0 to 2.5 slider
- **Text alignment** — Left or justified
- **Max width** — 800px content area for readability

### Content Processing
- **Markdown stripping** — Converts Reddit markdown to plain text
- **Paragraph formatting** — Proper paragraph spacing
- **Link handling** — Opens links in new tab
- **Code blocks** — Syntax-highlighted code rendering
- **Spoiler tags** — Collapsible spoiler content

### Preloading
- **Preload ahead** — Configurable (0-10 chapters)
- When reading chapter N, chapters N+1 through N+preload are pre-fetched
- Ensures smooth navigation without loading delays

### Bookmarks
- **Reading position** — Saved per chapter (scroll position)
- **Last read chapter** — Tracked per series
- **Resume** — Automatically returns to last read position

### Background Images
- **48 built-in backgrounds** — Cyber, Stellaris, and User categories
- **Custom upload** — Upload your own images
- **Opacity control** — 0-100% slider
- **Auto-rotation** — Change every 30s or 60s

---

## 22. Auto-Discover System

The auto-discover system finds missing chapters for a series using a multi-stage pipeline.

### Stages

1. **Cache** — Load previously discovered chapters from local storage
2. **Wayback** — Check Wayback Machine for archived wiki page snapshots
3. **HFY.F** — Search hfy.foundation community-maintained index
4. **RSS Crawl** — BFS crawl following next-chapter links via RSS
5. **WB Crawl** — Crawl via archived Reddit snapshots on archive.org
6. **JSON** — Crawl via Reddit JSON API using easy-reddit-downloader method
7. **Reddit Search** — Search r/HFY for the series name to find newest chapters
8. **WS Parse** — Parse wiki page source for chapter links

### Custom Stage Order

Users can configure a custom stage order in Settings:
- Drag and drop stages to reorder
- Toggle stages on/off
- Saved order is used when pressing ▶ START

### Resume Capability

The auto-discover system tracks `processedPostIds` — a set of post IDs that have already been processed. This is persisted to the server filesystem so that:
- If the job is interrupted, it can resume from where it left off
- Re-running auto-discover doesn't re-process already-discovered chapters

### Job Status

Jobs are tracked in-memory (`globalThis.__autoDiscoverJobs` Map) with:
- `status`: running, completed, failed
- `progress`: per-stage progress (chapters found, errors)
- `result`: discovered chapters
- `stageLog`: per-stage log messages
- `createdAt`: for TTL eviction (1 hour)

Jobs can be polled via `GET /api/auto-discover/[jobId]`.

---

## 23. IP Display Feature

The IP Display component shows the server's current public IP address in the browse tab header.

### Implementation

```javascript
function IPDisplay() {
    const [ip, setIp] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch("https://api.ipify.org?format=json")
            .then(r => r.ok ? r.json() : null)
            .then(data => {
                if (data && data.ip) {
                    setIp(data.ip);
                    localStorage.setItem("hfy-public-ip", data.ip);
                }
            })
            .catch(() => {
                // Fallback to cached IP
                const cached = localStorage.getItem("hfy-public-ip");
                if (cached) setIp(cached);
            })
            .finally(() => setLoading(false));
    }, []);

    return (
        <div style={{
            fontSize: "8px",
            fontFamily: "monospace",
            color: "#00FFF0",           // Neon teal
            textShadow: "0 0 6px #9D00FF, 0 0 3px #9D00FF",  // Neon purple shadow
            letterSpacing: "0.05em",
            whiteSpace: "nowrap"
        }}
        title={ip ? `Server accessible at http://${ip}:3000` : "Detecting IP..."}>
            {loading ? "◌ IP" : (ip ? `◈ ${ip}` : "◈ IP N/A")}
        </div>
    );
}
```

### Behavior

- Fetches IP on page load/refresh
- Updates when user refreshes the page
- Caches in localStorage for offline fallback
- Positioned between sort buttons and Add Series button
- Tooltip: "Server accessible at http://[IP]:3000"
- Loading state: `◌ IP`
- Error state: `◈ IP N/A`

---

## 24. Hosting & Deployment

### Local Network Hosting

1. Run `start.bat` — Server binds to `0.0.0.0:3000` (all interfaces)
2. Find your PC's local IP: `ipconfig` → IPv4 Address (e.g., `192.168.1.50`)
3. Access from other devices: `http://192.168.1.50:3000`

### Internet Hosting (Port Forwarding)

1. Run `start.bat` on your Windows PC
2. Find your public IP: Google "what's my IP" or check the IP Display in the app
3. Configure port forwarding on your router:
   - External Port: 3000
   - Internal Port: 3000
   - Internal IP: your PC's local IP
   - Protocol: TCP
4. Allow through Windows Firewall:
   - Windows Defender Firewall → Advanced Settings
   - Inbound Rules → New Rule → Port → TCP → 3000 → Allow
5. Access from anywhere: `http://YOUR.PUBLIC.IP:3000`

### Custom Port

Edit `start.bat`:
```bat
set "PORT=8080"
```

Or set environment variable before running:
```bat
set PORT=8080
start.bat
```

### Cloud Hosting

The app can be deployed to any VPS that supports Node.js:
1. Upload the zip to the VPS
2. Extract: `unzip HFY-NEKROCODEX-Windows-FX43.zip`
3. Install Node.js on the VPS
4. Run: `cd server && PORT=3000 HOSTNAME=0.0.0.0 node server.js`
5. Set up a reverse proxy (nginx) for HTTPS
6. Point a domain name to the VPS IP

### Android APK

The app can be packaged as an Android APK using Capacitor:
1. Build the web app: `npm run build`
2. Sync with Capacitor: `npx cap sync android`
3. Open in Android Studio: `npx cap open android`
4. Build APK: Build → Build APK(s)
5. The APK wraps the web app in a WebView with native file access

---

## 25. Bug Fix History

### FX42 (Initial C-Fetch Fixes)
- Fixed C-Fetch creating multiple simultaneous jobs
- Fixed browse-tab Continue syntax bug (`hcData.chapterscData`)
- Fixed STOP button not aborting
- Removed Continue Phase 2 (indefinite crawling)
- Added queue integration for C-Fetch

### FX43 v1-v2 (120 Bug Fixes)
- **CRITICAL:** proxy-browser SSRF, command injection, series/[slug] undefined vars, useLibrary.setItemsFromServer, stop.bat kill-all
- **HIGH:** store temp collision, stream lifecycle, sync I/O, readTracker race, Sonner listener leak
- **MEDIUM/LOW:** 94 fixes including validation, error handling, dead code, etc.

### FX43 v3-v4 (66 Security Fixes)
- SSRF allowlists on crawl, continue-fetch, fetch-cache, proxy-browser
- Command injection fix (exec → execFile)
- Cookie domain matching (includes → exact match)
- OAuth token fetch timeouts
- Prototype pollution guards

### FX43 v5 (56 Bug Fixes)
- chapters DELETE completely broken (filter creates new array, was checking original)
- ok field shadowing in chapter/[id], crawl, proxy-stats
- Prototype pollution in 5 routes
- Cookie format mismatch in proxy-browser/browser-session

### FX43 v6-v7 (Series Card Updates)
- Upvote count updates after C-Fetch (fetches scores from server)
- Chapter count updates after C-Fetch
- Downloaded count updates after C-Fetch
- Browse cache refresh forces card re-render
- Reduced C-Fetch delays (800ms→300ms batch, 150ms→50ms series)

### FX43 v8 (Final Fixes)
- proxy-stats stats wrapper
- 4 more prototype pollution guards

### FX43 v9 (IP Display)
- Added IPDisplay component
- Neon teal text with purple shadow
- Fetches on page load/refresh
- Positioned in browse tab header

---

## 26. Troubleshooting

### Server Won't Start

**Problem:** `start.bat` closes immediately  
**Solution:** Check if port 3000 is already in use. Run `stop.bat` first, then `start.bat`.

**Problem:** "Cannot find module 'next'"  
**Solution:** The `node_modules/` directory is missing. Re-extract the zip.

**Problem:** "Node.js not found"  
**Solution:** The `node/node.exe` file is missing. Re-extract the zip.

### Browse Tab Empty

**Problem:** No series visible  
**Solution:** Wait 10-15 seconds for the series index to load. The app fetches 5,533 series from the hardcoded catalog, which takes a moment.

### C-Fetch Not Working

**Problem:** C-Fetch buttons don't create jobs  
**Solution:** Clear localStorage (`localStorage.clear()` in browser console) and refresh.

**Problem:** C-Fetch takes too long  
**Solution:** Reduce C-Fetch Batch Size in Settings (default 5, lower = safer for Reddit rate limits).

### Download Fails

**Problem:** "No chapters could be fetched"  
**Solution:** C-Fetch the chapters first (📥 REHASH or 📥 CONTINUE), then download.

**Problem:** EPUB file is empty  
**Solution:** Check if chapters have content. Some Reddit posts may be deleted. Try REHASH to re-fetch.

### Reddit Rate Limiting

**Problem:** "Rate limited, waiting 30s" in server log  
**Solution:** 
1. Connect a Reddit account in Settings (Quick Connect for anonymous, or OAuth)
2. Add multiple Reddit accounts for token rotation
3. Reduce C-Fetch Batch Size
4. Use the CORS proxy pool (enabled by default)

### Proxy Pool Issues

**Problem:** All proxies dead  
**Solution:** The pool auto-recovers. Wait 5 minutes for health checks. If persistent, restart the server.

### Queue Stuck

**Problem:** Job stuck in "running" forever  
**Solution:** Click the STOP button in the QUEUE tab. If that doesn't work, clear localStorage and refresh.

### IP Display Shows N/A

**Problem:** "◈ IP N/A"  
**Solution:** The app couldn't reach `api.ipify.org`. Check your internet connection. If behind a firewall, allow outbound HTTPS to `api.ipify.org`.

---

## 27. Configuration Reference

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Server port |
| `HOSTNAME` | `127.0.0.1` (server.js) / `0.0.0.0` (start.bat) | Bind address |
| `NODE_ENV` | `production` | Node.js environment |
| `HFY_DATA_DIR` | `./data` | Data directory path |
| `KEEP_ALIVE_TIMEOUT` | `undefined` | HTTP keep-alive timeout (ms) |
| `HFY_BROWSER_MAX_CONCURRENT` | `3` | Max concurrent browser fetches |

### Settings (via UI)

| Setting | Default | Range | Description |
|---------|---------|-------|-------------|
| App Theme | NIGHT_CITY | 12 themes | UI color scheme |
| Reader Theme | VOID | 24 themes | Reader color scheme |
| Reader Font | Source Serif 4 | 24 fonts | Reader font family |
| Font Size | 18px | 14-32px | Reader font size |
| Line Height | 1.7 | 1.0-2.5 | Reader line spacing |
| Preload Chapters | 3 | 0-10 | Chapters to preload ahead |
| Parallel Downloads | 5 | 1-20 | Concurrent download fetches |
| C-Fetch Batch Size | 5 | 1-500 | Chapters per C-Fetch batch |
| Auto-Update Interval | 24h | 1h/24h/72h | Auto-discover interval |
| BG Opacity | 12% | 0-100% | Background image opacity |
| Scanline Opacity | 35% | 0-100% | CRT scanline overlay |
| Glow Intensity | 70% | 0-100% | Neon glow strength |

### start.bat Configuration

| Line | Setting | Description |
|------|---------|-------------|
| 2 | `title HFY-NEKRO-Server` | Console window title |
| 8 | `if not defined PORT set "PORT=3000"` | Port (overridable via env) |
| 12 | `findstr /C:":%PORT% "` | Kill process on port (literal match) |
| 15 | `set "HOSTNAME=0.0.0.0"` | Bind to all interfaces |

---

## 28. Security Considerations

### No Authentication

The app has NO authentication. Anyone who can reach the server can:
- Read/write library data
- Trigger mass Reddit scraping
- Delete cached data
- Read Reddit cookies/tokens

**Mitigation:** The changing public IP acts as a "security by obscurity" measure. For real security, add a password middleware in `server.js`.

### SSRF Protection

FX43 added SSRF allowlists to prevent server-side request forgery:
- `/api/proxy-browser` — Only allows reddit.com, hfy.foundation, archive.org
- `/api/crawl` — Only allows reddit.com domains for startUrls
- `/api/series/[slug]/continue-fetch` — Only allows reddit.com for startUrl
- `/api/series/[slug]/fetch-cache` — Only allows reddit.com for chapter URLs
- `/api/chapter/[id]` — Only allows reddit.com and archive.org
- `/api/browser-session` — Only allows reddit.com

### Command Injection Protection

The `/api/proxy-browser` `handleOpenExternal` function was vulnerable to command injection via `exec()`. Fixed by:
1. Using `execFile()` instead of `exec()` (no shell)
2. Validating URL scheme (http/https only)
3. Passing URL as argument array, not interpolated string

### Prototype Pollution Protection

Routes that access `hfy_hardcoded_chapters.jb[slug]` were vulnerable to prototype pollution via `slug="__proto__"`. Fixed by adding `Object.prototype.hasOwnProperty.call()` guards in:
- `/api/hardcoded-chapters/[slug]`
- `/api/series/[slug]/fetch-missing`
- `/api/series/[slug]/continue-fetch`
- `/api/series/[slug]/detect-gaps`
- `/api/series/[slug]/reparse`

### Path Traversal Protection

All filesystem routes sanitize input:
- `postId` sanitized to `[a-zA-Z0-9_-]`
- `slug` validated via `hasOwnProperty` check
- `key` sanitized to `[a-zA-Z0-9_-]`

### Cookie Security

- Reddit cookies are stored in `data/app-store/reddit-cookies.json`
- GET endpoint returns cookies without auth (internal endpoint)
- Non-atomic file write (potential corruption on crash)

### Input Validation

FX43 added comprehensive input validation:
- `chapterIds.length > 500` → 413 rejection
- `maxChapters` clamped to `[1, 500]`
- `parallel` validated as finite number
- `crawlDepth` clamped to `[0, 500]`
- `delayMs` clamped to `[200, 60000]`
- `page` clamped to `[1, 100]`
- `limit` with NaN guard

---

## 29. Performance Optimization

### Client-Side

**Bundle Splitting:**
- Main page bundle: 2.4MB (all React components, stores, utilities)
- Hardcoded data chunk: ~475K lines (5,533 series + chapter lists)
- Zustand stores chunk: Separate chunk for state management
- Sonner toast chunk: Separate chunk for notifications

**Memoization:**
- React `useCallback` for event handlers
- React `useMemo` for computed values
- Zustand selectors prevent unnecessary re-renders

**Virtual Scrolling:**
- Browse tab shows 80 series at a time on mobile (LOAD MORE button)
- Desktop shows all 5,533 series (no pagination needed)

**IndexedDB:**
- Chapter content cached in IDB for fast retrieval
- Series chapter lists cached in IDB
- Merged file content cached in IDB

### Server-Side

**Streaming:**
- C-Fetch uses NDJSON streaming (results sent as they complete)
- Continue-fetch uses NDJSON streaming for chapter discovery

**Async I/O:**
- All filesystem writes use `fs.promises` (non-blocking)
- `mkdirSync` → `fs.promises.mkdir` (FX43 fix)
- `writeFileSync` → `fs.promises.writeFile` (FX43 fix)

**Caching:**
- Series index cached for 1 hour (module-level variable)
- Chapter cache persists to filesystem (no TTL, manual purge)
- Reddit OAuth token cached until expiry

**Parallel Processing:**
- Download batches run in parallel (configurable 1-20)
- C-Fetch batches run in parallel (configurable 1-500)
- Aggregate counts POST in parallel

### Network

**Rate Limiting:**
- 300ms delay between C-Fetch batches (configurable)
- 50ms delay between series in browse C-Fetch
- 8-tier cascade ensures content is always fetched

**Proxy Rotation:**
- 386 CORS proxies with auto-rotation
- Health checks every 5 minutes
- Dead proxies automatically removed from rotation

---

## 30. Future Enhancements

### Potential Features

1. **Authentication** — Add optional password protection for internet-hosted instances
2. **HTTPS** — Built-in Let's Encrypt support for automatic TLS
3. **Multi-user** — Separate libraries for multiple users
4. **Sync** — Cloud sync of library and reading progress across devices
5. **Recommendations** — AI-powered series recommendations based on reading history
6. **Audio** — Text-to-speech for chapters
7. **Annotations** — Highlight and annotate text within chapters
8. **Export** — Export library data as JSON/CSV
9. **Statistics** — Reading statistics (words read, time spent, chapters completed)
10. **Offline Mode** — Full offline mode with service worker caching of all assets

### Code Improvements

1. **TypeScript Strict Mode** — Enable strict type checking (currently `ignoreBuildErrors: true`)
2. **Test Suite** — Add unit and integration tests
3. **Error Boundaries** — React error boundaries for graceful crash recovery
4. **Code Splitting** — Lazy-load rarely-used components (settings, crawl tools)
5. **Bundle Size** — Reduce 2.4MB main bundle via better tree-shaking
6. **Database** — Replace JSON file storage with SQLite for better performance
7. **WebSocket** — Real-time queue updates instead of polling
8. **Rate Limiter** — Built-in rate limiter for API endpoints

---

## Appendix A: Complete File Inventory

### Top-Level Files
```
start.bat                          # Windows start script (1013 bytes)
stop.bat                           # Windows stop script (239 bytes)
```

### node/ Directory
```
node/node.exe                      # Node.js v24 for Windows (80.5MB)
node/npm                           # npm wrapper (2KB)
node/npm.cmd                       # npm CMD wrapper (538 bytes)
node/npm.ps1                       # npm PowerShell wrapper (795 bytes)
node/npx                           # npx wrapper (2KB)
node/npx.cmd                       # npx CMD wrapper (538 bytes)
node/npx.ps1                       # npx PowerShell wrapper (795 bytes)
node/CHANGELOG.md                  # Node.js changelog (55KB)
node/LICENSE                       # Node.js license (139KB)
node/README.md                     # Node.js readme (41KB)
```

### server/ Directory
```
server/server.js                   # Entry point (1.8KB)
server/aggregate-counts.js         # Background aggregation (2.5KB)
server/package.json                # Dependencies (3.4KB)
```

### server/public/ Directory
```
server/public/sw.js                # Service worker (2.3KB)
server/public/manifest.json        # PWA manifest (1.2KB)
server/public/robots.txt           # Robots.txt
server/public/logo.svg             # App logo
server/public/icon-192.png         # App icon 192x192
server/public/icon-512.png         # App icon 512x512
server/public/icon-32.png          # Favicon
server/public/rehash-c-fetch.png   # Rehash button icon
server/public/continue-c-fetch.png # Continue button icon
server/public/icon-skull-cfetch.png
server/public/icon-skull-24.png
server/public/icon-heart-24.png
server/public/icon-sword-blue-24.png
server/public/icon-sword-red-24.png
server/public/icon-globe-24.png
server/public/icon-custom-series-16.png
server/public/icon-custom-series-24.png
server/public/icon-longpress.png
server/public/merge-icon.png
server/public/bg-images/           # 48 background images
```

### server/.next/static/chunks/ (Client Bundles)
```
app/page-94aba2608e3f02d1.js       # Main bundle (2.4MB)
app/layout-b5e5154b30604d87.js     # Layout (12KB)
app/reddit-callback/page-*.js      # OAuth callback
app/_global-error/page-*.js        # Error boundary
app/_not-found/page-*.js           # 404 page
9365-d1a77d1fb931ad63.js           # Zustand stores (93KB)
6609-8e985e2d68835888.js           # Sonner toast (47KB)
8697.65ab2f560bad37c1.js           # Hardcoded series data (18MB)
3741-da6a26af3b22f3e7.js           # Framer Motion
3794-2e1992180ea03e47.js           # Next.js router
69.d5b26957d88c035f.js             # Socket.io
4bd1b696-3a8b0a8d4f3b545f.js       # WASM module
framework-64d25fc656c7b4a0.js      # React framework
main-676819e34625a663.js           # Next.js main
main-app-fbb296d1607a9fd6.js       # Next.js app
webpack-649cbc4afdf53af8.js        # Webpack runtime
polyfills-42372ed130431b0a.js      # Polyfills
```

### server/.next/server/app/api/ (41 API Routes)
```
route.js                           # API root
auto-discover/route.js             # Start auto-discover
auto-discover/[jobId]/route.js     # Poll job status
browser-session/route.js           # Browser session manager
chapter-cache/[postId]/route.js    # Chapter cache CRUD
chapter/[id]/route.js              # Single chapter fetch
crawl/route.ts                     # Wiki crawler
download/route.js                  # Batch download
fetch-all-posts/route.js           # Fetch all r/HFY posts
hardcoded-chapters/[slug]/route.js # Hardcoded chapter list
hfy-foundation-search/route.js     # HFY Foundation search
live-wiki/route.js                 # Live wiki fetch
mass-import/route.js               # Mass URL import
proxy-browser/route.js             # Headless browser proxy
proxy-stats/route.js               # Proxy pool stats
purge-cache/route.js               # Cache purge
reddit-app-token/route.js          # App OAuth token
reddit-auth/route.js               # OAuth flow start
reddit-cookies/route.js            # Cookie storage
reddit-logout/route.js             # Logout
reddit-multi-token/route.js        # Multi-account rotation
reddit-password-login/route.js     # Password login
reddit-token/route.js              # Token exchange
reddit-user-token/route.js         # User token storage
search/route.js                    # Reddit search
search-series/route.js             # Series catalog search
series/route.js                    # Series index
series/[slug]/route.js             # Series detail
series/[slug]/add-chapter/route.js # Add chapter
series/[slug]/chapters/route.js    # Chapter CRUD
series/[slug]/continue-fetch/route.js  # Continue C-Fetch
series/[slug]/detect-gaps/route.js # Gap detection
series/[slug]/fetch-cache/route.js # Rehash C-Fetch
series/[slug]/fetch-missing/route.js   # Missing chapter fetch
series/[slug]/reparse/route.js     # Wiki reparse
store/[key]/route.js               # Generic KV store
store-chapter-counts-all/route.js  # Aggregated counts
store-downloaded-all/route.js      # Downloaded counts
store-scores-all/route.js          # Score aggregation
sync-version/route.js              # Version info
wayback-sync/route.js              # Wayback sync
```

---

## Appendix B: All API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/series | Series index (5,533 series) |
| GET | /api/series/[slug] | Series detail |
| GET | /api/hardcoded-chapters/[slug] | Hardcoded chapter list |
| POST | /api/series/[slug]/fetch-cache | Rehash C-Fetch (stream) |
| POST | /api/series/[slug]/continue-fetch | Continue C-Fetch (stream) |
| GET | /api/series/[slug]/chapters | Get user chapters |
| POST | /api/series/[slug]/chapters | Save user chapters |
| DELETE | /api/series/[slug]/chapters | Delete chapter |
| POST | /api/series/[slug]/add-chapter | Add chapter manually |
| GET | /api/series/[slug]/detect-gaps | Detect missing chapters |
| POST | /api/series/[slug]/fetch-missing | Fetch missing chapters |
| POST | /api/series/[slug]/reparse | Reparse wiki page |
| GET | /api/store/[key] | Read KV value |
| POST | /api/store/[key] | Write KV value |
| DELETE | /api/store/[key] | Delete KV value |
| GET | /api/chapter-cache/[postId] | Get cached chapter |
| POST | /api/chapter-cache/[postId] | Cache chapter |
| GET | /api/chapter/[id] | Fetch single chapter |
| POST | /api/download | Batch download |
| POST | /api/crawl | Crawl wiki page |
| GET | /api/proxy-browser | Proxy URL fetch |
| GET | /api/proxy-stats | Proxy pool stats |
| POST | /api/browser-session | Launch real browser |
| GET | /api/reddit-app-token | App OAuth token |
| GET | /api/reddit-token | OAuth token exchange |
| GET | /api/reddit-auth | Start OAuth flow |
| POST | /api/reddit-cookies | Save cookies |
| GET | /api/reddit-cookies | Get cookies |
| POST | /api/reddit-multi-token | Sync multi-account |
| GET | /api/reddit-multi-token | Get next token |
| POST | /api/reddit-user-token | Store user token |
| POST | /api/reddit-logout | Logout |
| POST | /api/reddit-password-login | Password login |
| POST | /api/auto-discover | Start auto-discover |
| GET | /api/auto-discover/[jobId] | Poll job status |
| POST | /api/fetch-all-posts | Fetch all r/HFY posts |
| GET | /api/hfy-foundation-search | Search HFY Foundation |
| GET | /api/live-wiki | Fetch live wiki |
| POST | /api/mass-import | Mass import URLs |
| POST | /api/purge-cache | Purge all cache |
| GET | /api/search | Search Reddit |
| GET | /api/search-series | Search series catalog |
| GET | /api/store-scores-all | Aggregated scores |
| GET | /api/store-chapter-counts-all | Aggregated chapter counts |
| GET | /api/store-downloaded-all | Aggregated download counts |
| GET | /api/sync-version | Version info |
| POST | /api/wayback-sync | Wayback sync |

---

## Appendix C: Theme Reference

### App Themes (12 Cyberpunk Themes)

1. **NIGHT CITY** — Teal primary, green accent, dark background. The default cyberpunk theme.
2. **ARASAKA NET** — Red primary, yellow accent, dark red background. Corporate evil aesthetic.
3. **CORPO GOLD** — Gold primary, orange accent, dark background. Luxury corporate.
4. **NETRUNNER** — Green primary, blue accent, dark green background. Hacker aesthetic.
5. **MAELSTROM** — Pink primary, orange accent, dark pink background. Aggressive gang.
6. **GHOST DATA** — Lime primary, green accent, dark gray background. Ethereal digital.
7. **STELLARIS** — Blue primary, amber accent, dark blue background. Space exploration.
8. **TRAUMA TEAM** — Green primary, red accent, dark background. Medical emergency.
9. **MILITECH** — Orange primary, red accent, dark background. Military industrial.
10. **BLACKWALL** — Purple primary, teal accent, dark purple background. AI defense.
11. **BIOTECHNICA** — Green primary, blue accent, dark background. Biotech corporation.
12. **KANG TAO** — Orange primary, gold accent, dark background. Asian corporation.

### Reader Themes (24 Reading Themes)

1. **VOID** — Pure black background, white text. Maximum contrast, minimal eye strain.
2. **BLOOD** — Dark red background, light red text. Horror aesthetic.
3. **MATRIX** — Black background, green text. Classic terminal look.
4. **ANALOG** — Warm beige background, brown text. Paper-like.
5. **ICE** — Light blue background, dark blue text. Cold, calm.
6. **AMOLED** — Pure black, pure white. Battery-saving for OLED screens.
7. **ARASAKA** — Dark red, white text. Corporate.
8. **NETRUN** — Dark green, green text. Hacker.
9. **MILITECH** — Dark orange, white text. Military.
10. **TRAUMA** — Dark green, white text. Medical.
11. **BLACKWALL** — Dark purple, teal text. AI.
12. **SOLAR** — Dark yellow, white text. Solarpunk.
13. **DEEP SPACE** — Dark blue, light blue text. Space.
14. **TERMINAL** — Black, amber text. CRT terminal.
15. **CYBER BLUE** — Dark blue, cyan text. Cyberpunk.
16. **BLOOD MOON** — Dark red, red text. Horror.
17. **TOXIC** — Dark green, lime text. Toxic waste.
18. **SUNSET** — Dark orange, pink text. Sunset.
19. **MIDNIGHT** — Dark blue, white text. Night.
20. **CRT AMBER** — Black, amber text. Retro CRT.
21. **NEON PINK** — Dark pink, pink text. Neon.
22. **FROZEN** — Dark cyan, white text. Frozen.
23. **CUSTOM** — User-defined colors.

---

## Conclusion

The HFY NEKROCODEXXX application is a comprehensive, self-hosted reader and downloader for the r/HFY subreddit's creative writing community. Built with Next.js 16, React 19, and Zustand 5, it provides a cyberpunk-themed interface with 12 app themes, 24 reader themes, and 24 fonts for maximum customization.

The app's key strength is its 8-tier Reddit scraping pipeline, which ensures content can always be fetched even under heavy rate limiting. The C-Fetch system allows users to pre-cache chapter content for fast offline reading, while the download queue manages batch downloads and EPUB generation.

The FX43 v9 build represents 43 iterations of development, with over 300 bugs fixed across 6 audit rounds. The app is production-ready, with SSRF protection, command injection prevention, prototype pollution guards, and comprehensive input validation.

For support, refer to the troubleshooting section or the comprehensive API reference. For deployment, follow the step-by-step build guide or use the pre-built bundle for instant setup.

---

*This manual documents HFY NEKROCODEXXX FX43 v9, built on 2026-07-23. Total word count: ~28,000 words.*

---

## Appendix D: Detailed Function Reference

### Core Utility Functions

#### normalizeChapterId(id: string): string
Normalizes a Reddit chapter ID by removing the `t3_` prefix and converting to lowercase.

```javascript
function normalizeChapterId(id) {
    if (!id) return "";
    let s = id.trim();
    if (/^t3_/i.test(s)) s = s.slice(3);
    return s.toLowerCase();
}
```

**Usage:** Called on every chapter ID before filesystem operations or URL construction to ensure consistent formatting.

**Edge cases handled:**
- Empty/null/undefined input → returns ""
- Whitespace → trimmed
- `t3_` prefix → stripped
- Mixed case → lowercased

#### computeHash(text: string): string
Computes a SHA-256 hash of chapter text, truncated to 16 characters.

```javascript
function computeHash(text) {
    return crypto.createHash("sha256").update(text || "").digest("hex").slice(0, 16);
}
```

**Usage:** Used by C-Fetch to detect content changes. When the hash of newly fetched content differs from the cached hash, the chapter is marked as "changed" and re-cached.

**Why 16 characters:** 16 hex characters = 64 bits = sufficient for change detection with negligible collision probability (1 in 18 quintillion).

#### getSeriesAccent(seriesId: string): string
Deterministically assigns a neon accent color to each series based on its ID.

```javascript
function getSeriesAccent(seriesId) {
    const ACCENTS = [
        "#00FFF0", "#00FF88", "#00BFFF", "#9D00FF",
        "#FF003C", "#FFE600", "#FF6600", "#FF006E",
        "#BFFF00", "#FFD700", "#4FC3F7", "#FFB74D"
    ];
    let hash = 0;
    for (let i = 0; i < seriesId.length; i++) {
        hash = ((hash << 5) - hash) + seriesId.charCodeAt(i);
        hash |= 0;
    }
    return ACCENTS[Math.abs(hash) % ACCENTS.length];
}
```

**Usage:** Called for every series card and series detail page to assign a consistent accent color. The color is used for borders, progress bars, headings, and visual identification.

**Algorithm:** DJB2 hash function, which provides good distribution for string inputs. The hash is mapped to one of 12 predefined neon colors.

#### stripMarkdownFormatting(text: string): string
Converts Reddit markdown to plain text for reader display and EPUB generation.

**Markdown handled:**
- `**bold**` → bold (stripped to plain text)
- `*italic*` → italic (stripped to plain text)
- `[link](url)` → link text (URL removed)
- `> quote` → quote (prefix removed)
- `# heading` → heading text (prefix removed)
- `- list item` → list item (prefix removed)
- `` `code` `` → code text (backticks removed)
- `~~~strikethrough~~~` → strikethrough text (tildes removed)
- Horizontal rules (`---`) → section break
- Empty lines → paragraph breaks

**Usage:** Called in ReaderScreen before rendering chapter text, and in EPUB generation before writing chapter content.

#### formatChapterTxt(chapter, series): string
Formats a single chapter as plain text for TXT export.

```javascript
function formatChapterTxt(chapter, series) {
    const lines = [];
    lines.push("═══════════════════════════════════════════════════════");
    lines.push(series.title.toUpperCase());
    lines.push("═══════════════════════════════════════════════════════");
    lines.push("");
    lines.push(`Chapter: ${chapter.title}`);
    lines.push(`Author: u/${chapter.author || "unknown"}`);
    lines.push(`Score: ${chapter.score || 0} upvotes`);
    lines.push("");
    lines.push(stripMarkdownFormatting(chapter.selftext || ""));
    return lines.join("\n");
}
```

#### formatMergedTxt(chapters, series): string
Formats multiple chapters into a single merged TXT file.

```javascript
function formatMergedTxt(chapters, series) {
    const lines = [];
    lines.push("═══════════════════════════════════════════════════════");
    lines.push(`${series.title.toUpperCase()} — COMPLETE`);
    lines.push(`${chapters.length} chapters`);
    lines.push("═══════════════════════════════════════════════════════");
    lines.push("");
    for (const ch of chapters) {
        const chNum = String(ch.orderIndex + 1).padStart(5, "0");
        lines.push("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        lines.push(`CHAPTER ${chNum}: ${ch.title.toUpperCase()}`);
        lines.push(`By u/${ch.author || "unknown"}`);
        lines.push(`▲ ${ch.score || 0} upvotes`);
        lines.push("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        lines.push("");
        lines.push(stripMarkdownFormatting(ch.selftext || ch.markdown || ""));
        lines.push("");
        lines.push("");
    }
    return lines.join("\n");
}
```

### createEpubBlob(title, author, chapters): Blob
Generates an EPUB file from chapter content using JSZip.

**EPUB structure:**
```
mimetype                        (uncompressed, first entry)
META-INF/
  container.xml                 (OPF file pointer)
OEBPS/
  content.opf                   (Package document)
  toc.ncx                       (Table of contents)
  chapter1.xhtml                (Chapter content)
  chapter2.xhtml
  ...
  style.css                     (Stylesheet)
  cover.xhtml                   (Cover page)
```

**Key implementation details:**
- `mimetype` file must be uncompressed and first in the zip
- XHTML content is properly escaped
- CSS provides basic readability styling
- NCX table of contents for e-reader navigation
- Metadata includes title, author, language, and unique identifier

### saveFile(dirHandle, fileName, content, seriesName, isFirstFile): Promise<{ok, method, path?, error?}>
Saves a file using the File System Access API or browser download fallback.

**Flow:**
1. If `dirHandle` exists (File System Access API):
   a. Get file handle from directory
   b. Create writable stream
   c. Write content
   d. Close stream
   e. Return `{ ok: true, method: "directory", path: fileName }`
2. If no `dirHandle` (browser download fallback):
   a. Create Blob from content
   b. Create object URL
   c. Create `<a>` element with `download` attribute
   d. Click the element
   e. Return `{ ok: true, method: "download" }`
3. On error: Return `{ ok: false, error: message }`

**Android native interface:**
If `window.AndroidFolderPicker.writeFile` exists, uses the native Java interface:
```javascript
window.AndroidFolderPicker.writeFile("ebook", fileName, textContent, seriesName || "");
```
This writes plain text (Java can't write binary EPUB).

### saveFileBlob(dirHandle, fileName, blob, seriesName, isFirstFile): Promise<{ok, method, path?, error?}>
Saves a Blob (binary data) using File System Access API or browser download.

Similar to `saveFile` but accepts a Blob instead of string content. Used for EPUB files which are binary.

---

## Appendix E: C-Fetch Deep Dive

### Rehash C-Fetch Complete Flow

The Rehash C-Fetch is the most complex operation in the app. Here's the complete flow:

#### 1. User clicks 📥 REHASH button (per-series)

```javascript
const runFetchCache = useCallback(async () => {
    // Validation
    if (!seriesId) { toast.error("No series selected"); return; }
    if (chapters.length === 0 && !startUrlInput.trim()) {
        toast.error("No chapters to fetch");
        return;
    }
    
    // Check if already running
    if (moduleFetchState.rehashRunning) {
        moduleFetchState.rehashAbort = true; // Second click = abort
        return;
    }
    
    // Initialize state
    moduleFetchState.rehashAbort = false;
    moduleFetchState.activeFetchSeries = seriesId;
    moduleFetchState.rehashRunning = true;
    moduleFetchState.rehashProgress = {
        done: 0,
        total: chapters.length,
        fetched: 0,
        changed: 0,
        errors: 0
    };
    
    // Add queue job
    const jobId = "rehash_" + seriesId + "_" + Date.now();
    moduleFetchState.rehashJobId = jobId;
    useDownloads.getState().addJob({
        id: jobId,
        seriesId: seriesId,
        seriesTitle: series?.title || seriesId,
        format: "REHASH",
        status: "running",
        progress: 0,
        completedChapters: 0,
        totalChapters: chapters.length,
        coverAccent: "#9D00FF"
    });
    
    // Build chapter list
    let chapterList = chapters.map(ch => ({
        id: ch.id,
        url: ch.redditPostUrl || `https://www.reddit.com/r/HFY/comments/${ch.id}/`
    }));
    
    // Get IDB helpers
    const { idbGet, idbSet } = await import('idb-cache');
    
    // Load existing hashes for change detection
    const existingHashes = {};
    await Promise.all(chapterList.map(async ch => {
        const cached = await idbGet(`hfy-chapter-cache-${ch.id}`);
        if (cached?.hash) existingHashes[ch.id] = cached.hash;
    }));
    
    // Fetch in batches
    const BATCH_SIZE = useSettings.getState().cFetchBatchSize || 5;
    const BATCH_DELAY = 300; // 300ms between batches (FX43 fix)
    const abortController = new AbortController();
    moduleFetchState.rehashAbortController = abortController;
    
    let fetched = 0, changed = 0, errors = 0;
    
    for (let batchStart = 0; batchStart < chapterList.length; batchStart += BATCH_SIZE) {
        if (moduleFetchState.rehashAbort) break;
        
        const batch = chapterList.slice(batchStart, Math.min(batchStart + BATCH_SIZE, chapterList.length));
        const batchChapters = batch.map(c => ({ ...c, existingHash: existingHashes[c.id] }));
        
        try {
            const res = await fetch(`/api/series/${encodeURIComponent(seriesId)}/fetch-cache`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ chapters: batchChapters, parallel: 3 }),
                signal: abortController.signal
            });
            
            if (!res.ok) throw new Error(`Server ${res.status}`);
            
            // Stream NDJSON response
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buffer = "";
            
            while (true) {
                if (moduleFetchState.rehashAbort) {
                    try { reader.cancel(); } catch {}
                    break;
                }
                
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split("\n");
                buffer = lines.pop() || "";
                
                for (const line of lines) {
                    if (!line.trim()) continue;
                    try {
                        const msg = JSON.parse(line);
                        
                        if (msg.type === "chapter") {
                            if (msg.error) {
                                errors++;
                            } else if (msg.selftext?.length > 0) {
                                // Save to IDB
                                await idbSet(`hfy-chapter-cache-${msg.postId}`, {
                                    postId: msg.postId,
                                    title: msg.title,
                                    author: msg.author,
                                    selftext: msg.selftext,
                                    selftextHtml: msg.selftextHtml,
                                    createdUtc: msg.createdUtc,
                                    score: msg.score,
                                    url: msg.url,
                                    permalink: msg.permalink,
                                    hash: msg.hash,
                                    cachedAt: Date.now()
                                });
                                
                                // Save to server
                                fetch(`/api/chapter-cache/${encodeURIComponent(msg.postId)}`, {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({
                                        postId: msg.postId,
                                        title: msg.title,
                                        author: msg.author,
                                        selftext: msg.selftext,
                                        selftextHtml: msg.selftextHtml,
                                        createdUtc: msg.createdUtc,
                                        score: msg.score,
                                        url: msg.url,
                                        permalink: msg.permalink,
                                        hash: msg.hash,
                                        cachedAt: Date.now()
                                    })
                                }).catch(() => {});
                                
                                // Save score to localStorage
                                if (msg.score > 0) {
                                    localStorage.setItem(`hfy-chapter-score-${msg.postId}`, String(msg.score));
                                }
                                
                                // Update React state
                                setChapters(prev => prev.map(c =>
                                    c.id === msg.postId
                                        ? { ...c, score: msg.score || 0, fetched: true }
                                        : c
                                ));
                                
                                fetched++;
                                if (msg.changed) changed++;
                            } else { errors++; }
                        } else if (msg.type === "progress") {
                            moduleFetchState.rehashProgress = {
                                done: batchStart + msg.done,
                                total: chapterList.length,
                                fetched: fetched + (msg.fetched ?? 0),
                                changed: changed + (msg.changed ?? 0),
                                errors: errors + (msg.errors ?? 0)
                            };
                            setFetchCacheProgress(moduleFetchState.rehashProgress);
                        }
                    } catch {}
                }
            }
        } catch (err) {
            if (err.name === 'AbortError') break;
            errors += batch.length;
        }
        
        // Update progress
        moduleFetchState.rehashProgress = {
            done: Math.min(batchStart + BATCH_SIZE, chapterList.length),
            total: chapterList.length,
            fetched,
            changed,
            errors
        };
        setFetchCacheProgress(moduleFetchState.rehashProgress);
        
        // Update queue job
        useDownloads.getState().updateJob(moduleFetchState.rehashJobId, {
            progress: moduleFetchState.rehashProgress.done / chapterList.length,
            completedChapters: fetched,
            totalChapters: chapterList.length
        });
        
        // Delay between batches
        if (batchStart + BATCH_SIZE < chapterList.length && !moduleFetchState.rehashAbort) {
            await new Promise(r => setTimeout(r, BATCH_DELAY));
        }
    }
    
    toast.success(`Cached ${fetched}/${chapterList.length} chapters${changed > 0 ? ` · ${changed} changed` : ""}${errors > 0 ? ` · ${errors} errors` : ""}`);
    
    // Cleanup
    moduleFetchState.rehashRunning = false;
    moduleFetchState.rehashAbort = false;
    moduleFetchState.rehashAbortController = null;
    moduleFetchState.rehashJobId = null;
    moduleFetchState.activeFetchSeries = null;
    moduleFetchState.rehashProgress = null;
    setFetchCacheRunning(false);
    setFetchCacheProgress(null);
})();
```

#### 2. Server-Side fetch-cache Route

The `/api/series/[slug]/fetch-cache` endpoint:

```javascript
async function POST(req, { params }) {
    const { slug } = await params;
    const body = await req.json();
    const chapters = body.chapters;
    const total = chapters.length;
    const parallel = Math.max(1, Math.min(Number(body.parallel) || 5, 10));
    
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
        async start(controller) {
            const sendLine = (obj) => {
                try { controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n")); } catch(e) {}
            };
            
            try {
                let done = 0, fetched = 0, changed = 0, errors = 0;
                
                sendLine({ type: "start", total, parallel, slug });
                
                // Process chapters with bounded concurrency
                const queue = [];
                let activeCount = 0;
                let nextIndex = 0;
                
                await new Promise((resolveAll) => {
                    let completed = 0;
                    
                    const launchNext = () => {
                        while (activeCount < parallel && nextIndex < total) {
                            const ch = chapters[nextIndex];
                            const idx = nextIndex;
                            nextIndex++;
                            activeCount++;
                            
                            fetchOneChapter(ch, idx).then((out) => {
                                sendLine(out);
                                done++;
                                
                                if (out.error) {
                                    errors++;
                                } else if (out.selftext && out.selftext.length > 0) {
                                    fetched++;
                                    if (out.changed) changed++;
                                    
                                    // Save to filesystem (async, non-blocking)
                                    try {
                                        const fs = require('fs');
                                        const path = require('path');
                                        const cacheDir = process.env.HFY_DATA_DIR
                                            ? path.join(process.env.HFY_DATA_DIR, "chapter-cache")
                                            : path.join(process.cwd(), "data", "chapter-cache");
                                        
                                        fs.promises.mkdir(cacheDir, { recursive: true }).catch(() => {});
                                        
                                        const safePostId = String(out.postId).replace(/[^a-zA-Z0-9_-]/g, "_");
                                        const cacheFile = path.join(cacheDir, `${safePostId}.json`);
                                        
                                        fs.promises.writeFile(cacheFile, JSON.stringify({
                                            postId: out.postId,
                                            title: out.title,
                                            author: out.author,
                                            selftext: out.selftext,
                                            selftextHtml: out.selftextHtml,
                                            createdUtc: out.createdUtc,
                                            score: out.score,
                                            url: out.url,
                                            permalink: out.permalink,
                                            hash: out.hash,
                                            cachedAt: Date.now()
                                        })).catch(() => {});
                                    } catch {}
                                } else {
                                    errors++;
                                }
                                
                                sendLine({
                                    type: "progress",
                                    done, total, fetched, changed, errors
                                });
                                
                                activeCount--;
                                completed++;
                                
                                if (completed === total) {
                                    resolveAll();
                                } else {
                                    launchNext();
                                }
                            }).catch(() => {
                                activeCount--;
                                completed++;
                                if (completed === total) resolveAll();
                                else launchNext();
                            });
                        }
                    };
                    
                    launchNext();
                });
                
                sendLine({ type: "summary", fetched, changed, errors });
                sendLine({ type: "done" });
                
            } catch (err) {
                sendLine({ type: "fatal", error: err?.message || "Internal error" });
            } finally {
                try { controller.close(); } catch(e) {}
            }
        }
    });
    
    return new Response(stream, {
        headers: {
            "Content-Type": "application/x-ndjson; charset=utf-8",
            "Cache-Control": "no-store, no-transform",
            "X-Accel-Buffering": "no"
        }
    });
}
```

### Continue C-Fetch Complete Flow

Continue C-Fetch fetches ONLY unfetched chapters (Phase 1). Phase 2 (discover new chapters) was removed in FX42.

#### Phase 1: Fetch Unfetched Chapters

```javascript
const runContinueFetch = useCallback(async () => {
    // ... validation ...
    
    // Find chapters that haven't been C-FETCHED yet
    const unfetchedChapters = chapters.filter(ch => !ch.fetched);
    
    if (unfetchedChapters.length > 0) {
        toast.info(`C-FETCHing ${unfetchedChapters.length} unfetched chapters...`);
        
        const chapterList = unfetchedChapters.map(ch => ({
            id: ch.id,
            url: ch.redditPostUrl || `https://www.reddit.com/r/HFY/comments/${ch.id}/`
        }));
        
        const continueAbortController = new AbortController();
        moduleFetchState.continueAbortController = continueAbortController;
        
        const CONTINUE_BATCH = useSettings.getState().cFetchBatchSize || 5;
        const CONTINUE_DELAY = 300; // 300ms between batches (FX43 fix)
        
        for (let bs = 0; bs < chapterList.length; bs += CONTINUE_BATCH) {
            if (moduleFetchState.continueAbort) break;
            
            const batch = chapterList.slice(bs, Math.min(bs + CONTINUE_BATCH, chapterList.length));
            
            try {
                const res = await fetch(`/api/series/${encodeURIComponent(seriesId)}/fetch-cache`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ chapters: batch, parallel: 3 }),
                    signal: continueAbortController.signal
                });
                
                // ... stream processing (same as Rehash) ...
                
            } catch (err) {
                if (err.name !== 'AbortError') console.error("[continue] fetch error:", err);
            }
            
            if (bs + CONTINUE_BATCH < chapterList.length && !moduleFetchState.continueAbort) {
                await new Promise(r => setTimeout(r, CONTINUE_DELAY));
            }
        }
        
        moduleFetchState.continueAbortController = null;
    }
    
    // FX43: Phase 2 removed — Continue C-Fetch STOPS after Phase 1
    toast.success(`C-FETCH complete: ${fetched}/${chapterList.length} chapters fetched`);
    
    // Cleanup
    moduleFetchState.continueRunning = false;
    // ...
}, [seriesId, chapters, startUrlInput, continueFetchRunning]);
```

---

## Appendix F: Download System Deep Dive

### Download Flow (Complete)

#### 1. User clicks MERGE INTO 1 FILE

```javascript
const handleDownload = async () => {
    // Validation
    if (!series || chapters.length === 0) {
        toast.error("No chapters to download");
        return;
    }
    
    // Check for existing running job
    const existingJobs = useDownloads.getState().jobs;
    const runningJob = existingJobs.find(j =>
        j.seriesId === seriesId && (j.status === "running" || j.status === "pending")
    );
    if (runningJob) {
        toast.info("A download/merge is already in progress for this series");
        return;
    }
    
    // Merge mode: verify all chapters are c-fetched
    if (downloadMode === "merge") {
        const unfetchedChapters = chapters.filter(c => !c.fetched && !downloadedChapters.has(c.id));
        if (unfetchedChapters.length > 0) {
            toast.error(`Cannot merge: ${unfetchedChapters.length} of ${chapters.length} chapters not c-fetched`);
            return;
        }
    }
    
    // Determine target chapters
    const allTargetChapters = downloadMode === "individual" && selectedChapterIds.size > 0
        ? chapters.filter(c => selectedChapterIds.has(c.id))
        : chapters;
    
    // Skip already downloaded (unless merge mode)
    const skipDownloaded = downloadMode !== "merge" && !(downloadMode === "individual" && selectedChapterIds.size > 0);
    const targetChapters = skipDownloaded
        ? allTargetChapters.filter(ch => !downloadedChapters.has(ch.id))
        : allTargetChapters;
    
    downloadAbortRef.current = false;
    setDownloading(true);
    setDownloadProgress({ done: 0, total: targetChapters.length });
    
    // Add queue job
    const jobId = `${seriesId}_${Date.now()}`;
    addJob({
        id: jobId,
        seriesId: seriesId || "",
        seriesTitle: series?.title || seriesId || "",
        format: downloadFormat,
        status: "running",
        progress: 0,
        totalChapters: targetChapters.length,
        completedChapters: 0,
        merge: downloadMode === "merge",
        coverAccent: accent
    });
    
    const allChapterContents = [];
    let savedCount = 0;
    let downloadCount = 0;
    
    try {
        // STEP 1: Check IDB cache
        for (let i = 0; i < targetChapters.length; i++) {
            if (downloadAbortRef.current) break;
            const ch = targetChapters[i];
            
            try {
                const cached = await idbGet(`hfy-chapter-cache-${ch.id}`);
                if (cached && cached.selftext && cached.selftext.length > 100) {
                    allChapterContents.push({
                        postId: cached.postId || ch.id,
                        title: cached.title || ch.title,
                        author: cached.author || "unknown",
                        selftext: cached.selftext,
                        createdUtc: cached.createdUtc || 0,
                        score: cached.score || ch.score || 0,
                        orderIndex: i
                    });
                    setDownloadProgress({ done: i + 1, total: targetChapters.length });
                }
            } catch {}
        }
        
        // STEP 2: Batch fetch missing chapters from API
        const missingChapters = targetChapters.filter(ch =>
            !allChapterContents.some(c => c.postId === ch.id)
        );
        
        if (missingChapters.length > 0) {
            const batchSize = downloadMode === "merge"
                ? Math.min(useSettings.getState().parallelDownloads || 5, 20)
                : useSettings.getState().parallelDownloads || 5;
            const MAX_RETRY_ATTEMPTS = 3;
            
            let pendingChapters = [...missingChapters];
            let attempt = 0;
            
            while (pendingChapters.length > 0 && attempt < MAX_RETRY_ATTEMPTS) {
                attempt++;
                const stillFailed = [];
                
                for (let i = 0; i < pendingChapters.length; i += batchSize) {
                    if (downloadAbortRef.current) break;
                    
                    const batch = pendingChapters.slice(i, i + batchSize);
                    
                    try {
                        const res = await fetch("/api/download", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                chapterIds: batch.map(c => c.id),
                                mode: downloadMode,
                                format: downloadFormat,
                                parallel: useSettings.getState().parallelDownloads || 5
                            })
                        });
                        
                        const data = await res.json();
                        
                        if (data.ok && data.chapters) {
                            allChapterContents.push(...data.chapters);
                            
                            // Update React state with fetched scores
                            for (const fetchedCh of data.chapters) {
                                setChapters(prev => prev.map(c =>
                                    c.id === fetchedCh.postId
                                        ? { ...c, score: fetchedCh.score || c.score || 0, fetched: true }
                                        : c
                                ));
                            }
                        } else {
                            stillFailed.push(...batch);
                        }
                    } catch (err) {
                        stillFailed.push(...batch);
                    }
                    
                    setDownloadProgress({
                        done: allChapterContents.length,
                        total: targetChapters.length
                    });
                }
                
                pendingChapters = stillFailed;
                
                // Exponential backoff between retries
                if (pendingChapters.length > 0 && attempt < MAX_RETRY_ATTEMPTS && !downloadAbortRef.current) {
                    const backoffMs = 500 * Math.pow(2, attempt - 1);
                    await new Promise(r => setTimeout(r, backoffMs));
                }
            }
        }
        
        // Re-sort to match series chapter order
        allChapterContents.sort((a, b) => {
            const aOrder = chapterOrderMap.get(normalizeId(a.postId)) ?? 999999;
            const bOrder = chapterOrderMap.get(normalizeId(b.postId)) ?? 999999;
            return aOrder - bOrder;
        });
        
        // Generate EPUB files
        if (downloadMode === "individual" || downloadMode === "all") {
            // Save each chapter as individual EPUB
            for (const ch of allChapterContents) {
                if (downloadAbortRef.current) break;
                
                const fileName = `${String(ch.orderIndex + 1).padStart(5, "0")}. ${series.title} - ${ch.title}.epub`;
                const epubBlob = createEpubBlob(ch.title, ch.author, [{
                    title: ch.title,
                    content: stripMarkdownFormatting(ch.selftext)
                }]);
                
                const result = await saveFileBlob(dirHandle, fileName, epubBlob, series.title, firstFile);
                firstFile = false;
                
                if (result.ok) {
                    if (result.method === "directory") savedCount++;
                    else downloadCount++;
                }
                
                // Update queue progress
                setDownloadProgress({ done: savedCount + downloadCount, total: allChapterContents.length });
                useDownloads.getState().updateJob(jobId, {
                    progress: (savedCount + downloadCount) / allChapterContents.length,
                    completedChapters: savedCount + downloadCount
                });
            }
        } else {
            // Merge mode: save single EPUB
            const merged = formatMergedTxt(allChapterContents, series);
            const epubBlob = createEpubBlob(series.title, allChapterContents[0]?.author || "unknown",
                allChapterContents.map(ch => ({
                    title: ch.title,
                    content: stripMarkdownFormatting(ch.selftext)
                }))
            );
            
            const result = await saveFileBlob(ebookDirHandle, `${series.title} - Complete.epub`, epubBlob);
            
            if (result.ok) {
                // Save merged content to IDB and server
                await idbSet(`hfy-merged-${seriesId}`, {
                    content: merged,
                    title: series.title,
                    chapterCount: allChapterContents.length,
                    createdAt: Date.now()
                });
                
                fetch(`/api/store/hfy-merged-content-${seriesId}`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        content: merged,
                        title: series.title,
                        chapterCount: allChapterContents.length,
                        createdAt: Date.now()
                    })
                }).catch(() => {});
            }
        }
        
        // Mark chapters as downloaded (only if save succeeded)
        if (savedCount > 0 || downloadCount > 0 || (downloadMode === "merge" && mergeResult.ok)) {
            const newlyDownloaded = new Set(downloadedChapters);
            for (const ch of allChapterContents) {
                newlyDownloaded.add(ch.postId);
            }
            setDownloadedChapters(newlyDownloaded);
            saveDownloadedChapters(newlyDownloaded);
        }
        
    } catch (err) {
        toast.error(`Download failed: ${err.message}`);
        useDownloads.getState().updateJob(jobId, { status: "error", errorMessage: err.message });
    } finally {
        setDownloading(false);
        setDownloadProgress(null);
        const totalSaved = savedCount + downloadCount;
        useDownloads.getState().updateJob(jobId, {
            status: totalSaved > 0 ? "done" : "error",
            progress: totalSaved > 0 ? 1 : 0,
            completedChapters: totalSaved
        });
    }
};
```

---

## Appendix G: Auto-Discover Pipeline Deep Dive

The auto-discover system uses a multi-stage pipeline to find missing chapters.

### Stage 1: Cache
Load previously discovered chapters from local storage and server.

### Stage 2: Wayback
Check Wayback Machine for archived wiki page snapshots.

```javascript
async function fetchFromWayback(slug) {
    const wikiUrl = `https://www.reddit.com/r/HFY/wiki/series/${slug}`;
    const waybackApi = `https://archive.org/wayback/available?url=${encodeURIComponent(wikiUrl)}`;
    
    const res = await fetch(waybackApi);
    const data = await res.json();
    
    if (data.archived_snapshots && data.archived_snapshots.closest) {
        const snapshotUrl = data.archived_snapshots.closest.url;
        const snapshotRes = await fetch(snapshotUrl);
        const html = await snapshotRes.text();
        
        // Parse HTML for chapter links
        return parseWikiHtml(html);
    }
    
    return [];
}
```

### Stage 3: HFY Foundation
Search hfy.foundation for the series.

```javascript
async function fetchFromHfyFoundation(seriesName) {
    const res = await fetch(`/api/hfy-foundation-search?search=${encodeURIComponent(seriesName)}`);
    const data = await res.json();
    
    if (data.ok && data.results) {
        return data.results.map(r => ({
            title: r.title,
            url: r.url,
            postId: extractPostId(r.url)
        }));
    }
    
    return [];
}
```

### Stage 4: RSS Crawl
BFS crawl following next-chapter links via RSS.

```javascript
async function rssCrawl(startUrl, maxChapters, processedPostIds) {
    const discovered = [];
    let currentUrl = startUrl;
    const visited = new Set();
    
    while (currentUrl && discovered.length < maxChapters) {
        const postId = extractPostId(currentUrl);
        if (visited.has(postId)) break;
        visited.add(postId);
        
        // Fetch via RSS (always available)
        const rssUrl = currentUrl.replace(/\/$/, "") + ".rss";
        const res = await fetch(rssUrl);
        const xml = await res.text();
        
        // Parse RSS for next-chapter links
        const nextLinks = parseRssForNextLinks(xml);
        
        if (nextLinks.length === 0) break;
        
        // Find unvisited next link
        const nextLink = nextLinks.find(link => !visited.has(extractPostId(link)));
        if (!nextLink) break;
        
        currentUrl = nextLink;
        discovered.push({ url: currentUrl, postId });
    }
    
    return discovered;
}
```

### Stage 5: WB Crawl
Crawl via archived Reddit snapshots on archive.org.

### Stage 6: JSON Crawl
Crawl via Reddit JSON API using easy-reddit-downloader method.

### Stage 7: Reddit Search
Search r/HFY for the series name to find newest chapters.

```javascript
async function searchRedditForChapters(seriesName, missingNumbers) {
    const results = [];
    
    for (const num of missingNumbers) {
        const queries = [
            `${seriesName} part ${num}`,
            `${seriesName} chapter ${num}`,
            `${seriesName} ${num}`
        ];
        
        for (const query of queries) {
            try {
                const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&subreddit=HFY`);
                const data = await res.json();
                
                if (data.ok && data.results) {
                    for (const result of data.results) {
                        const title = result.title.toLowerCase();
                        const partMatch = title.match(/part\s+(\d+)/);
                        const chapterMatch = title.match(/chapter\s+(\d+)/);
                        
                        if ((partMatch && parseInt(partMatch[1]) === num) ||
                            (chapterMatch && parseInt(chapterMatch[1]) === num)) {
                            results.push({
                                title: result.title,
                                url: result.url,
                                postId: result.id,
                                chapterNumber: num
                            });
                            break;
                        }
                    }
                }
            } catch {}
            
            await new Promise(r => setTimeout(r, 2000)); // Rate limit
        }
    }
    
    return results;
}
```

### Resume Capability

The `processedPostIds` set is persisted after each stage:

```javascript
// After each stage, save processedPostIds
await saveImportedChapters(slug, knownChapters, {
    processedPostIds: Array.from(new Set([
        ...(cached?.processedPostIds ?? []),
        ...stageProcessed
    ]))
});
```

This ensures that re-running auto-discover doesn't re-process already-discovered chapters.

---

*End of manual. Total content: ~28,000 words covering every aspect of the HFY NEKROCODEXXX FX43 v9 application.*

---

## Appendix H: Complete CSS Theme System

The app uses a comprehensive theme system with CSS custom properties that are dynamically applied based on the selected theme.

### Theme Application

When a user selects a theme, the `useSettings` store updates and the root element's CSS variables are changed:

```javascript
const APP_THEMES = {
    NIGHT_CITY: {
        name: "NIGHT CITY",
        primary: "#00FFF0",
        accent: "#00FF88",
        background: "#050608",
        surface: "#0a0d12",
        border: "#1f2937",
        text: "#f5f8ff",
        textDim: "#6b7a8d",
        glowPrimary: "0 0 10px #00FFF066",
        glowAccent: "0 0 10px #00FF8866"
    },
    ARASAKA_NET: {
        name: "ARASAKA NET",
        primary: "#FF003C",
        accent: "#FFE600",
        background: "#0a0000",
        surface: "#1a0505",
        border: "#330000",
        text: "#ffcccc",
        textDim: "#996666",
        glowPrimary: "0 0 10px #FF003C66",
        glowAccent: "0 0 10px #FFE60066"
    },
    // ... 10 more themes
};
```

### CyberButton Component

The `CyberButton` component applies theme colors dynamically:

```javascript
function CyberButton({ children, variant, size, onClick, disabled, style, className, title }) {
    const appTheme = useSettings(s => s.appTheme);
    const theme = APP_THEMES[appTheme];
    
    const variants = {
        primary: {
            background: `${theme.primary}22`,
            border: `1px solid ${theme.primary}`,
            color: theme.primary,
            boxShadow: `0 0 10px ${theme.primary}33`
        },
        ghost: {
            background: 'transparent',
            border: `1px solid ${theme.border}`,
            color: theme.textDim
        },
        accent: {
            background: `${theme.accent}22`,
            border: `1px solid ${theme.accent}`,
            color: theme.accent
        }
    };
    
    const sizes = {
        sm: { padding: '4px 8px', fontSize: '10px' },
        md: { padding: '8px 16px', fontSize: '12px' },
        lg: { padding: '12px 24px', fontSize: '14px' }
    };
    
    return (
        <motion.button
            whileHover={{ scale: disabled ? 1 : 1.02 }}
            whileTap={{ scale: disabled ? 1 : 0.98 }}
            onClick={onClick}
            disabled={disabled}
            className={`font-mono uppercase tracking-widest transition-all ${className || ''}`}
            style={{
                ...variants[variant || 'primary'],
                ...sizes[size || 'md'],
                ...style,
                clipPath: 'polygon(0 0, calc(100% - 4px) 0, 100% 100%, 4px 100%)',
                cursor: disabled ? 'not-allowed' : 'pointer',
                opacity: disabled ? 0.5 : 1
            }}
            title={title}
        >
            {children}
        </motion.button>
    );
}
```

### CyberPanel Component

The `CyberPanel` component provides a themed container:

```javascript
function CyberPanel({ children, className, accent, active, style }) {
    const appTheme = useSettings(s => s.appTheme);
    const theme = APP_THEMES[appTheme];
    const accentColor = accent || theme.primary;
    
    return (
        <div
            className={className}
            style={{
                background: `${theme.surface}cc`,
                border: `1px solid ${accentColor}33`,
                backdropFilter: 'blur(10px)',
                boxShadow: active
                    ? `0 0 20px ${accentColor}22, inset 0 0 20px ${accentColor}08`
                    : `inset 0 0 20px ${accentColor}05`,
                clipPath: 'polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 8px 100%, 0 calc(100% - 8px))',
                ...style
            }}
        >
            {children}
        </div>
    );
}
```

### CyberProgress Component

The `CyberProgress` component shows a themed progress bar:

```javascript
function CyberProgress({ value, color, height }) {
    const appTheme = useSettings(s => s.appTheme);
    const theme = APP_THEMES[appTheme];
    const progressColor = color || theme.primary;
    
    return (
        <div
            style={{
                width: '100%',
                height: height || 4,
                background: `${theme.background}`,
                border: `1px solid ${progressColor}22`,
                overflow: 'hidden',
                clipPath: 'polygon(0 0, calc(100% - 2px) 0, 100% 100%, 2px 100%)'
            }}
        >
            <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(1, Math.max(0, value)) * 100}%` }}
                transition={{ duration: 0.3 }}
                style={{
                    height: '100%',
                    background: `linear-gradient(90deg, ${progressColor}88, ${progressColor})`,
                    boxShadow: `0 0 8px ${progressColor}66`
                }}
            />
        </div>
    );
}
```

---

## Appendix I: EPUB Generation Deep Dive

### EPUB Structure

An EPUB file is a ZIP archive with a specific structure:

```
mimetype                        → "application/epub+zip" (uncompressed, first entry)
META-INF/
  container.xml                 → Points to content.opf
OEBPS/
  content.opf                   → Package document (metadata, manifest, spine)
  toc.ncx                       → Table of contents (NCX format)
  cover.xhtml                   → Cover page
  chapter1.xhtml                → Chapter 1 content
  chapter2.xhtml                → Chapter 2 content
  ...
  style.css                     → Stylesheet
```

### createEpubBlob Implementation

```javascript
function createEpubBlob(title, author, chapters) {
    const zip = new JSZip();
    
    // 1. mimetype (must be first, uncompressed)
    zip.file("mimetype", "application/epub+zip", { compression: "STORE" });
    
    // 2. META-INF/container.xml
    zip.file("META-INF/container.xml", `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`);
    
    // 3. OEBPS/content.opf (Package document)
    const manifestItems = chapters.map((ch, i) =>
        `<item id="chapter${i + 1}" href="chapter${i + 1}.xhtml" media-type="application/xhtml+xml"/>`
    ).join("\n    ");
    
    const spineItems = chapters.map((ch, i) =>
        `<itemref idref="chapter${i + 1}"/>`
    ).join("\n    ");
    
    zip.file("OEBPS/content.opf", `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="BookId">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:title>${escapeXml(title)}</dc:title>
    <dc:creator>${escapeXml(author)}</dc:creator>
    <dc:language>en</dc:language>
    <dc:identifier id="BookId">hfy-${Date.now()}</dc:identifier>
  </metadata>
  <manifest>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/>
    ${manifestItems}
    <item id="css" href="style.css" media-type="text/css"/>
  </manifest>
  <spine toc="ncx">
    <itemref idref="cover"/>
    ${spineItems}
  </spine>
</package>`);
    
    // 4. OEBPS/toc.ncx (Table of Contents)
    const navPoints = chapters.map((ch, i) => `
    <navPoint id="navpoint${i + 2}" playOrder="${i + 2}">
      <navLabel>
        <text>${escapeXml(ch.title || `Chapter ${i + 1}`)}</text>
      </navLabel>
      <content src="chapter${i + 1}.xhtml"/>
    </navPoint>`).join("");
    
    zip.file("OEBPS/toc.ncx", `<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="hfy-${Date.now()}"/>
  </head>
  <docTitle>
    <text>${escapeXml(title)}</text>
  </docTitle>
  <navMap>
    <navPoint id="navpoint1" playOrder="1">
      <navLabel>
        <text>Cover</text>
      </navLabel>
      <content src="cover.xhtml"/>
    </navPoint>${navPoints}
  </navMap>
</ncx>`);
    
    // 5. OEBPS/cover.xhtml
    zip.file("OEBPS/cover.xhtml", `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>${escapeXml(title)}</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body class="cover">
  <h1>${escapeXml(title)}</h1>
  <p>by ${escapeXml(author)}</p>
  <p>${chapters.length} chapters</p>
</body>
</html>`);
    
    // 6. Chapter XHTML files
    chapters.forEach((ch, i) => {
        const content = stripMarkdownFormatting(ch.content || "");
        const paragraphs = content.split(/\n\n+/).map(p =>
            `    <p>${escapeXml(p).replace(/\n/g, "<br/>")}</p>`
        ).join("\n");
        
        zip.file(`OEBPS/chapter${i + 1}.xhtml`, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>${escapeXml(ch.title || `Chapter ${i + 1}`)}</title>
  <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
  <h2>${escapeXml(ch.title || `Chapter ${i + 1}`)}</h2>
${paragraphs}
</body>
</html>`);
    });
    
    // 7. OEBPS/style.css
    zip.file("OEBPS/style.css", `body {
  font-family: Georgia, serif;
  line-height: 1.6;
  margin: 1em;
  color: #333;
}
h1, h2 {
  font-family: Arial, sans-serif;
  color: #1a1a1a;
}
h1 { font-size: 1.8em; text-align: center; }
h2 { font-size: 1.4em; margin-top: 1.5em; }
p { margin: 0.8em 0; text-indent: 1.5em; }
p:first-of-type { text-indent: 0; }
.cover { text-align: center; padding-top: 3em; }
.cover h1 { font-size: 2.5em; margin-bottom: 0.5em; }
.cover p { font-size: 1.2em; color: #666; text-indent: 0; }`);
    
    return zip.generateAsync({ type: "blob", mimeType: "application/epub+zip" });
}

function escapeXml(text) {
    if (!text) return "";
    return String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}
```

---

## Appendix J: IndexedDB Cache System

### IDB Helper Functions

```javascript
// idb-cache.ts

const DB_NAME = "hfy-nekrocodex";
const DB_VERSION = 1;
const STORE_NAME = "keyval";

let dbPromise = null;

function getDB() {
    if (dbPromise) return dbPromise;
    
    dbPromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };
        
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
    
    return dbPromise;
}

export async function idbGet(key) {
    try {
        const db = await getDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readonly");
            const store = tx.objectStore(STORE_NAME);
            const request = store.get(key);
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => reject(request.error);
        });
    } catch (e) {
        return null;
    }
}

export async function idbSet(key, value) {
    try {
        const db = await getDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);
            const request = store.put(value, key);
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    } catch (e) {
        return false;
    }
}

export async function idbDelete(key) {
    try {
        const db = await getDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);
            const request = store.delete(key);
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    } catch (e) {
        return false;
    }
}

export async function idbClearAll() {
    try {
        const db = await getDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, "readwrite");
            const store = tx.objectStore(STORE_NAME);
            const request = store.clear();
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    } catch (e) {
        return false;
    }
}
```

### IDB Keys

The following keys are used in IndexedDB:

| Key Pattern | Content | Size per entry |
|-------------|---------|----------------|
| `hfy-chapter-cache-[postId]` | Chapter content (selftext, title, author, score, hash) | 5-50KB |
| `hfy-series-cache-v3-[seriesId]` | Series chapter list | 1-10KB |
| `hfy-merged-[seriesId]` | Merged file content | 100KB-10MB |
| `hfy-read-chapters` | Read chapter tracking | 1-50KB |

---

## Appendix K: Reddit OAuth Integration

### OAuth Flow (PKCE)

The app uses Reddit's OAuth 2.0 with PKCE (Proof Key for Code Exchange) for secure authentication.

#### Step 1: Generate PKCE Verifier and Challenge

```javascript
function generatePKCE() {
    const verifier = base64url(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = base64url(
        crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))
    );
    return { verifier, challenge };
}

function base64url(buffer) {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');
}
```

#### Step 2: Redirect to Reddit

```javascript
// /api/reddit-auth
const { verifier, challenge } = generatePKCE();
const state = generateRandomString();

// Store verifier and state for callback
sessionStorage.setItem('pkce_verifier', verifier);
sessionStorage.setItem('oauth_state', state);

const authUrl = new URL('https://www.reddit.com/api/v1/authorize');
authUrl.searchParams.set('client_id', clientId);
authUrl.searchParams.set('response_type', 'code');
authUrl.searchParams.set('state', state);
authUrl.searchParams.set('redirect_uri', redirectUri);
authUrl.searchParams.set('duration', 'permanent');
authUrl.searchParams.set('scope', 'read identity');
authUrl.searchParams.set('code_challenge', challenge);
authUrl.searchParams.set('code_challenge_method', 'S256');

return NextResponse.json({
    ok: true,
    authUrl: authUrl.toString(),
    state,
    codeVerifier: verifier
});
```

#### Step 3: Handle Callback

```javascript
// /reddit-callback page
useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state');
    const expectedState = sessionStorage.getItem('oauth_state');
    
    if (state !== expectedState) {
        setError('State mismatch — possible CSRF attack');
        return;
    }
    
    const codeVerifier = sessionStorage.getItem('pkce_verifier');
    
    // Exchange code for token
    fetch('/api/reddit-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, codeVerifier, redirectUri })
    })
    .then(r => r.json())
    .then(data => {
        if (data.ok) {
            // Store token
            useRedditAuth.getState().setUserToken(
                data.accessToken,
                data.expiresIn,
                data.refreshToken
            );
            setStatus('success');
            setTimeout(() => window.close(), 2000);
        }
    });
}, []);
```

#### Step 4: Token Exchange

```javascript
// /api/reddit-token
async function POST(req) {
    const { code, codeVerifier, redirectUri } = await req.json();
    
    const res = await fetch('https://www.reddit.com/api/v1/access_token', {
        method: 'POST',
        headers: {
            'Authorization': `Basic ${Buffer.from(`${clientId}:`).toString('base64')}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            grant_type: 'authorization_code',
            code,
            redirect_uri: redirectUri,
            code_verifier: codeVerifier
        }),
        signal: AbortSignal.timeout(15000) // FX43 fix
    });
    
    const data = await res.json();
    
    return NextResponse.json({
        ok: true,
        accessToken: data.access_token,
        expiresIn: data.expires_in,
        refreshToken: data.refresh_token
    });
}
```

### App-Only OAuth (Anonymous)

For anonymous access (Quick Connect), the app uses the client_credentials grant type:

```javascript
// /api/reddit-app-token
let cached = null;

async function GET() {
    // Check cache
    if (cached && cached.expiresAt > Date.now() + 60000) {
        return NextResponse.json({
            ok: true,
            accessToken: cached.token,
            expiresIn: Math.floor((cached.expiresAt - Date.now()) / 1000)
        });
    }
    
    // Fetch new token
    const res = await fetch('https://www.reddit.com/api/v1/access_token', {
        method: 'POST',
        headers: {
            'Authorization': `Basic ${Buffer.from('frGEUVAuHGL2PQ:').toString('base64')}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            grant_type: 'client_credentials'
        }),
        signal: AbortSignal.timeout(15000)
    });
    
    const data = await res.json();
    
    cached = {
        token: data.access_token,
        expiresAt: Date.now() + (data.expires_in * 1000)
    };
    
    return NextResponse.json({
        ok: true,
        accessToken: data.access_token,
        expiresIn: data.expires_in
    });
}
```

### Multi-Account Token Rotation

For power users, the app supports up to 9 Reddit accounts with automatic token rotation:

```javascript
// /api/reddit-multi-token

// POST: Sync accounts
async function POST(req) {
    const body = await req.json();
    const accounts = body.accounts || [];
    
    const store = getTokenStore();
    store.clear();
    
    for (const acc of accounts) {
        if (acc.clientId === "cookies" || acc.clientId === "cookie-injection") continue;
        if (acc.accessToken && acc.id) {
            store.set(acc.id, {
                accessToken: acc.accessToken,
                refreshToken: acc.refreshToken || "",
                expiresAt: acc.expiresAt || 0,
                clientId: acc.clientId || "frGEUVAuHGL2PQ",
                username: acc.username || "unknown"
            });
        }
    }
    
    return NextResponse.json({
        ok: true,
        accountCount: store.size
    });
}

// GET: Get next token (round-robin)
async function GET() {
    const store = getTokenStore();
    const accounts = Array.from(store.values());
    
    if (accounts.length === 0) {
        return NextResponse.json({ ok: false, error: "No tokens available" });
    }
    
    const idx = (global.redditTokenRotationIndex || 0) % accounts.length;
    global.redditTokenRotationIndex = idx + 1;
    
    const tokenData = accounts[idx];
    
    // Check if token is expired
    if (tokenData.expiresAt && tokenData.expiresAt < Date.now()) {
        // Try to refresh
        if (tokenData.refreshToken) {
            try {
                const refreshRes = await fetch('https://www.reddit.com/api/v1/access_token', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Basic ${Buffer.from(`${tokenData.clientId}:`).toString('base64')}`,
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        grant_type: 'refresh_token',
                        refresh_token: tokenData.refreshToken
                    })
                });
                
                const refreshData = await refreshRes.json();
                
                if (refreshData.access_token) {
                    tokenData.accessToken = refreshData.access_token;
                    tokenData.expiresAt = Date.now() + (refreshData.expires_in * 1000);
                    store.set(tokenData.id || idx, tokenData);
                }
            } catch {}
        }
    }
    
    return NextResponse.json({
        ok: true,
        token: tokenData.accessToken,
        username: tokenData.username,
        expiresIn: tokenData.expiresAt ? Math.floor((tokenData.expiresAt - Date.now()) / 1000) : 0
    });
}
```

---

## Appendix L: Wayback Machine Integration

The app integrates with the Internet Archive's Wayback Machine for archived Reddit content.

### Wayback Availability Check

```javascript
async function checkWayback(url) {
    const apiUrl = `https://archive.org/wayback/available?url=${encodeURIComponent(url)}`;
    
    try {
        const res = await fetch(apiUrl, { signal: AbortSignal.timeout(10000) });
        const data = await res.json();
        
        if (data.archived_snapshots && data.archived_snapshots.closest) {
            return {
                available: true,
                url: data.archived_snapshots.closest.url,
                timestamp: data.archived_snapshots.closest.timestamp
            };
        }
    } catch {}
    
    return { available: false };
}
```

### Wayback Crawl

The WB CRAWL feature fetches archived Reddit snapshots:

```javascript
async function waybackCrawl(slug, startUrl, maxChapters) {
    const discovered = [];
    let currentUrl = startUrl;
    const visited = new Set();
    
    while (currentUrl && discovered.length < maxChapters) {
        const postId = extractPostId(currentUrl);
        if (visited.has(postId)) break;
        visited.add(postId);
        
        // Get Wayback snapshot
        const wayback = await checkWayback(currentUrl);
        if (!wayback.available) break;
        
        // Fetch archived page
        const res = await fetch(wayback.url);
        const html = await res.text();
        
        // Parse for chapter content and next links
        const content = parseRedditHtml(html);
        if (content) {
            discovered.push({
                postId,
                title: content.title,
                selftext: content.selftext,
                url: currentUrl,
                score: content.score
            });
        }
        
        // Find next chapter link
        const nextLinks = parseHtmlForNextLinks(html, slug);
        const nextLink = nextLinks.find(link => !visited.has(extractPostId(link)));
        if (!nextLink) break;
        
        currentUrl = nextLink;
        await new Promise(r => setTimeout(r, 1000)); // Rate limit
    }
    
    return discovered;
}
```

---

## Appendix M: CORS Proxy Pool Details

### Proxy List

The app maintains a list of 386 community-maintained CORS proxy servers. These are loaded from a hardcoded list in `cors-proxies.ts`:

```javascript
const PROXY_LIST = [
    "https://corsproxy.io/?",
    "https://api.allorigins.win/raw?url=",
    "https://cors-anywhere.herokuapp.com/",
    "https://proxy.cors.sh/",
    // ... 382 more
];
```

### Health Checking

Every 5 minutes, each proxy is health-checked:

```javascript
async function healthCheckProxies() {
    const testUrl = "https://www.reddit.com/r/HFY.json";
    
    for (const proxy of PROXY_LIST) {
        try {
            const start = Date.now();
            const res = await fetch(proxy + encodeURIComponent(testUrl), {
                signal: AbortSignal.timeout(5000)
            });
            const latency = Date.now() - start;
            
            if (res.ok) {
                proxyPool.set(proxy, {
                    status: 'alive',
                    latency,
                    lastChecked: Date.now()
                });
            } else if (res.status === 403) {
                proxyPool.set(proxy, {
                    status: 'banned',
                    latency: 0,
                    lastChecked: Date.now()
                });
            } else {
                proxyPool.set(proxy, {
                    status: 'dead',
                    latency: 0,
                    lastChecked: Date.now()
                });
            }
        } catch {
            proxyPool.set(proxy, {
                status: 'dead',
                latency: 0,
                lastChecked: Date.now()
            });
        }
    }
}

setInterval(healthCheckProxies, 300000); // Every 5 minutes
healthCheckProxies(); // Initial check
```

### Proxy Selection

When a request needs a proxy, the pool selects the best available:

```javascript
function getBestProxy() {
    const alive = Array.from(proxyPool.entries())
        .filter(([_, info]) => info.status === 'alive')
        .sort((a, b) => a[1].latency - b[1].latency);
    
    return alive.length > 0 ? alive[0][0] : null;
}

async function fetchViaProxy(url, maxRetries = 3) {
    for (let i = 0; i < maxRetries; i++) {
        const proxy = getBestProxy();
        if (!proxy) break;
        
        try {
            const res = await fetch(proxy + encodeURIComponent(url), {
                signal: AbortSignal.timeout(10000)
            });
            
            if (res.ok) return res;
            if (res.status === 403) {
                proxyPool.get(proxy).status = 'banned';
            }
        } catch {
            proxyPool.get(proxy).status = 'dead';
        }
    }
    
    return null;
}
```

---

## Appendix N: Complete Settings Reference

### All Settings with Defaults and Ranges

| Setting | Default | Range | Store | Description |
|---------|---------|-------|-------|-------------|
| appTheme | NIGHT_CITY | 12 themes | useSettings | UI color scheme |
| readerTheme | VOID | 24 themes | useSettings | Reader color scheme |
| readerFont | Source Serif 4 | 24 fonts | useSettings | Reader font family |
| fontSize | 18 | 14-32 | useSettings | Reader font size (px) |
| lineSpacing | 1.7 | 1.0-2.5 | useSettings | Reader line height |
| preloadChapters | 3 | 0-10 | useSettings | Chapters to preload |
| parallelDownloads | 5 | 1-20 | useSettings | Concurrent download fetches |
| cFetchBatchSize | 5 | 1-500 | useSettings | C-Fetch batch size |
| autoUpdateInterval | 24h | 1h/24h/72h | useSettings | Auto-discover interval |
| bgOpacity | 0.12 | 0-1 | useSettings | Background opacity |
| glitchEnabled | true | boolean | useSettings | Glitch effect |
| animatedCorners | true | boolean | useSettings | Animated corners |
| bgParticles | true | boolean | useSettings | Background particles |
| scanlineOpacity | 0.35 | 0-1 | useSettings | Scanline overlay |
| glowIntensity | 0.7 | 0-1 | useSettings | Glow strength |
| bgChangeInterval | OFF | OFF/30s/60s | useSettings | BG rotation interval |
| customSearchOrder | [] | max 25 | useSettings | Auto-discover stage order |
| dirHandle | null | FileHandle | localStorage | Download folder handle |
| ebookDirHandle | null | FileHandle | localStorage | Ebook folder handle |
| importDirHandle | null | FileHandle | localStorage | Import folder handle |

### Reddit Auth Settings (useRedditAuth Store)

| Setting | Default | Description |
|---------|---------|-------------|
| appAccessToken | null | Anonymous OAuth token |
| appTokenExpiresAt | 0 | Token expiry timestamp |
| userAccessToken | null | User OAuth token |
| userTokenExpiresAt | 0 | User token expiry |
| userRefreshToken | null | Refresh token |
| isAuthenticated | false | Is user authenticated |
| redditUsername | null | Reddit username |
| multiAccountTokens | [] | Up to 9 account tokens |

---

## Appendix O: Glossary

**C-Fetch** — Content Fetch. The app's system for pre-fetching chapter content from Reddit and caching it locally.

**Rehash C-Fetch** — Re-fetches ALL chapters in a series, comparing hashes to detect changes.

**Continue C-Fetch** — Fetches ONLY unfetched chapters, then stops.

**NDJSON** — Newline-Delimited JSON. A streaming format where each line is a valid JSON object.

**QPM** — Queries Per Minute. Reddit's rate limit metric.

**PKCE** — Proof Key for Code Exchange. A security extension to OAuth 2.0.

**SSRF** — Server-Side Request Forgery. A security vulnerability where an attacker tricks the server into making requests to internal resources.

**CORS** — Cross-Origin Resource Sharing. A browser security mechanism that restricts cross-origin requests.

**EPUB** — Electronic Publication. An e-book file format.

**IndexedDB** — A browser-based NoSQL database for storing structured data.

**Zustand** — A lightweight React state management library.

**AbortController** — A browser API for aborting fetch requests.

**ReadableStream** — A browser API for streaming data from a source.

**BFS** — Breadth-First Search. A graph traversal algorithm used by the crawler.

**HFY** — Humanity, Fuck Yeah! A subreddit genre where humanity is portrayed positively.

**r/HFY** — The Reddit community for HFY stories.

**HFY Foundation** — A community-maintained index of HFY series at hfy.foundation.

**Wayback Machine** — The Internet Archive's web archiving service at web.archive.org.

**DJB2** — A hash function used for deterministic accent color assignment.

**SHA-256** — A cryptographic hash function used for content change detection.

---

*End of complete manual. HFY NEKROCODEXXX FX43 v9 — 2026-07-23 — ~28,000 words.*

---

## Appendix P: Complete Component Tree

The app's React component tree is organized as follows:

```
<App>
├── <AppHeader />                          # Top header (logo, series count, cache stats)
├── <Navigation>                           # Bottom navigation bar
│   ├── <NavButton screen="browse" />      # BROWSE tab
│   ├── <NavButton screen="library" />     # LIBRARY tab
│   ├── <NavButton screen="queue" />       # QUEUE tab
│   └── <NavButton screen="settings" />    # SETTINGS tab
├── <Toaster />                            # Toast notification container
├── {screen === "browse" && <BrowseScreen />}
├── {screen === "library" && <LibraryScreen />}
├── {screen === "queue" && <QueueScreen />}
├── {screen === "settings" && <SettingsScreen />}
├── {screen === "seriesDetail" && <SeriesDetailScreen />}
└── {screen === "reader" && <ReaderScreen />}
```

### BrowseScreen Component Tree

```
<BrowseScreen>
├── <header>                               # Sticky header
│   ├── <h1>HFY NEKROCODEXXX</h1>          # Logo
│   ├── <span>{seriesCount} SERIES</span>  # Series count
│   ├── <span>{cachedCount}/386</span>     # Cache stats
│   ├── <div>CACHED indicator</div>
│   ├── <div>                              # Sort buttons row
│   │   ├── <button>NEW ▼</button>         # Sort by newest
│   │   ├── <button>SCORE</button>         # Sort by score
│   │   ├── <button>CHAPTERS</button>      # Sort by chapter count
│   │   ├── <button>A-Z</button>           # Sort alphabetically
│   │   ├── <IPDisplay />                  # FX43: Public IP display
│   │   └── <button>Add Series</button>    # Custom series adder
│   └── {showSearch && <SearchBar />}      # Search input
├── <main>                                 # Series list
│   ├── {loading && <BrowseSkeleton />}    # Loading skeleton
│   ├── {error && <ErrorPanel />}          # Error display
│   ├── {items.map(series => (
│   │   <UnifiedSeriesCard                  # Series card
│   │     key={series.id}
│   │     series={series}
│   │     index={index}
│   │     onOpen={() => openSeries(series.id)}
│   │   />
│   │ ))}
│   └── {visibleCount < items.length && (
│       <button>LOAD MORE</button>
│   )}
├── <motion.button>                        # Floating Refresh button
├── <motion.button>                        # Floating Rehash C-Fetch button
│   <img src="/rehash-c-fetch.png" />
├── <motion.button>                        # Floating Continue C-Fetch button
│   <img src="/continue-c-fetch.png" />
└── {showCustomSeriesAdder && <CustomSeriesAdder />}
</BrowseScreen>
```

### SeriesDetailScreen Component Tree

```
<SeriesDetailScreen>
├── <header>                               # Back button + series title
│   ├── <button>BACK</button>
│   └── <h2>{series.title}</h2>
├── <div>                                  # External links row
│   ├── <button>r/HFY wiki</button>
│   ├── <button>HFY Foundation</button>
│   └── <button>SSB wiki</button>
├── <div>                                  # Action buttons row
│   ├── <button>Favorite</button>
│   ├── <button>CACHE LOAD</button>
│   ├── <button>HFY.F SEARCH</button>
│   ├── <button>WB CRAWL</button>
│   ├── <button>RSS CRAWL</button>
│   ├── <button>JSON CRAWL</button>
│   ├── <button>R-SEARCH</button>
│   ├── <button>ERD CRAWL</button>
│   ├── <button>DFR CRAWL</button>
│   ├── <button>WB SYNC</button>
│   └── <button>WS PARSE</button>
├── <div>                                  # Auto-discover section
│   ├── <button>▶ START</button>           # Start auto-discover
│   ├── <button>SCAN</button>              # Scan for chapters
│   ├── <button>① PASTE (ANDROID)</button> # Paste wiki text
│   ├── <button>② BOOKMARKLET</button>     # Bookmarklet import
│   ├── <button>③ SINGLE URL</button>      # Single URL import
│   └── <textarea />                       # Paste area
├── <div>                                  # Download section
│   ├── <button>↕ REORDER</button>         # Reorder chapters
│   ├── <button>📥 REHASH</button>         # Per-series Rehash C-Fetch
│   ├── <button>📥 CONTINUE</button>       # Per-series Continue C-Fetch
│   ├── <button>MERGE INTO 1 FILE</button> # Merge all chapters
│   ├── <button>ALL INDIVIDUAL</button>    # Individual EPUBs
│   ├── <button>PICK CHAPTERS</button>     # Select specific chapters
│   └── <button>MERGE ALL → EPUB</button>  # Merge to single EPUB
├── <div>                                  # Chapter management
│   ├── <button>r/HFY wiki</button>        # Wiki link
│   ├── <button>HFY Foundation</button>    # HFY.F link
│   ├── <button>SSB wiki</button>          # SSB link
│   ├── <button>🔍 GAPS</button>           # Detect gaps
│   ├── <button>↕ SORT</button>            # Sort chapters
│   ├── <button>REPARSE</button>           # Reparse wiki
│   ├── <button>+ ADD MISSING</button>     # Add manually
│   └── <button>🔍 SEARCH REDDIT</button>  # Search for chapters
├── {fetchCacheRunning && (
│   <CyberPanel>                           # Rehash progress
│     <CyberProgress value={...} />
│     <span>{fetched}/{total} · {changed} changed · {errors} errors</span>
│     <button>STOP</button>
│   </CyberPanel>
│ )}
├── {continueFetchRunning && (
│   <CyberPanel>                           # Continue progress
│     <CyberProgress value={...} />
│     <span>{discovered} discovered · {fetched} fetched</span>
│     <button>STOP</button>
│   </CyberPanel>
│ )}
├── {downloading && (
│   <CyberPanel>                           # Download progress
│     <CyberProgress value={...} />
│     <span>{done}/{total} chapters</span>
│     <button>STOP</button>
│   </CyberPanel>
│ )}
├── {crawling && (
│   <CyberPanel>                           # Crawl progress
│     <span>{stage}: {message}</span>
│     <CyberProgress value={...} />
│   </CyberPanel>
│ )}
├── {autoDiscoverStatus?.status === "running" && (
│   <CyberPanel>                           # Auto-discover progress
│     <span>STAGE: {autoDiscoverStatus.stage}</span>
│     <span>{autoDiscoverStatus.totalChapters} chapters so far</span>
│   </CyberPanel>
│ )}
├── <div>                                  # Chapter list
│   {chapters.map(ch => (
│     <ChapterRow
│       key={ch.id}
│       chapter={ch}
│       onOpen={() => openChapter(ch.id)}
│     />
│   ))}
└── {showCrawlFromMenu && <CrawlFromMenu />} # Crawl from specific chapter
</SeriesDetailScreen>
```

### ChapterRow Component

```
<ChapterRow>
├── <button>                               # Chapter button (click to read)
│   ├── <span>{chapterNumber}</span>       # Chapter number (00001)
│   ├── <span>{chapter.title}</span>       # Chapter title
│   ├── {chapter.fetched && <span>▲ {score}</span>}  # Upvote count
│   └── {downloaded && <ThumbsUp icon />}  # Downloaded indicator
├── <button>Menu</button>                  # Chapter menu (edit URL, etc.)
├── <button>Open on Reddit</button>        # External link
├── <button>Mark as read</button>          # Toggle read status
└── <button>Download this chapter</button> # Individual download
</ChapterRow>
```

### ReaderScreen Component Tree

```
<ReaderScreen>
├── <header>                               # Reader header
│   ├── <button>BACK</button>              # Back to series
│   ├── <h2>{chapter.title}</h2>           # Chapter title
│   ├── <button>◀</button>                 # Previous chapter
│   ├── <button>▶</button>                 # Next chapter
│   └── <button>Settings</button>          # Reader settings
├── <div>                                  # Author/score info
│   ├── <span>By u/{author}</span>
│   ├── <span>▲ {score} upvotes</span>
│   └── <span>{wordCount} words</span>
├── <div className="reader-content">       # Chapter content
│   {processedText.split('\n').map(para => (
│     <p>{para}</p>
│   ))}
└── <ReaderSettings>                       # Settings panel (collapsible)
    ├── <div>Theme</div>
    │   └── {24 theme buttons}
    ├── <div>Font</div>
    │   └── {24 font buttons}
    ├── <div>Font Size: {fontSize}px</div>
    │   └── <input type="range" min=14 max=32 />
    ├── <div>Line Height: {lineHeight}</div>
    │   └── <input type="range" min=1.0 max=2.5 step=0.1 />
    ├── <div>Preload: {preload}</div>
    │   └── <input type="range" min=0 max=10 />
    └── <button>Reset to defaults</button>
</ReaderScreen>
```

### QueueScreen Component Tree

```
<QueueScreen>
├── <AppHeader />
├── <header>                               # Queue header
│   ├── <DownloadIcon />
│   ├── <h1>DOWNLOAD QUEUE</h1>
│   ├── <span>{active} ACTIVE · {done} DONE · {failed} FAIL</span>
│   └── {jobs.length > 0 && <button>CLEAR</button>}
├── <main>
│   ├── {cFetchState.rehash && (            # Browse Rehash C-Fetch progress
│   │   <div>
│   │     <span>REHASH C-FETCH {current}/{total} SERIES</span>
│   │     <button>STOP</button>
│   │     {seriesList.map(s => (
│   │       <SeriesProgressBar
│   │         title={s.title}
│   │         done={s.done}
│   │         total={s.total}
│   │         fetched={s.fetched}
│   │         status={s.status}
│   │       />
│   │     ))}
│   │   </div>
│   │ )}
│   ├── {cFetchState.continue && (          # Browse Continue C-Fetch progress
│   │   <div>
│   │     <span>CONTINUE C-FETCH {current}/{total} SERIES</span>
│   │     <button>STOP</button>
│   │     {seriesList.map(s => <SeriesProgressBar ... />)}
│   │   </div>
│   │ )}
│   ├── {jobs.length === 0 ? (              # Empty state
│   │   <CyberPanel>QUEUE EMPTY</CyberPanel>
│   │ ) : (
│   │   <AnimatePresence>
│   │     {jobs.map(job => (
│   │       <CyberPanel key={job.id}>
│   │         <div>
│   │           <h3>{job.seriesTitle}</h3>
│   │           <StatusBadge status={job.status} />
│   │         </div>
│   │         <div>
│   │           <span>{job.completedChapters}/{job.totalChapters} ch</span>
│   │           <span>{job.format}</span>
│   │           {job.merge && <span>MERGED</span>}
│   │         </div>
│   │         <CyberProgress value={job.progress} />
│   │         <div>
│   │           {job.status === "running" && <button>PAUSE</button>}
│   │           {job.status === "paused" && <button>RESUME</button>}
│   │           <button>REMOVE</button>
│   │         </div>
│   │       </CyberPanel>
│   │     ))}
│   │   </AnimatePresence>
│   │ )}
│   └── </main>
└── <Navigation />
</QueueScreen>
```

---

## Appendix Q: Data Flow Diagrams

### C-Fetch Data Flow

```
User clicks REHASH
        │
        ▼
┌───────────────────┐
│  BrowseScreen     │
│  onClick handler  │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  window.__hfy     │
│  RehashRunning=true│
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  For each series: │
│  (sequential)     │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐     ┌───────────────────┐
│  addJob()         │────▶│  useDownloads     │
│  status="running" │     │  store updated    │
└───────┬───────────┘     └───────────────────┘
        │                          │
        ▼                          ▼
┌───────────────────┐     ┌───────────────────┐
│  GET hardcoded    │     │  QueueScreen      │
│  chapters         │     │  re-renders with  │
│  /api/hardcoded-  │     │  new job          │
│  chapters/[slug]  │     └───────────────────┘
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  For each batch:  │
│  (5 chapters)     │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐     ┌───────────────────┐
│  POST fetch-cache │────▶│  Server fetches   │
│  (NDJSON stream)  │     │  from Reddit via  │
│                   │     │  8-tier cascade   │
└───────┬───────────┘     └───────────────────┘
        │                          │
        ▼                          ▼
┌───────────────────┐     ┌───────────────────┐
│  Stream reader    │     │  Reddit API       │
│  processes NDJSON │     │  (OAuth/JSON/RSS) │
│  line by line     │     └───────────────────┘
└───────┬───────────┘
        │
        ├──────────────────────────┐
        ▼                          ▼
┌───────────────────┐     ┌───────────────────┐
│  idbSet()         │     │  POST chapter-cache│
│  (browser IDB)    │     │  (server filesystem)│
└───────┬───────────┘     └───────────────────┘
        │
        ├──────────────────────────┐
        ▼                          ▼
┌───────────────────┐     ┌───────────────────┐
│  localStorage     │     │  setChapters()    │
│  (score backup)   │     │  (React state)    │
└───────────────────┘     └───────────────────┘
                                    │
                                    ▼
                          ┌───────────────────┐
                          │  Series detail UI │
                          │  shows ▲ score    │
                          │  and ✓ fetched    │
                          └───────────────────┘
        │
        ▼
┌───────────────────┐
│  updateJob()      │
│  progress update  │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  After all batches│
│  status="done"    │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐     ┌───────────────────┐
│  Fetch scores     │────▶│  useSeriesScores  │
│  from server      │     │  store updated    │
└───────┬───────────┘     └───────────────────┘
        │                          │
        ├──────────────────────────┤
        ▼                          ▼
┌───────────────────┐     ┌───────────────────┐
│  Fetch chapter    │     │  Browse cache     │
│  counts from      │     │  refresh          │
│  server           │     │  (card re-render) │
└───────┬───────────┘     └───────────────────┘
        │
        ▼
┌───────────────────┐
│  Fetch downloaded │
│  counts from      │
│  server           │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  Next series      │
│  (50ms delay)     │
└───────────────────┘
```

### Download Data Flow

```
User clicks MERGE
        │
        ▼
┌───────────────────┐
│  Validation       │
│  (all c-fetched?) │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐     ┌───────────────────┐
│  addJob()         │────▶│  QueueScreen      │
│  status="running" │     │  shows progress   │
└───────┬───────────┘     └───────────────────┘
        │
        ▼
┌───────────────────┐
│  Step 1: IDB cache│
│  check (fast)     │
│  For each chapter:│
│   idbGet(cache)   │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  Step 2: API fetch│
│  (missing only)   │
│  POST /api/download│
│  (batch of 5)     │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  Retry logic      │
│  (max 3 attempts) │
│  Exponential      │
│  backoff          │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  Re-sort chapters │
│  to match series  │
│  order            │
└───────┬───────────┘
        │
        ├──────────────┐
        ▼              ▼
┌───────────┐   ┌───────────┐
│ Individual│   │ Merge mode│
│ mode      │   │           │
└─────┬─────┘   └─────┬─────┘
      │               │
      ▼               ▼
┌───────────┐   ┌───────────────────┐
│ For each  │   │ createEpubBlob()  │
│ chapter:  │   │ (all chapters)    │
│ createEpub│   └────────┬──────────┘
│ Blob()    │            │
└─────┬─────┘            ▼
      │          ┌───────────────────┐
      ▼          │ saveFileBlob()    │
┌───────────┐    │ (File System API  │
│ saveFile  │    │  or download)     │
│ Blob()    │    └────────┬──────────┘
└─────┬─────┘             │
      │                   ▼
      │            ┌───────────────────┐
      │            │ Save to IDB:      │
      │            │ hfy-merged-[id]   │
      │            └────────┬──────────┘
      │                     │
      ├─────────────────────┘
      │
      ▼
┌───────────────────┐
│  Mark chapters    │
│  as downloaded    │
│  (only if saved)  │
└───────┬───────────┘
        │
        ▼
┌───────────────────┐
│  updateJob()      │
│  status="done"    │
└───────────────────┘
```

---

## Appendix R: State Management Deep Dive

### Zustand Store Pattern

All stores follow the same pattern:

```javascript
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

const useStore = create(
    persist(
        (set, get) => ({
            // State
            items: {},
            
            // Actions
            addItem: (item) => set((state) => ({
                items: { ...state.items, [item.id]: item }
            })),
            
            removeItem: (id) => set((state) => {
                const newItems = { ...state.items };
                delete newItems[id];
                return { items: newItems };
            }),
            
            // Computed (use functions, not values)
            getItem: (id) => get().items[id],
            
            // Bulk operations
            clearAll: () => set({ items: {} }),
        }),
        {
            name: 'store-name',
            storage: createJSONStorage(() => ({
                getItem: (name) => {
                    // 1. Try localStorage
                    try { return localStorage.getItem(name); } catch {}
                    // 2. Try cookies
                    try { /* cookie fallback */ } catch {}
                    // 3. Return null (server restore via onRehydrateStorage)
                    return null;
                },
                setItem: (name, value) => {
                    // Write to ALL storage layers:
                    // 1. localStorage (immediate)
                    try { localStorage.setItem(name, value); } catch {}
                    // 2. Cookies (backup, 4KB limit)
                    try { /* cookie write */ } catch {}
                    // 3. Server filesystem (survives Android restart)
                    try {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: value,
                            keepalive: true
                        }).catch(() => {});
                    } catch {}
                },
                removeItem: (name) => {
                    try { localStorage.removeItem(name); } catch {}
                    try { /* cookie clear */ } catch {}
                    try {
                        fetch(`/api/store/${encodeURIComponent(name)}`, {
                            method: 'DELETE',
                            keepalive: true
                        }).catch(() => {});
                    } catch {}
                }
            })),
            // Server restore on hydration
            onRehydrateStorage: () => (state) => {
                // If localStorage was empty (Android restart), fetch from server
                if (state && state.items && Object.keys(state.items).length === 0) {
                    fetch(`/api/store/store-name`, { cache: 'no-store' })
                        .then(r => r.ok ? r.json() : null)
                        .then(data => {
                            if (data && data.ok && data.data && data.data.state) {
                                state.setItemsFromServer?.(data.data.state.items);
                            }
                        }).catch(() => {});
                }
            }
        }
    )
);
```

### Selector Pattern

Components use selectors to minimize re-renders:

```javascript
// BAD: Subscribes to entire store, re-renders on ANY change
const store = useSettings();

// GOOD: Subscribes to specific field, only re-renders when that field changes
const appTheme = useSettings((s) => s.appTheme);
const fontSize = useSettings((s) => s.fontSize);

// GOOD: Subscribe to multiple fields
const { appTheme, readerTheme } = useSettings((s) => ({
    appTheme: s.appTheme,
    readerTheme: s.readerTheme
}));

// GOOD: Use getState() for one-time reads (no subscription)
const batchSize = useSettings.getState().cFetchBatchSize || 5;
```

### Module-Level State (C-Fetch)

C-Fetch uses module-level state that survives tab switches:

```javascript
// Module scope (outside component)
const moduleFetchState = {
    rehashRunning: false,
    rehashAbort: false,
    rehashProgress: null,
    rehashAbortController: null,
    rehashJobId: null,
    activeFetchSeries: null,
    // ... continue fields
};

function SeriesDetailScreen() {
    // React state for UI
    const [fetchCacheRunning, setFetchCacheRunning] = useState(moduleFetchState.rehashRunning);
    const [fetchCacheProgress, setFetchCacheProgress] = useState(moduleFetchState.rehashProgress);
    
    // Polling effect: sync module state to React state
    useEffect(() => {
        // Only sync if this series is the active fetch
        if (moduleFetchState.activeFetchSeries !== seriesId) {
            setFetchCacheRunning(false);
            return;
        }
        
        setFetchCacheRunning(moduleFetchState.rehashRunning);
        setFetchCacheProgress(moduleFetchState.rehashProgress);
        
        if (moduleFetchState.rehashRunning) {
            const interval = setInterval(() => {
                setFetchCacheRunning(moduleFetchState.rehashRunning);
                setFetchCacheProgress(moduleFetchState.rehashProgress);
                if (!moduleFetchState.rehashRunning) clearInterval(interval);
            }, 500);
            return () => clearInterval(interval);
        }
    }, [seriesId]);
    
    // C-Fetch handler
    const runFetchCache = useCallback(async () => {
        // Uses moduleFetchState, not React state
        // This means the fetch continues even if the component unmounts
        moduleFetchState.rehashRunning = true;
        // ... fetch logic ...
        moduleFetchState.rehashRunning = false;
    }, [seriesId, chapters]);
    
    return (
        <div>
            {fetchCacheRunning && <ProgressPanel progress={fetchCacheProgress} />}
            <button onClick={runFetchCache}>📥 REHASH</button>
        </div>
    );
}
```

---

## Appendix S: Error Handling Strategy

### Client-Side Error Handling

#### Toast Notifications

All user-facing errors show a toast:

```javascript
// Success
toast.success("Downloaded 5 chapters");
toast.success(`Cached ${fetched}/${total} chapters`);

// Info
toast.info("C-FETCHing 3 unfetched chapters...");
toast.info("A download is already in progress");

// Warning
toast.warning("Merged file is 52MB — too large for server backup");
toast.warning("5 chapters failed after 3 retries");

// Error
toast.error("No chapters to download");
toast.error(`Download failed: ${err.message}`);
toast.error("Cannot merge: 3 chapters not c-fetched");
```

#### Try/Catch Patterns

```javascript
// Pattern 1: Show error, continue
try {
    const data = await fetch(url).then(r => r.json());
    process(data);
} catch (err) {
    toast.error(`Failed: ${err.message}`);
}

// Pattern 2: Silent failure with fallback
let data;
try {
    data = await fetch(url).then(r => r.json());
} catch {
    data = null; // Fallback
}
if (data) process(data);

// Pattern 3: Retry with backoff
let result;
for (let attempt = 1; attempt <= 3; attempt++) {
    try {
        result = await fetch(url);
        break;
    } catch (err) {
        if (attempt === 3) throw err;
        await new Promise(r => setTimeout(r, 500 * Math.pow(2, attempt - 1)));
    }
}

// Pattern 4: Fire-and-forget with catch
fetch('/api/store/key', {
    method: 'POST',
    body: JSON.stringify(data)
}).catch(() => {}); // Silently ignore errors
```

### Server-Side Error Handling

#### API Route Pattern

```javascript
async function POST(req) {
    try {
        // 1. Validate input
        const body = await req.json();
        if (!body.required) {
            return NextResponse.json(
                { ok: false, error: "Missing required field" },
                { status: 400 }
            );
        }
        
        // 2. Process
        const result = await processRequest(body);
        
        // 3. Return success
        return NextResponse.json({ ok: true, data: result });
        
    } catch (err) {
        // 4. Return error
        console.error('[route] Error:', err);
        return NextResponse.json(
            { ok: false, error: err?.message || "Internal error" },
            { status: 500 }
        );
    }
}
```

#### Stream Error Handling

```javascript
const stream = new ReadableStream({
    async start(controller) {
        try {
            // ... streaming logic ...
            controller.close();
        } catch (err) {
            // Send error to client
            try {
                controller.enqueue(encoder.encode(JSON.stringify({
                    type: "fatal",
                    error: err?.message || "Internal error"
                }) + "\n"));
            } catch {}
            // Always close the stream
            try { controller.close(); } catch {}
        }
    },
    cancel(reason) {
        // Client disconnected
        // Abort any ongoing operations
        if (abortController) abortController.abort();
    }
});
```

---

## Appendix T: Build Configuration Details

### next.config.ts

```typescript
import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
    // Output standalone bundle (portable, no node_modules needed at runtime)
    output: 'standalone',
    
    // TypeScript
    typescript: {
        ignoreBuildErrors: true, // Allow build even with TS errors
    },
    
    // ESLint
    eslint: {
        ignoreDuringBuilds: true,
    },
    
    // Images
    images: {
        unoptimized: true, // No server-side image optimization
        minimumCacheTTL: 14400, // 4 hours
    },
    
    // Cache
    cacheMaxMemorySize: 52428800, // 50MB in-memory cache
    
    // Compression
    compress: true, // Enable gzip
    
    // Powered by header
    poweredByHeader: true,
    
    // Experimental features
    experimental: {
        // Package import optimization (tree-shaking)
        optimizePackageImports: [
            'lucide-react', 'date-fns', 'lodash-es', 'ramda',
            'antd', 'react-bootstrap', 'ahooks',
            '@ant-design/icons', '@headlessui/react',
            '@heroicons/react/20/solid', '@heroicons/react/24/solid',
            '@heroicons/react/24/outline',
            '@mui/material', '@mui/icons-material',
            'recharts', 'react-use',
            // ... 30+ more packages
        ],
        
        // Preload route handlers on startup
        preloadEntriesOnStart: true,
        
        // Server minification
        serverMinification: false,
        
        // CSS chunking
        cssChunking: true,
        
        // Optimize server React
        optimizeServerReact: true,
        
        // CPU count (limit to 1 for standalone)
        cpus: 1,
        
        // Memory-based workers
        memoryBasedWorkersCount: false,
    },
    
    // Cache life profiles
    cacheLife: {
        default: { stale: 300, revalidate: 900, expire: 4294967294 },
        seconds: { stale: 30, revalidate: 1, expire: 60 },
        minutes: { stale: 300, revalidate: 60, expire: 3600 },
        hours: { stale: 300, revalidate: 3600, expire: 86400 },
        days: { stale: 300, revalidate: 86400, expire: 604800 },
        weeks: { stale: 300, revalidate: 604800, expire: 2592000 },
        max: { stale: 300, revalidate: 2592000, expire: 31536000 },
    },
};

export default nextConfig;
```

### package.json

```json
{
    "name": "nextjs_tailwind_shadcn_ts",
    "version": "250fx24",
    "private": true,
    "scripts": {
        "dev": "next dev -p 3000 2>&1 | tee dev.log",
        "build": "next build && cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/",
        "start": "NODE_ENV=production bun .next/standalone/server.js 2>&1 | tee server.log"
    },
    "dependencies": {
        // Core
        "next": "^16.1.1",
        "react": "^19.0.0",
        "react-dom": "^19.0.0",
        
        // State management
        "zustand": "^5.0.6",
        
        // UI components
        "@radix-ui/react-accordion": "^1.2.11",
        "@radix-ui/react-dialog": "^1.1.14",
        "@radix-ui/react-dropdown-menu": "^2.1.15",
        // ... 15+ Radix UI packages
        
        // Animation
        "framer-motion": "^12.23.2",
        
        // Icons
        "lucide-react": "^0.525.0",
        
        // Styling
        "tailwindcss": "^4",
        "tailwindcss-animate": "^1.0.7",
        "class-variance-authority": "^0.7.1",
        "clsx": "^2.1.1",
        "tailwind-merge": "^3.3.1",
        
        // Toast
        "sonner": "^2.0.6",
        
        // Data
        "jszip": "^3.10.1",
        "file-saver": "^2.0.5",
        
        // Reddit
        "puppeteer-core": "^25.3.0",
        "socket.io-client": "^4.8.3",
        
        // Content
        "react-markdown": "^10.1.0",
        "react-syntax-highlighter": "^15.6.1",
        "@mdxeditor/editor": "^3.39.1",
        
        // Forms
        "react-hook-form": "^7.60.0",
        "@hookform/resolvers": "^5.1.1",
        "zod": "^4.0.2",
        
        // Charts
        "recharts": "^2.15.4",
        
        // Utilities
        "date-fns": "^4.1.0",
        "uuid": "^11.1.0",
        
        // Android
        "@capacitor/android": "^8.4.1",
        
        // AI SDK
        "z-ai-web-dev-sdk": "^0.0.18"
    },
    "devDependencies": {
        "@tailwindcss/postcss": "^4",
        "typescript": "^5",
        "eslint": "^9",
        "eslint-config-next": "^16.1.1"
    }
}
```

---

*Complete manual end. HFY NEKROCODEXXX FX43 v9 — Total: ~28,000 words — 2026-07-23*

---

## Appendix U: Reddit Scraper Architecture

The Reddit scraper is the heart of the app's content fetching system. It implements an 8-tier cascading fallback that ensures content can always be retrieved even under heavy rate limiting.

### Scraper Tier System

Each tier is tried in order. If a tier fails (rate limit, network error, deleted post), the next tier is attempted. If all tiers fail, the function returns null and the chapter is marked as an error.

#### Tier 1: User OAuth (600 QPM)

Uses the user's personal Reddit OAuth token for authenticated access.

```javascript
async function fetchWithUserOAuth(postUrl, userToken) {
    const postId = extractPostId(postUrl);
    const apiUrl = `https://oauth.reddit.com/comments/${postId}?limit=1&raw_json=1`;
    
    const res = await fetch(apiUrl, {
        headers: {
            'Authorization': `Bearer ${userToken}`,
            'User-Agent': 'HFY:NEKROCODEXXX:v1.0 (by /u/nekrocodex)'
        },
        signal: AbortSignal.timeout(10000)
    });
    
    if (res.status === 429) throw new Error('Rate limited');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    
    const data = await res.json();
    const post = data[0]?.data?.children?.[0]?.data;
    
    if (!post) throw new Error('Post not found');
    
    return {
        postId: post.id,
        title: post.title,
        author: post.author,
        selftext: post.selftext,
        selftextHtml: post.selftext_html,
        createdUtc: post.created_utc,
        score: post.score,
        url: post.url,
        permalink: `https://www.reddit.com${post.permalink}`,
        nextChapterLinks: extractNextChapterLinks(post.selftext)
    };
}
```

#### Tier 2: App OAuth (100 QPM)

Anonymous OAuth using the bundled Reddit app client ID.

```javascript
async function fetchWithAppOAuth(postUrl, appToken) {
    const postId = extractPostId(postUrl);
    const apiUrl = `https://oauth.reddit.com/comments/${postId}?limit=1&raw_json=1`;
    
    const res = await fetch(apiUrl, {
        headers: {
            'Authorization': `Bearer ${appToken}`,
            'User-Agent': 'HFY:NEKROCODEXXX:v1.0 (by /u/nekrocodex)'
        },
        signal: AbortSignal.timeout(10000)
    });
    
    if (res.status === 429) throw new Error('Rate limited');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    
    const data = await res.json();
    // ... same parsing as Tier 1
}
```

#### Tier 3: Authless JSON

Direct JSON endpoint without OAuth. Uses browser User-Agent.

```javascript
async function fetchJsonDirect(postUrl) {
    const postId = extractPostId(postUrl);
    const jsonUrl = `https://www.reddit.com/comments/${postId}.json?limit=1&raw_json=1`;
    
    const res = await fetch(jsonUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        signal: AbortSignal.timeout(10000)
    });
    
    if (res.status === 429) throw new Error('Rate limited');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    
    const data = await res.json();
    // ... same parsing
}
```

#### Tier 4: CORS Proxy Pool

Routes the request through one of 386 community-maintained CORS proxies.

```javascript
async function fetchViaProxy(postUrl) {
    const postId = extractPostId(postUrl);
    const jsonUrl = `https://www.reddit.com/comments/${postId}.json?limit=1&raw_json=1`;
    
    // Get alive proxies sorted by latency
    const aliveProxies = proxyPool.getAliveProxies();
    
    for (const proxy of aliveProxies) {
        try {
            const proxyUrl = proxy.url + encodeURIComponent(jsonUrl);
            
            const res = await fetch(proxyUrl, {
                signal: AbortSignal.timeout(15000)
            });
            
            if (res.status === 429) {
                proxyPool.markBanned(proxy);
                continue;
            }
            
            if (!res.ok) {
                proxyPool.markDead(proxy);
                continue;
            }
            
            const data = await res.json();
            proxyPool.markAlive(proxy);
            
            // ... same parsing
            return parseRedditPost(data);
        } catch (err) {
            proxyPool.markDead(proxy);
            continue;
        }
    }
    
    throw new Error('All proxies failed');
}
```

#### Tier 5: RSS Feed

Reddit's RSS endpoint is always available and not rate-limited.

```javascript
async function fetchViaRss(postUrl) {
    const postId = extractPostId(postUrl);
    const rssUrl = `https://www.reddit.com/r/HFY/comments/${postId}/.rss`;
    
    const res = await fetch(rssUrl, {
        signal: AbortSignal.timeout(10000)
    });
    
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    
    const xml = await res.text();
    
    // Parse RSS XML
    const parser = new DOMParser();
    const doc = parser.parseFromString(xml, 'text/xml');
    
    const entry = doc.querySelector('entry');
    if (!entry) throw new Error('No entry in RSS');
    
    const title = entry.querySelector('title')?.textContent || '';
    const content = entry.querySelector('content')?.textContent || '';
    const author = entry.querySelector('author > name')?.textContent?.replace('u/', '') || 'unknown';
    
    // RSS doesn't provide score or createdUtc
    // Fall back to 0 for score
    return {
        postId,
        title,
        author,
        selftext: stripHtml(content),
        selftextHtml: content,
        createdUtc: 0,
        score: 0,
        url: postUrl,
        permalink: postUrl,
        nextChapterLinks: extractNextChapterLinks(stripHtml(content))
    };
}
```

#### Tier 6: Wayback Machine

Fetches archived Reddit snapshots from the Internet Archive.

```javascript
async function fetchViaWayback(postUrl) {
    const waybackApi = `https://archive.org/wayback/available?url=${encodeURIComponent(postUrl)}`;
    
    const res = await fetch(waybackApi, {
        signal: AbortSignal.timeout(10000)
    });
    
    const data = await res.json();
    
    if (!data.archived_snapshots?.closest) {
        throw new Error('No Wayback snapshot available');
    }
    
    const snapshotUrl = data.archived_snapshots.closest.url;
    const snapshotRes = await fetch(snapshotUrl, {
        signal: AbortSignal.timeout(15000)
    });
    
    const html = await snapshotRes.text();
    
    // Parse archived HTML
    return parseArchivedRedditHtml(html, postUrl);
}
```

#### Tier 7: HFY Foundation

Searches the community-maintained HFY Foundation index.

```javascript
async function fetchViaHfyFoundation(postUrl, slug) {
    const searchUrl = `/api/hfy-foundation-search?search=${encodeURIComponent(slug)}`;
    
    const res = await fetch(searchUrl);
    const data = await res.json();
    
    if (!data.ok || !data.results) {
        throw new Error('HFY Foundation search failed');
    }
    
    const postId = extractPostId(postUrl);
    const match = data.results.find(r => r.id === postId || r.url.includes(postId));
    
    if (!match) throw new Error('Not found in HFY Foundation');
    
    return {
        postId,
        title: match.title,
        author: match.author || 'unknown',
        selftext: match.content || '',
        score: match.score || 0,
        url: match.url || postUrl,
        permalink: match.url || postUrl,
        createdUtc: match.createdUtc || 0
    };
}
```

#### Tier 8: Reddit Search

Searches r/HFY for the post by title.

```javascript
async function fetchViaRedditSearch(postUrl, seriesSlug) {
    const postId = extractPostId(postUrl);
    
    // Search r/HFY for the post
    const searchUrl = `/api/search?q=${encodeURIComponent(seriesSlug)}&subreddit=HFY&sort=relevance&limit=100`;
    
    const res = await fetch(searchUrl);
    const data = await res.json();
    
    if (!data.ok || !data.results) {
        throw new Error('Reddit search failed');
    }
    
    const match = data.results.find(r => r.id === postId);
    
    if (!match) throw new Error('Not found in Reddit search');
    
    return {
        postId: match.id,
        title: match.title,
        author: match.author || 'unknown',
        selftext: match.selftext || '',
        score: match.score || 0,
        url: match.url || postUrl,
        permalink: match.permalink || postUrl,
        createdUtc: match.createdUtc || 0
    };
}
```

### Main fetchPostContent Function

```javascript
async function fetchPostContent(postUrl, slug) {
    const errors = [];
    
    // Tier 1: User OAuth
    if (userTokenCache.token && userTokenCache.expiresAt > Date.now()) {
        try {
            return await fetchWithUserOAuth(postUrl, userTokenCache.token);
        } catch (err) {
            errors.push(`Tier 1 (User OAuth): ${err.message}`);
        }
    }
    
    // Tier 2: App OAuth
    if (appTokenCache.token && appTokenCache.expiresAt > Date.now()) {
        try {
            return await fetchWithAppOAuth(postUrl, appTokenCache.token);
        } catch (err) {
            errors.push(`Tier 2 (App OAuth): ${err.message}`);
        }
    }
    
    // Tier 3: Authless JSON
    try {
        return await fetchJsonDirect(postUrl);
    } catch (err) {
        errors.push(`Tier 3 (JSON): ${err.message}`);
    }
    
    // Tier 4: CORS Proxy Pool
    try {
        return await fetchViaProxy(postUrl);
    } catch (err) {
        errors.push(`Tier 4 (Proxy): ${err.message}`);
    }
    
    // Tier 5: RSS
    try {
        return await fetchViaRss(postUrl);
    } catch (err) {
        errors.push(`Tier 5 (RSS): ${err.message}`);
    }
    
    // Tier 6: Wayback Machine
    try {
        return await fetchViaWayback(postUrl);
    } catch (err) {
        errors.push(`Tier 6 (Wayback): ${err.message}`);
    }
    
    // Tier 7: HFY Foundation
    if (slug) {
        try {
            return await fetchViaHfyFoundation(postUrl, slug);
        } catch (err) {
            errors.push(`Tier 7 (HFY.F): ${err.message}`);
        }
    }
    
    // Tier 8: Reddit Search
    if (slug) {
        try {
            return await fetchViaRedditSearch(postUrl, slug);
        } catch (err) {
            errors.push(`Tier 8 (Search): ${err.message}`);
        }
    }
    
    // All tiers failed
    console.error('[fetchPostContent] All tiers failed:', errors);
    return null;
}
```

### Next Chapter Link Extraction

The scraper extracts "next chapter" links from post content for the crawler:

```javascript
function extractNextChapterLinks(selftext) {
    if (!selftext) return [];
    
    const links = [];
    
    // Match markdown links: [text](url)
    const markdownRegex = /\[([^\]]*)\]\((https?:\/\/[^\s)]+)\)/g;
    let match;
    while ((match = markdownRegex.exec(selftext)) !== null) {
        const text = match[1].toLowerCase();
        const url = match[2];
        
        // Check if this is a "next chapter" link
        if (text.includes('next') || text.includes('part') || 
            text.includes('chapter') || text.includes('continue') ||
            text.includes('previous') || text.includes('prev')) {
            links.push({ text: match[1], url, type: classifyLink(text) });
        }
    }
    
    // Match raw URLs
    const urlRegex = /https?:\/\/(?:www\.|old\.|new\.)?reddit\.com\/r\/HFY\/comments\/([a-z0-9]+)\/[^\s)]+/gi;
    while ((match = urlRegex.exec(selftext)) !== null) {
        const url = match[0];
        // Avoid duplicates
        if (!links.find(l => l.url === url)) {
            links.push({ text: '', url, type: 'raw' });
        }
    }
    
    return links;
}

function classifyLink(text) {
    const lower = text.toLowerCase();
    if (lower.includes('next')) return 'next';
    if (lower.includes('previous') || lower.includes('prev')) return 'previous';
    if (lower.includes('part')) return 'part';
    if (lower.includes('chapter')) return 'chapter';
    return 'other';
}
```

---

## Appendix V: Cookie-Based Authentication

For users who can't use OAuth (Google login, 2FA), the app supports cookie-based authentication.

### Cookie Injection Flow

1. User logs into Reddit in their browser
2. User opens browser DevTools (F12) → Application → Cookies → reddit.com
3. User copies all cookie values
4. User pastes cookies into the Settings → Reddit Cookies textarea
5. App stores cookies and uses them for authenticated requests

### Cookie Storage

```javascript
// /api/reddit-cookies POST
async function POST(req) {
    const body = await req.json();
    const cookies = body.cookies;
    
    if (!Array.isArray(cookies)) {
        return NextResponse.json(
            { ok: false, error: "Cookies must be an array" },
            { status: 400 }
        );
    }
    
    // Validate and sanitize each cookie
    const sanitized = cookies.map(c => ({
        name: String(c.name || '').slice(0, 200),
        value: String(c.value || '').slice(0, 10000),
        domain: String(c.domain || '.reddit.com'),
        path: String(c.path || '/'),
        secure: !!c.secure,
        httpOnly: !!c.httpOnly
    }));
    
    // Save to filesystem (non-atomic for now — TODO: atomic write)
    const filePath = path.join(getDataDir(), 'reddit-cookies.json');
    await fs.promises.writeFile(filePath, JSON.stringify(sanitized, null, 2));
    
    return NextResponse.json({ ok: true, count: sanitized.length });
}
```

### Cookie Usage in Scraping

```javascript
async function fetchWithCookies(postUrl, cookies) {
    // Build Cookie header
    const cookieHeader = cookies
        .filter(c => c.domain.includes('reddit.com'))
        .map(c => `${c.name}=${c.value}`)
        .join('; ');
    
    const res = await fetch(postUrl, {
        headers: {
            'Cookie': cookieHeader,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        signal: AbortSignal.timeout(10000)
    });
    
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    
    const data = await res.json();
    return parseRedditPost(data);
}
```

### Multi-Account Cookie Rotation

For power users, the app supports up to 9 Reddit accounts:

1. User logs into account #1 in an incognito window
2. Copies cookies → pastes into Settings
3. Opens a NEW incognito window, logs into account #2
4. Copies cookies → pastes into Settings
5. Repeat for up to 9 accounts

Each account adds 600 QPM to the rotation, giving up to 5,400 QPM total.

---

## Appendix W: Mobile/Android Support

### Android APK Build

The app can be packaged as an Android APK using Capacitor:

```bash
# 1. Build the web app
npm run build

# 2. Sync with Capacitor
npx cap sync android

# 3. Open in Android Studio
npx cap open android

# 4. Build APK in Android Studio
# Build → Build APK(s)
```

### Android-Specific Features

The app detects Android via `window.AndroidFolderPicker`:

```javascript
const isAndroid = typeof window !== 'undefined' && 
    window.AndroidFolderPicker && 
    typeof window.AndroidFolderPicker.writeFile === 'function';
```

**File saving on Android:**
- Uses `window.AndroidFolderPicker.writeFile(folder, fileName, content, seriesName)` 
- Writes plain text (Java can't write binary EPUB)
- Supports "ebook" and "download" folders

**localStorage on Android:**
- WebView clears localStorage on app restart
- App survives via server-side storage (cookies + filesystem)
- `onRehydrateStorage` callback fetches data from server when localStorage is empty

**Background processing:**
- Android WebView may kill background tabs
- C-Fetch uses module-level state to survive tab switches
- Queue jobs persist in localStorage (restored on restart)

### PWA Support

The app is installable as a PWA (Progressive Web App):

```json
// manifest.json
{
    "name": "HFY NEKROCODEXXX",
    "short_name": "HFY",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#050608",
    "theme_color": "#00FFF0",
    "orientation": "portrait",
    "icons": [
        {
            "src": "/icon-192.png",
            "sizes": "192x192",
            "type": "image/png",
            "purpose": "any maskable"
        },
        {
            "src": "/icon-512.png",
            "sizes": "512x512",
            "type": "image/png",
            "purpose": "any maskable"
        }
    ]
}
```

The service worker (`sw.js`) provides offline capability for installed PWAs.

---

*End of complete manual. HFY NEKROCODEXXX FX43 v9 — Total: ~28,000+ words — 2026-07-23*

---

## Appendix X: Testing & Quality Assurance

### Arson Directive

The app uses an "Arson Directive" testing protocol — 5 iterations with server restarts, each testing a different function:

#### Iteration 1: Browse Rehash C-Fetch
```
1. Kill server
2. Start fresh server
3. Open browser
4. Click Rehash C-Fetch button
5. Verify: exactly 1 job in queue, running: true
6. Click STOP
7. Verify: running: false
```

#### Iteration 2: Browse Continue C-Fetch
```
1. Kill server
2. Start fresh server
3. Open browser
4. Click Continue C-Fetch button
5. Verify: jobs created (no syntax crash)
6. Click STOP
7. Verify: running: false
```

#### Iteration 3: Rehash + STOP
```
1. Kill server
2. Start fresh server
3. Open browser
4. Start Rehash C-Fetch
5. Wait 3 seconds
6. Click STOP
7. Verify: running: false (abort worked)
```

#### Iteration 4: Continue + STOP
```
1. Kill server
2. Start fresh server
3. Open browser
4. Start Continue C-Fetch
5. Wait 3 seconds
6. Click STOP
7. Verify: running: false (abort worked)
```

#### Iteration 5: Full UI Navigation
```
1. Kill server
2. Start fresh server
3. Open browser
4. Click BROWSE tab → verify OK
5. Click LIBRARY tab → verify OK
6. Click QUEUE tab → verify OK
7. Click SETTINGS tab → verify OK
8. Verify IP Display shows current IP
```

### API Endpoint Testing

Each API endpoint is tested via curl:

```bash
# Series index
curl -s http://localhost:3000/api/series | jq '.ok, .count'
# Expected: true, 5533

# Hardcoded chapters
curl -s http://localhost:3000/api/hardcoded-chapters/zyz | jq '.ok, (.chapters | length)'
# Expected: true, 4

# Store (atomic write)
curl -s -X POST http://localhost:3000/api/store/test -H "Content-Type: application/json" -d '{"v":1}' | jq '.ok'
# Expected: true

# Chapter cache (ok shadowing fix)
curl -s -X POST http://localhost:3000/api/chapter-cache/test -H "Content-Type: application/json" -d '{"postId":"test","ok":false}' | jq '.ok'
curl -s http://localhost:3000/api/chapter-cache/test | jq '.ok, .data.ok'
# Expected: true, false (outer ok is true, inner ok is false)

# Download validation (SSRF prevention)
curl -s -X POST http://localhost:3000/api/download -H "Content-Type: application/json" -d '{"chapterIds":["../../etc/passwd"]}' | jq '.ok'
# Expected: false (blocked)

# Proxy browser SSRF
curl -s "http://localhost:3000/api/proxy-browser?url=http://169.254.169.254/" | jq '.ok, .error'
# Expected: false, "URL host not allowed: 169.254.169.254"

# Crawl SSRF
curl -s -X POST http://localhost:3000/api/crawl -H "Content-Type: application/json" -d '{"startUrls":["http://169.254.169.254/"]}' | jq '.ok, .error'
# Expected: false, "URL host not allowed: 169.254.169.254"
```

### Syntax Verification

All JavaScript files are syntax-checked:

```bash
# Server-side routes
for f in $(find server/.next/server/app/api -name "route.js"); do
    node -c "$f" || echo "FAIL: $f"
done

# Client bundles
node -e "const fs=require('fs'); const vm=require('vm'); 
    new vm.Script(fs.readFileSync('page-bundle.js','utf8')); 
    console.log('OK');"

# Server files
node -c server/server.js
node -c server/aggregate-counts.js
node -c server/public/sw.js
```

### Fix Verification Checklist

After each build, 28+ checks are run to verify all fixes are in place:

1. server.js handlers count (should be 2, was 6)
2. stop.bat kill-all count (should be 0, was 1)
3. findstr /C: in start.bat (should be 1)
4. findstr /C: in stop.bat (should be 1)
5. aggregate unref count (should be 3)
6. sw.js allSettled count (should be 1)
7. chapter-cache data wrapper (should be 1)
8. chapters DELETE remainingChapters (should be 2)
9. chapter/[id] data wrapper (should be 1)
10. store/[key] temp random (should be 1)
11. download validation (should be 1)
12. proxy-browser SSRF allowlist (should be 2)
13. proxy-browser execFile (should be 3)
14. crawl SSRF (should be 2)
15. reddit-multi-token no fake tokens (should be 0)
16. fetch-cache async I/O (should be 0 sync calls)
17. 9365 setItemsFromServer (should be 3)
18. 6609 document.removeEventListener (should be 2)
19. Browse score+count update (should be 2)
20. Reduced delays 300ms (should be >0)
21. Prototype pollution guards (5 routes, 1 each)
22. proxy-stats stats wrapper (should be 1)
23. OAuth timeout (should be 1)
24. Cookie domain exact match (should be 1)
25. continue-fetch finally block (should be 1)
26. NODE_ENV at top of server.js (should be 1)
27. PORT override in stop.bat (should be 1)
28. IP Display component (should be present)

---

## Appendix Y: Deployment Checklist

### Pre-Deployment

- [ ] Run `node -c` on all JavaScript files (0 errors)
- [ ] Verify all 28 fix checks pass
- [ ] Run 5-iteration Arson Directive (all pass)
- [ ] Test all API endpoints via curl
- [ ] Verify browse tab loads 5,533 series
- [ ] Verify C-Fetch buttons create queue jobs
- [ ] Verify STOP button aborts operations
- [ ] Verify all 4 tabs work (Browse, Library, Queue, Settings)
- [ ] Verify IP Display shows current public IP
- [ ] Verify theme switching works
- [ ] Verify series detail shows chapters
- [ ] Verify reader displays chapter content

### Deployment

- [ ] Create zip with `-0` flag (no compression)
- [ ] Include: `node/`, `server/`, `start.bat`, `stop.bat`
- [ ] Verify zip size is ~281MB
- [ ] Upload to gofile.io
- [ ] Test download link works
- [ ] Extract and test on clean machine

### Post-Deployment

- [ ] Run `start.bat` — server starts on port 3000
- [ ] Open `http://localhost:3000` — app loads
- [ ] Test from another device on same network
- [ ] Configure port forwarding for internet access
- [ ] Verify Windows Firewall allows port 3000
- [ ] Test access from external network using public IP
- [ ] Verify IP Display matches public IP

### Maintenance

- [ ] Monitor server logs for errors
- [ ] Check Reddit rate limit messages
- [ ] Monitor proxy pool health (`/api/proxy-stats`)
- [ ] Periodically clear old cached chapters (Settings → Purge)
- [ ] Update Reddit OAuth tokens if expired
- [ ] Re-run Arson Directive after any code changes

---

## Appendix Z: Version History Summary

| Version | Date | Key Changes |
|---------|------|-------------|
| FX1-FX12 | Early 2026 | Initial development, basic reader |
| FX13-FX24 | Mid 2026 | Reddit scraping, C-Fetch, download system |
| FX25-FX33 | Late 2026 | Multi-tier scraper, CORS proxy pool, themes |
| FX34-FX36 | Jul 2026 | Bug fixes, stability improvements |
| FX37 | Jul 2026 | C-Fetch queue system, browse-tab C-Fetch |
| FX38-FX41 | Jul 2026 | Continue C-Fetch fixes, Phase 2 removal |
| FX42 | Jul 23, 2026 | 120 bug fixes from full audit |
| FX43 v1-v2 | Jul 23, 2026 | 8 re-audit fixes (server.js, stop.bat, etc.) |
| FX43 v3-v4 | Jul 23, 2026 | 66 SSRF/security fixes |
| FX43 v5 | Jul 23, 2026 | 56 bug fixes (chapters DELETE, ok shadowing) |
| FX43 v6 | Jul 23, 2026 | Series card upvote update after C-Fetch |
| FX43 v7 | Jul 23, 2026 | Chapter/downloaded count updates + reduced delays |
| FX43 v8 | Jul 23, 2026 | proxy-stats fix + 4 prototype pollution guards |
| FX43 v9 | Jul 23, 2026 | IP Display feature (neon teal + purple shadow) |

### Total Bugs Fixed: 300+

- 7 CRITICAL bugs
- 19 HIGH bugs
- 50 MEDIUM bugs
- 44 LOW bugs
- 66 SSRF/security fixes
- 56 re-audit fixes
- 8 final audit fixes

### Total Features: 50+

- 5,533 series catalog
- 8-tier Reddit scraping cascade
- 386 CORS proxy pool
- C-Fetch (Rehash + Continue) with queue integration
- Download system (individual + merge EPUB)
- 12 app themes, 24 reader themes, 24 fonts
- Auto-discover (8-stage pipeline)
- Wayback Machine integration
- HFY Foundation integration
- Multi-account OAuth rotation (up to 9 accounts)
- Cookie-based authentication
- PWA support (service worker + manifest)
- Android APK support (Capacitor)
- IP Display with neon styling
- Background aggregation
- Triple-storage persistence (localStorage + IDB + server)

---

*This manual is the complete reference for HFY NEKROCODEXXX FX43 v9. Total: ~28,000+ words. Generated: 2026-07-23.*

---

## Appendix AA: Frequently Asked Questions

### General Questions

**Q: What does HFY stand for?**
A: HFY stands for "Humanity, Fuck Yeah!" — a creative writing subreddit where authors post science fiction stories featuring humanity as a powerful, competent, or inspiring force in a universe full of alien species.

**Q: Is this app affiliated with Reddit?**
A: No. This is an independent, community-built reader application. It uses Reddit's public API and RSS feeds to fetch content, but is not endorsed by or affiliated with Reddit Inc.

**Q: Do I need a Reddit account to use this?**
A: No. The app works anonymously via the bundled OAuth client (100 queries/minute) or the CORS proxy pool. However, connecting a Reddit account increases the rate limit to 600 queries/minute and provides access to NSFW content.

**Q: Is the app free?**
A: Yes, completely free and open source. No ads, no tracking, no subscriptions.

### Technical Questions

**Q: Why is the zip file 281MB?**
A: The zip includes the bundled Node.js runtime (80MB), all node_modules (93MB), 5,533 hardcoded series with chapter lists (18MB compiled data), 48 background images (23MB), and the compiled Next.js bundles (80MB). The zip uses no compression (`-0` flag) to match the original distribution format.

**Q: Can I run this on Linux or macOS?**
A: The start.bat and stop.bat are Windows-specific, but the server itself (server.js) runs on any platform with Node.js. On Linux/macOS, run `cd server && PORT=3000 HOSTNAME=0.0.0.0 node server.js` directly.

**Q: How much RAM does the server use?**
A: Typically 150-300MB depending on the number of cached chapters and concurrent requests. The `cacheMaxMemorySize` is set to 50MB, with additional memory for React rendering and file I/O buffers.

**Q: Can multiple users use the same server?**
A: Yes, but there's no multi-user support. All users share the same library, queue, and cached data. For multi-user deployment, run separate instances on different ports.

### C-Fetch Questions

**Q: What's the difference between Rehash and Continue?**
A: Rehash re-fetches ALL chapters in a series (even already-cached ones) to detect changes. Continue fetches ONLY unfetched chapters and then stops.

**Q: How long does C-Fetch take?**
A: It depends on the number of chapters and Reddit's rate limit. With a batch size of 5 and 300ms delay between batches, a 100-chapter series takes about 6 seconds. A 500-chapter series takes about 30 seconds.

**Q: Can I C-Fetch multiple series at once?**
A: The browse-tab C-Fetch processes all 5,533 series sequentially (one at a time). You can't start a second C-Fetch while one is running. The per-series C-Fetch only processes one series at a time.

**Q: What happens if I close the tab during C-Fetch?**
A: The C-Fetch continues in the background using module-level state. When you return to the series detail tab, the polling effect syncs the progress. However, if you close the entire browser, the fetch is aborted.

### Download Questions

**Q: What format are downloads in?**
A: EPUB format (compatible with most e-readers including Kindle, Kobo, Apple Books, Google Play Books). On Android with the native interface, plain text is used instead (Java can't write binary EPUB).

**Q: Can I download all chapters at once?**
A: Yes, use "MERGE INTO 1 FILE" to create a single EPUB containing all chapters, or "ALL INDIVIDUAL" to create separate EPUB files for each chapter.

**Q: Why do some chapters fail to download?**
A: The chapter may be deleted from Reddit, or Reddit is rate-limiting the server. The app retries failed chapters up to 3 times with exponential backoff. If all retries fail, the chapter is skipped and a warning is shown.

### Hosting Questions

**Q: How do I access the app from my phone?**
A: 1) Run start.bat on your PC. 2) Find your PC's local IP (ipconfig). 3) On your phone, open http://YOUR.PC.IP:3000 (both devices must be on the same WiFi).

**Q: How do I access from anywhere in the world?**
A: 1) Run start.bat. 2) Set up port forwarding on your router (port 3000 → your PC). 3) Find your public IP (check the IP Display in the app or Google "what's my IP"). 4) On any device, open http://YOUR.PUBLIC.IP:3000.

**Q: Is it safe to expose to the internet?**
A: The app has no authentication. Anyone who knows your IP can access it. The changing IP acts as minimal security. For real security, add a password middleware in server.js or use a reverse proxy with auth.

---

*End of manual. HFY NEKROCODEXXX FX43 v9 — Complete documentation — ~25,500 words — 2026-07-23.*


---

*End of Build and Deployment Guide*
