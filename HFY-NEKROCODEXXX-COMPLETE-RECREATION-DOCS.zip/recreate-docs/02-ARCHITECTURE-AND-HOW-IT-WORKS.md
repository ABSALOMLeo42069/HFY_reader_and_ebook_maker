# HFY NEKROCODEXXX — Architecture and How It Works

**Version:** FX45 v31  
**Last Updated:** 2026-07-30

---

## Table of Contents

1. [High-Level Architecture](#1-high-level-architecture)
2. [Technology Stack](#2-technology-stack)
3. [Server Architecture](#3-server-architecture)
4. [Client Architecture](#4-client-architecture)
5. [Data Flow](#5-data-flow)
6. [State Management](#6-state-management)
7. [Persistence Model](#7-persistence-model)
8. [Reddit Fetch Strategy Cascade](#8-reddit-fetch-strategy-cascade)
9. [CORS Proxy Pool](#9-cors-proxy-pool)
10. [JSONL Indexing Engine](#10-jsonl-indexing-engine)
11. [Chapter Discovery Pipeline](#11-chapter-discovery-pipeline)
12. [C-FETCH System](#12-c-fetch-system)
13. [Download and Merge System](#13-download-and-merge-system)
14. [Auto-Discover Pipeline](#14-auto-discover-pipeline)
15. [OAuth Multi-Account Token Rotation](#15-oauth-multi-account-token-rotation)
16. [Service Worker and PWA](#16-service-worker-and-pwa)
17. [Android APK Architecture](#17-android-apk-architecture)
18. [Windows Standalone Architecture](#18-windows-standalone-architecture)
19. [Build Configuration](#19-build-configuration)
20. [API Reference](#20-api-reference)

---

## 1. High-Level Architecture

HFY NEKROCODEXXX follows a client-server architecture within a single Node.js process. The server runs on port 3000 and serves both the React frontend (static assets) and the API endpoints (dynamic data). A secondary HTTP server runs on port 3001 for JSONL batch operations.

```
┌──────────────────────────────────────────────────────────────────┐
│                     User's Browser / WebView                      │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │              React SPA (page-94aba2608e3f02d1.js)         │    │
│  │                                                            │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │    │
│  │  │ Browse  │  │ Library │  │ Archive │  │Discover │     │    │
│  │  │  Tab    │  │  Tab    │  │  Tab    │  │  Tab    │     │    │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │    │
│  │                                                            │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────────────────┐       │    │
│  │  │  Queue  │  │Settings │  │   Zustand Stores     │       │    │
│  │  │  Tab    │  │  Tab    │  │ (library, scores,    │       │    │
│  │  └─────────┘  └─────────┘  │  nav, settings, etc) │       │    │
│  │                             └─────────────────────┘       │    │
│  │                                                            │    │
│  │  ┌──────────────────────────────────────────────────┐    │    │
│  │  │           JSONL Engine (window.__jsonlEngine)      │    │    │
│  │  │  ┌─────────┐ ┌─────────┐ ┌──────────┐            │    │    │
│  │  │  │ Index   │ │ Authors │ │Subreddits│            │    │    │
│  │  │  │ (Map)   │ │ (Map)   │ │ (Map)   │            │    │    │
│  │  │  └─────────┘ └─────────┘ └──────────┘            │    │    │
│  │  └──────────────────────────────────────────────────┘    │    │
│  │                                                            │    │
│  │  ┌──────────────────────────────────────────────────┐    │    │
│  │  │         IndexedDB (hfy-dir-handles, caches)        │    │    │
│  │  └──────────────────────────────────────────────────┘    │    │
│  └──────────────────────────────────────────────────────────┘    │
│                              │                                     │
│                     fetch() / HTTP                                 │
│                              ▼                                     │
└──────────────────────────────┼────────────────────────────────────┘
                               │
┌──────────────────────────────┼────────────────────────────────────┐
│                    Node.js Server (port 3000)                      │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │                    Next.js 16 Standalone                    │    │
│  │                                                            │    │
│  │  ┌──────────────────────────────────────────────────┐    │    │
│  │  │              API Routes (41 endpoints)              │    │    │
│  │  │                                                      │    │    │
│  │  │  /api/store/[key]     — Key-value store              │    │    │
│  │  │  /api/series           — Series list                  │    │    │
│  │  │  /api/series/[slug]    — Series detail + chapters     │    │    │
│  │  │  /api/series/[slug]/add-chapter  — Add chapter       │    │    │
│  │  │  /api/series/[slug]/fetch-cache  — C-FETCH           │    │    │
│  │  │  /api/series/[slug]/continue-fetch — Continue crawl  │    │    │
│  │  │  /api/series/[slug]/fetch-missing  — Gap filling     │    │    │
│  │  │  /api/series/[slug]/detect-gaps    — Gap detection   │    │    │
│  │  │  /api/series/[slug]/reparse        — Reparse wiki    │    │    │
│  │  │  /api/chapter/[id]    — Chapter content              │    │    │
│  │  │  /api/chapter-cache/[postId] — Chapter cache         │    │    │
│  │  │  /api/download         — Download chapters            │    │    │
│  │  │  /api/crawl            — RSS crawl                    │    │    │
│  │  │  /api/search           — Search series                │    │    │
│  │  │  /api/search-series    — Search series index          │    │    │
│  │  │  /api/auto-discover    — Auto-discover pipeline       │    │    │
│  │  │  /api/auto-discover/[jobId] — Job status             │    │    │
│  │  │  /api/reddit-auth      — OAuth PKCE                   │    │    │
│  │  │  /api/reddit-token     — Token exchange               │    │    │
│  │  │  /api/reddit-multi-token — Multi-account rotation    │    │    │
│  │  │  /api/reddit-cookies   — Cookie management            │    │    │
│  │  │  /api/reddit-app-token — App-only token               │    │    │
│  │  │  /api/reddit-user-token — User token storage          │    │    │
│  │  │  /api/reddit-password-login — Direct login            │    │    │
│  │  │  /api/reddit-logout    — Logout                       │    │    │
│  │  │  /api/proxy-browser    — HTTP proxy + browser session │    │    │
│  │  │  /api/proxy-stats      — Proxy statistics             │    │    │
│  │  │  /api/store-scores-all — All series scores            │    │    │
│  │  │  /api/store-chapter-counts-all — Chapter counts      │    │    │
│  │  │  /api/hfy-foundation-search — hfy.foundation search  │    │    │
│  │  │  /api/live-wiki        — Live wiki fetch              │    │    │
│  │  │  /api/wayback-sync     — Wayback Machine sync         │    │    │
│  │  │  /api/mass-import      — Mass import chapters         │    │    │
│  │  │  /api/purge-cache      — Purge cache                  │    │    │
│  │  │  /api/fetch-all-posts  — Fetch all posts              │    │    │
│  │  │  /api/hardcoded-chapters/[slug] — Hardcoded chapters │    │    │
│  │  │  /api/browser-session  — Browser session              │    │    │
│  │  └──────────────────────────────────────────────────┘    │    │
│  │                                                            │    │
│  │  ┌──────────────────────────────────────────────────┐    │    │
│  │  │           Reddit Scraper (4034.js chunk)            │    │    │
│  │  │                                                      │    │    │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐              │    │    │
│  │  │  │ OAuth   │ │ Cookies │ │ Browser │              │    │    │
│  │  │  │ JSON    │ │         │ │  Sim   │              │    │    │
│  │  │  └─────────┘ └─────────┘ └─────────┘              │    │    │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐              │    │    │
│  │  │  │  RSS    │ │  CORS   │ │  .json  │              │    │    │
│  │  │  │ Feed    │ │ Proxies │ │ Fallback│              │    │    │
│  │  │  └─────────┘ └─────────┘ └─────────┘              │    │    │
│  │  │  ┌─────────┐ ┌─────────┐                          │    │    │
│  │  │  │ Wayback │ │  hfy.   │                          │    │    │
│  │  │  │ Machine │ │foundat. │                          │    │    │
│  │  │  └─────────┘ └─────────┘                          │    │    │
│  │  └──────────────────────────────────────────────────┘    │    │
│  │                                                            │    │
│  │  ┌──────────────────────────────────────────────────┐    │    │
│  │  │              Filesystem Persistence                  │    │    │
│  │  │                                                      │    │    │
│  │  │  data/app-store/    — Key-value JSON store           │    │    │
│  │  │  data/user-chapters/ — Series chapter lists          │    │    │
│  │  │  data/chapter-cache/ — Fetched chapter content       │    │    │
│  │  └──────────────────────────────────────────────────┘    │    │
│  └──────────────────────────────────────────────────────────┘    │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │          JSONL Batch Handler (port 3001)                  │    │
│  │                                                            │    │
│  │  /batch-scores  — Batch score storage                     │    │
│  │  /batch-cache   — Batch chapter cache                     │    │
│  │  /stats         — Index statistics                        │    │
│  │  /store/[key]   — File-based store                        │    │
│  │  /file/[name]   — Serve JSONL files                       │    │
│  └──────────────────────────────────────────────────────────┘    │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │          Aggregation Script (aggregate-counts.js)         │    │
│  │                                                            │    │
│  │  Runs on startup + every 120 seconds:                     │    │
│  │  - Scans app-store/hfy-downloaded-*.json                  │    │
│  │  - Scans user-chapters/*.json                             │    │
│  │  - POSTs to /api/store/hfy-downloaded-counts              │    │
│  │  - POSTs to /api/store/hfy-chapter-counts                 │    │
│  └──────────────────────────────────────────────────────────┘    │
└────────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│                        External Services                          │
│                                                                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐    │
│  │  Reddit  │  │ Wayback  │  │   hfy.   │  │    CORS      │    │
│  │   API    │  │ Machine  │  │foundation│  │  Proxy Pool  │    │
│  │          │  │          │  │          │  │  (386 proxies)│    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘    │
└────────────────────────────────────────────────────────────────────┘
```

The architecture is designed around the principle that the server is a thin proxy and file system, while the client (browser) does most of the heavy lifting. State management is entirely client-side via Zustand stores. The server does not maintain session state — each API request is independent.

---

## 2. Technology Stack

### Core Framework

- **Next.js 16.2.10** with App Router (src/app/)
- **React 19.0.0**
- **TypeScript 5** (with ignoreBuildErrors: true for standalone build)
- **Node.js 22+** (Node.js 24 bundled with the Windows package)
- **Bun 1.3.x** as the package manager and build tool

### Styling and UI

- **Tailwind CSS 4** via @tailwindcss/postcss
- **Framer Motion 12.23** for screen transitions, splash screen, glitch animations
- **lucide-react 0.525** for icons
- **Sonner 2.0.6** for toast notifications
- Custom cyberpunk UI components (clip-path polygons, neon glows, scanline overlays)

### State Management

- **Zustand 5.0.6** with persist middleware (uses localStorage)
- 7 Zustand stores: useLibrary, useSeriesScores, useSettings, useNav, useDownloadQueue, useBrowseCache, useMultiAccount

### Data Layer

- Filesystem persistence: data/user-chapters/{slug}.json for series chapter lists
- IndexedDB for directory handles and chapter content caches
- Server-side key-value store: data/app-store/{key}.json

### Networking

- Native fetch API everywhere
- socket.io-client 4.8 for the WebSocket parser mini-service (port 3003)
- 386 public CORS proxies in a rotation pool

### Document Export

- **JSZip 3.10** for EPUB generation (client-side)
- **file-saver 2.0** for downloads
- **react-markdown 10.1** for rendering chapter content

### PWA and Mobile

- public/manifest.json (Web App Manifest)
- public/sw.js (Service Worker — cache-first for static, network-first for pages)
- Capacitor 8.4 for Android APK wrapping

### Reddit API Integration

- Reddit's .rss Atom feeds (primary — bypasses IP blocks)
- Reddit's .json endpoints (via CORS proxy pool — secondary)
- OAuth 2.0 with PKCE for authenticated access
- Reddit's wiki API for series index

### Build Configuration

The webapp is built with Next.js standalone output mode:

```json
{
  "output": "standalone",
  "swcMinify": false,
  "webpack": { "optimization": { "minimize": false } },
  "typescript": { "ignoreBuildErrors": true }
}
```

- `output: "standalone"` — produces a self-contained server in .next/standalone/ that does not require npm install on the target machine
- `swcMinify: false` — prevents TDZ (Temporal Dead Zone) errors in the bundled code
- `webpack.optimization.minimize: false` — same reason; prevents variable hoisting issues
- `typescript.ignoreBuildErrors: true` — ships despite TypeScript errors (the code works at runtime even if types are imperfect)

The 72,248 chapters are distributed across 22 chunk files loaded into memory at startup. The main page chunk (page-94aba2608e3f02d1.js) is approximately 2.7 MB and contains all React components, Zustand stores, and client-side logic.

---

## 3. Server Architecture

The server is a Next.js 16 standalone application that runs on port 3000. It consists of three main components:

### 3.1 server.js

The main entry point. It:
1. Sets NODE_ENV to production
2. Changes the working directory to __dirname (the server/ folder)
3. Parses PORT and HOSTNAME from environment variables
4. Loads the Next.js configuration
5. Starts the Next.js server via startServer()
6. After the server is up, starts aggregate-counts.js and jsonl-handler.js

The server.js file also includes a 250 KB/s keepalive system (disabled in webapp/Windows builds) that was designed for Android to maintain network activity and prevent the OS from killing the foreground service. The keepalive downloads 250 KB from a CDN and uploads 250 KB to an echo service every second, with a memory guard that skips keepalive if RSS exceeds 1.5 GB.

Global error handlers catch unhandled rejections and uncaught exceptions to prevent the server from crashing:

```javascript
process.on('unhandledRejection', (reason, promise) => {
    console.error('[unhandledRejection]', reason?.message || reason);
});
process.on('uncaughtException', (err) => {
    console.error('[uncaughtException]', err?.message || err);
});
```

### 3.2 aggregate-counts.js

Runs on startup and every 120 seconds. It:
1. Scans data/app-store/hfy-downloaded-*.json for downloaded chapter counts
2. Scans data/user-chapters/*.json for real chapter counts
3. POSTs aggregated data to /api/store/hfy-downloaded-counts and /api/store/hfy-chapter-counts

Uses http.request() instead of fetch() because fetch is not available in the Android Node.js runtime (Node.js v18 on ARM64). The aggregation script is non-blocking and runs in the background.

### 3.3 jsonl-handler.js

A separate HTTP server on port 3001 that handles batch operations for the JSONL indexing engine:
- POST /batch-scores — batch save scores to hfy-scores-{seriesId}.json
- POST /batch-cache — batch save chapter content to chapter-cache/{postId}.json
- GET /stats — return indexing statistics
- GET /store/{key} — file-based key-value store
- GET /file/{name} — serve JSONL files from public/

This separate server exists because the main Next.js server processes requests individually (one HTTP request per operation), which is too slow for batch operations involving thousands of posts. The JSONL handler can accept a single POST with 10,000+ entries and write them all to disk in one operation.

---

## 4. Client Architecture

The client is a React Single Page Application (SPA) built with Next.js App Router. The entire client-side code is bundled into a single JavaScript chunk: page-94aba2608e3f02d1.js (2.7 MB).

### 4.1 Component Hierarchy

```
<App>
  ├── <ErrorBoundary>
  │   └── <RootComponent>
  │       ├── <SplashScreen> (shown for 3 seconds on boot)
  │       ├── <AnimatePresence> (screen transitions)
  │       │   └── {screen === "browse" && <BrowseScreen>}
  │       │   └── {screen === "library" && <LibraryScreen>}
  │       │   └── {screen === "archive" && <ArchiveScreen>}
  │       │   └── {screen === "discovered" && <DiscoveredSeriesScreen>}
  │       │   └── {screen === "queue" && <QueueScreen>}
  │       │   └── {screen === "settings" && <SettingsScreen>}
  │       │   └── {screen === "series" && <SeriesDetailScreen>}
  │       │   └── {screen === "reader" && <ReaderScreen>}
  │       └── <FloatingNav> (bottom navigation bar)
  ├── <Toaster> (toast notifications)
  └── <ConfirmDialog> (themed confirmation popups)
```

### 4.2 Screen Components

**BrowseScreen:** Displays all 5,393 series in a grid of cards. Supports sorting (NEW, SCORE, CHAPTERS, A-Z), searching, and long-press to add to library. Each card shows series title, author, chapter count, downloaded count, total upvotes, and source indicators.

**LibraryScreen:** Displays the user's saved series. Filters: All, Favorites, Reading, Downloaded, Local, Recent. Same card layout as BrowseScreen.

**ArchiveScreen:** Browses all posts from indexed JSONL files. Features subreddit filter, sort (Top, Newest, Oldest), title search, author filter, date filter, min score filter, and pagination (20 posts per page). Each post card shows score, title, author, subreddit, date, content length, comment count, NSFW badge, and flair.

**DiscoveredSeriesScreen:** Shows series auto-detected from JSONL posts. Detail view shows chapters, confidence score, strategy summary, gaps, and action buttons (ADD TO LIBRARY, RE-DISCOVER, DELETE, ADD TO SERIES).

**QueueScreen:** Shows active and completed download/C-FETCH operations with progress bars and STOP buttons.

**SettingsScreen:** Contains all configuration. Organized into sections: Reddit Accounts, Downloader Cascade, CORS Proxy Pool, App Theme, Reader Theme, Download Settings, Local Folders, Subreddit JSONL Data, Persistence Audit, Reddit Cookies, About.

**SeriesDetailScreen:** Shows series synopsis, source links, chapter list, and action buttons (REHASH, CONTINUE, GAPS, SEARCH, CACHE ALL FROM JSONL). Each chapter row shows chapter number, title, upvote count (or skull icon if not fetched), read/unread status, download status, author, and word count.

**ReaderScreen:** Full-screen reader with markdown rendering, font controls, theme selection, swipe navigation, and progress tracking.

### 4.3 Zustand Stores

The application uses 7 Zustand stores for state management:

**useLibrary:** Manages the user's library (saved series, favorites, reading progress).
```javascript
{
  items: { [seriesId]: { seriesId, title, author, isFavorite, lastReadChapterId, progress, readChapters, ... } },
  addToLibrary: (item) => void,
  toggleFavorite: (seriesId) => void,
  ...
}
```

**useSeriesScores:** Manages upvote scores for all series.
```javascript
{
  scores: { [seriesId]: { [postId]: number } },
  setSeriesScores: (seriesId, scores) => void,
  ...
}
```

**useSettings:** Manages app settings (font size, font family, themes, batch size, etc.).
```javascript
{
  fontSize: number,
  fontFamily: string,
  appTheme: string,
  readerTheme: string,
  cFetchBatchSize: number,
  ...
}
```

**useNav:** Manages navigation state.
```javascript
{
  screen: string,  // "browse" | "library" | "archive" | "discovered" | "queue" | "settings" | "series" | "reader"
  seriesId: string | null,  // current series for series detail
  chapterId: string | null,  // current chapter for reader
  goTo: (screen, params?) => void,
  openSeries: (seriesId) => void,
  ...
}
```

**useDownloadQueue:** Manages the download/C-FETCH queue.
```javascript
{
  jobs: [{ id, type, seriesId, progress, status, ... }],
  addJob: (job) => void,
  updateJob: (id, updates) => void,
  ...
}
```

**useBrowseCache:** Caches browse tab data (series list, sort order, search results).

**useMultiAccount:** Manages connected Reddit accounts for OAuth rotation.
```javascript
{
  accounts: [{ id, username, accessToken, refreshToken, expiresAt, clientId, ... }],
  addAccount: (account) => void,
  removeAccount: (id) => void,
  ...
}
```

---

## 5. Data Flow

### 5.1 Browsing Series

1. User opens the app → SplashScreen shows for 3 seconds
2. After boot, BrowseScreen mounts
3. BrowseScreen calls fetch('/api/series') to get the series list
4. /api/series calls fetchSeriesIndex() in 4034.js
5. fetchSeriesIndex() tries 4 strategies: OAuth → RedDownloader → direct .json → CORS proxy pool
6. If all fail, falls back to getBakedSeriesIndex() (5,533 hardcoded series)
7. Series list is returned to the client and cached in useBrowseCache
8. BrowseScreen renders series cards

### 5.2 Reading a Chapter

1. User taps a series → SeriesDetailScreen opens
2. SeriesDetailScreen calls fetch('/api/series/{slug}/chapters') to get chapter list
3. Chapter list is loaded from user-chapters/{slug}.json (or hardcoded data)
4. User taps a chapter → ReaderScreen opens
5. ReaderScreen calls fetch('/api/chapter/{id}') to get chapter content
6. /api/chapter calls fetchPostContent() in 4034.js
7. fetchPostContent() tries strategies in order:
   - Strategy -1: JSONL local archive (if indexed)
   - Strategy 0: OAuth JSON (oauth.reddit.com)
   - Strategy 0.5: Cookie-based fetch
   - Strategy 0.7: Browser simulation
   - Strategy 1: Direct RSS
   - Strategy 2: CORS proxy pool
   - Strategy 3: Direct .json fallback
   - Wayback Machine
   - hfy.foundation
8. Content is returned, cached in IndexedDB and server chapter-cache/
9. ReaderScreen renders the content as markdown

### 5.3 C-FETCH (REHASH)

1. User taps REHASH on SeriesDetailScreen
2. Client sends POST /api/series/{slug}/fetch-cache with NDJSON streaming
3. Server iterates through all chapters in the series
4. For each chapter, calls fetchPostContent() (which checks JSONL first)
5. Server streams progress updates as NDJSON lines: {"type":"progress","done":5,"total":100}
6. Client updates progress bar in real-time
7. When complete, scores are saved to hfy-scores-{slug}.json
8. Chapter content is saved to chapter-cache/{postId}.json
9. Client's useSeriesScores store is updated

---

## 6. State Management

State management is handled entirely client-side via Zustand stores. The server is stateless — each API request is independent.

### Triple-Storage Persistence Pattern

Each Zustand store uses a custom persistence adapter that writes to three locations:

1. **localStorage** — fast, synchronous reads. Used for all state. Cleared on Android restart.
2. **IndexedDB** — persists across restarts. Used for large data (chapter caches, directory handles).
3. **Server filesystem** — durable, unlimited size. The authoritative source of truth.

On startup:
1. Zustand reads from localStorage (synchronous, fast)
2. If localStorage is empty (Android restart), an effect triggers server restore
3. Server restore fetches from /api/store/{key} and populates localStorage
4. If any store was restored from server, the page reloads once (with sessionStorage guard to prevent loops)

### Persistence Adapter

```javascript
const tripleStorage = {
  getItem: (name) => {
    // Synchronous read from localStorage
    return localStorage.getItem(name);
  },
  setItem: (name, value) => {
    // Write to localStorage (synchronous)
    localStorage.setItem(name, value);
    // Fire-and-forget write to server
    fetch(`/api/store/${name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: value
    }).catch(() => {});
  },
  removeItem: (name) => {
    localStorage.removeItem(name);
    fetch(`/api/store/${name}`, { method: 'DELETE' }).catch(() => {});
  }
};
```

---

## 7. Persistence Model

All data is stored on the server filesystem at `HFY_DATA_DIR/hfy-data/` (or `./data/` on desktop):

### Directory Structure

```
data/
├── app-store/                          # Key-value JSON store
│   ├── hfy-nekrocodexxx-library.json   # Library items + favorites
│   ├── hfy-nekrocodexxx-settings.json  # App settings
│   ├── hfy-series-scores-v1.json       # All series scores (large, 2-3 MB)
│   ├── hfy-scores-{seriesId}.json      # Per-series scores
│   ├── hfy-chapter-scores-{seriesId}.json # Per-series chapter scores + fetched status
│   ├── hfy-downloaded-{seriesId}.json  # Downloaded chapter markers
│   ├── hfy-downloaded-counts.json      # Aggregated download counts
│   ├── hfy-chapter-counts.json         # Aggregated chapter counts
│   ├── hfy-merged-content-{seriesId}.json # Merged ebook content
│   ├── hfy-merged-flag-{seriesId}.json # Merge deletion flags
│   ├── hfy-custom-series.json          # Custom series definitions
│   ├── hfy-custom-link-patterns.json   # Custom crawl link patterns
│   ├── hfy-pattern-toggles.json        # Built-in pattern toggles
│   ├── hfy-local-series.json           # Locally imported series
│   ├── hfy-discovered-series.json      # Discovered series (JSONL)
│   ├── hfy-scores-_jsonl_all.json      # All JSONL scores (bulk)
│   ├── hfy-chapter-scores-_jsonl_all.json # All JSONL chapter scores
│   ├── reddit-cookies-json.json        # Reddit cookies
│   └── ... (other store files)
│
├── user-chapters/                      # Series chapter lists
│   ├── zyz.json                        # ZYZ series chapters
│   ├── the_nature_of_predators.json    # NoP series chapters
│   └── ... (one file per series with user-added chapters)
│
└── chapter-cache/                      # Fetched chapter content
    ├── ciqsdj.json                     # Chapter content for post ciqsdj
    ├── cj0km0.json                     # Chapter content for post cj0km0
    └── ... (one file per fetched chapter)
```

### Atomic Writes

The /api/store/[key] route uses atomic writes to prevent corruption:

```javascript
async function writeFileAtomic(p, content) {
    const tmp = p + ".tmp." + process.pid;
    await fs.promises.writeFile(tmp, content, "utf8");
    try {
        await fs.promises.rename(tmp, p);
    } catch {
        // Rename may fail across devices — fall back to direct write
        try { await fs.promises.unlink(tmp).catch(() => {}); } catch {}
        await fs.promises.writeFile(p, content, "utf8");
    }
}
```

### safeName Function

The safeName function transforms URL keys to filesystem-safe names:

```javascript
function safeName(key) {
    return key.replace(/[^a-zA-Z0-9_-]/g, "_");
}
```

This means `hfy-discovered-series.json` becomes `hfy-discovered-series_json.json` on disk. Both GET and POST use the same transformation, so the mapping is consistent.

---

## 8. Reddit Fetch Strategy Cascade

The fetchPostContent function in 4034.js tries 9 strategies in sequence. Each strategy is attempted only if the previous one failed. The function returns the first successful result.

### Strategy -1: JSONL Local Archive (Ultimate Primary)

If the post exists in the JSONL index (window.__jsonlIndex), the content is read from the local JSONL file using file.slice(byteOffset, byteOffset + lineLength). This is instant (less than 1 millisecond) and requires no network calls.

### Strategy 0: OAuth JSON (Primary)

Uses OAuth Bearer tokens from connected Reddit accounts to access oauth.reddit.com. The token is obtained from the multi-account rotation pool (getNextMultiToken). If no user tokens are available, falls back to the app-only token (getAppOnlyToken).

```javascript
const oauthAuth = await getRedditOAuthToken();
const hdrs = { "User-Agent": getRandomUA(), Accept: "application/json" };
if (oauthAuth) hdrs["Authorization"] = `Bearer ${oauthAuth.token}`;
const res = await fetch(`https://oauth.reddit.com/comments/${postId}`, {
    headers: hdrs,
    signal: AbortSignal.timeout(8000),
    cache: "no-store"
});
```

### Strategy 0.5: Cookie-Based Fetch

Uses injected Reddit session cookies for authenticated .json access. The cookies are stored in the reddit-cookies-json store and sent as Cookie headers.

### Strategy 0.7: Browser Simulation

Sends complete Chrome browser headers (Sec-Fetch-*, Sec-Ch-Ua, Accept-Encoding) with OAuth token to mimic a real browser visit. This helps bypass some rate limiting that checks for browser-like headers.

### Strategy 1: Direct RSS

Reddit's .rss Atom feeds are not subject to the same IP-level restrictions as .json endpoints. The RSS feed returns XML which is parsed to extract the post content.

```javascript
const res = await fetch(`https://www.reddit.com/r/HFY/comments/${postId}.rss`, {
    headers: { "User-Agent": getRandomUA(), ...oauthHeaders },
    signal: AbortSignal.timeout(8000)
});
const xml = await res.text();
// Parse XML to extract content
```

### Strategy 2: CORS Proxy Pool

If all direct methods fail, the app tries 386 public CORS proxies in sequence. Each proxy is tried once; if it fails, the next proxy is tried. Proxies that fail are marked as "dead" with a cooldown period.

### Strategy 3: Direct .json Fallback

Last resort: fetch the .json endpoint directly without OAuth. This will likely fail if the IP is rate-limited, but it's worth trying as a final attempt.

### Wayback Machine

If all Reddit strategies fail, the app tries to retrieve archived content from web.archive.org. The Wayback Machine API is queried for the post URL, and the most recent snapshot is fetched.

### hfy.foundation

The hfy.foundation community project indexes HFY content. The app queries hfy.foundation's API for the post, and if found, returns the indexed content.

---

## 9. CORS Proxy Pool

The CORS proxy pool consists of 386 public CORS proxy servers. The pool is defined in the cors_proxies module (part of 4034.js chunk) and includes proxies from various sources:

- allorigins.win (multiple variants)
- corsproxy.io
- api.codetabs.com
- thingproxy
- cors-anywhere
- dev.aiken
- aux.sx
- ashitani
- ... and many more

### Proxy Rotation Strategy

1. Shuffle the proxy list at startup
2. Try each proxy in order until one succeeds
3. Mark failing proxies as "dead" with a cooldown period (5 minutes)
4. Periodically re-check dead proxies (every 10 minutes)
5. Track latency statistics per proxy

### fetchWithProxies Function

```javascript
async function fetchWithProxies(url, options) {
    const { maxProxiesToTry = 10, timeoutMs = 10000, expectedType = "json" } = options;
    const aliveProxies = proxyPool.alive;
    const shuffled = shuffle(aliveProxies).slice(0, maxProxiesToTry);
    
    for (const proxy of shuffled) {
        const proxyUrl = proxy.template
            .replace('{{url}}', encodeURIComponent(url))
            .replace('{{rawUrl}}', url)
            .replace('{{origin}}', new URL(url).origin);
        
        try {
            const res = await fetch(proxyUrl, {
                signal: AbortSignal.timeout(timeoutMs),
                cache: "no-store"
            });
            if (res.ok) {
                const text = await res.text();
                proxy.lastSuccess = Date.now();
                proxy.latency = Date.now() - startTime;
                return { ok: true, text, proxyId: proxy.id };
            }
        } catch (e) {
            proxy.lastFailure = Date.now();
            proxy.failCount++;
            if (proxy.failCount > 3) {
                proxy.dead = true;
                proxy.deadUntil = Date.now() + 5 * 60 * 1000;
            }
        }
    }
    return { ok: false, error: "All proxies failed" };
}
```

---

## 10. JSONL Indexing Engine

The JSONL indexing engine is a client-side system that parses Reddit data dump files (JSONL format) and builds in-memory indices for fast content retrieval.

### Data Structures

**Primary Index (window.__jsonlIndex):**
A Map of postId to post metadata:
```javascript
{
    fileName: string,           // "r_hfy_posts.jsonl"
    fileEntry: FileSystemFileHandle,
    byteOffset: number,         // byte position of this post's line
    lineLength: number,         // byte length of this line
    id: string,                 // Reddit post ID
    title: string,
    author: string,             // lowercase
    score: number,              // upvote score
    created_utc: number,        // Unix timestamp
    permalink: string,
    subreddit: string,          // lowercase
    num_comments: number,
    over_18: boolean,
    is_self: boolean,
    selftextLength: number,
    url: string,
    link_flair_text: string | null,
    upvote_ratio: number | null,
}
```

**Author Index (window.__jsonlAuthors):**
A Map of author (lowercase) to author metadata:
```javascript
{
    name: string,
    postCount: number,
    totalScore: number,
    firstPostDate: number,
    lastPostDate: number,
    postIds: string[],
    subreddits: Set<string>,
}
```

**Subreddit Index (window.__jsonlSubreddits):**
A Map of subreddit (lowercase) to subreddit metadata.

**File Metadata (window.__jsonlFiles):**
A Map of fileName to file metadata (for change detection).

### Indexing Process

1. User selects a folder containing .jsonl files via Settings
2. The folder handle is stored in IndexedDB (persists across restarts)
3. scanAndIndex() iterates through all .jsonl files in the folder
4. For each file, it streams the content using file.stream().getReader()
5. Each line is parsed as JSON and added to the primary index
6. Author and subreddit indices are updated
7. Progress is reported every 1000 posts
8. After indexing, scores are pre-loaded to the server

### Content Retrieval

When a post's content is needed, the engine uses random-access file reading:

```javascript
async getPostContent(postId) {
    const meta = this.lookupPost(postId);
    if (!meta) return null;
    
    const file = await meta.fileEntry.getFile();
    const chunk = file.slice(meta.byteOffset, meta.byteOffset + meta.lineLength + 1000);
    const text = await chunk.text();
    const lineEnd = text.indexOf('
');
    const line = lineEnd >= 0 ? text.substring(0, lineEnd) : text;
    return JSON.parse(line);
}
```

This reads ONLY the needed bytes from the file, making it extremely fast (less than 1 millisecond per post).

---

## 11. Chapter Discovery Pipeline

The chapter discovery pipeline finds missing chapters in a series using multiple strategies.

### Local Gap Filling (JSONL First)

When the user clicks "Fetch Missing" on a series, the system:
1. Identifies missing chapter numbers (gaps in the sequence)
2. For each missing chapter, searches the JSONL index first (instant, local)
3. If not found in JSONL, falls back to Arctic Shift search
4. If found, adds the chapter to the series via /api/series/{slug}/add-chapter

### Chapter Chain Building

After indexing, the system builds chapter chains by:
1. Parsing all JSONL posts for "next" links
2. Building a directed graph of postId → [nextPostId, ...]
3. Starting from known chapter 1s, following the chain
4. Finding missing chapters (in chain but not in app)
5. Adding missing chapters to the series

### PostId Matching

Cross-references JSONL postIds with the app's existing chapters:
1. Build a set of all known postIds (from hardcoded + user chapters)
2. Find JSONL posts NOT in the known set
3. Group by author and title pattern
4. Suggest series for each group

---

## 12. C-FETCH System

C-FETCH (Content Fetch) is the system for pre-fetching chapter content and upvote scores.

### REHASH Mode

1. User clicks REHASH on SeriesDetailScreen
2. Client sends POST /api/series/{slug}/fetch-cache
3. Server iterates through all chapters
4. For each chapter, calls fetchPostContent() (checks JSONL first)
5. Server streams progress as NDJSON: {"type":"progress","done":5,"total":100}
6. Client updates progress bar
7. Scores saved to hfy-scores-{slug}.json
8. Content saved to chapter-cache/{postId}.json

### CONTINUE Mode

1. Fetches unfetched chapters first
2. Then crawls forward from the last known chapter
3. Follows "next" links via Reddit search
4. Adds newly discovered chapters to the series

### STOP

Uses AbortController to cancel the HTTP connection immediately. The fetch state is module-level (not React state), so it survives tab switches.

### Batch Processing

Chapters are fetched in batches (configurable 1-500, default 5). A one-second delay between batches helps avoid rate limiting. The batch size is controlled by the C-FETCH Batch Size slider in Settings.

---

## 13. Download and Merge System

### Individual Download

1. User clicks download icon on a chapter
2. Client calls fetch('/api/download', { method: 'POST', body: { postId, format: 'epub' } })
3. Server fetches chapter content via fetchPostContent()
4. Server generates EPUB using JSZip
5. EPUB is returned as a blob
6. Client saves to user-selected folder via FileSystemDirectoryHandle

### Download All

1. Iterates through all chapters in the series
2. Downloads each chapter in parallel (configurable 1-1000 parallel downloads)
3. Retries failed chapters up to 3 times with exponential backoff
4. Shows progress in QueueScreen

### Merge

1. Checks that all chapters have been fetched (merge safety check)
2. If any unfetched chapters exist, blocks merge with a warning
3. Generates a single EPUB with table of contents
4. Files named with zero-padded chapter numbers: 001. Series Name - Chapter Title.epub
5. Merged file saved to IndexedDB + server

### Merge Deletion

1. Clears merged file from IndexedDB
2. Clears merged file from server (DELETE /api/store/hfy-merged-content-{slug})
3. Sets deletion flag in localStorage (prevents re-restore from server)

---

## 14. Auto-Discover Pipeline

The auto-discover pipeline runs 8 stages in sequence to find missing chapters.

### Stage 1: Cache Check

Check IndexedDB for locally cached chapter lists. If a cached list exists and is recent, use it.

### Stage 2: Wayback Machine

Retrieve the archived wiki page from web.archive.org. The Wayback Machine API is queried for the series wiki URL, and the most recent snapshot is parsed for chapter links.

### Stage 3: hfy.foundation

Search the hfy.foundation community index for the series. hfy.foundation provides structured data about HFY series including chapter lists.

### Stage 4: BFS Crawl

Follow "next" links via RSS from a known starting chapter:
1. Start with the first known chapter
2. Fetch the chapter content via RSS
3. Parse for "next" links using findChapterLinks()
4. Follow the first unvisited next link
5. Repeat until no more next links are found
6. All discovered chapters are added to the series

### Stage 5: Wayback Crawl

Same as BFS Crawl but using Wayback Machine archived pages instead of live RSS.

### Stage 6: Reddit JSON

Fetch the wiki page JSON from Reddit and parse for chapter links.

### Stage 7: Reddit Search

Search r/HFY for the series name. Results are filtered by author and title pattern to find chapters that may not be linked from the wiki.

### Stage 8: WebSocket Parser

Connect to a WebSocket-based crawler service (mini-service on port 3003). The service uses a headless browser to crawl Reddit and find chapters that other strategies missed.

Each stage can be enabled or disabled individually in Settings. Results are deduplicated by post ID and normalized URL. The pipeline supports resume via job IDs.

---

## 15. OAuth Multi-Account Token Rotation

Reddit enforces API rate limits per account (600 QPM for user tokens, 100 QPM for app-only tokens). The application supports connecting up to 9 Reddit accounts via OAuth, with automatic round-robin token rotation.

### Token Rotation

```javascript
async function getNextMultiToken() {
    const store = getMultiTokenStore();
    if (store.size === 0) return null;
    
    const allAccounts = Array.from(store.entries()).filter(([, v]) =>
        v.accessToken && v.clientId !== "cookies" && v.clientId !== "cookie-injection"
    );
    if (allAccounts.length === 0) return null;
    
    let liveAccounts = allAccounts.filter(([, v]) => Date.now() < v.expiresAt - 5 * 60 * 1000);
    
    // If no live accounts, try to refresh expired ones
    if (liveAccounts.length === 0) {
        for (const [id, v] of allAccounts) {
            if (v.refreshToken && v.clientId) {
                try {
                    const refreshRes = await fetch("https://www.reddit.com/api/v1/access_token", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded",
                            Authorization: `Basic ${Buffer.from(v.clientId + ":").toString("base64")}`,
                            "User-Agent": USER_AGENT_DFR
                        },
                        body: new URLSearchParams({
                            grant_type: "refresh_token",
                            refresh_token: v.refreshToken
                        }).toString(),
                        signal: AbortSignal.timeout(10000),
                        cache: "no-store"
                    });
                    if (refreshRes.ok) {
                        const refreshData = await refreshRes.json();
                        if (refreshData.access_token) {
                            v.accessToken = refreshData.access_token;
                            v.expiresAt = Date.now() + (refreshData.expires_in || 3600) * 1000;
                            store.set(id, v);
                            liveAccounts.push([id, v]);
                        }
                    }
                } catch (e) { /* log and continue */ }
            }
        }
    }
    
    if (liveAccounts.length === 0) return null;
    const idx = (global.redditTokenRotationIndex || 0) % liveAccounts.length;
    global.redditTokenRotationIndex = idx + 1;
    const [, tokenData] = liveAccounts[idx];
    return { token: tokenData.accessToken, username: tokenData.username };
}
```

With 9 accounts synced, the rotation cycles through all 9 in round-robin order, providing 9 x 600 QPM = 5,400 QPM.

---

## 16. Service Worker and PWA

The application registers a service worker (public/sw.js) that enables PWA features and offline caching.

### Service Worker Strategy

- **Install:** Pre-cache static assets (/, /manifest.json, /icon-192.png, /icon-512.png)
- **Activate:** Delete old cache versions
- **Fetch:** 
  - Cache-first for static assets (images, /_next/static/)
  - Network-first for pages (with cache fallback)
  - No caching for API requests (/api/)

### Web App Manifest

The manifest.json enables installation as a PWA:
```json
{
  "name": "HFY NEKROCODEXXX",
  "short_name": "HFY NEKRO",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#050608",
  "theme_color": "#FF003C",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

---

## 17. Android APK Architecture

The Android APK wraps the webapp in a native Android shell using Capacitor 8.4.

### Components

**MainActivity.java:** Hosts a WebView that loads http://localhost:3000. Handles back button navigation and Android lifecycle events.

**NodeForegroundService.java:** Runs as a foreground service to prevent the OS from killing the Node.js process. Acquires:
- WiFi lock (WIFI_MODE_FULL_HIGH_PERF) — keeps WiFi radio in maximum-throughput mode
- Wake lock (PARTIAL_WAKE_LOCK) — keeps CPU active when screen is off
- 250 kbps keepalive — downloads and uploads 250 KB/s to maintain network activity

**NodeRunner.java:** Manages the Node.js process:
- Launches the native Node.js binary (ARM64) via ProcessBuilder
- Sets HFY_DATA_DIR to getFilesDir()/hfy-data/ (persistent storage)
- Monitors the process and auto-restarts after 3-second delay if it crashes
- Uses volatile Process and keepRunning flags for thread safety

### APK Construction

1. Build the base APK from the Android project (Capacitor)
2. Replace assets/server/ with the latest webapp build (stored uncompressed with zip -0 for Node.js memory-mapping)
3. Zip-align the APK
4. Sign with apksigner (v2 + v3 signatures)

### Native Libraries

The APK includes 10 native libraries:
- libsqlite3.so
- libssl.so
- libcrypto.so
- ICU libraries
- c-ares library
- libnode.so (Node.js binary)

---

## 18. Windows Standalone Architecture

The Windows package uses node.exe with a .cmd launcher script.

### Package Structure

```
HFY-NEKROCODEXXX/
├── HFY-NEKROCODEXXX.cmd    (launcher — starts server, opens window)
├── start.bat                (fallback — runs server only)
├── stop.bat                 (stops server)
├── README.txt               (quick start guide)
├── node/
│   └── node.exe             (Node.js runtime, 80 MB)
└── server/
    ├── server.js            (Next.js standalone server)
    ├── aggregate-counts.js  (periodic aggregation)
    ├── jsonl-handler.js     (JSONL batch handler, port 3001)
    ├── package.json
    ├── .next/               (compiled Next.js app)
    │   ├── static/          (client-side chunks)
    │   └── server/          (server-side chunks + API routes)
    ├── public/              (static assets, icons, images)
    ├── data/                (user data directory)
    │   ├── app-store/       (key-value store)
    │   ├── user-chapters/   (series chapter lists)
    │   └── chapter-cache/   (fetched chapter content)
    └── node_modules/        (minimal dependencies, 45 MB)
```

### Launcher Script

The start.bat script:
1. Sets environment variables (PORT, HOSTNAME, NODE_ENV)
2. Kills any existing process on port 3000
3. Starts the server in a minimized cmd window: `start "HFY-NEKRO-Server" /min cmd /c "node server.js > server.log 2>&1"`
4. Waits 5 seconds for the server to start
5. Opens Chrome or Edge in --app mode (standalone window without browser chrome)
6. Falls back to system default browser if Chrome/Edge not installed

---

## 19. Build Configuration

### Building from Source

```bash
# Install dependencies
bun install

# Build the Next.js app
bunx next build --webpack

# Copy static assets to standalone
cp -r .next/static .next/standalone/.next/
cp -r public .next/standalone/

# The standalone build is in .next/standalone/
# It includes server.js, .next/, public/, and minimal node_modules/
```

### next.config.ts

```typescript
const nextConfig = {
  output: "standalone",
  swcMinify: false,
  webpack: {
    optimization: {
      minimize: false  // Prevents TDZ errors
    }
  },
  typescript: {
    ignoreBuildErrors: true  // Ships despite TS errors
  },
  images: {
    unoptimized: true  // No server-side image optimization
  },
  experimental: {
    serverMinification: false,
    cssChunking: true
  }
};
```

### Package Dependencies

The production dependencies (from package.json):
- next: ^16.1.1
- react: ^19.0.0
- react-dom: ^19.0.0
- zustand: ^5.0.6
- framer-motion: ^12.23.2
- lucide-react: ^0.525.0
- sonner: ^2.0.6
- jszip: ^3.10.1
- file-saver: ^2.0.5
- react-markdown: ^10.1.0
- puppeteer-core: ^25.3.0
- socket.io-client: ^4.8.3
- @dnd-kit/core, @dnd-kit/sortable, @dnd-kit/utilities (drag-and-drop for chapter reordering)
- @radix-ui/* (accessible UI components)
- @tanstack/react-query, @tanstack/react-table
- recharts (charts)
- sharp (image processing, not used at runtime)
- @capacitor/android (Android APK)
- prisma, @prisma/client (database, not actively used)

### Minimal node_modules

The distribution package includes a minimal node_modules (45 MB) created using @vercel/nft (Node File Tracing). Only the 17 packages actually required by the server at runtime are included:

- @next/env
- @swc/helpers
- baseline-browser-mapping
- caniuse-lite
- client-only
- detect-libc
- nanoid
- next
- picocolors
- react
- react-dom
- semver
- source-map-js
- styled-jsx

.map files, .d.ts files, README/LICENSE files, and platform-specific native binaries (sharp, @img) are excluded to reduce size.

---

## 20. API Reference

### Store API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/store/[key]` | GET | Read JSON from data/app-store/{key}.json |
| `/api/store/[key]` | POST | Write JSON to data/app-store/{key}.json |
| `/api/store/[key]` | DELETE | Delete data/app-store/{key}.json |
| `/api/store-scores-all` | GET | Get all series scores |
| `/api/store-chapter-counts-all` | GET | Get all chapter counts |

### Series API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/series` | GET | Get series list (from Reddit wiki or baked fallback) |
| `/api/series/[slug]` | GET | Get series detail |
| `/api/series/[slug]/chapters` | GET | Get chapter list |
| `/api/series/[slug]/chapters` | POST | Add chapter |
| `/api/series/[slug]/chapters` | DELETE | Delete chapter |
| `/api/series/[slug]/add-chapter` | POST | Add chapter (alternative endpoint) |
| `/api/series/[slug]/fetch-cache` | POST | C-FETCH (NDJSON stream) |
| `/api/series/[slug]/continue-fetch` | POST | Continue crawl |
| `/api/series/[slug]/fetch-missing` | POST | Fetch missing chapters |
| `/api/series/[slug]/detect-gaps` | GET | Detect numbering gaps |
| `/api/series/[slug]/reparse` | POST | Reparse wiki page |
| `/api/hardcoded-chapters/[slug]` | GET | Get hardcoded chapter list |

### Content API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chapter/[id]` | GET | Get chapter content |
| `/api/chapter-cache/[postId]` | GET | Get cached chapter |
| `/api/chapter-cache/[postId]` | POST | Save cached chapter |
| `/api/download` | POST | Download chapters as EPUB/TXT |
| `/api/crawl` | POST | RSS crawl |
| `/api/fetch-all-posts` | GET | Fetch all posts from a subreddit |

### Search API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/search` | GET | Search Reddit |
| `/api/search-series` | GET | Search series index |
| `/api/hfy-foundation-search` | GET | Search hfy.foundation |
| `/api/live-wiki` | GET | Fetch live wiki page |

### Reddit Auth API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/reddit-auth` | GET | Start OAuth PKCE flow |
| `/api/reddit-token` | POST | Exchange code for token |
| `/api/reddit-user-token` | POST | Store user token |
| `/api/reddit-app-token` | GET | Get app-only token |
| `/api/reddit-multi-token` | GET | Get next rotation token |
| `/api/reddit-multi-token` | POST | Sync accounts to server |
| `/api/reddit-cookies` | GET/POST | Cookie management |
| `/api/reddit-password-login` | POST | Direct login |
| `/api/reddit-logout` | POST | Logout |

### Proxy API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/proxy-browser` | GET/POST/DELETE | HTTP proxy + browser session |
| `/api/proxy-stats` | GET | Proxy pool statistics |

### Auto-Discover API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auto-discover` | POST | Start auto-discover job |
| `/api/auto-discover/[jobId]` | GET | Get job status |

### Utility API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/wayback-sync` | POST | Sync with Wayback Machine |
| `/api/mass-import` | POST | Mass import chapters |
| `/api/purge-cache` | POST | Purge all cache |
| `/api/browser-session` | GET/POST/DELETE | Browser session management |

### JSONL Handler API (port 3001)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/batch-scores` | POST | Batch save scores |
| `/batch-cache` | POST | Batch save chapter content |
| `/stats` | GET | Index statistics |
| `/store/[key]` | GET | File-based store |
| `/file/[name]` | GET | Serve JSONL files |

---

*End of Architecture and How It Works*
