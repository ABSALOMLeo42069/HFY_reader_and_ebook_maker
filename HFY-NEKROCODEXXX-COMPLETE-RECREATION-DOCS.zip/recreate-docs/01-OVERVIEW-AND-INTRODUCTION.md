# HFY NEKROCODEXXX — Complete Application Overview and Introduction

**Version:** FX45 v31  
**Last Updated:** 2026-07-30  
**Developer:** Mahmudul Hossain

---

## Table of Contents

1. [What Is HFY NEKROCODEXXX?](#1-what-is-hfy-nekrocodexxx)
2. [Why Does This App Exist?](#2-why-does-this-app-exist)
3. [Core Features](#3-core-features)
4. [Platform Support](#4-platform-support)
5. [Target Audience](#5-target-audience)
6. [Legal Considerations](#6-legal-considerations)
7. [Privacy and Data Collection](#7-privacy-and-data-collection)
8. [Application Versions and History](#8-application-versions-and-history)
9. [Quick Start Guide](#9-quick-start-guide)
10. [User Interface Overview](#10-user-interface-overview)
11. [Navigation Structure](#11-navigation-structure)
12. [Theme System](#12-theme-system)
13. [Font System](#13-font-system)
14. [Reader Experience](#14-reader-experience)
15. [Content Discovery](#15-content-discovery)
16. [Offline Capabilities](#16-offline-capabilities)
17. [Performance Characteristics](#17-performance-characteristics)
18. [System Requirements](#18-system-requirements)
19. [Frequently Asked Questions](#19-frequently-asked-questions)
20. [Glossary](#20-glossary)

---

## 1. What Is HFY NEKROCODEXXX?

HFY NEKROCODEXXX is a standalone, self-hosted reading application designed specifically for consuming serialized fiction published on Reddit's r/HFY (Humanity, Fuck Yeah!) subreddit. The application runs a local Node.js server on the user's device and serves a React-based single-page application to the browser. All user data — including the library, reading progress, favorites, downloaded chapters, and cached upvote scores — is stored locally on the device. No data is transmitted to any external server except when fetching chapter content directly from Reddit.

The name "NEKROCODEXXX" is a deliberate reference to the Cyberpunk 2077 video game's aesthetic and naming conventions. The application's visual design draws deep inspiration from the Cyberpunk 2077 user interface — specifically the Night City HUD, Arasaka corporate UI, Trauma Team interfaces, and Militech data panels. The aesthetic features sharp diagonal clips, neon glows, scanline overlays, corner brackets, monospace typography, and a heavy reliance on red (#FF003C) and cyan (#00FFF0) as primary accent colors.

The application is not a website. It is not a Software-as-a-Service product. It is not a progressive web app that breaks when the internet drops. It is a full cyberdeck that runs on the user's own machine — Android phone, Windows PC, or any device with Node.js. The entire application runs locally, serving a React frontend to a WebView (on Android), a Chromium app window (on Windows), or any modern browser (webapp mode).

The catalog of 5,393 series containing 72,248 chapters is bundled with the application and loads into memory at startup. This allows immediate browsing, searching, and sorting without any network connection. An internet connection is required only when fetching chapter content or upvote data from Reddit, and even then, the application uses multiple strategies to work around Reddit's rate limiting.

No accounts, sign-ups, analytics, telemetry, or advertising are present in the application. The application does not phone home, does not report usage statistics, does not require an email address, and does not ask for any personal information. It is a tool for reading stories, and that is all it does.

---

## 2. Why Does This App Exist?

Reading multi-chapter serial fiction on the Reddit mobile client is a poor experience. The official Reddit app collapses long comments, injects advertising between posts, and is not designed for sequential chapter navigation. When a reader wants to follow a 500-chapter science fiction series posted across months or years of Reddit posts, the official client makes it difficult to track progress, find the next chapter, or read offline.

Third-party Reddit readers typically require accounts, do not support offline reading, or are discontinued when Reddit changes its API policies. The dedicated r/HFY community has long needed a tool that treats serialized fiction as a first-class citizen — with chapter lists, reading progress, offline caching, and ebook export.

HFY NEKROCODEXXX addresses these issues with the following design principles:

**Offline catalog:** The full series and chapter index (5,393 series, 72,248 chapters) is available immediately on launch. The user can browse, search, sort, and read without waiting for network requests. The catalog is bundled in the application package and loads into memory at startup.

**Dedicated reading view:** The reader supports customizable fonts (3px to 48px), font family selection (monospace, serif, sans-serif, or custom upload), color themes (25 app themes + 22 reader themes), swipe navigation between chapters, preloading of adjacent chapters for smooth transitions, and automatic progress tracking. No advertising, no collapsed comments, no Reddit UI chrome.

**Local execution:** The application runs on the user's own hardware. No external server, no API keys to manage, no cloud dependencies. All data stays on the device. The user owns their reading data.

**Rate-limit mitigation:** Reddit aggressively rate-limits API access. The application employs a 9-strategy fetch cascade that tries multiple methods in sequence: OAuth JSON (primary), cookie-based fetch, browser simulation with full Chrome headers, direct RSS feeds, CORS proxy pool (386 proxies), direct .json fallback, fetchWithRedDownloader, Wayback Machine archives, and hfy.foundation indexed content. User-Agent strings rotate across 8 browser profiles to reduce fingerprinting.

**Download and merge:** Chapters can be saved as EPUB or TXT for offline reading on any device. The "Download All" feature saves every chapter in a series. The "Merge" feature combines all chapters into a single EPUB or TXT file with zero-padded chapter numbers for correct sort order. A merge safety check prevents incomplete output files by blocking merge if any chapters have not been fetched.

**C-FETCH system:** The signature feature is "C-Fetch" (Content Fetch) — a system for pre-fetching chapter content (body text + upvote scores) from Reddit and caching it locally. This makes reading faster (content loads instantly from cache instead of hitting Reddit) and enables offline reading. C-FETCH operates in two modes: Rehash (re-fetch all chapters in a series) and Continue (fetch only unfetched chapters, then crawl forward to discover new chapters).

**JSONL archive integration:** The application can index JSONL dump files (from Arctic Shift or similar Reddit data archives) containing hundreds of thousands of posts. Once indexed, all content, scores, and metadata are served from local files — making the app fully offline-capable. The JSONL index becomes the primary source for all content, with Reddit API calls only used for posts not in the archive.

---

## 3. Core Features

### 3.1 Bundled Catalog

The application ships with a hardcoded catalog of 5,393 series containing 72,248 chapters. This data is compiled from the r/HFY wiki series index and is loaded into memory at startup. The catalog includes:

- Series title, author, and subreddit
- Wiki page URL on r/HFY
- HFY Foundation URL (community index)
- Chapter count per series
- Series slug (URL-safe identifier)

The catalog remains browsable even if Reddit is unavailable. It serves as the baseline against which user-imported or crawled chapter lists are merged. When the user connects Reddit accounts or uses the C-FETCH system, the catalog is enriched with real upvote scores, chapter content, and additional metadata.

### 3.2 Reader Interface

The reading view is designed for long-form fiction consumption. It is not a generic web page reader — it is purpose-built for reading multi-chapter stories.

**Font controls:**
- Adjustable font size from 3px to 48px (the 3px minimum is intentional for extreme zoom-out, allowing the user to see an overview of a long chapter)
- Font family selection: monospace, serif, sans-serif, or custom font upload
- Line height adjustment
- Text alignment options

**Color themes:**
- 22 reader-specific themes including Void (dark default), Blood (red on black), Matrix (green on black), Analog (sepia), Ice (blue on dark), AMOLED (pure black), Arasaka (corporate red), Netrunner (cyan), Militech (military green), Trauma (medical white), Blackwall (AI red), Solar (warm orange), Deep Space (navy), Terminal (green phosphor), Cyber Blue, Blood Moon, Toxic, Sunset, Midnight, CRT Amber, Neon Pink
- Custom color builder: the user can set custom background, text, and accent colors
- Separate app-level and reader-level theme configuration (the app chrome can be one theme while the reader is another)

**Navigation:**
- Swipe left/right to navigate between chapters (touch devices)
- Previous/Next buttons (desktop)
- Chapter preload: the app preloads adjacent chapters (configurable 1-100 chapters ahead) for smooth transitions
- Automatic progress tracking: the app remembers where you left off in each chapter
- Scroll position restoration when returning to a chapter

**Reading experience:**
- Markdown rendering of chapter content (bold, italic, headers, lists, code blocks, links)
- "Next chapter" links are highlighted and clickable
- Comment content is included for stories that continue in the comments (following the hfy2epub heuristic)
- Word count display per chapter
- Estimated reading time

### 3.3 C-FETCH (Content Fetching)

C-FETCH is the mechanism by which chapter content and upvote scores are retrieved from Reddit. Unfetched chapters display a skull icon; clicking it initiates a fetch for that chapter.

**Multi-strategy approach:** The application employs 9 fetch strategies, trying each in sequence until one succeeds:

1. **JSONL local archive** (Strategy -1, ultimate primary) — if the post exists in the JSONL index, return it instantly with no network calls
2. **OAuth JSON** (Strategy 0, primary) — uses OAuth Bearer tokens from connected Reddit accounts to access oauth.reddit.com
3. **Cookie-based fetch** (Strategy 0.5) — uses injected Reddit session cookies for authenticated .json access
4. **Browser simulation** (Strategy 0.7) — sends complete Chrome browser headers (Sec-Fetch-*, Sec-Ch-Ua, Accept-Encoding) with OAuth token
5. **Direct RSS** (Strategy 1) — Reddit's .rss Atom feeds are not subject to the same IP-level restrictions as .json endpoints
6. **CORS proxy pool** (Strategy 2) — 386 public proxy servers with health checking and automatic rotation
7. **Direct .json fallback** (Strategy 3) — last resort .json fetch with OAuth token
8. **fetchWithRedDownloader** — alternate JSON fetcher with OAuth token
9. **Wayback Machine** — retrieves archived content from web.archive.org
10. **hfy.foundation** — indexed content from the community project

**REHASH mode:** Fetches all chapters in a series in batches. Batch size is configurable via the C-FETCH Batch Size slider in Settings (1-500, default 5). A one-second delay between batches helps avoid rate limiting. Progress is shown as "done/total" with a STOP button to abort.

**CONTINUE mode:** First fetches any unfetched chapters, then crawls forward from the last known chapter to discover new chapters by following "next chapter" links via Reddit search. This is useful for ongoing series where the author has posted new chapters since the last fetch.

**STOP:** Cancels an in-progress fetch using AbortController to immediately terminate the HTTP connection. The fetch state is module-level (not React state), so it survives tab switches. A polling effect syncs the module-level state to React state for UI updates.

**User-Agent rotation:** User-Agent strings rotate across 8 browser profiles (Chrome, Firefox, Safari, Edge on Windows, macOS, and Linux) to reduce fingerprinting and avoid IP-based blocking.

### 3.4 Auto-Discover Pipeline

When a series has no cached chapters or requires re-discovery, the auto-discover pipeline executes the following 8 stages in sequence:

1. **Cache** — check for locally cached chapter lists in IndexedDB
2. **Wayback Machine** — retrieve archived wiki page from web.archive.org
3. **hfy.foundation** — search the community indexed database
4. **BFS Crawl** — follow "next" links via RSS from a known starting chapter (breadth-first search)
5. **Wayback Crawl** — BFS using archived Reddit pages
6. **Reddit JSON** — fetch and parse the wiki page JSON from Reddit
7. **Reddit Search** — search r/HFY for the series name
8. **WebSocket Parser** — connect to a WebSocket-based crawler service (mini-service on port 3003)

Each stage can be enabled or disabled individually in Settings. Results are deduplicated by post ID and normalized URL. The pipeline supports resume capability via job IDs, so an interrupted discovery can be continued without re-running from scratch.

### 3.5 Multi-Account OAuth Rotation

Reddit enforces API rate limits per account. The application supports connecting up to 9 Reddit accounts via OAuth, with automatic round-robin token rotation. Expired tokens are automatically refreshed using the stored refresh token (as of v250fx13). Cookie-injected accounts are excluded from OAuth rotation and use a separate fetch path.

**Supported login methods:**
1. **OAuth (PKCE)** — standard authorization code flow with PKCE (Proof Key for Code Exchange)
2. **System browser + Google** — OAuth flow opened in the system browser for Google sign-in support
3. **Real browser (Puppeteer)** — launches a visible Chrome or Edge instance for manual login, then captures session cookies
4. **Direct login** — username and password (no browser)
5. **Cookie injection** — manual paste of Reddit session cookies from browser DevTools

With 9 accounts synced, the rotation cycles through all 9 in round-robin order, providing 9 x 600 QPM = 5,400 queries per minute instead of 600 QPM from a single account.

### 3.6 Downloading and Merging

**Individual download:** Save a single chapter as EPUB (web) or TXT (Android native). The file is named with zero-padded chapter numbers (e.g., `001. Series Name - Chapter Title.epub`) for correct sort order.

**Download all:** Save every chapter in a series as individual files. Parallel download count is configurable (1-1000). The system retries failed chapters up to 3 times with exponential backoff.

**Merge:** Combine all chapters into a single EPUB or TXT file. A merge safety check blocks the operation if any chapters have not been c-fetched or downloaded, preventing incomplete output files. The merged file includes a table of contents with chapter numbers and titles.

**Merge deletion:** The merged file can be deleted, which clears it from IndexedDB, the server filesystem, and sets a deletion flag in localStorage to prevent re-restore from server.

Downloading a chapter also fetches and caches its upvote score, marks the chapter as fetched, and updates the series's total score.

### 3.7 Library Management

**Favorites:** Star series to add them to the Favorites filter. Favorites persist across restarts via localStorage + server filesystem. A gold star indicator appears on series cards in the Browse tab when a series is favorited.

**Read tracking:** Chapters are automatically marked as read when opened. Progress bars display per-series completion percentage. The last read chapter ID, title, and scroll position are saved per series.

**Downloaded count:** Each series card displays the count of locally downloaded chapters. This count is aggregated by `aggregate-counts.js` which runs on startup and every 120 seconds.

**Real chapter counts:** Cards display the actual chapter count (hardcoded plus crawled), not just the baseline. When new chapters are discovered via auto-discover or manual addition, the count updates.

**Sorting:** By name (A-Z), progress (reading completion), chapter count, or upvotes (total score across all fetched chapters).

**Library filters:** All, Favorites, Reading, Downloaded, Local, Recent.

### 3.8 JSONL Archive Integration (Parts 1-14)

The application includes a complete JSONL archive integration that transforms it from a network-dependent reader into a fully offline-capable archive reader. This integration consists of 14 parts:

1. **Project Overview** — JSONL files become the ultimate primary source for all content, scores, and metadata
2. **Folder Access** — 4th folder type ("jsonl") added alongside download, ebook, import
3. **Indexing Engine** — Primary index (postId to metadata), author index, subreddit index, file metadata
4. **Content Fetching** — JSONL as Strategy -1 (before Arctic Shift), random-access via file.slice()
5. **Score Pre-Loading** — All hardcoded series chapters get real scores from JSONL automatically
6. **Chapter Discovery** — Local gap filling, chapter chain building, PostId matching
7. **New Tabs** — Archive (browse all JSONL posts) and Discovered Series (auto-detected new series)
8. **Adding Posts to Series** — Add post to existing series or create custom series from Archive
9. **Download & Merge** — Instant merge from JSONL (1000 chapters in under 10 seconds)
10. **Persistence** — All changes persist to localStorage + IndexedDB + server filesystem
11. **RSS Crawl Engine** — Stays as-is, JSONL integration is transparent
12. **Performance** — 1000x+ speedup for content retrieval, 300x+ for C-FETCH
13. **File Replacement** — Automatic re-indexing when JSONL files are replaced
14. **Implementation Order** — 7-phase implementation plan

### 3.9 Themed Interface

The interface uses a dark, neon cyberpunk aesthetic inspired by Cyberpunk 2077. Each series is assigned a stable accent color derived from its ID (using a deterministic hash), so the same series is always rendered with the same color regardless of sort order or position.

All confirmation dialogs, warnings, and error messages use a themed popup system rather than native browser dialogs. The popup system supports custom accent colors, titles, and body text.

The app includes 25 app-level themes: Night City, Arasaka Net, Corpo Gold, Netrunner, Maelstrom, Ghost Data, Stellaris, Trauma Team, Militech, Blackwall, Biotechnica, Kang Tao, Delamain, Placide, Neon Pink, Acid Green, Ice Blue, Crimson Tide, Void Purple, Solar Flare, Ghost White, Dark Ember, Toxic Waste, Synthwave, Vaporwave, and Custom.

### 3.10 Android Background Service

On Android, the application runs as a foreground service to prevent the operating system from terminating the Node.js process:

- **WiFi lock** — WIFI_MODE_FULL_HIGH_PERF keeps the WiFi radio in maximum-throughput mode
- **Wake lock** — PARTIAL_WAKE_LOCK keeps the CPU active when the screen is off
- **250 kbps keepalive** — downloads and uploads 250 KB per second to maintain network activity (disabled in webapp/Windows builds)
- **Auto-restart** — if the Node.js process exits unexpectedly, it is restarted after a 3-second delay
- **Service restart** — if the foreground service is killed, it is restarted via onTaskRemoved, onDestroy, and START_STICKY

### 3.11 Port Conflict Protection

If the server auto-restarts before the previous process has fully released port 3000, the new instance detects the conflict (EADDRINUSE), waits 5 seconds, and retries. If the port remains in use, the process exits cleanly and is restarted by the NodeRunner.

### 3.12 Persistence Model

All data is stored on the server filesystem at HFY_DATA_DIR/hfy-data/ (or ./data/ on desktop):

- `app-store/` — key-value store for library, settings, scores, and download records
- `user-chapters/` — imported and crawled chapter lists (one JSON file per series)
- `chapter-cache/` — fetched chapter content (one JSON file per post)

The Zustand state stores use a three-tier persistence pattern:

1. **localStorage** — fast, synchronous reads (cleared on Android restart)
2. **IndexedDB** — persists across restarts, stores directory handles and chapter caches
3. **Server filesystem** — durable, unlimited size, the authoritative source of truth

On startup, if localStorage is empty, the application asynchronously restores state from the server via /api/store/[key]. A coordinated restore effect triggers on app mount, and if any store was restored from the server (localStorage was empty), the page reloads once to ensure all data is consistent. A sessionStorage flag prevents infinite reload loops.

---

## 4. Platform Support

The application supports three platforms:

### 4.1 Android APK

The Android APK wraps the webapp in a native Android shell:

- **Node.js binary** for ARM64, executed via linker64
- **Java bridge:** MainActivity (WebView host), NodeForegroundService (wake lock, WiFi lock, keepalive), NodeRunner (process management, auto-restart)
- **250 kbps WiFi lock** (250 KB download + 250 KB upload per second)
- **Auto-restart** with 3-second delay and keepRunning/userRequestedStop flags
- **Persistent storage** at getFilesDir()/hfy-data/

The APK is built by taking a base APK (built from the Android project with Capacitor), replacing assets/server/ (stored uncompressed with zip -0), zip-aligning, and signing with apksigner (v2 + v3).

**Permissions requested:**
- INTERNET, ACCESS_WIFI_STATE — network access and WiFi lock
- FOREGROUND_SERVICE_DATA_SYNC — Android 14+ foreground service type
- WAKE_LOCK — CPU wake lock
- MANAGE_EXTERNAL_STORAGE — file access for downloads
- REQUEST_IGNORE_BATTERY_OPTIMIZATIONS — battery optimization bypass
- VIBRATE — haptic feedback on long-press

### 4.2 Windows Standalone

The Windows package uses node.exe with a .cmd launcher script:

- **node.exe** — Node.js runtime (80 MB, included in package)
- **HFY-NEKROCODEXXX.cmd** — launcher script that starts the server and opens a standalone Chromium window
- **start.bat** — fallback launcher that runs the server only
- **server/** — the complete webapp (pre-built, no npm install required)

The launcher starts the server, waits 5 seconds, then opens a standalone window via Chrome or Edge --app flag (no browser chrome, similar to a native application). If neither Chrome nor Edge is installed, the application falls back to the system default browser.

### 4.3 Webapp (Cross-Platform)

The webapp ZIP can be run on any operating system with Node.js:

1. Extract the ZIP
2. Open a terminal in the server/ directory
3. Run: `node server.js`
4. Open http://localhost:3000 in a browser

No npm install, build step, or configuration is required. All dependencies are bundled in node_modules/.

---

## 5. Target Audience

The application is designed for:

- **HFY fans** who want a dedicated reader with offline capability
- **Mobile users** (Android via APK or PWA) who need cached content for reading on the go
- **Power users** who want to download entire series as EPUB files
- **Community members** who want to discover new chapters in ongoing series
- **Self-hosters** who want to run their own reader instance accessible from any device on their network
- **Offline readers** who want to archive Reddit content before it gets deleted or removed
- **Researchers** who want to study r/HFY content using the JSONL archive integration

---

## 6. Legal Considerations

### Personal Use Only

The stories accessible through this application are the intellectual property of their original authors, published by those authors on the r/HFY subreddit. Reddit's User Agreement permits users to access and consume this content through Reddit's platform and authorized interfaces.

This application is intended strictly for personal, private reading. It is not a distribution tool.

### Ebook Distribution Is Prohibited

The application includes features to download chapters and merge them into EPUB or TXT files. These features exist for the convenience of the individual user — to read content offline, on e-readers, or in a preferred format.

Users may not distribute, share, republish, sell, host, or otherwise make available any ebook or text file generated by this application. This includes but is not limited to:

- Uploading merged EPUBs or TXT files to file-sharing services, torrent sites, or public repositories
- Posting downloaded chapters on other websites, forums, or social media
- Selling or commercially exploiting any content fetched through this application
- Republishing author content in any form without the original author's explicit written permission

Doing so constitutes copyright infringement against the original authors. The authors of r/HFY stories have not granted permission for their work to be redistributed in this manner.

If you enjoy a story, support the original author by upvoting their posts on Reddit, sharing direct links to the Reddit thread, or contacting them directly regarding licensing or republication.

### Disclaimer of Warranty

This software is provided "as is," without warranty of any kind. The developer is not responsible for any misuse of the application, any consequences of redistributing copyrighted content, or any actions taken by Reddit or content authors against users who violate these terms.

---

## 7. Privacy and Data Collection

The application collects no data. Specifically:

- **No analytics** — no Google Analytics, no Plausible, no Matomo, no tracking pixels
- **No telemetry** — no usage reports, no crash reports, no feature usage statistics
- **No accounts** — no sign-up, no login, no email collection
- **No cookies** — the application does not set tracking cookies (Reddit cookies are used only for authentication when the user explicitly provides them)
- **No external servers** — all data stays on the user's device; the only external connections are to Reddit (for content fetching) and the CORS proxy pool (for bypassing rate limits)
- **No advertising** — no ad networks, no sponsored content
- **No third-party APIs** — no Facebook, no Twitter, no Google (except for OAuth login if the user chooses to use it)

The application's network activity consists solely of:
1. Fetching chapter content from Reddit (when the user opens a chapter or runs C-FETCH)
2. Fetching series metadata from the r/HFY wiki
3. Connecting to the CORS proxy pool (only when direct Reddit access fails)
4. Connecting to the Wayback Machine (only when Reddit and proxies fail)
5. Connecting to hfy.foundation (community index, optional)

All of these connections are initiated by user actions or background tasks that the user has explicitly enabled. The application does not make unsolicited network requests.

---

## 8. Application Versions and History

The application has gone through multiple major version lines:

### FX Series (FX1 through FX45)

The FX series represents the initial development line, with 45 iterative releases:

- **FX1-FX10:** Initial development, basic reader functionality, hardcoded series catalog
- **FX11-FX20:** Added C-FETCH system, download/merge, theme engine
- **FX21-FX30:** Added CORS proxy pool, auto-discover pipeline, multi-account OAuth
- **FX31-FX40:** Added JSONL archive integration (Parts 1-14), Archive and Discovered Series tabs
- **FX41-FX45:** Bug fixes, persistence improvements, performance optimization

### v250 Series (v250fx1 through v250fx13)

The v250 series is a refinement of FX45 with additional features:

- **v250fx1-v250fx4:** Browser simulation, User-Agent rotation, Windows EXE standalone window fix
- **v250fx5-v250fx9:** Font minimum 3px, custom series PNG icons, merge indicator icons, multi-OAuth fix, system browser login, real browser backend, favorites persistence fix, C-FETCH REHASH/CONTINUE/STOP fix
- **v250fx10:** Chapter persistence to IndexedDB, scores file recursion fix, library getItem async fix, migration for corrupted scores
- **v250fx11:** Star/favorite display on Browse cards, toggleFavorite auto-add fix
- **v250fx12:** Star size reduction, addToLibrary merge fix, async getItem race condition fix
- **v250fx13:** Comprehensive OAuth token rotation across ALL fetch paths, getNextMultiToken refresh, getRedditOAuthToken awaits getNextMultiToken

### Current Version: FX45 v31

The current version includes all features from FX45 v30 plus:
- JSONL integration Parts 1-14
- Discovery tab "Add to Series" modal (replaces prompt-based ADD CHAPTERS)
- Fixed: node_modules included in distribution
- Fixed: 10 hardcoded localhost URLs replaced with dynamic hostname
- Fixed: Splash screen and Settings CORS count updated from "250+" to "386"
- Version string updated to FX45 v31

---

## 9. Quick Start Guide

### Windows

1. Download the ZIP file (HFY-NEKROCODEXXX-FX45v31-FIXED.zip)
2. Extract to any folder (e.g., C:\HFY\)
3. Double-click `start.bat`
4. A console window opens. Wait 5-10 seconds for the server to initialize.
5. A standalone window opens via Chrome or Edge in --app mode (no browser chrome)
6. If neither Chrome nor Edge is installed, the application falls back to the system default browser

**If the launcher does not open:**
- If antivirus or SmartScreen blocks execution, select "More info" then "Run anyway"
- Use `start.bat` as an alternative — it runs the server directly
- The `server/` folder must be in the same directory as the launcher
- Check `server.log` for error messages

### Webapp (Any OS with Node.js)

1. Download the webapp ZIP
2. Extract it
3. Open a terminal in the `server/` directory
4. Run: `node server.js`
5. Open `http://localhost:3000` in a browser

No `npm install` or build step is required. All dependencies are bundled.

### Android APK

1. Download the APK file
2. **Uninstall any previous version first** — different versions may be signed with different keys
3. Enable installation from unknown sources in Android settings
4. Install the APK
5. Open the application. The server starts automatically.
6. Wait 10-30 seconds for the chapter data to load on first launch
7. The WebView loads http://localhost:3000 automatically

---

## 10. User Interface Overview

The application's user interface is organized into six main tabs, accessible via a bottom navigation bar:

### Browse Tab

The Browse tab displays all 5,393 series. Each card shows:
- Series title and author
- Total chapter count (including crawled chapters)
- Downloaded chapter count
- Total upvotes across c-fetched chapters
- Source indicators (hardcoded, crawled, hfy.foundation, custom)
- Merge indicator if a merged file exists
- Gold star if favorited

Sort options: NEW, SCORE, CHAPTERS, A-Z. Search by title or author. Long-press a card to add the series to your Library.

### Library Tab

The Library tab displays your saved series with filters: All, Favorites, Reading, Downloaded, Local, Recent. Sort options: A-Z, Progress, Chapters, Upvotes.

### Archive Tab

The Archive tab browses all posts from indexed JSONL files. Features include:
- Subreddit filter (All, r/HFY, r/Sexyspacebabes, etc.)
- Sort: Top (by score), Newest, Oldest
- Search by title (instant, client-side)
- Author filter
- Date filter (All Time, Last Year, Last Month, Last Week)
- Minimum score filter
- Pagination (20 posts per page)
- Each post card shows: score, title, author, subreddit, date, content length, comment count, NSFW badge, flair
- Click READ to open full post view
- Click ADD TO SERIES to add to an existing series or create a new one

### Discover Tab

The Discover tab shows series auto-detected from JSONL posts that aren't in the app's 5,393 hardcoded series. Each discovered series card shows:
- Series title and author
- Chapter count and total upvotes
- Subreddit, first post date, last post date
- CREATE SERIES, VIEW POSTS, READ FIRST buttons
- ADD TO LIBRARY, RE-DISCOVER, DELETE, ADD TO SERIES (in detail view)

### Queue Tab

The Queue tab shows all active and completed download/C-FETCH operations with progress bars, status indicators (WAIT, ACTIVE, PAUSE, OK, FAIL), and STOP buttons.

### Settings Tab

The Settings tab contains all configuration options organized into sections:
- Reddit Accounts (Token Rotation)
- Downloader Cascade
- CORS Proxy Pool
- App Theme (25 themes)
- Reader Theme (22 themes)
- Download Settings (parallel downloads, C-FETCH batch size)
- Local Folders (download, ebook, import, jsonl)
- Subreddit JSONL Data (folder selection, re-index, clear index)
- Persistence Audit and Repair
- Reddit Cookies
- About (version, developer, scrapers, CORS pool, fallback)

---

## 11. Navigation Structure

The application uses a bottom navigation bar with 6 tabs (configurable). The navigation is implemented via a Zustand store (`useNav`) that tracks the current screen and provides a `goTo` function.

**Screen transitions** use Framer Motion with spring physics:
- New screens slide in from the right
- Previous screens slide out to the left
- Modal screens slide up from the bottom

**Back navigation:**
- Android hardware back button is intercepted
- A custom back handler manages the navigation stack
- If on a sub-screen (e.g., series detail), back goes to the parent screen
- If on a top-level tab, back exits the app (Android) or does nothing (web)

**Deep linking:**
- The app supports deep links via URL hash (e.g., `#series/zyz` opens the ZYZ series detail)
- OAuth redirect URIs are handled via `/reddit-callback` route

---

## 12. Theme System

The application includes 25 app-level themes and 22 reader-level themes. Each theme defines:
- Primary color (for accents, buttons, active states)
- Background color
- Text color
- Border color
- Shadow/glow color

Themes are implemented as CSS custom properties (variables) that are applied to the root element. When the user changes the theme, the CSS variables update and the entire UI re-renders with the new colors.

**Custom theme builder:** Users can create their own theme by setting custom values for primary, background, text, accent, and border colors. The custom theme is saved to localStorage and persists across restarts.

**Per-series accent colors:** Each series is assigned a stable accent color derived from its ID using a deterministic hash function. This ensures the same series always has the same color, regardless of sort order or position in the list.

---

## 13. Font System

The reader supports multiple font families:

**Built-in fonts:**
- Monospace (system default)
- Serif (system default)
- Sans-serif (system default)

**Google Fonts (bundled):**
The app preloads 30+ web fonts including: Rajdhani, Orbitron, Audiowide, Share Tech Mono, JetBrains Mono, Fira Code, Source Code Pro, IBM Plex Mono, Space Mono, Major Mono Display, Syne Mono, VT323, Press Start 2P, Black Ops One, Russo One, Exo 2, Chakra Petch, Saira, Saira Condensed, Teko, Yanone Kaffeesatz, Oswald, Bebas Neue, Anton, Archivo Black, Roboto Condensed, Barlow Condensed, Barlow, Inter, Rubik, and Work Sans.

**Custom font upload:** Users can upload their own .woff, .woff2, .ttf, or .otf font files. The font is stored in IndexedDB and applied to the reader text.

**Font size:** Adjustable from 3px to 48px. The 3px minimum is intentional for extreme zoom-out, allowing the user to see an overview of a very long chapter.

---

## 14. Reader Experience

The reader is the core feature of the application. It is designed to provide the best possible reading experience for long-form fiction.

**Content rendering:**
- Markdown is rendered to HTML using react-markdown
- Supported elements: headings (h1-h6), bold, italic, strikethrough, code blocks, inline code, blockquotes, ordered/unordered lists, links, images, horizontal rules
- "Next chapter" links are highlighted with a distinct color and are clickable
- Reddit-specific formatting (e.g., >!spoiler!<) is supported

**Reading progress:**
- Scroll position is tracked and saved per chapter
- When returning to a chapter, the scroll position is restored
- A progress bar at the top shows reading progress within the current chapter
- The app remembers the last read chapter per series

**Preloading:**
- The app preloads adjacent chapters (configurable 1-100 chapters ahead)
- Preloaded chapters are stored in memory for instant access
- When navigating to a preloaded chapter, it appears instantly with no loading state

**Offline reading:**
- Once a chapter is fetched, it is cached in IndexedDB and on the server filesystem
- Cached chapters are available offline
- The app works without an internet connection for all cached content

---

## 15. Content Discovery

The application provides multiple ways to discover new content:

**Browse tab:** Browse all 5,393 hardcoded series. Sort by name, chapter count, upvotes, or progress. Search by title or author.

**Search:** The search function checks the JSONL index first (instant, local), then falls back to Arctic Shift API, then Reddit search. Results include series and individual posts.

**Auto-discover:** For series with incomplete chapter lists, the 8-stage auto-discover pipeline finds missing chapters by crawling Reddit, Wayback Machine, hfy.foundation, and performing Reddit searches.

**RSS crawl:** Follow "next chapter" links from a known starting chapter using the BFS crawl engine. The crawl engine uses the hfy2epub approach: parse the post content for links matching "next", "next chapter", "part N+1", etc., and follow the first match.

**Archive tab:** Browse all posts from indexed JSONL files. Filter by subreddit, author, date, score. Read any post or add it to a series.

**Discovered Series tab:** View series auto-detected from JSONL posts. These are series that exist in the JSONL archive but aren't in the app's hardcoded catalog.

---

## 16. Offline Capabilities

The application is designed to work offline once content has been cached:

**Catalog:** The full 5,393 series catalog is bundled with the app and available offline immediately.

**Chapter content:** Once a chapter is fetched (via C-FETCH or by opening it), the content is cached in IndexedDB and on the server filesystem. Cached chapters are available offline.

**Scores:** Upvote scores are cached alongside chapter content. The Browse tab and series cards show cached scores even when offline.

**JSONL archive:** When JSONL files are indexed, all content, scores, and metadata are available offline. The JSONL index becomes the primary source for all content, eliminating the need for network access.

**Service worker:** The app registers a service worker that caches static assets (JS chunks, CSS, fonts, images) for offline access. The service worker uses a cache-first strategy for static assets and a network-first strategy for pages (with cache fallback).

**Progressive Web App (PWA):** The app is installable as a PWA on Android and desktop. When installed, it runs in a standalone window without browser chrome.

---

## 17. Performance Characteristics

**Startup time:**
- Server starts in under 1 second
- Catalog loads into memory in 2-3 seconds
- Splash screen displays for 3 seconds (boot timer), then the app is ready

**Content retrieval:**
- Without JSONL: 1-3 seconds per chapter (Arctic Shift API call)
- With JSONL: less than 1 millisecond per chapter (local file read via file.slice)
- C-FETCH 100 chapters without JSONL: 5-10 minutes
- C-FETCH 100 chapters with JSONL: less than 1 second
- Merge 1,000 chapters without JSONL: 10+ minutes
- Merge 1,000 chapters with JSONL: less than 10 seconds

**Search:**
- Without JSONL: 2-5 seconds (Arctic Shift API)
- With JSONL: less than 100 milliseconds (in-memory filter of 216K+ posts)

**Memory usage:**
- Primary JSONL index (216K posts): approximately 54 MB
- Author index (4.5K authors): approximately 2.3 MB
- Subreddit index (4-10 subreddits): negligible
- Total JSONL index: approximately 56 MB
- Server process: 150-300 MB depending on cached chapters and concurrent requests

**Disk usage:**
- Application package: 73 MB (compressed), 225 MB (uncompressed)
- JSONL files (user-provided): 2.9 GB for all 4 standard dump files
- IndexedDB (handles + caches): approximately 50 MB
- Server filesystem (data dir): approximately 100 MB

---

## 18. System Requirements

### Windows
- Windows 10/11 64-bit
- 2 GB RAM minimum (4 GB recommended for JSONL indexing)
- 500 MB disk space (5 GB recommended for app + JSONL files)
- Chrome or Edge browser (for standalone window mode)

### Android
- Android 10 (API 29) or later
- ARM64 architecture
- 4 GB RAM recommended
- 500 MB internal storage (5 GB for app + JSONL files)

### Webapp (Linux/macOS/Windows)
- Node.js v22 or later
- 2 GB RAM minimum
- 500 MB disk space
- Any modern browser

### Network
- Internet connection required for initial content fetching
- Once content is cached, the app works offline
- JSONL indexing eliminates the need for network access for indexed content

---

## 19. Frequently Asked Questions

**Q: What does HFY stand for?**  
A: HFY stands for "Humanity, Fuck Yeah!" — a creative writing subreddit where authors post science fiction stories featuring humanity as a powerful, competent, or inspiring force in a universe full of alien species.

**Q: Is this app affiliated with Reddit?**  
A: No. This is an independent, community-built reader application. It uses Reddit's public API and RSS feeds to fetch content, but is not endorsed by or affiliated with Reddit Inc.

**Q: Do I need a Reddit account to use this?**  
A: No. The app works anonymously via the bundled OAuth client (100 queries/minute) or the CORS proxy pool. However, connecting a Reddit account increases the rate limit to 600 queries/minute per account and provides access to NSFW content.

**Q: Is the app free?**  
A: Yes, completely free and open source. No ads, no tracking, no subscriptions.

**Q: Can I run this on Linux or macOS?**  
A: The start.bat and stop.bat are Windows-specific, but the server itself (server.js) runs on any platform with Node.js. On Linux/macOS, run `cd server && PORT=3000 HOSTNAME=0.0.0.0 node server.js` directly.

**Q: How do I access the app from my phone?**  
A: 1) Run start.bat on your PC. 2) Find your PC's local IP (ipconfig). 3) On your phone, open http://YOUR.PC.IP:3000 (both devices must be on the same WiFi).

**Q: How do I access from anywhere in the world?**  
A: 1) Run start.bat. 2) Set up port forwarding on your router (port 3000 to your PC). 3) Find your public IP. 4) On any device, open http://YOUR.PUBLIC.IP:3000.

**Q: Is it safe to expose to the internet?**  
A: The app has no authentication. Anyone who knows your IP can access it. The changing IP acts as minimal security. For real security, add a password middleware in server.js or use a reverse proxy with auth.

**Q: What's the difference between Rehash and Continue?**  
A: Rehash re-fetches ALL chapters in a series (even already-cached ones) to detect changes. Continue fetches ONLY unfetched chapters and then stops, then crawls forward to discover new chapters.

**Q: Can I C-Fetch multiple series at once?**  
A: The browse-tab C-Fetch processes all 5,533 series sequentially (one at a time). The per-series C-FETCH only processes one series at a time.

**Q: What format are downloads in?**  
A: EPUB format (compatible with most e-readers including Kindle, Kobo, Apple Books, Google Play Books). On Android with the native interface, plain text is used instead.

**Q: Why do some chapters fail to download?**  
A: The chapter may be deleted from Reddit, or Reddit is rate-limiting the server. The app retries failed chapters up to 3 times with exponential backoff.

---

## 20. Glossary

- **C-FETCH** — Content Fetch; the system for pre-fetching chapter content and upvote scores from Reddit
- **REHASH** — C-FETCH mode that re-fetches all chapters in a series
- **CONTINUE** — C-FETCH mode that fetches only unfetched chapters, then crawls forward
- **JSONL** — JSON Lines format; one JSON object per line; used for Reddit data dumps
- **Arctic Shift** — A Reddit data archive project that provides JSONL dumps and an API
- **CORS proxy** — A proxy server that adds CORS headers to allow cross-origin requests
- **OAuth** — Open Authorization; a protocol for token-based authentication
- **PKCE** — Proof Key for Code Exchange; an OAuth extension for public clients
- **QPM** — Queries Per Minute; Reddit's rate limit metric
- **BFS** — Breadth-First Search; used by the crawl engine to discover chapters
- **IndexedDB** — Browser-based database for storing significant amounts of structured data
- **Service Worker** — A script that runs in the background, enabling PWA features and offline caching
- **PWA** — Progressive Web App; a web app that can be installed on the device
- **EPUB** — Electronic Publication; an ebook file format
- **HFY** — Humanity, Fuck Yeah!; the subreddit this app is designed for
- **Wiki** — Reddit's wiki pages, used by r/HFY to index series
- **Next chapter link** — A link in a post's content that points to the next chapter in the series
- **Slug** — A URL-safe identifier for a series (e.g., "zyz" for the ZYZ series)
- **Hardcoded series** — Series that are bundled with the app's catalog (5,393 total)
- **Custom series** — Series created by the user from the Archive tab or custom import
- **Discovered series** — Series auto-detected from JSONL posts that aren't in the hardcoded catalog
- **Triple storage** — The persistence pattern using localStorage + IndexedDB + server filesystem

---

*End of Overview and Introduction*
