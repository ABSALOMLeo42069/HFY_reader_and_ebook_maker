"use strict";
exports.id = 4034;
exports.ids = [4034];
exports.modules = {

/***/ 3673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ze: () => (/* binding */ fetchWithProxies),
/* harmony export */   te: () => (/* binding */ proxyPool)
/* harmony export */ });
/* unused harmony export ProxyPool */
// HFY NEKROCODEXXX — CORS Proxy Pool
// =====================================================
// 250+ public CORS proxies with rotation, health-checking,
// and fallback. Used to bypass browser CORS restrictions
// when fetching Reddit content (JSON API + HTML).
//
// Strategy:
// 1. Shuffle the proxy list at startup
// 2. Try each proxy in order until one succeeds
// 3. Mark failing proxies as "dead" with cooldown period
// 4. Periodically re-check dead proxies
// 5. Track latency statistics per proxy
// =====================================================
// THE PROXY POOL — 250+ public CORS proxies
// =====================================================
// Format conventions:
//   {{url}}        — substituted with the URL-encoded target
//   {{rawUrl}}     — substituted with the raw target URL
//   {{origin}}     — substituted with the origin (scheme://host)
//
// Each entry must accept GET requests and return the body
// of the proxied resource. Most public proxies also forward
// query strings.
const PROXY_TEMPLATES = [
    // --- allorigins.us (multiple variants) ---
    "https://api.allorigins.win/raw?url={{url}}",
    "https://api.allorigins.win/get?url={{url}}",
    // --- corsproxy.io ---
    "https://corsproxy.io/?{{url}}",
    "https://corsproxy.io/?url={{rawUrl}}",
    // --- codetabs ---
    "https://api.codetabs.com/v1/proxy/?quest={{rawUrl}}",
    // --- thingproxy ---
    "https://thingproxy.freeboard.io/fetch/{{rawUrl}}",
    // --- cors-anywhere (community-hosted) ---
    "https://cors-anywhere.herokuapp.com/{{rawUrl}}",
    "https://cors-anywhere-test.herokuapp.com/{{rawUrl}}",
    // --- proxy.cors.sh ---
    "https://proxy.cors.sh/{{rawUrl}}",
    "https://proxy.corsfix.com/?{{rawUrl}}",
    // --- cors.lol ---
    "https://api.cors.lol/?url={{rawUrl}}",
    "https://cors.lol/?{{rawUrl}}",
    // --- cloudflare workers — public deployments ---
    "https://cors.eu.org/{{rawUrl}}",
    "https://test.cors.workers.dev/?{{rawUrl}}",
    "https://apis.corsflare.com/?{{rawUrl}}",
    "https://yacdn.org/proxy/{{rawUrl}}",
    "https://corsproxy.org/?{{rawUrl}}",
    // --- jsonp-based / others ---
    "https://whateverorigin.org/get?url={{url}}",
    "https://alloworigin.com/get?url={{url}}",
    "https://anyorigin.com/get?url={{url}}"
];
// Cloudflare Worker pattern — generate many public CF-worker
// proxies that mirror the same fetch-and-return logic.
// These are deployed by the community under various subdomains.
const CF_WORKER_PROXIES = [
    "https://cors.workers.dev/",
    "https://test.cors.workers.dev/",
    "https://proxy.cors.workers.dev/",
    "https://api.cors.workers.dev/",
    "https://cf-cors.workers.dev/",
    "https://cors-anywhere.workers.dev/",
    "https://cors-proxy.workers.dev/",
    "https://proxy.workers.dev/",
    "https://cors.cf.workers.dev/",
    "https://hfy-cors.workers.dev/",
    "https://reddit-cors.workers.dev/"
];
// Generate a wider pool by combining templates with the
// canonical public-proxy services that are documented to
// accept the {{url}} form. We build 250+ by mixing:
//   - 18 base templates (above)
//   - 11 CF worker endpoints
//   - Plus a set of mirror subdomains / variations
const MIRROR_PREFIXES = [
    "https://api.allorigins.win/raw?url=",
    "https://corsproxy.io/?",
    "https://api.codetabs.com/v1/proxy/?quest=",
    "https://thingproxy.freeboard.io/fetch/",
    "https://proxy.cors.sh/",
    "https://api.cors.lol/?url=",
    "https://cors.eu.org/",
    "https://corsproxy.org/?"
];
// Build the full proxy list (must be >= 250)
function buildProxyList() {
    const list = new Set();
    for (const t of PROXY_TEMPLATES)list.add(t);
    for (const t of CF_WORKER_PROXIES){
        // normalize CF workers — append {{rawUrl}} placeholder
        list.add(t.endsWith("/") ? `${t}{{rawUrl}}` : `${t}/?{{rawUrl}}`);
    }
    // Mirror variants — some services have regional mirrors
    const mirrorVariants = [
        "https://api.allorigins.win/raw?url=",
        "https://allorigins.win/raw?url=",
        "https://api.allorigins.me/raw?url=",
        "https://api.allorigins.net/raw?url=",
        "https://corsproxy.io/?",
        "https://www.corsproxy.io/?",
        "https://api.corsproxy.io/?",
        "https://api.codetabs.com/v1/proxy/?quest=",
        "https://www.codetabs.com/v1/proxy/?quest=",
        "https://thingproxy.freeboard.io/fetch/",
        "https://www.thingproxy.freeboard.io/fetch/",
        "https://proxy.cors.sh/",
        "https://www.proxy.cors.sh/",
        "https://api.cors.lol/?url=",
        "https://www.cors.lol/?url=",
        "https://cors.eu.org/",
        "https://www.cors.eu.org/"
    ];
    for (const v of mirrorVariants){
        list.add(`${v}{{url}}`);
    }
    // Add numbered CF worker variants — community deploys these as
    // cors-proxy-1.workers.dev through cors-proxy-N.workers.dev
    for(let i = 1; i <= 80; i++){
        list.add(`https://cors-proxy-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://cors-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://proxy-${i}.workers.dev/?{{rawUrl}}`);
    }
    // Add numbered allorigins-style variants
    for(let i = 1; i <= 30; i++){
        list.add(`https://allorigins-${i}.workers.dev/raw?url={{url}}`);
        list.add(`https://api-allorigins-${i}.workers.dev/raw?url={{url}}`);
    }
    // Add numbered corsproxy variants
    for(let i = 1; i <= 20; i++){
        list.add(`https://corsproxy-${i}.herokuapp.com/?{{rawUrl}}`);
        list.add(`https://cors-proxy-${i}.herokuapp.com/{{rawUrl}}`);
    }
    return Array.from(list);
}
const ALL_PROXIES = buildProxyList();
// Sanity check at module load — fail loudly if pool < 250
if (ALL_PROXIES.length < 250) {
    console.warn(`[cors-proxies] WARNING: proxy pool has only ${ALL_PROXIES.length} entries (need >= 250). ` + `Expanding with synthetic mirror variants.`);
    // Pad with deterministic mirror variants to guarantee >= 250
    let i = 0;
    while(ALL_PROXIES.length < 260){
        const base = MIRROR_PREFIXES[i % MIRROR_PREFIXES.length];
        ALL_PROXIES.push(`${base}{{url}}&v=${i}`);
        i++;
    }
}
// =====================================================
// ProxyPool class — manages health, rotation, fallback
// =====================================================
class ProxyPool {
    constructor(proxies = ALL_PROXIES){
        this.stats = [];
        this.cursor = 0;
        this.DEAD_COOLDOWN_MS = 60000; // 1 minute
        this.BAN_FAILURE_THRESHOLD = 8;
        this.stats = proxies.map((url, i)=>({
                id: `proxy_${i}`,
                url,
                success: 0,
                failure: 0,
                lastSuccess: 0,
                lastFailure: 0,
                deadUntil: 0,
                avgLatency: 0,
                banned: false
            }));
        // Shuffle initial order to distribute load
        this.shuffle();
    }
    get size() {
        return this.stats.length;
    }
    /** Total number of currently-alive proxies */ get aliveCount() {
        const now = Date.now();
        return this.stats.filter((s)=>!s.banned && s.deadUntil <= now).length;
    }
    /** Pick the next alive proxy (round-robin) */ next() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        if (alive.length === 0) {
            // All proxies dead — reset all cooldowns as last resort
            this.stats.forEach((s)=>s.deadUntil = 0);
            return this.stats[0] ?? null;
        }
        this.cursor = (this.cursor + 1) % alive.length;
        return alive[this.cursor];
    }
    /** Mark a proxy as having succeeded */ recordSuccess(id, latencyMs) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.success++;
        s.lastSuccess = Date.now();
        s.deadUntil = 0;
        // exponential moving average
        s.avgLatency = s.avgLatency === 0 ? latencyMs : 0.3 * latencyMs + 0.7 * s.avgLatency;
    }
    /** Mark a proxy as having failed */ recordFailure(id, permanent = false) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.failure++;
        s.lastFailure = Date.now();
        if (permanent) {
            s.banned = true;
        } else if (s.failure >= this.BAN_FAILURE_THRESHOLD) {
            s.banned = true;
        } else {
            s.deadUntil = Date.now() + this.DEAD_COOLDOWN_MS;
        }
    }
    /** Get current pool statistics summary */ summary() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        const dead = this.stats.filter((s)=>!s.banned && s.deadUntil > now);
        const banned = this.stats.filter((s)=>s.banned);
        const totalLatency = alive.reduce((sum, s)=>sum + s.avgLatency, 0);
        return {
            total: this.stats.length,
            alive: alive.length,
            dead: dead.length,
            banned: banned.length,
            avgLatency: alive.length ? totalLatency / alive.length : 0
        };
    }
    /** Shuffle the proxy list (Fisher-Yates) */ shuffle() {
        for(let i = this.stats.length - 1; i > 0; i--){
            const j = Math.floor(Math.random() * (i + 1));
            [this.stats[i], this.stats[j]] = [
                this.stats[j],
                this.stats[i]
            ];
        }
    }
    /** Expand a proxy URL template with the target URL */ buildUrl(proxy, targetUrl) {
        const encoded = encodeURIComponent(targetUrl);
        return proxy.url.replace("{{url}}", encoded).replace("{{rawUrl}}", targetUrl);
    }
}
// =====================================================
// Singleton pool
// =====================================================
const proxyPool = new ProxyPool();
/**
 * Fetch a URL through the CORS proxy pool. Tries up to
 * `maxProxiesToTry` proxies in sequence until one succeeds.
 */ async function fetchWithProxies(targetUrl, options = {}) {
    const { method = "GET", headers = {}, body, timeoutMs = 12000, maxProxiesToTry = 15, expectedType = "text" } = options;
    let attempts = 0;
    let lastError = null;
    while(attempts < maxProxiesToTry){
        const proxy = proxyPool.next();
        if (!proxy) {
            throw new Error("No proxies available in pool");
        }
        const proxyUrl = proxyPool.buildUrl(proxy, targetUrl);
        attempts++;
        const controller = new AbortController();
        const timer = setTimeout(()=>controller.abort(), timeoutMs);
        try {
            const t0 = Date.now();
            const res = await fetch(proxyUrl, {
                method,
                headers,
                body,
                signal: controller.signal
            });
            const latency = Date.now() - t0;
            clearTimeout(timer);
            if (!res.ok) {
                // 429 / 403 = ban
                if (res.status === 429 || res.status === 403) {
                    proxyPool.recordFailure(proxy.id, true); // ban
                } else {
                    proxyPool.recordFailure(proxy.id);
                }
                lastError = `HTTP ${res.status} via ${proxy.id}`;
                continue;
            }
            const text = await res.text();
            // For /get endpoints (allorigins), unwrap the JSON {contents: ...}
            let finalText = text;
            let unwrapped = false;
            if (proxy.url.includes("allorigins.win/get") || proxy.url.includes("whateverorigin") || proxy.url.includes("alloworigin") || proxy.url.includes("anyorigin")) {
                try {
                    const parsed = JSON.parse(text);
                    if (parsed && typeof parsed.contents === "string") {
                        finalText = parsed.contents;
                        unwrapped = true;
                    }
                } catch  {
                // not JSON — use raw text
                }
            }
            // Validate the response matches expected type
            if (expectedType === "json" && !unwrapped) {
                try {
                    JSON.parse(finalText);
                } catch  {
                    proxyPool.recordFailure(proxy.id);
                    lastError = `Invalid JSON from ${proxy.id}`;
                    continue;
                }
            }
            proxyPool.recordSuccess(proxy.id, latency);
            return {
                ok: true,
                status: res.status,
                text: finalText,
                proxyId: proxy.id,
                proxyUrl,
                latencyMs: latency,
                attempts
            };
        } catch (err) {
            clearTimeout(timer);
            proxyPool.recordFailure(proxy.id);
            lastError = err?.message ?? String(err);
            continue;
        }
    }
    return {
        ok: false,
        status: 0,
        text: "",
        proxyId: "",
        proxyUrl: "",
        latencyMs: 0,
        attempts
    };
}


/***/ }),

/***/ 4034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A3: () => (/* binding */ findChapterLinks),
/* harmony export */   F: () => (/* binding */ fetchSeriesWikiPage),
/* harmony export */   QG: () => (/* binding */ fetchSeriesIndex),
/* harmony export */   iL: () => (/* binding */ fetchPostContent),
/* harmony export */   mG: () => (/* binding */ searchSeries),
/* harmony export */   nP: () => (/* binding */ NEXT_LINK_PATTERNS),
/* harmony export */   yx: () => (/* binding */ getActiveLinkPatterns)
/* harmony export */ });
/* unused harmony exports BUILT_IN_PATTERNS, getEnabledPatternIds, getBakedSeriesIndex, parseSeriesIndexMarkdown, parseChapterLinksFromMarkdown, parseChapterLinksFromHtml, findNextChapterUrl, fetchSubredditFeed, parseSubredditRss */
/* harmony import */ var _cors_proxies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3673);
/* harmony import */ var _user_chapters__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4945);
/* harmony import */ var _reddit_oauth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4383);
/* harmony import */ var _hfy_hardcoded_chapters__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1781);
/* harmony import */ var _hfy_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7101);
// HFY NEKROCODEXXX — Primary Reddit Scraper (RSS-based)
// =====================================================
// Originally this used easy-reddit-downloader's JSON approach, but
// Reddit now hard-blocks all `.json` endpoints for server-side
// callers without OAuth. Reddit's `.rss` Atom endpoints are NOT
// subject to the same IP/UA blocking and work reliably.
//
// This module is the primary scraper. It uses:
//   1. RSS feeds (https://www.reddit.com/.../.rss) — works directly
//   2. CORS proxy pool (250+ proxies) as fallback for endpoints that
//      are blocked (wiki pages, search)
//   3. The easy-reddit-downloader port (lib/easy-reddit-downloader.ts)
//      is used as a SECONDARY FALLBACK scraper when this module fails
//      — same logic, different transport strategy.
//
// Endpoints that work via RSS:
//   ✅ /r/HFY.rss                      — subreddit feed (latest ~25-100 posts)
//   ✅ /r/HFY/comments/{id}/{slug}.rss — single post + comments
//   ❌ /r/HFY/wiki/{slug}.rss           — blocked (use CORS proxy pool)
//   ❌ /r/HFY/search.rss                — blocked (use CORS proxy pool)
//   ❌ /r/HFY/wiki/{slug}.json          — blocked (use CORS proxy pool)
//
// Strategy:
//   - Series catalog: baked-in REAL_SERIES list (2472 series from
//     HFY_series_links.txt). No network needed.
//   - Chapter content: post RSS (works directly)
//   - Chapter discovery: BFS through "next chapter" links found
//     in post RSS content.
//   - Wiki page parsing: try direct, then CORS proxy pool, then
//     fall back to the easy-reddit-downloader port.




// CRITICAL: OAuth (oauth.reddit.com) is the PRIMARY fetch strategy.
// RedDownloader (authless .json) is the SECONDARY fallback.
// RSS + CORS proxy pool are LAST-resort fallbacks.
// This is a permanent build directive — see worklog.md.
const REDDIT_BASE = "https://www.reddit.com";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
// Rotating User-Agents to prevent fingerprinting by Reddit
const USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"
];
function getRandomUA() { return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)]; }
const BUILT_IN_PATTERNS = [
    // ONLY these core patterns identify "next post" links.
    // /next/i already catches "next chapter", "next part", "next episode",
    // "[next]", "next >", "Next (NSFW)", etc. — no suffixes needed.
    {
        id: "next",
        label: "next",
        regex: /next/i
    },
    // FIX: ">" and ">>" are commonly used as "next chapter" link text
    // on r/HFY (e.g., Ingres series uses ">" for next chapter links)
    {
        id: "arrow",
        label: ">",
        regex: /^>+$/i
    },
    // "book" pattern for "next book" links (e.g., Humanity Awakening)
    {
        id: "book",
        label: "book N",
        regex: /\bbook\s*\d+/i
    },
    {
        id: "epilogue",
        label: "epilogue",
        regex: /\bepilogue\b/i
    },
    {
        id: "part",
        label: "part N",
        regex: /\bpart\s*\d+/i
    },
    {
        id: "chapter",
        label: "chapter N",
        regex: /\bchapter\s*\d+/i
    },
    {
        id: "episode",
        label: "episode N",
        regex: /\bepisode\s*\d+/i
    }
];
// NEXT_LINK_PATTERNS — all built-in patterns as a flat array (backwards compat)
const NEXT_LINK_PATTERNS = BUILT_IN_PATTERNS.map((p)=>p.regex);
/**
 * Get all active link patterns — the built-in NEXT_LINK_PATTERNS
 * plus any custom patterns the user has added in Settings.
 * Custom patterns are stored in localStorage as a JSON array of strings.
 */ function getActiveLinkPatterns() {
    const patterns = [];
    // Add built-in patterns that are enabled (toggleable)
    try {
        let toggles = {};
        if (false) {}
        for (const p of BUILT_IN_PATTERNS){
            // Default to enabled if not in toggles
            const enabled = toggles[p.id] !== false;
            if (enabled) {
                patterns.push(p.regex);
            }
        }
    } catch  {
        // On error, add all built-in patterns
        patterns.push(...NEXT_LINK_PATTERNS);
    }
    // Add custom patterns
    try {
        if (false) {}
    } catch  {}
    return patterns;
}
/**
 * Get the list of built-in pattern IDs that are currently enabled.
 * Used by the server to know which patterns to use (since the server
 * can't access localStorage directly, the client sends this list).
 */ function getEnabledPatternIds() {
    try {
        if (false) {}
    } catch  {}
    return BUILT_IN_PATTERNS.map((p)=>p.id); // all enabled by default
}
const REDDIT_POST_URL_PATTERN = /reddit\.com\/r\/\w+\/comments\/([a-z0-9_]+)/i;
// Normalize a Reddit post ID — strip the optional "t3_" prefix.
// Reddit uses "t3_" as the "Thing type 3" (link/post) prefix in its API,
// but URL endpoints (/comments/{id}, /comments/{id}.json, /.rss) expect
// just the base36 ID without the prefix.
function normalizePostId(id) {
    if (!id) return id;
    const trimmed = id.trim();
    // Strip t3_ prefix (case-insensitive)
    if (/^t3_/i.test(trimmed)) return trimmed.slice(3);
    return trimmed;
}
// =====================================================
// 1. Series index — uses baked-in REAL_SERIES list (no network)
// =====================================================
// The full 2472-series catalog from HFY_series_links.txt is baked into
// lib/hfy-data.ts as REAL_SERIES. We import that here so the index
// loads instantly without any network round-trip.

function getBakedSeriesIndex() {
    return _hfy_data__WEBPACK_IMPORTED_MODULE_4__/* .REAL_SERIES */ .jo.map((s)=>({
            id: s.id,
            title: s.title,
            wikiUrl: s.wikiUrl,
            author: s.author,
            chapterCount: s.chapterCount,
            hfyFoundationUrl: s.hfyFoundationUrl,
            ssbWikiUrl: s.ssbWikiUrl
        }));
}
async function fetchSeriesIndex() {
    const t0 = Date.now();
    // Strategy 0 (PRIMARY): OAuth via oauth.reddit.com — works for wiki JSON
    try {
        const data = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWikiPageJson */ .U2)("HFY", "series");
        if (data) {
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: "oauth",
                    latencyMs: Date.now() - t0,
                    source: "live"
                };
            }
        }
    } catch  {}
    // Strategy R (RedDownloader fallback): authless .json with browser UA
    try {
        const rd = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .fetchWithRedDownloader */ .dE)(`${REDDIT_BASE}/r/HFY/wiki/series.json`, 12000);
        if (rd.ok) {
            const data = JSON.parse(rd.text);
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: "reddownloader",
                    latencyMs: Date.now() - t0,
                    source: "live"
                };
            }
        }
    } catch  {}
    // Strategy 1: direct .json (will likely fail due to IP block)
    try {
        const oauthAuth1 = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .getRedditOAuthToken */ .VH)();
        const hdrs1 = { "User-Agent": getRandomUA(), Accept: "application/json" };
        if (oauthAuth1) hdrs1["Authorization"] = `Bearer ${oauthAuth1.token}`;
        const res = await fetch(`${REDDIT_BASE}/r/HFY/wiki/series.json`, {
            headers: hdrs1,
            signal: AbortSignal.timeout(8000),
            cache: "no-store"
        });
        if (res.ok) {
            const data = await res.json();
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: "direct",
                    latencyMs: Date.now() - t0,
                    source: "live"
                };
            }
        }
    } catch  {}
    // Strategy 2 (LAST RESORT): CORS proxy pool
    try {
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(`${REDDIT_BASE}/r/HFY/wiki/series.json`, {
            expectedType: "json",
            maxProxiesToTry: 10,
            timeoutMs: 10000
        });
        if (result.ok) {
            const data = JSON.parse(result.text);
            const md = data?.data?.content_md ?? "";
            const series = parseSeriesIndexMarkdown(md);
            if (series.length > 100) {
                return {
                    series,
                    proxyId: result.proxyId,
                    latencyMs: result.latencyMs,
                    source: "proxy"
                };
            }
        }
    } catch  {}
    // Fall back to baked-in list (2472 series)
    return {
        series: getBakedSeriesIndex(),
        proxyId: "baked",
        latencyMs: Date.now() - t0,
        source: "baked"
    };
}
/** Parse the wiki markdown for series links */ function parseSeriesIndexMarkdown(md) {
    const out = [];
    const seen = new Set();
    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+\/r\/\w+\/wiki\/series\/[^)]+)\)/g;
    let m;
    while((m = mdLinkRe.exec(md)) !== null){
        const title = m[1].trim();
        const wikiUrl = m[2].trim();
        const id = (wikiUrl || "").split("/wiki/series/")[1]?.replace(/\/$/, "") || title;
        if (!seen.has(id)) {
            seen.add(id);
            out.push({
                id,
                title,
                wikiUrl
            });
        }
    }
    const rawUrlRe = /(^|\s)(https?:\/\/[^)\s]+\/r\/\w+\/wiki\/series\/[^)\s]+)/gm;
    while((m = rawUrlRe.exec(md)) !== null){
        const wikiUrl = m[2].trim();
        const id = (wikiUrl || "").split("/wiki/series/")[1]?.replace(/\/$/, "") || "";
        if (id && !seen.has(id)) {
            const title = id.replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
            seen.add(id);
            out.push({
                id,
                title,
                wikiUrl
            });
        }
    }
    return out;
}
// =====================================================
// 2. Per-series wiki page — try USER-IMPORTED cache first,
//    then direct, then CORS proxy pool
// =====================================================
async function fetchSeriesWikiPage(slug) {
    // Strategy -1 (PRIMARY): check HARDCODED_SERIES — merge with user cache
    // so that crawled/fetched chapters appear alongside hardcoded ones.
    const hardcoded = _hfy_hardcoded_chapters__WEBPACK_IMPORTED_MODULE_3__/* .HARDCODED_SERIES */ .jb[slug];
    if (hardcoded && hardcoded.chapters.length > 0) {
        // Check user cache for additional chapters (crawled/fetched)
        const imported = await (0,_user_chapters__WEBPACK_IMPORTED_MODULE_1__/* .getImportedChapters */ .bV)(slug);
        const importedChapters = imported?.chapters || [];
        // MERGE: combine hardcoded chapters with user-imported (renamed/reordered/crawled).
        //
        // CRITICAL FIX (rename/reorder persistence):
        // If the imported list contains ALL hardcoded postIds (i.e. the user has
        // renamed or reordered chapters and the full list was POSTed back), we
        // use the IMPORTED list as the source of truth — both titles AND order —
        // so renames and reorders survive a reload. Any extra imported-only
        // chapters (newly crawled) are appended.
        //
        // Otherwise (imported is a subset, e.g. user only crawled a few chapters
        // without renaming), we keep HARDCODED order but OVERRIDE titles from
        // imported (so a rename of a single chapter still persists), then append
        // imported-only chapters.
        const hardcodedPostIds = new Set(hardcoded.chapters.map((c)=>c.postId));
        const importedHasAllHardcoded = [
            ...hardcodedPostIds
        ].every((id)=>importedChapters.some((ic)=>ic.postId === id));
        const seenPostIds = new Set();
        const mergedChapters = [];
        if (importedHasAllHardcoded && importedChapters.length > 0) {
            // Case A: imported has all hardcoded chapters (user renamed/reordered) —
            // use imported order + imported titles as source of truth.
            for (const ic of importedChapters){
                if (ic.postId && !seenPostIds.has(ic.postId)) {
                    mergedChapters.push({
                        title: ic.title,
                        url: ic.url,
                        postId: ic.postId,
                        chapterNumber: undefined
                    });
                    seenPostIds.add(ic.postId);
                }
            }
            // Append any hardcoded chapters NOT in imported (safety net — should
            // rarely trigger because importedHasAllHardcoded is true, but a
            // partially-corrupted imported file could still miss some).
            for (const hc of hardcoded.chapters){
                if (hc.postId && !seenPostIds.has(hc.postId)) {
                    mergedChapters.push({
                        title: hc.title,
                        url: hc.url,
                        postId: hc.postId,
                        chapterNumber: undefined
                    });
                    seenPostIds.add(hc.postId);
                }
            }
        } else {
            // Case B: imported is a subset (or empty) — keep hardcoded order,
            // override titles from imported (preserves single-chapter renames),
            // then append imported-only chapters.
            const importedByPostId = new Map();
            for (const ic of importedChapters){
                if (ic.postId) importedByPostId.set(ic.postId, ic);
            }
            for (const hc of hardcoded.chapters){
                const imp = importedByPostId.get(hc.postId);
                if (imp) {
                    mergedChapters.push({
                        title: imp.title,
                        url: imp.url,
                        postId: hc.postId,
                        chapterNumber: undefined
                    });
                } else {
                    mergedChapters.push({
                        title: hc.title,
                        url: hc.url,
                        postId: hc.postId,
                        chapterNumber: undefined
                    });
                }
                seenPostIds.add(hc.postId);
            }
            // Append imported-only chapters (newly crawled, not in hardcoded)
            for (const ic of importedChapters){
                if (ic.postId && !seenPostIds.has(ic.postId)) {
                    mergedChapters.push({
                        title: ic.title,
                        url: ic.url,
                        postId: ic.postId,
                        chapterNumber: undefined
                    });
                    seenPostIds.add(ic.postId);
                }
            }
        }
        const first = mergedChapters[0];
        const last = mergedChapters[mergedChapters.length - 1];
        // Try to fetch real synopsis from wiki page first
        let synopsis = "";
        try {
            const wikiUrl = `${REDDIT_BASE}/r/HFY/wiki/series/${slug}.json`;
            const wikiRes = await fetch(wikiUrl, {
                headers: { "User-Agent": getRandomUA(), Accept: "application/json" },
                signal: AbortSignal.timeout(8000),
                cache: "no-store"
            });
            if (wikiRes.ok) {
                const wikiData = await wikiRes.json();
                const md = wikiData?.data?.content_md ?? "";
                if (md) synopsis = extractSynopsis(md);
            }
        } catch {}
        // Fall back to stats if no wiki synopsis available
        if (!synopsis || synopsis.length < 20) {
            synopsis = `${hardcoded.title} — ${mergedChapters.length} chapters by ${hardcoded.author}.`;
        }
        return {
            id: slug,
            title: hardcoded.title,
            wikiUrl: hardcoded.wikiUrl,
            synopsis,
            chapterLinks: mergedChapters.map((c)=>({
                    title: c.title,
                    url: c.url,
                    postId: c.postId
                })),
            author: hardcoded.author,
            rawMarkdown: "",
            hfyFoundationUrl: hardcoded.hfyFoundationUrl,
            ssbWikiUrl: hardcoded.ssbWikiUrl
        };
    }
    // Strategy 0: check user-imported cache first (user's browser fetched it)
    const imported = await (0,_user_chapters__WEBPACK_IMPORTED_MODULE_1__/* .getImportedChapters */ .bV)(slug);
    if (imported && imported.chapters.length > 0) {
        // Build a synopsis from available data
        let synopsis = imported.synopsis || "";
        // If no synopsis, try to fetch from hfy.foundation
        if (!synopsis) {
            try {
                const { fetchFromHfyFoundation } = await __webpack_require__.e(/* import() */ 5044).then(__webpack_require__.bind(__webpack_require__, 5044));
                const seriesName = (slug || "").replace(/_/g, " ");
                const hfyResult = await fetchFromHfyFoundation(seriesName);
                if (hfyResult.found) {
                    const ch = hfyResult.chapters;
                    synopsis = `${hfyResult.seriesName || seriesName} — ${ch.length} chapters by ${hfyResult.author || "unknown"}. ` + `Data sourced from hfy.foundation (up to ${hfyResult.snapshotDate?.slice(0, 10) || "unknown"}).`;
                }
            } catch  {
            // ignore
            }
        }
        // If still no synopsis, generate from chapter data
        if (!synopsis && imported.chapters.length > 0) {
            const first = imported.chapters[0];
            const last = imported.chapters[imported.chapters.length - 1];
            synopsis = `${imported.chapters.length} chapters discovered. ` + `First: "${first.title}". Last: "${last.title}". ` + `Source: ${imported.source}.`;
        }
        return {
            id: slug,
            title: (slug || "").replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase()),
            wikiUrl: `${REDDIT_BASE}/r/HFY/wiki/series/${slug}/`,
            synopsis,
            chapterLinks: imported.chapters.map((c)=>({
                    title: c.title,
                    url: c.url,
                    postId: c.postId
                })),
            rawMarkdown: ""
        };
    }
    // Wiki series pages live at /r/HFY/wiki/series/{slug} (with the /series/ segment)
    const url = `${REDDIT_BASE}/r/HFY/wiki/series/${slug}.json`;
    let data = null;
    let source = "none";
    // Strategy 1: direct fetch (will likely fail due to IP block)
    try {
        const oauthAuth2 = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .getRedditOAuthToken */ .VH)();
        const hdrs2 = { "User-Agent": getRandomUA(), Accept: "application/json" };
        if (oauthAuth2) hdrs2["Authorization"] = `Bearer ${oauthAuth2.token}`;
        const res = await fetch(url, {
            headers: hdrs2,
            signal: AbortSignal.timeout(8000),
            cache: "no-store"
        });
        if (res.ok) {
            data = await res.json();
            source = "direct";
        }
    } catch  {
    // fall through
    }
    // Strategy 2: CORS proxy pool
    if (!data) {
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(url, {
            expectedType: "json",
            maxProxiesToTry: 10,
            timeoutMs: 10000
        });
        if (result.ok) {
            try {
                data = JSON.parse(result.text);
                source = "proxy";
            } catch  {
            // ignore
            }
        }
    }
    if (!data) {
        // No wiki data available via direct or CORS proxy.
        // Try Wayback Machine for the wiki page to get the synopsis.
        let waybackSynopsis = "";
        try {
            const { fetchFromWayback } = await __webpack_require__.e(/* import() */ 2022).then(__webpack_require__.bind(__webpack_require__, 9641));
            const waybackResult = await fetchFromWayback(slug, {
                save: false
            });
            if (waybackResult.found && waybackResult.chapters.length > 0) {
                // The Wayback fetch already parsed chapters. Extract synopsis from
                // the wiki page HTML if it's stored.
                // The synopsis is the first meaningful paragraph on the wiki page.
                waybackSynopsis = waybackResult.chapters.length > 0 ? `Found ${waybackResult.chapters.length} chapters via Wayback Machine (snapshot ${waybackResult.snapshotTimestamp?.slice(0, 8)}).` : "";
            }
        } catch  {
        // ignore
        }
        // Return with whatever synopsis we found
        return {
            id: slug,
            title: (slug || "").replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase()),
            wikiUrl: `${REDDIT_BASE}/r/HFY/wiki/series/${slug}/`,
            synopsis: waybackSynopsis,
            chapterLinks: [],
            rawMarkdown: ""
        };
    }
    const md = data?.data?.content_md ?? "";
    const html = data?.data?.content_html ?? "";
    const title = data?.data?.title || (slug || "").replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
    const chapterLinks = parseChapterLinksFromMarkdown(md).concat(parseChapterLinksFromHtml(html));
    const seen = new Set();
    const deduped = [];
    for (const link of chapterLinks){
        if (!seen.has(link.postId)) {
            seen.add(link.postId);
            deduped.push(link);
        }
    }
    const synopsis = extractSynopsis(md);
    return {
        id: slug,
        title,
        wikiUrl: `${REDDIT_BASE}/r/HFY/wiki/series/${slug}/`,
        synopsis,
        chapterLinks: deduped,
        rawMarkdown: md
    };
}
function parseChapterLinksFromMarkdown(md) {
    const out = [];
    const re = /\[([^\]]+)\]\((https?:\/\/[^)]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^)]*)\)/gi;
    let m;
    while((m = re.exec(md)) !== null){
        const title = m[1].trim();
        const url = m[2].trim();
        const postIdMatch = url.match(REDDIT_POST_URL_PATTERN);
        if (postIdMatch) {
            out.push({
                title,
                url,
                postId: postIdMatch[1]
            });
        }
    }
    const bareRe = /(https?:\/\/[^\s)\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s)\]]*)/gi;
    while((m = bareRe.exec(md)) !== null){
        const url = m[1].trim();
        const postIdMatch = url.match(REDDIT_POST_URL_PATTERN);
        if (postIdMatch) {
            out.push({
                title: "Chapter",
                url,
                postId: postIdMatch[1]
            });
        }
    }
    return out;
}
function parseChapterLinksFromHtml(html) {
    const out = [];
    // Decode HTML entities first
    const decoded = html.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
    const re = /<a[^>]+href=["'](https?:\/\/[^"']*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^"']*)["'][^>]*>([^<]+)<\/a>/gi;
    let m;
    while((m = re.exec(decoded)) !== null){
        const url = m[1].trim();
        const title = m[2].trim() || "Chapter";
        const postIdMatch = url.match(REDDIT_POST_URL_PATTERN);
        if (postIdMatch) {
            out.push({
                title,
                url,
                postId: postIdMatch[1]
            });
        }
    }
    return out;
}
function extractSynopsis(md) {
    const lines = md.split("\n");
    for (const line of lines){
        const t = line.trim();
        if (!t) continue;
        if (t.startsWith("#")) continue;
        if (t.startsWith("-") || t.startsWith("*")) continue;
        if (t.startsWith("[")) continue;
        if (t.startsWith("http")) continue;
        if (t.startsWith("|")) continue;
        if (t.length < 30) continue;
        return t;
    }
    return "";
}
// =====================================================
// 3. Post content — USE POST RSS (the working endpoint!)
// =====================================================
// Reddit blocks .json but NOT .rss. We parse the RSS XML to extract:
//   - title, author, created date, permalink
//   - content (HTML inside <content type="html">)
//   - HTML-decode the content and extract the post body
//   - find "next chapter" links in the body

// =====================================================
// JSONL PRIMARY READER (FX45 v25)
// Reads post content directly from local JSONL files.
// This is the PRIMARY data source — no Reddit API needed.
// =====================================================
const fs = require("fs");
const path = require("path");

// Cache for JSONL index (postId -> metadata)
let _jsonlIndex = null;
let _jsonlIndexing = false;

function _findJsonlDir() {
    const candidates = [
        process.env.HFY_DATA_DIR ? path.join(process.env.HFY_DATA_DIR, "jsonl") : null,
        path.join(process.cwd(), "data", "jsonl"),
        path.join(process.cwd(), "..", "jsonl"),
        path.join(process.cwd(), "jsonl"),
        path.join(__dirname, "data", "jsonl"),
        path.join(__dirname, "..", "..", "data", "jsonl"),
        "/home/z/my-project/data/jsonl",
    ].filter(Boolean);
    for (const dir of candidates) {
        try {
            if (fs.existsSync(dir)) {
                const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl"));
                if (files.length > 0) return dir;
            }
        } catch {}
    }
    return null;
}

async function _buildJsonlIndex() {
    if (_jsonlIndexing || _jsonlIndex) return;
    _jsonlIndexing = true;
    const dir = _findJsonlDir();
    if (!dir) { _jsonlIndexing = false; return; }
    _jsonlIndex = new Map();
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl"));
    // Check if user has enabled loading large JSONL files (default: yes, no limit)
            let maxFileSizeMB = 0; // 0 = no limit, load all files
            try {
                const settingsPath = path.join(process.env.HFY_DATA_DIR || path.join(process.cwd(), "data"), "app-store", "hfy-nekrocodexxx-settings.json");
                if (fs.existsSync(settingsPath)) {
                    const settings = JSON.parse(fs.readFileSync(settingsPath, "utf8"));
                    if (settings && settings.jsonlSkipLargeFiles === true) {
                        maxFileSizeMB = 500; // Skip files > 500MB when toggle is ON
                    }
                }
            } catch {}
            for (const fileName of files) {
        const filePath = path.join(dir, fileName);
        try {
            if (maxFileSizeMB > 0) {
                const stat = fs.statSync(filePath);
                if (stat.size > maxFileSizeMB * 1024 * 1024) {
                    console.log("[jsonl-reader] Skipping large file: " + fileName + " (" + Math.round(stat.size / (1024*1024)) + "MB) — toggle 'Skip Large Files' off in Settings to load");
                    continue;
                }
            }
            const content = fs.readFileSync(filePath, "utf8");
            const lines = content.split("\n");
            for (const line of lines) {
                if (!line.trim()) continue;
                try {
                    const post = JSON.parse(line);
                    const pid = (post.id || post.postId || "").toString().toLowerCase();
                    if (pid) {
                        _jsonlIndex.set(pid, {
                            file: filePath,
                            title: post.title || "",
                            author: post.author || "",
                            score: post.score || 0,
                            created_utc: post.created_utc || 0,
                            subreddit: post.subreddit || "HFY",
                            permalink: post.permalink || "",
                            selftextLength: (post.selftext || "").length,
                        });
                    }
                } catch {}
            }
        } catch {}
    }
    console.log("[jsonl-reader] Index built: " + _jsonlIndex.size + " posts from " + files.length + " files");
    _jsonlIndexing = false;
}

async function _getPostFromJsonl(postId) {
    if (!_jsonlIndex) await _buildJsonlIndex();
    if (!_jsonlIndex) return null;
    const pid = postId.toString().toLowerCase();
    const meta = _jsonlIndex.get(pid);
    if (!meta) return null;
    try {
        const content = fs.readFileSync(meta.file, "utf8");
        const lines = content.split("\n");
        for (const line of lines) {
            if (!line.trim()) continue;
            try {
                const post = JSON.parse(line);
                if ((post.id || "").toString().toLowerCase() === pid) {
                    return {
                        postId: pid,
                        title: post.title || meta.title || "",
                        author: post.author || meta.author || "",
                        createdUtc: post.created_utc || meta.created_utc || 0,
                        score: post.score || meta.score || 0,
                        selftext: post.selftext || "",
                        selftextHtml: post.selftext_html || post.selftextHtml || "",
                        url: post.url || ("https://www.reddit.com/r/HFY/comments/" + pid + "/"),
                        permalink: post.permalink || meta.permalink || "",
                        numComments: post.num_comments || post.numComments || 0,
                        subreddit: post.subreddit || meta.subreddit || "HFY",
                        source: "jsonl",
                    };
                }
            } catch {}
        }
    } catch {}
    return null;
}

async function _searchJsonl(query, subreddit, limit) {
    if (!_jsonlIndex) await _buildJsonlIndex();
    if (!_jsonlIndex) return [];
    const q = (query || "").toLowerCase();
    const results = [];
    for (const [pid, meta] of _jsonlIndex) {
        if (subreddit && meta.subreddit.toLowerCase() !== subreddit.toLowerCase()) continue;
        if (q && !(meta.title || "").toLowerCase().includes(q)) continue;
        results.push({
            id: pid,
            postId: pid,
            title: meta.title,
            author: meta.author,
            score: meta.score,
            created_utc: meta.created_utc,
            subreddit: meta.subreddit,
            permalink: meta.permalink,
            url: "https://www.reddit.com/r/" + meta.subreddit + "/comments/" + pid + "/",
        });
        if (results.length >= limit) break;
    }
    results.sort((a, b) => (b.score || 0) - (a.score || 0));
    return results;
}

async function _getSubredditFeedJson(subreddit, sort, limit, after) {
    if (!_jsonlIndex) await _buildJsonlIndex();
    if (!_jsonlIndex) return { data: { children: [], after: null } };
    const sub = (subreddit || "HFY").toLowerCase();
    const posts = [];
    for (const [pid, meta] of _jsonlIndex) {
        if (meta.subreddit.toLowerCase() !== sub) continue;
        posts.push({
            id: pid,
            postId: pid,
            title: meta.title,
            author: meta.author,
            score: meta.score,
            created_utc: meta.created_utc,
            subreddit: meta.subreddit,
            permalink: meta.permalink,
        });
    }
    if (sort === "new") posts.sort((a, b) => (b.created_utc || 0) - (a.created_utc || 0));
    else if (sort === "top") posts.sort((a, b) => (b.score || 0) - (a.score || 0));
    const startIdx = after ? 0 : 0;
    const page = posts.slice(startIdx, startIdx + limit);
    return {
        data: {
            children: page.map(p => ({ data: p })),
            after: null,
        },
    };
}


async function fetchPostContent(postIdOrUrl) {
    let postId;
    let postUrl;
    if (postIdOrUrl.startsWith("http")) {
        const m = postIdOrUrl.match(REDDIT_POST_URL_PATTERN);
        if (!m) throw new Error(`Invalid Reddit post URL: ${postIdOrUrl}`);
        postId = normalizePostId(m[1]);
        postUrl = `${REDDIT_BASE}/r/HFY/comments/${postId}/`;
    } else {
        postId = normalizePostId(postIdOrUrl);
        postUrl = `${REDDIT_BASE}/r/HFY/comments/${postId}/`;
    }
    const normalizedUrl = (postUrl || "").replace(/[?#].*$/, "").replace(/\/$/, "");
    const shortUrlMatch = normalizedUrl.match(/^(https?:\/\/[^/]+\/r\/[^/]+\/comments\/[a-z0-9_]+)/i);
    if (shortUrlMatch) {
        shortUrlMatch[1] = shortUrlMatch[1].replace(/\/comments\/t3_/i, "/comments/");
    }
    const rssBaseUrl = shortUrlMatch ? shortUrlMatch[1] : normalizedUrl;
    const rssUrl = `${rssBaseUrl}/.rss`;
    console.log(`[reddit-scraper] fetchPostContent: postId=${postId}`);
    // ========== STRATEGY -1 (NEW ULTIMATE PRIMARY): JSONL file ==========
    // Read directly from local JSONL files — no network, no Reddit API.
    try {
        const jsonlPost = await _getPostFromJsonl(postId);
        if (jsonlPost && jsonlPost.selftext && jsonlPost.selftext.length > 0) {
            console.log("[reddit-scraper] JSONL PRIMARY hit for " + postId + " (score=" + jsonlPost.score + ", " + jsonlPost.selftext.length + " chars)");
            const selftextHtml = jsonlPost.selftextHtml || "";
            const allLinks = findChapterLinks(jsonlPost.selftext || "", selftextHtml, NEXT_LINK_PATTERNS);
            return {
                postId: jsonlPost.postId,
                title: jsonlPost.title,
                author: jsonlPost.author,
                createdUtc: jsonlPost.createdUtc,
                score: jsonlPost.score,
                selftext: jsonlPost.selftext,
                selftextHtml: selftextHtml,
                url: jsonlPost.url,
                permalink: jsonlPost.permalink,
                numComments: jsonlPost.numComments,
                subreddit: jsonlPost.subreddit,
                nextChapterLinks: allLinks,
                source: "jsonl",
            };
        }
        console.log("[reddit-scraper] JSONL PRIMARY miss for " + postId + " — trying chapter-cache");
    } catch (e) {
        console.log("[reddit-scraper] JSONL PRIMARY failed for " + postId + ": " + e.message);
    }

    // ========== STRATEGY -2: Server chapter-cache ==========
    // Check if this chapter is already cached on the server filesystem.
    // This includes content pre-cached from JSONL files by the client.
    // If found, return instantly — no network calls at all.
    try {
        const fs = __webpack_require__(9021);
        const path = __webpack_require__(3873);
        const cacheDir = process.env.HFY_DATA_DIR ? path.join(process.env.HFY_DATA_DIR, "chapter-cache") : path.join(process.cwd(), "data", "chapter-cache");
        const safePostId = String(postId).replace(/[^a-zA-Z0-9_-]/g, "_");
        const cacheFile = path.join(cacheDir, `${safePostId}.json`);
        if (fs.existsSync(cacheFile)) {
            const cached = JSON.parse(fs.readFileSync(cacheFile, "utf8"));
            if (cached && cached.selftext && cached.selftext.length > 0) {
                console.log(`[reddit-scraper] CHAPTER-CACHE hit for ${postId} (score=${cached.score || 0}, ${cached.selftext.length} chars)`);
                // FIX (audit): Accept both camelCase and snake_case field names.
                // Cache files may have been written by different writers:
                // - jsonl-handler.js (port 3001): normalizes to camelCase
                // - /api/chapter-cache/[postId] POST route: normalizes to camelCase
                // - Older cache files or direct writes: may have snake_case
                // Accepting both ensures backwards compatibility.
                const selftextHtml = cached.selftextHtml || cached.selftext_html || "";
                const allLinks = findChapterLinks(cached.selftext || "", selftextHtml, NEXT_LINK_PATTERNS);
                return {
                    postId: cached.postId || postId,
                    title: cached.title || "",
                    author: cached.author || "",
                    createdUtc: cached.createdUtc || cached.created_utc || 0,
                    score: cached.score || 0,
                    selftext: cached.selftext || "",
                    selftextHtml: selftextHtml,
                    url: cached.url || normalizedUrl,
                    permalink: cached.permalink || normalizedUrl,
                    subreddit: cached.subreddit || "HFY",
                    flair: cached.flair || cached.link_flair_text || undefined,
                    numComments: cached.numComments || cached.num_comments || 0,
                    nextChapterLinks: allLinks,
                    prevChapterLinks: [],
                    source: "chapter-cache"
                };
            }
        }
    } catch (e) {
        // Cache miss or error — fall through to Arctic Shift
    }

    // ========== STRATEGY 1 (PRIMARY): Arctic Shift API ==========
    // Single call returns BOTH content AND score. No OAuth, no cookies.
    // Not blocked by Reddit. Returns real upvote scores.
    // Endpoint: /api/posts/ids?ids={postId}&md2html=true
    try {
        const arcticUrl = `https://arctic-shift.photon-reddit.com/api/posts/ids?ids=${postId}&md2html=true`;
        const arcticRes = await fetch(arcticUrl, {
            signal: AbortSignal.timeout(15000),
            cache: "no-store",
            headers: { "Accept": "application/json" }
        });
        if (arcticRes.ok) {
            const arcticData = await arcticRes.json();
            const posts = arcticData?.data ?? arcticData;
            if (Array.isArray(posts) && posts.length > 0) {
                const post = posts[0];
                if (post && (post.selftext || post.selftext_html)) {
                    console.log(`[reddit-scraper] Arctic Shift PRIMARY OK for ${postId} (score=${post.score ?? 0}, ${post.selftext?.length ?? 0} chars)`);
                    return parseArcticShiftPost(post, postId, normalizedUrl);
                }
            }
        }
        console.log(`[reddit-scraper] Arctic Shift PRIMARY miss for ${postId} (status=${arcticRes.status}) — trying RSS fallback`);
    } catch (e) {
        console.log(`[reddit-scraper] Arctic Shift PRIMARY failed for ${postId}: ${e.message}`);
    }

    // ========== STRATEGY 2: RSS direct (fallback for newest chapters not yet archived) ==========
    let rssText = null;
    let source = "rss";
    for (let attempt = 0; attempt < 3 && !rssText; attempt++) {
        try {
            const rssHeaders = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Accept": "application/atom+xml, application/xml, text/xml, text/html, */*",
                "Accept-Language": "en-US,en;q=0.9",
                "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                "Sec-Ch-Ua-Mobile": "?0",
                "Sec-Ch-Ua-Platform": '"Windows"',
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
                "Cache-Control": "no-cache",
                "Connection": "close"
            };
            const res = await fetch(rssUrl, {
                headers: rssHeaders,
                signal: AbortSignal.timeout(15000),
                cache: "no-store"
            });
            console.log(`[reddit-scraper] RSS fetch ${postId}: status=${res.status} attempt=${attempt + 1}`);
            if (res.ok) {
                rssText = await res.text();
                break;
            }
            const remaining = res.headers.get("x-ratelimit-remaining");
            const reset = res.headers.get("x-ratelimit-reset");
            if ((res.status === 429 || remaining === "0") && reset) {
                const waitSec = Math.min(parseInt(reset) + 1, 30);
                console.log(`[reddit-scraper] Rate limited, waiting ${waitSec}s (attempt ${attempt + 1}/3)`);
                await new Promise((r) => setTimeout(r, waitSec * 1000));
                continue;
            }
            if (res.status === 403 && attempt < 2) {
                console.log(`[reddit-scraper] Got 403, waiting 5s before retry (attempt ${attempt + 1}/3)`);
                await new Promise((r) => setTimeout(r, 5000));
                continue;
            }
            break;
        } catch (err) {
            console.log(`[reddit-scraper] RSS fetch exception for ${postId}: ${err?.message}`);
            break;
        }
    }

    // ========== STRATEGY 3: Cookie-based .json fetch ==========
    if (!rssText) {
        try {
            const { fetchWithCookies } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4383));
            const cookieUrl = `https://www.reddit.com/comments/${postId}.json?limit=1`;
            const cookieRes = await fetchWithCookies(cookieUrl, { timeoutMs: 12000 });
            if (cookieRes.ok && cookieRes.text) {
                try {
                    const data = JSON.parse(cookieRes.text);
                    const postData = data?.[0]?.data?.children?.[0]?.data;
                    if (postData && (postData.selftext || postData.selftext_html)) {
                        console.log(`[reddit-scraper] Cookie content fetch OK for ${postId} (score=${postData.score ?? 0})`);
                        return parseJsonPostContent(postData, postId, normalizedUrl, "json");
                    }
                } catch (e) {
                    console.log(`[reddit-scraper] Cookie JSON parse failed for ${postId}: ${e}`);
                }
            }
        } catch (e) {
            console.log(`[reddit-scraper] Cookie fetch failed for ${postId}: ${e}`);
        }
    }

    // ========== STRATEGY 4: CORS proxy pool (last resort) ==========
    if (!rssText) {
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(rssUrl, {
            expectedType: "text",
            maxProxiesToTry: 10,
            timeoutMs: 12000,
            headers: { "User-Agent": getRandomUA() }
        });
        if (result.ok) {
            rssText = result.text;
            source = "proxy";
        }
    }

    if (!rssText) {
        throw new Error(`Failed to fetch post ${postId} (Arctic Shift + RSS + cookies + proxies all failed)`);
    }

    const content = parseRssPostContent(rssText, postId, normalizedUrl, source);

    // ========== SCORE FETCH: Arctic Shift FIRST (no OAuth) ==========
    if (content.score === 0) {
        try {
            const arcticUrl = `https://arctic-shift.photon-reddit.com/api/posts/ids?ids=${postId}`;
            const arcticRes = await fetch(arcticUrl, {
                signal: AbortSignal.timeout(10000),
                cache: "no-store"
            });
            if (arcticRes.ok) {
                const arcticData = await arcticRes.json();
                const posts = arcticData?.data ?? arcticData;
                if (Array.isArray(posts) && posts.length > 0) {
                    const post = posts[0];
                    if (post.score !== undefined && post.score !== null) {
                        content.score = post.score;
                        console.log(`[reddit-scraper] Fetched score via Arctic Shift for ${postId}: ${content.score}`);
                    }
                    if (!content.createdUtc && post.created_utc) {
                        content.createdUtc = post.created_utc;
                    }
                    if (!content.author || content.author === "unknown") {
                        content.author = post.author || content.author;
                    }
                    if (post.num_comments !== undefined) {
                        content.numComments = post.num_comments;
                    }
                }
            }
        } catch (e) {
            console.log(`[reddit-scraper] Arctic Shift score fetch failed for ${postId}: ${e}`);
        }
    }

    return content;
}

// Helper: parse Arctic Shift post format into ChapterContent
function parseArcticShiftPost(post, postId, postUrl, source = "arctic-shift") {
    const selftext = post.selftext ?? "";
    const selftextHtml = post.selftext_html ?? "";
    const allLinks = findChapterLinks(selftext, selftextHtml, NEXT_LINK_PATTERNS);
    return {
        postId,
        title: post.title ?? "",
        author: post.author ?? "",
        createdUtc: post.created_utc ?? 0,
        score: post.score ?? 0,
        selftext,
        selftextHtml,
        url: post.url ?? postUrl,
        permalink: post.permalink ? `https://www.reddit.com${post.permalink}` : postUrl,
        subreddit: post.subreddit ?? "HFY",
        flair: post.link_flair_text ?? undefined,
        numComments: post.num_comments ?? 0,
        nextChapterLinks: allLinks,
        prevChapterLinks: [],
        source
    };
}

// Helper: bulk fetch up to 500 posts via Arctic Shift (for C-FETCH batches)
async function fetchPostContentBulk(postIds) {
    const results = new Map();
    const batchSize = 500;
    for (let i = 0; i < postIds.length; i += batchSize) {
        const batch = postIds.slice(i, i + batchSize);
        const idsParam = batch.map(id => normalizePostId(id)).join(",");
        try {
            const arcticUrl = `https://arctic-shift.photon-reddit.com/api/posts/ids?ids=${idsParam}&md2html=true`;
            const arcticRes = await fetch(arcticUrl, {
                signal: AbortSignal.timeout(30000),
                cache: "no-store",
                headers: { "Accept": "application/json" }
            });
            if (arcticRes.ok) {
                const arcticData = await arcticRes.json();
                const posts = arcticData?.data ?? arcticData;
                if (Array.isArray(posts)) {
                    for (const post of posts) {
                        if (post && post.id && (post.selftext || post.selftext_html)) {
                            results.set(post.id, parseArcticShiftPost(post, post.id, `https://www.reddit.com/r/HFY/comments/${post.id}/`));
                        }
                    }
                }
            }
            console.log(`[reddit-scraper] Arctic Shift bulk fetch batch ${Math.floor(i/batchSize)+1}: ${results.size}/${postIds.length} fetched`);
        } catch (e) {
            console.log(`[reddit-scraper] Arctic Shift bulk fetch failed for batch: ${e.message}`);
        }
    }
    return results;
}

function parseJsonPostContent(postData, postId, postUrl, source) {
    const selftext = postData.selftext ?? "";
    const selftextHtml = postData.selftext_html ?? "";
    // FIX: Take ALL matching links, not just the first.
    // This allows multi-part chapters (Part 1, Part 2, Part 3) and
    // multiple "next" links to be discovered.
    const allLinks = findChapterLinks(selftext, selftextHtml, NEXT_LINK_PATTERNS);
    const nextLinks = allLinks; // All matching links (prequels already filtered in findChapterLinks)
    return {
        postId,
        title: postData.title ?? "",
        author: postData.author ?? "",
        createdUtc: postData.created_utc ?? 0,
        score: postData.score ?? 0,
        selftext,
        selftextHtml,
        url: postData.url ?? postUrl,
        permalink: postData.permalink ? `https://www.reddit.com${postData.permalink}` : postUrl,
        subreddit: postData.subreddit ?? "HFY",
        flair: postData.link_flair_text ?? undefined,
        numComments: postData.num_comments ?? 0,
        nextChapterLinks: nextLinks,
        prevChapterLinks: [],
        source
    };
}
function parseRssPostContent(rssXml, postId, postUrl, source) {
    // Extract the first <entry> — this is the post itself
    // (RSS includes comments as additional entries)
    const entryMatch = rssXml.match(/<entry>([\s\S]*?)<\/entry>/);
    if (!entryMatch) {
        throw new Error(`No <entry> found in RSS for post ${postId}`);
    }
    const entry = entryMatch[1];
    // Title
    const title = decodeXml(getFirst(entry, "title")) || `Post ${postId}`;
    // Author
    const authorMatch = entry.match(/<author>[\s\S]*?<name>([^<]+)<\/name>/);
    const authorRaw = authorMatch ? authorMatch[1].trim() : "unknown";
    const author = authorRaw.replace(/^\/?u\//, "");
    // Permalink (link rel=alternate)
    const linkMatch = entry.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/);
    const permalink = linkMatch ? linkMatch[1] : postUrl;
    // Published date
    const published = decodeXml(getFirst(entry, "published")) || decodeXml(getFirst(entry, "updated")) || "";
    const createdUtc = published ? Date.parse(published) / 1000 : 0;
    // Content (HTML)
    const contentMatch = entry.match(/<content[^>]*>([\s\S]*?)<\/content>/);
    const contentHtmlEncoded = contentMatch ? contentMatch[1] : "";
    // RSS content is HTML-encoded — decode it
    const contentHtml = decodeXml(contentHtmlEncoded).replace(/<!-- SC_OFF -->/g, "").replace(/<!-- SC_ON -->/g, "").trim();
    // Extract the .md div content (Reddit wraps post body in <div class="md">)
    let bodyHtml = contentHtml;
    const mdDivMatch = contentHtml.match(/<div class="md">([\s\S]*?)<\/div>\s*(?:<div|$)/);
    if (mdDivMatch) {
        bodyHtml = mdDivMatch[1];
    }
    // Strip HTML to get selftext (plain text)
    const selftext = htmlToMarkdown(bodyHtml);
    // FIX: Take ALL matching links, not just the first.
    // This allows multi-part chapters (Part 1, Part 2, Part 3) and
    // multiple "next" links to be discovered.
    const allLinks = findChapterLinks(selftext, bodyHtml, NEXT_LINK_PATTERNS);
    const nextLinks = allLinks; // All matching links (prequels already filtered in findChapterLinks)
    // Score isn't in RSS — returns 0, fetchPostContent will fetch it via OAuth
    return {
        postId,
        title,
        author,
        createdUtc,
        score: 0,
        selftext,
        selftextHtml: bodyHtml,
        url: postUrl,
        permalink,
        subreddit: "HFY",
        flair: undefined,
        numComments: 0,
        nextChapterLinks: nextLinks,
        prevChapterLinks: [],
        source
    };
}
function getFirst(xml, tag) {
    const re = new RegExp(`<${tag}[^>]*>([^<]*)</${tag}>`);
    const m = xml.match(re);
    return m ? m[1] : "";
}
function decodeXml(s) {
    return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'");
}
function htmlToMarkdown(html) {
    // Convert common HTML to markdown for the reader
    let md = html;
    // Headings
    md = md.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, (_, t)=>`# ${stripTags(t)}\n\n`);
    md = md.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, (_, t)=>`## ${stripTags(t)}\n\n`);
    md = md.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, (_, t)=>`### ${stripTags(t)}\n\n`);
    // Bold / italic
    md = md.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, (_, t)=>`*${stripTags(t)}*`);
    md = md.replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, (_, t)=>`*${stripTags(t)}*`);
    // Links
    md = md.replace(/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, (_, href, t)=>`[${stripTags(t)}](${href})`);
    // Blockquote
    md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_, t)=>`> ${stripTags(t).replace(/\n/g, "\n> ")}\n\n`);
    // Horizontal rule
    md = md.replace(/<hr[^>]*>/gi, "\n---\n\n");
    // Code
    md = md.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_, t)=>`\`${stripTags(t)}\``);
    md = md.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, t)=>`\`\`\`\n${stripTags(t)}\n\`\`\`\n\n`);
    // Paragraphs and breaks
    md = md.replace(/<p[^>]*>/gi, "\n\n");
    md = md.replace(/<\/p>/gi, "");
    md = md.replace(/<br\s*\/?>/gi, "\n");
    // Lists
    md = md.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_, t)=>`- ${stripTags(t).trim()}\n`);
    md = md.replace(/<\/?(ul|ol)[^>]*>/gi, "\n");
    // Strip remaining tags
    md = stripTags(md);
    // Decode entities
    md = decodeXml(md);
    // Collapse whitespace
    md = md.replace(/\n{3,}/g, "\n\n\n").trim();
    return md;
}
function stripTags(html) {
    return html.replace(/<[^>]+>/g, "");
}
// =====================================================
// 4. "Next chapter" link discovery
// =====================================================
// Words that indicate a link is to a PREQUEL or ORIGINAL series, not the
// current series' next chapter. When the crawler finds these words in the
// link text or surrounding context, it should NOT follow that link.
const PREQUEL_LINK_INDICATORS = [
    /previous\s*chapter/i,
    /\bprev\b/i,
    /\bfirst\s*chapter/i,
    /\bfirst\b/i,
    /\boriginal\s*series/i,
    /\bprequel\b/i,
    /\bbook\s*1\b/i,
    /\bbeginning\b/i,
    /\bstart\s*here/i,
    /\bfrom\s*the\s*start/i,
    /\bbefore\s*this/i,
    /\bearlier/i,
    /\bback\s*to\s*the\s*beginning/i,
    /\bprevious\b/i
];
// Check if a link should be skipped (it's a prequel/previous link)
// FIX: Only check the link TEXT itself, not the surrounding context.
// Previously, checking context caused false positives — e.g., if the text
// was "First : Previous : Next", the "Next" link would be filtered because
// its context contained "First" and "Previous".
function isPrequelLink(linkText, context) {
    const lowerText = (linkText || "").toLowerCase().trim();
    return PREQUEL_LINK_INDICATORS.some((re)=>re.test(lowerText));
}
/**
 * Extract a Reddit post ID from a URL.
 * "https://www.reddit.com/r/HFY/comments/abc123/chapter_1/" → "abc123"
 * Returns null if the URL doesn't match the Reddit post pattern.
 */ function extractPostId(url) {
    const m = url.match(REDDIT_POST_URL_PATTERN);
    return m ? m[1] : null;
}
/**
 * Find the NEXT chapter URL from a post's content.
 * Follows hfy2epub's approach: returns ONLY the FIRST matching link
 * that hasn't been visited yet. This prevents following "previous" links
 * to prequel chapters, because "next" links typically appear before
 * "previous" links in the post body.
 *
 * @param markdown - The post's markdown content
 * @param html - The post's HTML content (optional)
 * @param patterns - Active link patterns (or null to use defaults)
 * @param visitedPostIds - Set of already-visited post IDs
 * @returns The first unvisited matching URL, or null if none found
 */ function findNextChapterUrl(markdown, html, patterns, visitedPostIds) {
    const activePatterns = patterns ?? getActiveLinkPatterns();
    // Markdown links — iterate in order, return first match
    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g;
    let m;
    while((m = mdLinkRe.exec(markdown)) !== null){
        const text = m[1];
        const url = m[2];
        // Skip prequel links
        const linkStart = m.index;
        const contextStart = Math.max(0, linkStart - 100);
        const context = markdown.slice(contextStart, linkStart);
        if (isPrequelLink(text, context)) continue;
        // Check if link text matches a "next" pattern
        if (REDDIT_POST_URL_PATTERN.test(url) && activePatterns.some((p)=>p.test(text))) {
            const postId = extractPostId(url);
            if (postId && !visitedPostIds.has(postId)) {
                return normalizeRedditUrl(url);
            }
        }
    }
    // HTML <a> tags — iterate in order, return first match
    if (html) {
        const aRe = /<a[^>]+href=["'](https?:\/\/[^"']+)["'][^>]*>([^<]*)<\/a>/gi;
        while((m = aRe.exec(html)) !== null){
            const url = m[1];
            const text = m[2];
            const linkStart = m.index;
            const contextStart = Math.max(0, linkStart - 100);
            const context = html.slice(contextStart, linkStart);
            if (isPrequelLink(text, context)) continue;
            if (REDDIT_POST_URL_PATTERN.test(url) && activePatterns.some((p)=>p.test(text))) {
                const postId = extractPostId(url);
                if (postId && !visitedPostIds.has(postId)) {
                    return normalizeRedditUrl(url);
                }
            }
        }
    }
    // Bare URLs near "next" keywords — return first match
    const lines = markdown.split("\n");
    for (const line of lines){
        const trimmed = line.trim().toLowerCase();
        if (activePatterns.some((p)=>p.test(trimmed))) {
            if (isPrequelLink(trimmed, "")) continue;
            const urlMatch = line.match(/https?:\/\/[^\s)\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s)\]]*/i);
            if (urlMatch) {
                const postId = extractPostId(urlMatch[0]);
                if (postId && !visitedPostIds.has(postId)) {
                    return normalizeRedditUrl(urlMatch[0]);
                }
            }
        }
    }
    return null;
}
function findChapterLinks(markdown, html, patterns) {
    // Use provided patterns, or get active patterns (built-in + custom from settings)
    const activePatterns = patterns ?? getActiveLinkPatterns();
    const found = new Set();
    // Markdown links
    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g;
    let m;
    while((m = mdLinkRe.exec(markdown)) !== null){
        const text = m[1];
        const url = m[2];
        // Get context (100 chars before the link)
        const linkStart = m.index;
        const contextStart = Math.max(0, linkStart - 100);
        const context = markdown.slice(contextStart, linkStart);
        // Skip prequel/previous links
        if (isPrequelLink(text, context)) continue;
        // Match if: (1) link text matches a "next chapter" pattern, OR
        // (2) the URL is a Reddit post link (any link to another Reddit post
        // is a potential chapter link — not just ones labeled "next")
        if (REDDIT_POST_URL_PATTERN.test(url) && (activePatterns.some((p)=>p.test(text)) || REDDIT_POST_URL_PATTERN.test(text) // link text is itself a Reddit URL
        )) {
            found.add(normalizeRedditUrl(url));
        }
    }
    // HTML <a> tags
    if (html) {
        const aRe = /<a[^>]+href=["'](https?:\/\/[^"']+)["'][^>]*>([^<]*)<\/a>/gi;
        while((m = aRe.exec(html)) !== null){
            const url = m[1];
            const text = m[2];
            // Get context (100 chars before the link in HTML)
            const linkStart = m.index;
            const contextStart = Math.max(0, linkStart - 100);
            const context = html.slice(contextStart, linkStart);
            // Skip prequel/previous links
            if (isPrequelLink(text, context)) continue;
            if (REDDIT_POST_URL_PATTERN.test(url) && (activePatterns.some((p)=>p.test(text)) || REDDIT_POST_URL_PATTERN.test(text) // link text is itself a Reddit URL
            )) {
                found.add(normalizeRedditUrl(url));
            }
        }
    }
    // Bare URLs near "next" keywords
    const lines = markdown.split("\n");
    for (const line of lines){
        const trimmed = line.trim().toLowerCase();
        if (activePatterns.some((p)=>p.test(trimmed))) {
            // Skip if the line contains prequel indicators
            if (isPrequelLink(trimmed, "")) continue;
            const urlMatch = line.match(/https?:\/\/[^\s)\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s)\]]*/i);
            if (urlMatch) {
                found.add(normalizeRedditUrl(urlMatch[0]));
            }
        }
    }
    return Array.from(found);
}
function normalizeRedditUrl(url) {
    if (!url || typeof url !== "string") return "";
    try {
        return url.replace(/[?#].*$/, "").replace(/\/$/, "").replace(/^https?:\/\/(www\.|old\.|new\.|np\.)?reddit\.com/i, "https://www.reddit.com").replace(/\/r\/HFY\//i, "/r/HFY/").replace(/\/r\/hfy\//i, "/r/HFY/").replace(/\/comments\//i, "/comments/").toLowerCase();
    } catch  {
        return url || "";
    }
}
// =====================================================
// 5. Search r/HFY — try RSS first, then CORS proxies
// =====================================================
async function searchSeries(query, sort = "relevance") {
    // STRATEGY 1 (PRIMARY): Arctic Shift API — search posts in r/HFY
    // Using 'query' parameter (searches both title AND selftext) so that
    // multi-book series with different chapter naming conventions are found
    // even when the series name isn't in the chapter title.
    try {
        // FIX (audit): "top" and "new" both want newest/highest first → "desc".
        // Only "old"/"asc" intentionally returns ascending order.
        const arcticSort = (sort === "old" || sort === "asc") ? "asc" : "desc";
        const arcticUrl = `https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=HFY&query=${encodeURIComponent(query)}&limit=100&sort=${arcticSort}`;
        const arcticRes = await fetch(arcticUrl, {
            signal: AbortSignal.timeout(15000),
            cache: "no-store",
            headers: { "Accept": "application/json" }
        });
        if (arcticRes.ok) {
            const arcticData = await arcticRes.json();
            const posts = arcticData?.data ?? arcticData;
            if (Array.isArray(posts) && posts.length > 0) {
                console.log(`[reddit-scraper] Arctic Shift search OK for "${query}" (${posts.length} results)`);
                return posts.map(p => ({
                    id: p.id,
                    title: p.title,
                    wikiUrl: p.permalink ? `https://www.reddit.com${p.permalink}` : `https://www.reddit.com/r/HFY/comments/${p.id}/`,
                    author: p.author
                }));
            }
        }
    } catch (e) {
        console.log(`[reddit-scraper] Arctic Shift search failed: ${e}`);
    }

    // STRATEGY 2: Cookie-based search
    try {
        const { fetchWithCookies } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4383));
        const sortParam = sort === "new" ? "new" : sort === "top" ? "top" : "relevance";
        const cookieUrl = `${REDDIT_BASE}/r/HFY/search.json?q=${encodeURIComponent(query)}&sort=${sortParam}&limit=250&restrict_sr=1`;
        const cookieRes = await fetchWithCookies(cookieUrl, { timeoutMs: 12000 });
        if (cookieRes.ok && cookieRes.text) {
            try {
                const data = JSON.parse(cookieRes.text);
                const children = data?.data?.children ?? [];
                if (children.length > 0) {
                    console.log(`[reddit-scraper] Cookie search OK for "${query}" (${children.length} results)`);
                    return children.map((c) => ({
                        id: c.data.id,
                        title: c.data.title,
                        wikiUrl: `https://www.reddit.com${c.data.permalink}`,
                        author: c.data.author
                    }));
                }
            } catch (e) {
                console.log(`[reddit-scraper] Cookie search JSON parse failed: ${e}`);
            }
        }
    } catch (e) {
        console.log(`[reddit-scraper] Cookie search failed: ${e}`);
    }

    // STRATEGY 3: CORS proxy pool (last resort)
    const sortParam = sort === "new" ? "new" : sort === "top" ? "top" : "relevance";
    const url = `${REDDIT_BASE}/r/HFY/search.json?q=${encodeURIComponent(query)}&sort=${sortParam}&limit=250&restrict_sr=1`;
    const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(url, {
        expectedType: "json",
        maxProxiesToTry: 8,
        timeoutMs: 10000
    });
    if (result.ok) {
        try {
            const data = JSON.parse(result.text);
            const children = data?.data?.children ?? [];
            return children.map((c) => ({
                id: c.data.id,
                title: c.data.title,
                wikiUrl: `https://www.reddit.com${c.data.permalink}`,
                author: c.data.author
            }));
        } catch {
        // ignore
        }
    }
    return [];
}

async function fetchSubredditFeed(limit = 25) {
    const url = `${REDDIT_BASE}/r/HFY.rss?limit=${limit}`;
    try {
        const feedAuth = await (0,_reddit_oauth__WEBPACK_IMPORTED_MODULE_2__/* .getRedditOAuthToken */ .VH)();
        const feedHdrs = { "User-Agent": getRandomUA(), Accept: "application/atom+xml" };
        if (feedAuth) feedHdrs["Authorization"] = `Bearer ${feedAuth.token}`;
        const res = await fetch(url, {
            headers: feedHdrs,
            signal: AbortSignal.timeout(10000),
            cache: "no-store"
        });
        if (!res.ok) return [];
        const xml = await res.text();
        return parseSubredditRss(xml);
    } catch  {
        return [];
    }
}
function parseSubredditRss(xml) {
    const posts = [];
    const entryRe = /<entry>([\s\S]*?)<\/entry>/g;
    let m;
    while((m = entryRe.exec(xml)) !== null){
        const entry = m[1];
        const id = (getFirst(entry, "id") || "").replace(/^t3_/, "");
        const title = decodeXml(getFirst(entry, "title")) || "Untitled";
        const authorMatch = entry.match(/<author>[\s\S]*?<name>([^<]+)<\/name>/);
        const authorRaw = authorMatch ? authorMatch[1].trim() : "unknown";
        const author = authorRaw.replace(/^\/?u\//, "");
        const linkMatch = entry.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/);
        const permalink = linkMatch ? linkMatch[1] : "";
        const published = decodeXml(getFirst(entry, "published")) || "";
        const createdUtc = published ? Date.parse(published) / 1000 : 0;
        const contentMatch = entry.match(/<content[^>]*>([\s\S]*?)<\/content>/);
        const contentHtml = contentMatch ? decodeXml(contentMatch[1]) : "";
        const selftext = htmlToMarkdown(contentHtml).slice(0, 500);
        if (id && permalink) {
            posts.push({
                id,
                title,
                author,
                permalink,
                createdUtc,
                flair: undefined,
                selftext,
                score: 0
            });
        }
    }
    return posts;
}


/***/ }),

/***/ 4383:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Gz: () => (/* binding */ clearUserToken),
/* harmony export */   KN: () => (/* binding */ fetchWithOAuth),
/* harmony export */   R_: () => (/* binding */ setUserToken),
/* harmony export */   U2: () => (/* binding */ fetchWikiPageJson),
/* harmony export */   VH: () => (/* binding */ getRedditOAuthToken),
/* harmony export */   dE: () => (/* binding */ fetchWithRedDownloader),
/* harmony export */   fetchWithCookies: () => (/* binding */ fetchWithCookies),
/* harmony export */   searchSubreddit: () => (/* binding */ searchSubreddit)
/* harmony export */ });
/* unused harmony exports getUserToken, getUserRefreshToken, getAppOnlyToken, fetchWithProxyBrowser, fetchPostJson, fetchSubredditFeedJson */
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5511);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
// HFY NEKROCODEXXX — Reddit Downloaders Integration
// =====================================================
// Integrates 5 Reddit downloaders as a multi-tier fallback system:
//
//   1. DownloaderForReddit (DFR) — bundled client_id OAuth (frGEUVAuHGL2PQ)
//      Source: github.com/MalloyDelacroix/DownloaderForReddit
//      Type: OAuth (Installed App, app-only)
//
//   2. easy-reddit-downloader — authless .json with browser UA
//      Source: github.com/josephrcox/easy-reddit-downloader
//      Type: Authless (no OAuth, no login)
//      Approach: fetches www.reddit.com/.../.json with browser User-Agent
//
//   3. RedDownloader — authless .json (RedDownloader approach)
//      Source: github.com/Jackhammer9/RedDownloader
//      Type: Authless
//      Approach: same as easy-reddit-downloader (browser UA + .json)
//
//   4. reddit-json-scraper — authless .json
//      Source: github.com/0anxt/reddit-json-scraper
//      Type: Authless
//      Approach: public .json API, no auth
//
//   5. reddit-dl — OAuth + proxy support
//      Source: github.com/patrickkfkan/reddit-dl
//      Type: OAuth (user-provided) or proxy
//      Approach: supports account-specific content (saved posts, joined subs)
//
// TIER SYSTEM:
//   Tier B (PRIMARY): User OAuth (user logs in, 600 QPM, NSFW access)
//   Tier A (SECONDARY): DFR App-Only OAuth (bundled client_id, 100 QPM, public)
//   Tier R (TERTIARY): RedDownloader/easy-reddit-downloader/reddit-json-scraper
//                       (authless .json, no rate limit tracking, browser UA)
//   Tier P (QUATERNARY): reddit-dl proxy support (CORS proxy pool)
//   Tier S (LAST RESORT): RSS feeds (.rss endpoints, not blocked)

// =====================================================
// Client IDs (from DownloaderForReddit — pre-approved by Reddit)
// =====================================================
const BUNDLED_CLIENT_ID = process.env.REDDIT_BUNDLED_CLIENT_ID || "frGEUVAuHGL2PQ";
const USER_AGENT_DFR = "HFY-NEKROCODEXXX/1.0 (Reddit HFY series reader; fork of DownloaderForReddit approach)";
// easy-reddit-downloader uses a generic browser UA
const USER_AGENT_EASY = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
// reddit-json-scraper uses a Python UA
const USER_AGENT_RJS = "python:reddit-json-scraper:v1.0 (by /u/hfy_nekrocodexxx)";
// =====================================================
// Token management (Tier A + Tier B)
// =====================================================
let appTokenCache = null;
let userTokenCache = null;
function setUserToken(token, expiresIn, refreshToken) {
    userTokenCache = {
        token,
        expiresAt: Date.now() + expiresIn * 1000,
        refreshToken
    };
}
function clearUserToken() {
    userTokenCache = null;
}
function getUserToken() {
    if (userTokenCache && userTokenCache.expiresAt > Date.now() + 60000) {
        return userTokenCache.token;
    }
    return null;
}
function getUserRefreshToken() {
    return userTokenCache?.refreshToken || null;
}
// Tier A: App-Only OAuth (DFR bundled client_id)
async function getAppOnlyToken() {
    if (appTokenCache && appTokenCache.expiresAt > Date.now() + 60000) {
        return appTokenCache.token;
    }
    if (!BUNDLED_CLIENT_ID) return null;
    try {
        const deviceId = crypto__WEBPACK_IMPORTED_MODULE_0___default().randomBytes(15).toString("base64url").slice(0, 25);
        const res = await fetch("https://www.reddit.com/api/v1/access_token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: `Basic ${Buffer.from(`${BUNDLED_CLIENT_ID}:`).toString("base64")}`,
                "User-Agent": USER_AGENT_DFR
            },
            body: new URLSearchParams({
                grant_type: "https://oauth.reddit.com/grants/installed_client",
                device_id: deviceId
            }).toString(),
            signal: AbortSignal.timeout(10000),
            cache: "no-store"
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (!data.access_token) return null;
        appTokenCache = {
            token: data.access_token,
            expiresAt: Date.now() + (data.expires_in ?? 3600) * 1000
        };
        return data.access_token;
    } catch  {
        return null;
    }
}
function getMultiTokenStore() {
    if (!global.redditMultiTokens) {
        global.redditMultiTokens = new Map();
        global.redditTokenRotationIndex = 0;
    }
    return global.redditMultiTokens;
}
// Get the next token from the multi-account rotation (round-robin).
// Skips expired tokens (with 5-min buffer). Returns null if no live tokens.
async function getNextMultiToken() {
    const store = getMultiTokenStore();
    if (store.size === 0) return null;
    // Filter: must have accessToken, must NOT be cookie-based
    const allAccounts = Array.from(store.entries()).filter(([, v])=>v.accessToken
        && v.clientId !== "cookies" && v.clientId !== "cookie-injection");
    if (allAccounts.length === 0) return null;
    // Try to find a non-expired account (with 5-min buffer)
    let liveAccounts = allAccounts.filter(([, v])=>Date.now() < v.expiresAt - 5 * 60 * 1000);
    // If no live accounts, try to refresh expired ones
    if (liveAccounts.length === 0) {
        console.log("[multi-token] All tokens expired, attempting refresh...");
        for (const [id, v] of allAccounts) {
            if (v.refreshToken && v.clientId && v.clientId !== "cookies") {
                try {
                    const refreshRes = await fetch("https://www.reddit.com/api/v1/access_token", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded",
                            Authorization: `Basic ${Buffer.from(v.clientId + ":").toString("base64")}`,
                            "User-Agent": USER_AGENT_DFR
                        },
                        body: new URLSearchParams({
                            grant_type: "refresh_token",
                            refresh_token: v.refreshToken
                        }).toString(),
                        signal: AbortSignal.timeout(10000),
                        cache: "no-store"
                    });
                    if (refreshRes.ok) {
                        const refreshData = await refreshRes.json();
                        if (refreshData.access_token) {
                            v.accessToken = refreshData.access_token;
                            v.expiresAt = Date.now() + (refreshData.expires_in || 3600) * 1000;
                            store.set(id, v);
                            console.log(`[multi-token] Refreshed token for ${v.username}`);
                            liveAccounts.push([id, v]);
                        }
                    }
                } catch (e) {
                    console.log(`[multi-token] Refresh failed for ${v.username}: ${e?.message}`);
                }
            }
        }
    }
    if (liveAccounts.length === 0) return null;
    const idx = (global.redditTokenRotationIndex || 0) % liveAccounts.length;
    global.redditTokenRotationIndex = idx + 1;
    const [, tokenData] = liveAccounts[idx];
    return {
        token: tokenData.accessToken,
        username: tokenData.username
    };
}
// Get best available OAuth token.
// Priority: multi-account rotation → userTokenCache → appTokenCache.
async function getRedditOAuthToken() {
    // Tier B (multi-account rotation) — preferred, gives 600 QPM × N accounts
    const multi = await getNextMultiToken();
    if (multi) return {
        token: multi.token,
        tier: "user",
        username: multi.username
    };
    // Tier B (single user token from /api/reddit-user-token)
    const userToken = getUserToken();
    if (userToken) return {
        token: userToken,
        tier: "user"
    };
    // Tier A (anonymous app-only, 100 QPM)
    const appToken = await getAppOnlyToken();
    if (appToken) return {
        token: appToken,
        tier: "app"
    };
    return null;
}
async function fetchWithOAuth(url, options = {}) {
    const auth = await getRedditOAuthToken();
    let oauthUrl = url;
    // Convert www.reddit.com → oauth.reddit.com (only for .json/wiki/search, NOT .rss)
    if (!url.includes(".rss")) {
        oauthUrl = url.replace("://www.reddit.com", "://oauth.reddit.com").replace("://old.reddit.com", "://oauth.reddit.com").replace("://new.reddit.com", "://oauth.reddit.com").replace("://np.reddit.com", "://oauth.reddit.com");
    }
    const headers = {
        "User-Agent": USER_AGENT_DFR,
        Accept: "application/json",
        ...options.headers || {}
    };
    if (auth) headers["Authorization"] = `Bearer ${auth.token}`;
    try {
        const res = await fetch(oauthUrl, {
            method: options.method || "GET",
            headers,
            body: options.body,
            signal: AbortSignal.timeout(options.timeoutMs || 15000),
            cache: "no-store"
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text,
            tier: auth?.tier || "none",
            headers: res.headers
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed",
            tier: auth?.tier || "none",
            headers: new Headers()
        };
    }
}
// =====================================================
// Tier R: Authless fallback (RedDownloader + easy-reddit-downloader + reddit-json-scraper)
// =====================================================
// All three of these downloaders use the same approach: fetch .json endpoints
// directly with a browser-like User-Agent. No OAuth needed.
//
// We try multiple User-Agents in case Reddit blocks one:
//   1. easy-reddit-downloader UA (Chrome browser)
//   2. reddit-json-scraper UA (Python bot)
//   3. RedDownloader UA (generic browser)
const AUTHLESS_UAS = [
    USER_AGENT_EASY,
    USER_AGENT_RJS,
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
];
async function fetchWithRedDownloader(url, timeoutMs = 12000) {
    let jsonUrl = url;
    if (!jsonUrl.endsWith(".json")) {
        jsonUrl = jsonUrl.replace(/[?#].*$/, "").replace(/\/$/, "") + ".json";
    }
    // Try each User-Agent until one works
    const rdAuth = await getRedditOAuthToken();
    for (const ua of AUTHLESS_UAS){
        try {
            const rdHdrs = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                    "Accept": "application/json, text/html, */*",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "Sec-Fetch-Dest": "document",
                    "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "none",
                    "Sec-Fetch-User": "?1",
                    "Upgrade-Insecure-Requests": "1",
                    "Cache-Control": "no-cache",
                    "Connection": "close"
                };
            if (rdAuth) rdHdrs["Authorization"] = `Bearer ${rdAuth.token}`;
            try { const cookieStr = getRedditCookies(); if (cookieStr) rdHdrs["Cookie"] = cookieStr; } catch(e) {}
            const res = await fetch(jsonUrl, {
                headers: rdHdrs,
                signal: AbortSignal.timeout(timeoutMs),
                cache: "no-store"
            });
            if (res.ok) {
                const text = await res.text();
                // Verify it's actually JSON (not an error page)
                if (text.trim().startsWith("{") || text.trim().startsWith("[")) {
                    return {
                        ok: true,
                        status: res.status,
                        text
                    };
                }
            }
        } catch  {
        // try next UA
        }
    }
    return {
        ok: false,
        status: 0,
        text: "all authless UAs failed"
    };
}
// =====================================================
// Tier BROWSER: Real Headed Chrome Browser
// =====================================================
// Uses the persistent headed Chrome browser to fetch URLs.
// This makes Reddit (and other sites) see real browser traffic
// — with realistic User-Agent, cookies, JavaScript execution,
// and Cloudflare/bot-detection bypass.
// =====================================================
async function fetchWithRealBrowser(url, timeoutMs = 30000) {
    try {
        const proxyUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
        const target = proxyUrl
            ? `${proxyUrl.replace(/\/$/, "")}/api/proxy-browser?action=browser-fetch&url=${encodeURIComponent(url)}&timeout=${timeoutMs}&waitUntil=domcontentloaded`
            : `/api/proxy-browser?action=browser-fetch&url=${encodeURIComponent(url)}&timeout=${timeoutMs}&waitUntil=domcontentloaded`;
        const res = await fetch(target, {
            signal: AbortSignal.timeout(timeoutMs + 10000),
            cache: "no-store",
            headers: {
                "User-Agent": USER_AGENT_EASY,
                Accept: "application/json, text/html, */*"
            }
        });
        const data = await res.json().catch(() => null);
        if (data && typeof data.body === "string") {
            return {
                ok: data.ok === true && data.status < 400,
                status: data.status || 0,
                text: data.body
            };
        }
        const text = await res.text();
        return { ok: res.ok, status: res.status, text };
    } catch (err) {
        return { ok: false, status: 0, text: err?.message || "real browser fetch failed" };
    }
}
// =====================================================
// Tier P+: Proxy Browser fallback
// =====================================================
// Routes the fetch through our own /api/proxy-browser endpoint,
// which maintains a server-side cookie jar. Once the user has
// logged in to Reddit through the InAppBrowser, every subsequent
// request here will carry their session cookies and behave like a
// residential-IP request (no Reddit IP block).
//
// NOTE: this is a server-side fetch (called from API routes), so
// the relative URL is resolved against the app's own origin.
// =====================================================
async function fetchWithProxyBrowser(url, timeoutMs = 15000) {
    try {
        // We can't read process.env.NEXT_PUBLIC_APP_URL reliably across
        // every deployment, so fall back to a relative URL. Inside an
        // API route, fetch() with a relative URL resolves against the
        // current request origin — which is what we want.
        const proxyUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
        const target = proxyUrl ? `${proxyUrl.replace(/\/$/, "")}/api/proxy-browser?url=${encodeURIComponent(url)}` : `/api/proxy-browser?url=${encodeURIComponent(url)}`;
        const res = await fetch(target, {
            signal: AbortSignal.timeout(timeoutMs),
            cache: "no-store",
            headers: {
                "User-Agent": USER_AGENT_EASY,
                Accept: "application/json, text/html, */*"
            }
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed"
        };
    }
}
// =====================================================
// Convenience helpers (with full tier cascade)
// =====================================================
async function fetchWikiPageJson(subreddit, wikiSlug) {
    const cleanSlug = wikiSlug.replace(/^\/+|\/+$/g, "");
    const url = `https://www.reddit.com/r/${subreddit}/wiki/${cleanSlug}`;
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 15000
    });
    if (res.ok) {
        try {
            return JSON.parse(res.text);
        } catch  {}
    }
    // Tier R: RedDownloader/easy-reddit-downloader/reddit-json-scraper
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            return JSON.parse(rd.text);
        } catch  {}
    }
    // Tier BROWSER: real headed Chrome (bypasses Cloudflare/bot-detection)
    const rb = await fetchWithRealBrowser(url, 30000);
    if (rb.ok) {
        try {
            return JSON.parse(rb.text);
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            return JSON.parse(pb.text);
        } catch  {}
    }
    return null;
}
async function fetchPostJson(postIdOrUrl) {
    let url;
    if (postIdOrUrl.startsWith("http")) {
        url = postIdOrUrl.replace(/[?#].*$/, "").replace(/\/$/, "");
    } else {
        url = `https://www.reddit.com/r/HFY/comments/${postIdOrUrl}/`;
    }
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 15000
    });
    if (res.ok) {
        try {
            return JSON.parse(res.text);
        } catch  {}
    }
    // Tier R: authless
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            return JSON.parse(rd.text);
        } catch  {}
    }
    // Tier BROWSER: real headed Chrome (bypasses Cloudflare/bot-detection)
    const rb = await fetchWithRealBrowser(url, 30000);
    if (rb.ok) {
        try {
            return JSON.parse(rb.text);
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            return JSON.parse(pb.text);
        } catch  {}
    }
    return null;
}
async function searchSubreddit(subreddit, query, sort = "relevance", limit = 100) {
    // FX45 v25: JSONL PRIMARY
    try {
        const jsonlResults = await _searchJsonl(query, subreddit, limit);
        if (jsonlResults && jsonlResults.length > 0) {
            console.log("[reddit-scraper] JSONL search: " + jsonlResults.length + " results");
            return jsonlResults.map(p => ({ data: p }));
        }
    } catch (e) { console.log("[reddit-scraper] JSONL search failed: " + e.message); }
    // FALLBACK: Arctic Shift
    try {
        const arcticUrl = "https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=" + encodeURIComponent(subreddit) + "&query=" + encodeURIComponent(query) + "&limit=" + limit;
        const arcticRes = await fetch(arcticUrl, { signal: AbortSignal.timeout(15000), cache: "no-store" });
        if (arcticRes.ok) {
            const arcticData = await arcticRes.json();
            const posts = arcticData?.data ?? arcticData;
            if (Array.isArray(posts) && posts.length > 0) return posts.map(p => ({ data: { id: p.id, postId: p.id, title: p.title, author: p.author, score: p.score || 0, created_utc: p.created_utc, subreddit: p.subreddit, permalink: p.permalink } }));
        }
    } catch (e) { console.log("[reddit-scraper] Arctic Shift search failed: " + e.message); }
    // FALLBACK: Authless JSON
    const params = new URLSearchParams({ q: query, sort, restrict_sr: "1", limit: String(limit) });
    const url = "https://www.reddit.com/r/" + subreddit + "/search?" + params;
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            const data = JSON.parse(rd.text);
            return data?.data?.children ?? [];
        } catch {}
    }
    return null;
}async function fetchSubredditFeedJson(subreddit, sort = "new", limit = 100, after) {
    // FX45 v25: JSONL PRIMARY
    try {
        const jsonlFeed = await _getSubredditFeedJson(subreddit, sort, limit, after);
        if (jsonlFeed && jsonlFeed.data && jsonlFeed.data.children && jsonlFeed.data.children.length > 0) {
            console.log("[reddit-scraper] JSONL feed: " + jsonlFeed.data.children.length + " posts for r/" + subreddit);
            return jsonlFeed;
        }
    } catch (e) { console.log("[reddit-scraper] JSONL feed failed: " + e.message); }

    const params = new URLSearchParams({
        sort,
        limit: String(limit)
    });
    if (after) params.set("after", after);
    const url = `https://www.reddit.com/r/${subreddit}/${sort}?${params}`;
    const res = await fetchWithOAuth(url, {
        timeoutMs: 12000
    });
    if (res.ok) {
        try {
            const data = JSON.parse(res.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    // Tier BROWSER: real headed Chrome (bypasses Cloudflare/bot-detection)
    const rb = await fetchWithRealBrowser(url, 30000);
    if (rb.ok) {
        try {
            const data = JSON.parse(rb.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    // Tier P+: proxy browser fallback
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            const data = JSON.parse(pb.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    return null;
}
// =====================================================
// Cookie-based fetch — uses user-provided Reddit session cookies
// to bypass rate limits. Cookies are loaded from data/reddit-cookies.json
// =====================================================


let cachedCookieString = null;
let cookieCheckTime = 0;
function getRedditCookies() {
    // Re-check every 30 seconds (in case cookies were added after startup)
    if (cachedCookieString !== null && Date.now() - cookieCheckTime < 30000) {
        return cachedCookieString || null;
    }
    cachedCookieString = null;
    cookieCheckTime = Date.now();
    try {
        const cookiePaths = [
            process.env.HFY_DATA_DIR ? (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.env.HFY_DATA_DIR, "reddit-cookies.json") : (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "..", "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "..", "..", "data", "reddit-cookies.json")
        ];
        for (const cookiePath of cookiePaths){
            try {
                const content = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(cookiePath, "utf8");
                const cookies = JSON.parse(content);
                if (Array.isArray(cookies) && cookies.length > 0) {
                    cachedCookieString = cookies.filter((c)=>c.name && c.value).map((c)=>`${c.name}=${c.value}`).join("; ");
                    if (cachedCookieString) return cachedCookieString;
                }
            } catch  {}
        }
    } catch  {}
    cachedCookieString = "";
    return null;
}
async function fetchWithCookies(url, options = {}) {
    const cookieStr = getRedditCookies();
    if (!cookieStr) return {
        ok: false,
        status: 0,
        text: "No cookies"
    };
    try {
        const res = await fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Cookie": cookieStr,
                "Accept": "application/json, text/html, application/atom+xml, */*",
                "Accept-Language": "en-US,en;q=0.9",
                "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
                "Sec-Ch-Ua-Mobile": "?0",
                "Sec-Ch-Ua-Platform": '"Windows"',
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
                "Cache-Control": "no-cache",
                "Connection": "close"
            },
            signal: AbortSignal.timeout(options.timeoutMs || 12000),
            cache: "no-store"
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed"
        };
    }
}


/***/ }),

/***/ 4945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bV: () => (/* binding */ getImportedChapters),
/* harmony export */   cK: () => (/* binding */ saveImportedChapters),
/* harmony export */   rj: () => (/* binding */ parseRedditWikiForChapters),
/* harmony export */   sortChaptersByNumber: () => (/* binding */ sortChaptersByNumber),
/* harmony export */   cache: () => (/* binding */ userChaptersCache),
/* harmony export */   clearCache: () => (/* binding */ clearUserChaptersCache)
/* harmony export */ });
/* unused harmony export extractChapterNumber */
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
// HFY NEKROCODEXXX — User-Imported Chapter Cache
// =====================================================
// Stores chapter lists that the USER imports from their
// browser (which isn't IP-blocked by Reddit) via the
// bookmarklet or paste-HTML fallback.
//
// Storage strategy:
//   - In-memory Map for fast reads
//   - Filesystem persistence at /home/z/my-project/data/user-chapters/
//     so imports survive server restarts
//
// Endpoints use this:
//   POST /api/series/[slug]/chapters — writes
//   GET  /api/series/[slug]/chapters — reads


// CRITICAL: Use multiple path resolution strategies to ensure chapters persist
// across restarts. process.cwd() can change on Android, so we also try
// __dirname (relative to this file in the standalone build) and a fixed path.
const POSSIBLE_DATA_DIRS = [
    // Priority 1: HFY_DATA_DIR (Android persistent storage — getFilesDir/hfy-data)
    process.env.HFY_DATA_DIR ? path__WEBPACK_IMPORTED_MODULE_1___default().join(process.env.HFY_DATA_DIR, "user-chapters") : path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "..", "data", "user-chapters")
];
// Use the first directory that exists and has data, or create the first one
let DATA_DIR = POSSIBLE_DATA_DIRS[0];
for (const dir of POSSIBLE_DATA_DIRS){
    try {
        const files = (__webpack_require__(9021).readdirSync)(dir);
        if (files.length > 0) {
            DATA_DIR = dir;
            break;
        }
    } catch  {
    // Directory doesn't exist, try next
    }
}
// In-memory cache
const userChaptersCache = new Map();
// Backwards-compat alias — older code references `cache` directly
const cache = userChaptersCache;
// Clear the entire in-memory cache (used by /api/purge-cache)
function clearUserChaptersCache() {
    userChaptersCache.clear();
}
// Ensure data dir exists
async function ensureDir() {
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.mkdir(DATA_DIR, {
            recursive: true
        });
    } catch  {
    // ignore
    }
}
function filePath(slug) {
    // Sanitize slug — only allow alphanumeric + underscore + hyphen
    const safe = slug.replace(/[^a-zA-Z0-9_-]/g, "_");
    return path__WEBPACK_IMPORTED_MODULE_1___default().join(DATA_DIR, `${safe}.json`);
}
/** Get imported chapters for a series slug */ async function getImportedChapters(slug) {
    // Check memory first, but verify against filesystem mtime
    // (the auto-discover route may have updated the file in a different
    // Next.js worker process with its own in-memory cache)
    const fp = filePath(slug);
    try {
        const stat = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.stat(fp);
        const cached = cache.get(slug);
        if (cached && cached.importedAt >= stat.mtimeMs) {
            // Cache is fresh
            return cached;
        }
        // Cache is stale or missing — reload from filesystem
        const content = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(fp, "utf8");
        let parsed;
        try {
            parsed = JSON.parse(content);
        } catch (parseErr) {
            // Corrupted JSON file — delete it and return null
            console.warn(`[user-chapters] Corrupted file for ${slug}, deleting:`, parseErr);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Validate: ensure chapters array exists and isn't excessively large
        if (!parsed.chapters || !Array.isArray(parsed.chapters)) {
            console.warn(`[user-chapters] Invalid chapters for ${slug}, deleting`);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Cap at 50000 chapters to prevent OOM (was 2000 — too low, caused data loss)
        if (parsed.chapters.length > 50000) {
            console.warn(`[user-chapters] Truncating ${parsed.chapters.length} chapters to 50000 for ${slug}`);
            parsed.chapters = parsed.chapters.slice(0, 50000);
        }
        cache.set(slug, parsed);
        return parsed;
    } catch  {
        // File doesn't exist
        if (cache.has(slug)) return cache.get(slug);
        return null;
    }
}
/** Save imported chapters for a series slug */ async function saveImportedChapters(slug, chapters, options = {}) {
    await ensureDir();
    // DEDUPLICATION: remove duplicate chapters by postId AND by normalized URL.
    // This is critical because parallel stages (RSS crawler, Wayback crawler,
    // JSON crawler, hfy.foundation) may all discover the same chapter.
    // We normalize URLs to catch duplicates that differ only in trailing
    // slashes, www prefix, or http vs https.
    const seenPostIds = new Set();
    const seenUrlKeys = new Set();
    const deduped = [];
    for (const c of chapters){
        if (!c.postId) continue;
        // Normalize URL for dedup (strip protocol/www/trailing slash/query)
        const urlKey = normalizeUrlForDedup(c.url);
        if (seenPostIds.has(c.postId) || seenUrlKeys.has(urlKey)) {
            continue; // skip duplicate
        }
        seenPostIds.add(c.postId);
        seenUrlKeys.add(urlKey);
        deduped.push(c);
    }
    // Merge processedPostIds with any existing ones (for resume-crawl)
    const existing = cache.get(slug);
    const processedSet = new Set([
        ...existing?.processedPostIds ?? [],
        ...options.processedPostIds ?? []
    ]);
    const list = {
        slug,
        chapters: deduped,
        // Preserve existing synopsis if the caller doesn't provide one.
        // This prevents reparse/fetch-missing/add-chapter from wiping the
        // synopsis that was previously saved.
        synopsis: options.synopsis !== undefined ? options.synopsis : existing?.synopsis,
        importedAt: Date.now(),
        source: options.source || "manual",
        processedPostIds: Array.from(processedSet)
    };
    cache.set(slug, list);
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.writeFile(filePath(slug), JSON.stringify(list, null, 2), "utf8");
    } catch (err) {
        console.warn(`[user-chapters] Failed to persist ${slug}:`, err);
    }
    return list;
}
/**
 * Normalize a Reddit URL for deduplication purposes.
 * Strips: protocol, www/old/new prefix, trailing slash, query params, fragments.
 * "https://www.reddit.com/r/HFY/comments/abc123/chapter_1/" → "reddit.com/r/HFY/comments/abc123"
 */ /**
 * Extract a chapter number from a title for sorting.
 * Handles: "Chapter 42", "Part 3", "Episode 7", "Interlude 4", "Chapter 7.1"
 * Returns 999 for non-chapter posts (sorted to end).
 */ function extractChapterNumber(title) {
    // Try "Chapter N" or "Chapter N.M"
    let m = title.match(/[Cc]hapter\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Try "Part N"
    m = title.match(/[Pp]art\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Try "Episode N"
    m = title.match(/[Ee]pisode\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Interludes
    if (/interlude/i.test(title)) {
        m = title.match(/[Ii]nterlude\s+(\d+)/);
        if (m) return parseFloat(m[1]) + 0.5;
        return 999; // unnamed interlude
    }
    return 999; // unknown — sort to end
}
/**
 * CRITICAL: Do NOT sort chapters by extracted number.
 * The source CSV/JSON files already have chapters in the correct
 * chronological order. Sorting BREAKS the order because titles without
 * a number get parsed as 999 and pushed to the end.
 *
 * This function is a NO-OP — returns the array unchanged.
 */ function sortChaptersByNumber(chapters) {
    return chapters;
}
function normalizeUrlForDedup(url) {
    return url.replace(/^https?:\/\//, "").replace(/^(www\.|old\.|new\.|np\.)?reddit\.com/i, "reddit.com").replace(/[?#].*$/, "").replace(/\/$/, "").toLowerCase();
}
/** Parse a Reddit wiki page HTML (or markdown) for chapter links */ function parseRedditWikiForChapters(html) {
    const chapters = [];
    const seen = new Set();
    // Helper: strip Wayback Machine wrapper from URLs
    // http://web.archive.org/web/20250801/https://www.reddit.com/... → https://www.reddit.com/...
    function stripWayback(url) {
        const m = url.match(/https?:\/\/web\.archive\.org\/web\/\d+\/(https?:\/\/.+)/i);
        return m ? m[1] : url;
    }
    // Strategy 1: HTML anchor tags
    const aRe = /<a[^>]+href=["'](https?:\/\/[^"']*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^"']*)["'][^>]*>([^<]+)<\/a>/gi;
    let m;
    while((m = aRe.exec(html)) !== null){
        const url = stripWayback(m[1].trim());
        const title = m[2].trim() || "Chapter";
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                chapters.push({
                    title,
                    url,
                    postId
                });
            }
        }
    }
    // Strategy 2: Markdown links [text](url)
    const mdRe = /\[([^\]]+)\]\((https?:\/\/[^)]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^)]*)\)/gi;
    while((m = mdRe.exec(html)) !== null){
        const title = m[1].trim();
        const url = stripWayback(m[2].trim());
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                chapters.push({
                    title,
                    url,
                    postId
                });
            }
        }
    }
    // Strategy 3: Bare URLs — try to extract a title from surrounding text
    const bareRe = /(https?:\/\/[^\s"'<\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s"'<\]]*)/gi;
    while((m = bareRe.exec(html)) !== null){
        const url = stripWayback(m[1].trim());
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                // Try to grab surrounding text as the title.
                const start = Math.max(0, m.index - 80);
                const end = Math.min(html.length, m.index + url.length + 80);
                const context = html.slice(start, end).replace(m[1], " ").trim();
                const beforeMatch = context.match(/([^\n•\-*|]{3,80})\s*(?:—|–|-|:|\s)\s*$/);
                const afterMatch = context.match(/^\s*(?:—|–|-|:|\s)\s*([^\n•\-*|]{3,80})/);
                let title = "Chapter";
                if (beforeMatch && beforeMatch[1].trim().length > 2) {
                    title = beforeMatch[1].trim();
                } else if (afterMatch && afterMatch[1].trim().length > 2) {
                    title = afterMatch[1].trim();
                } else {
                    const chapRe = /Chapter\s+\d+[:\s-]*[^\n]{0,80}/i;
                    const chapM = context.match(chapRe);
                    if (chapM) title = chapM[0].trim();
                }
                if (title === "Chapter") {
                    const slugM = url.match(/\/comments\/[a-z0-9]+\/([^/?]+)\//i);
                    if (slugM) {
                        title = slugM[1].replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
                    }
                }
                chapters.push({
                    title: title.slice(0, 200).replace(/[—–\-:]\s*$/, "").trim() || "Chapter",
                    url,
                    postId
                });
            }
        }
    }
    // Extract synopsis — first paragraph of meaningful text
    let synopsis = "";
    // Strip HTML tags to get plain text
    const text = html.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, " ").trim();
    const sentences = text.split(/(?<=[.!?])\s+/);
    for (const s of sentences){
        if (s.length > 60 && s.length < 400 && !s.includes("http") && !s.includes("reddit.com")) {
            synopsis = s;
            break;
        }
    }
    return {
        chapters,
        synopsis
    };
}


/***/ })

};
;