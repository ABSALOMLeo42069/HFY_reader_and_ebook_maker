// HFY NEKROCODEXXX — JSONL Batch Handler
// Runs on port 3001 alongside the main server (port 3000)

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3001;
const DATA_DIR = process.env.HFY_DATA_DIR || path.join(process.cwd(), 'data');

function getCacheDir() { return path.join(DATA_DIR, 'chapter-cache'); }
function getStoreDir() { return path.join(DATA_DIR, 'app-store'); }

function ensureDirs() {
    try { fs.mkdirSync(getCacheDir(), { recursive: true }); } catch {}
    try { fs.mkdirSync(getStoreDir(), { recursive: true }); } catch {}
}
ensureDirs();

const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

    const url = new URL(req.url, `http://localhost:${PORT}`);
    const pathname = url.pathname;

    // Serve a JSONL file by name (for testing)
    if (req.method === 'GET' && pathname.startsWith('/file/')) {
        const fileName = pathname.replace('/file/', '');
        const filePath = path.join(process.cwd(), 'public', fileName);
        try {
            const stat = fs.statSync(filePath);
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': stat.size });
            fs.createReadStream(filePath).pipe(res);
        } catch (e) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'File not found: ' + fileName }));
        }
        return;
    }

    if (req.method === 'POST' && pathname === '/batch-cache') {
        const chunks = [];
        req.on('data', chunk => { chunks.push(chunk); });
        req.on('end', () => {
            try {
                const body = Buffer.concat(chunks).toString('utf8');
                const data = JSON.parse(body);
                const chapters = data.chapters || [];
                let saved = 0;
                for (const ch of chapters) {
                    if (!ch.postId || !ch.selftext) continue;
                    const safePostId = String(ch.postId).replace(/[^a-zA-Z0-9_-]/g, '_');
                    const cacheFile = path.join(getCacheDir(), `${safePostId}.json`);
                    try {
                        fs.writeFileSync(cacheFile, JSON.stringify({
                            postId: ch.postId, title: ch.title || '', author: ch.author || '',
                            selftext: ch.selftext, selftextHtml: ch.selftextHtml || '',
                            createdUtc: ch.createdUtc || 0, score: ch.score || 0,
                            url: ch.url || '', permalink: ch.permalink || '',
                            numComments: ch.numComments || 0, subreddit: ch.subreddit || 'HFY',
                            cachedAt: Date.now()
                        }));
                        saved++;
                    } catch {}
                }
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true, saved, total: chapters.length }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: e.message }));
            }
        });
        return;
    }

    if (req.method === 'POST' && pathname === '/batch-scores') {
        const chunks = [];
        req.on('data', chunk => { chunks.push(chunk); });
        req.on('end', () => {
            try {
                const body = Buffer.concat(chunks).toString('utf8');
                const data = JSON.parse(body);
                const { seriesId, scores } = data;
                if (!seriesId || !scores) {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: false, error: 'Missing seriesId or scores' }));
                    return;
                }
                const scoresFile = path.join(getStoreDir(), `hfy-scores-${seriesId}.json`);
                try { fs.writeFileSync(scoresFile, JSON.stringify(scores)); } catch {}
                const chapterScores = {};
                for (const [pid, score] of Object.entries(scores)) {
                    chapterScores[pid] = { score, fetched: true };
                }
                const chapterScoresFile = path.join(getStoreDir(), `hfy-chapter-scores-${seriesId}.json`);
                try { fs.writeFileSync(chapterScoresFile, JSON.stringify(chapterScores)); } catch {}
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true, count: Object.keys(scores).length }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: e.message }));
            }
        });
        return;
    }

    // PART 9: Read store files (for audit)
    if (req.method === 'GET' && pathname.startsWith('/store/')) {
        const fileName = pathname.replace('/store/', '');
        const filePath = path.join(getStoreDir(), fileName);
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(content);
        } catch (e) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: 'File not found: ' + fileName }));
        }
        return;
    }

    if (req.method === 'GET' && pathname === '/stats') {
        try {
            const cacheFiles = fs.readdirSync(getCacheDir()).filter(f => f.endsWith('.json'));
            const storeFiles = fs.readdirSync(getStoreDir()).filter(f => f.endsWith('.json'));
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true, chapterCacheCount: cacheFiles.length, storeCount: storeFiles.length, dataDir: DATA_DIR }));
        } catch (e) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: e.message }));
        }
        return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: false, error: 'Not found' }));
});

server.listen(PORT, '127.0.0.1', () => {
    console.log(`[jsonl-handler] Running on port ${PORT}`);
});

module.exports = { server };
