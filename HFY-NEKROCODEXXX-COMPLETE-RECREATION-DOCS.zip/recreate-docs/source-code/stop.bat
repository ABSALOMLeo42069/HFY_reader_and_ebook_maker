@echo off
setlocal
set "PORT=3000"
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (taskkill /F /PID %%a >nul 2>&1)
taskkill /FI "WINDOWTITLE eq HFY-NEKRO-Server*" /F >nul 2>&1
for /f "tokens=2" %%i in ('tasklist /FI "IMAGENAME eq node.exe" /FO LIST 2^>nul ^| findstr "PID:"') do (taskkill /F /PID %%i >nul 2>&1)
echo Stopped.
timeout /t 2 /nobreak >nul
exit /b 0
