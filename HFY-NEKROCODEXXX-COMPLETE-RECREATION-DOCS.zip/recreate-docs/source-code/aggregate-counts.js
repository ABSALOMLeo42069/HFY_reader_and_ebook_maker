// Aggregates downloaded + chapter counts and stores them via /api/store
// Called on server startup + periodically
//
// FIX: Use http.request instead of fetch() — fetch() may not be available
// in all Node.js environments (especially Android's bundled Node runtime),
// and unhandled fetch rejections can crash the server.
// Also use process.env.PORT instead of hardcoded 3000.

const fs = require('fs');
const path = require('path');
const http = require('http');

function getDataDir() {
    if (process.env.HFY_DATA_DIR) return process.env.HFY_DATA_DIR;
    return path.join(process.cwd(), 'data');
}

function httpPostJSON(port, keyPath, data) {
    return new Promise((resolve) => {
        const body = JSON.stringify(data);
        const req = http.request({
            hostname: '127.0.0.1',
            port: port,
            path: `/api/store/${keyPath}`,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(body)
            },
            timeout: 10000
        }, (res) => {
            res.on('data', () => {});
            res.on('end', () => resolve(true));
        });
        req.on('error', () => resolve(false));
        req.on('timeout', () => { try { req.destroy(); } catch {}; resolve(false); });
        req.write(body);
        req.end();
    });
}

async function aggregateAndStore() {
    try {
        const dataDir = getDataDir();
        const appStoreDir = path.join(dataDir, 'app-store');
        const userChaptersDir = path.join(dataDir, 'user-chapters');
        const port = parseInt(process.env.PORT, 10) || 3000;

        // 1. Aggregate downloaded counts from app-store/hfy-downloaded-*.json
        const downloadedCounts = {};
        try {
            const files = await fs.promises.readdir(appStoreDir);
            for (const f of files) {
                if (/^hfy-downloaded-.+\.json$/i.test(f)) {
                    try {
                        const content = await fs.promises.readFile(path.join(appStoreDir, f), 'utf8');
                        const parsed = JSON.parse(content);
                        if (Array.isArray(parsed)) {
                            const seriesId = f.replace(/^hfy-downloaded-/i, '').replace(/\.json$/i, '');
                            downloadedCounts[seriesId] = parsed.length;
                        }
                    } catch {}
                }
            }
        } catch {}

        // 2. Aggregate chapter counts from user-chapters/*.json
        const chapterCounts = {};
        try {
            const files = await fs.promises.readdir(userChaptersDir);
            for (const f of files) {
                if (/\.json$/i.test(f)) {
                    try {
                        const content = await fs.promises.readFile(path.join(userChaptersDir, f), 'utf8');
                        const parsed = JSON.parse(content);
                        if (parsed && Array.isArray(parsed.chapters)) {
                            const seriesId = f.replace(/\.json$/i, '');
                            chapterCounts[seriesId] = parsed.chapters.length;
                        }
                    } catch {}
                }
            }
        } catch {}

        // 3. Store via /api/store using http.request (not fetch)
        await httpPostJSON(port, 'hfy-downloaded-counts', downloadedCounts);
        await httpPostJSON(port, 'hfy-chapter-counts', chapterCounts);

        console.log(`[aggregate] Stored ${Object.keys(downloadedCounts).length} downloaded counts, ${Object.keys(chapterCounts).length} chapter counts`);
    } catch (err) {
        console.error('[aggregate] Error:', err.message);
    }
}

// Run on startup (after 5s delay to let server boot) + every 60s
setTimeout(aggregateAndStore, 5000);
setInterval(aggregateAndStore, 60000);

module.exports = { aggregateAndStore };
