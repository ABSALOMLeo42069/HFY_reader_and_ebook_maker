const path = require('path')

const dir = path.join(__dirname)

process.env.NODE_ENV = 'production'
process.chdir(__dirname)

const currentPort = parseInt(process.env.PORT, 10) || 3000
const hostname = process.env.HOSTNAME || '0.0.0.0'

let keepAliveTimeout = parseInt(process.env.KEEP_ALIVE_TIMEOUT, 10)
const nextConfig = {"env":{},"typescript":{"ignoreBuildErrors":true},"typedRoutes":false,"distDir":"./.next","cleanDistDir":true,"assetPrefix":"","cacheMaxMemorySize":52428800,"configOrigin":"next.config.ts","useFileSystemPublicRoutes":true,"generateEtags":true,"pageExtensions":["tsx","ts","jsx","js"],"poweredByHeader":true,"compress":true,"images":{"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","loaderFile":"","domains":[],"disableStaticImages":false,"minimumCacheTTL":14400,"formats":["image/webp"],"maximumRedirects":3,"maximumResponseBody":50000000,"dangerouslyAllowLocalIP":false,"dangerouslyAllowSVG":false,"contentSecurityPolicy":"script-src 'none'; frame-src 'none'; sandbox;","contentDispositionType":"attachment","localPatterns":[{"pathname":"**","search":""}],"remotePatterns":[],"qualities":[75],"unoptimized":true,"customCacheHandler":false},"devIndicators":{"position":"bottom-left"},"onDemandEntries":{"maxInactiveAge":60000,"pagesBufferLength":5},"basePath":"","sassOptions":{},"trailingSlash":false,"i18n":null,"productionBrowserSourceMaps":false,"excludeDefaultMomentLocales":true,"reactProductionProfiling":false,"reactStrictMode":false,"reactMaxHeadersLength":6000,"httpAgentOptions":{"keepAlive":true},"logging":{"serverFunctions":true,"browserToTerminal":"warn"},"compiler":{},"expireTime":31536000,"staticPageGenerationTimeout":60,"output":"standalone","modularizeImports":{"@mui/icons-material":{"transform":"@mui/icons-material/{{member}}"},"lodash":{"transform":"lodash/{{member}}"}},"outputFileTracingRoot":"/home/z/my-project/build/v230-apk","cacheComponents":false,"cacheLife":{"default":{"stale":300,"revalidate":900,"expire":4294967294},"seconds":{"stale":30,"revalidate":1,"expire":60},"minutes":{"stale":300,"revalidate":60,"expire":3600},"hours":{"stale":300,"revalidate":3600,"expire":86400},"days":{"stale":300,"revalidate":86400,"expire":604800},"weeks":{"stale":300,"revalidate":604800,"expire":2592000},"max":{"stale":300,"revalidate":2592000,"expire":31536000}},"cacheHandlers":{},"experimental":{"appNewScrollHandler":false,"useSkewCookie":false,"cssChunking":true,"multiZoneDraftMode":false,"appNavFailHandling":false,"prerenderEarlyExit":true,"serverMinification":false,"linkNoTouchStart":false,"caseSensitiveRoutes":false,"cachedNavigations":false,"partialFallbacks":false,"dynamicOnHover":false,"varyParams":false,"prefetchInlining":false,"preloadEntriesOnStart":true,"clientRouterFilter":true,"clientRouterFilterRedirects":false,"fetchCacheKeyPrefix":"","proxyPrefetch":"flexible","optimisticClientCache":true,"manualClientBasePath":false,"cpus":1,"memoryBasedWorkersCount":false,"imgOptConcurrency":null,"imgOptTimeoutInSeconds":7,"imgOptMaxInputPixels":268402689,"imgOptSequentialRead":null,"imgOptSkipMetadata":null,"isrFlushToDisk":true,"workerThreads":false,"optimizeCss":false,"nextScriptWorkers":false,"scrollRestoration":false,"externalDir":false,"disableOptimizedLoading":false,"gzipSize":true,"craCompat":false,"esmExternals":true,"fullySpecified":false,"swcTraceProfiling":false,"forceSwcTransforms":false,"largePageDataBytes":128000,"typedEnv":false,"parallelServerCompiles":false,"parallelServerBuildTraces":false,"ppr":false,"authInterrupts":false,"webpackMemoryOptimizations":false,"optimizeServerReact":true,"strictRouteTypes":false,"viewTransition":false,"removeUncaughtErrorAndRejectionListeners":false,"validateRSCRequestHeaders":false,"staleTimes":{"dynamic":0,"static":300},"reactDebugChannel":true,"serverComponentsHmrCache":true,"staticGenerationMaxConcurrency":8,"staticGenerationMinPagesPerWorker":25,"transitionIndicator":false,"gestureTransition":false,"inlineCss":false,"useCache":false,"globalNotFound":false,"browserDebugInfoInTerminal":"warn","lockDistDir":true,"proxyClientMaxBodySize":209715200,"hideLogsAfterAbort":false,"mcpServer":true,"turbopackFileSystemCacheForDev":true,"turbopackFileSystemCacheForBuild":false,"turbopackInferModuleSideEffects":true,"turbopackPluginRuntimeStrategy":"childProcesses","optimizePackageImports":["lucide-react","date-fns","lodash-es","ramda","antd","react-bootstrap","ahooks","@ant-design/icons","@headlessui/react","@headlessui-float/react","@heroicons/react/20/solid","@heroicons/react/24/solid","@heroicons/react/24/outline","@visx/visx","@tremor/react","rxjs","@mui/material","@mui/icons-material","recharts","react-use","effect","@effect/schema","@effect/platform","@effect/platform-node","@effect/platform-browser","@effect/platform-bun","@effect/sql","@effect/sql-mssql","@effect/sql-mysql2","@effect/sql-pg","@effect/sql-sqlite-node","@effect/sql-sqlite-bun","@effect/sql-sqlite-wasm","@effect/sql-sqlite-react-native","@effect/rpc","@effect/rpc-http","@effect/typeclass","@effect/experimental","@effect/opentelemetry","@material-ui/core","@material-ui/icons","@tabler/icons-react","mui-core","react-icons/ai","react-icons/bi","react-icons/bs","react-icons/cg","react-icons/ci","react-icons/di","react-icons/fa","react-icons/fa6","react-icons/fc","react-icons/fi","react-icons/gi","react-icons/go","react-icons/gr","react-icons/hi","react-icons/hi2","react-icons/im","react-icons/io","react-icons/io5","react-icons/lia","react-icons/lib","react-icons/lu","react-icons/md","react-icons/pi","react-icons/ri","react-icons/rx","react-icons/si","react-icons/sl","react-icons/tb","react-icons/tfi","react-icons/ti","react-icons/vsc","react-icons/wi"],"trustHostHeader":false,"isExperimentalCompile":false},"htmlLimitedBots":"[\\w-]+-Google|Google-[\\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight","bundlePagesRouterDependencies":false,"configFileName":"next.config.ts","swcMinify":false,"turbopack":{"root":"/home/z/my-project/build/v230-apk"},"distDirRoot":".next"}

process.env.__NEXT_PRIVATE_STANDALONE_CONFIG = JSON.stringify(nextConfig)

require('next')
const { startServer } = require('next/dist/server/lib/start-server')

if (
  Number.isNaN(keepAliveTimeout) ||
  !Number.isFinite(keepAliveTimeout) ||
  keepAliveTimeout < 0
) {
  keepAliveTimeout = undefined
}

startServer({
  dir,
  isDev: false,
  config: nextConfig,
  hostname,
  port: currentPort,
  allowRetry: false,
  keepAliveTimeout,
}).then(() => {
  // Start the aggregation script after server is up
  try { require('./aggregate-counts.js'); } catch (e) { console.error('[aggregate] Failed:', e.message); }
  // Start JSONL batch handler (port 3001)
  try { require('./jsonl-handler.js'); } catch (e) { console.error('[jsonl-handler] Failed:', e.message); }
}).catch((err) => {
  console.error(err);
  process.exit(1);
});
// ========== 250KBPS KEEPALIVE ==========
// FIX: Use http.request with setTimeout loop (not setInterval) to avoid
// memory buildup. Each request is fully cleaned up before the next one.
// Also added memory guard — if memory usage exceeds 80% of the cgroup
// limit, skip keepalive temporarily.
const KEEPALIVE_BYTES = 256000;
const KEEPALIVE_INTERVAL = 1000;
const KEEPALIVE_DOWNLOAD_URLS = [
    'https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js',
    'https://unpkg.com/react@18/umd/react.production.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js',
    'https://cdn.jsdelivr.net/npm/lodash@4/lodash.min.js',
    'https://unpkg.com/lodash@4/lodash.min.js'
];
const KEEPALIVE_UPLOAD_URLS = [
    'https://httpbin.org/post',
    'https://postman-echo.com/post',
    'https://httpbin.org/anything',
    'https://pie.dev/post'
];
let keepaliveDownloadIdx = 0;
let keepaliveUploadIdx = 0;
let keepaliveRunning = false;
function startKeepalive() {
    if (keepaliveRunning) return;
    keepaliveRunning = true;
    const https = require('https');
    const http = require('http');

    function checkMemory() {
        try {
            const mem = process.memoryUsage();
            const rssMB = mem.rss / 1024 / 1024;
            // Skip if RSS exceeds 1.5GB (leave room for the server + Chrome)
            if (rssMB > 1536) return false;
        } catch {}
        return true;
    }

    function downloadKeepalive() {
        if (!checkMemory()) return;
        const url = KEEPALIVE_DOWNLOAD_URLS[keepaliveDownloadIdx % KEEPALIVE_DOWNLOAD_URLS.length];
        keepaliveDownloadIdx++;
        try {
            const lib = url.startsWith('https') ? https : http;
            const req = lib.get(url, { timeout: 5000 }, (res) => {
                res.on('data', () => {});
                res.on('error', () => {});
            });
            req.on('error', () => {});
            req.on('timeout', () => { try { req.destroy(); } catch {} });
        } catch {}
    }
    function uploadKeepalive() {
        if (!checkMemory()) return;
        const url = KEEPALIVE_UPLOAD_URLS[keepaliveUploadIdx % KEEPALIVE_UPLOAD_URLS.length];
        keepaliveUploadIdx++;
        try {
            const data = Buffer.alloc(KEEPALIVE_BYTES, Math.floor(Math.random() * 256));
            const parsed = new URL(url);
            const lib = parsed.protocol === 'https:' ? https : http;
            const req = lib.request({
                hostname: parsed.hostname,
                port: parsed.port,
                path: parsed.pathname,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/octet-stream',
                    'Content-Length': data.length
                },
                timeout: 5000
            }, (res) => {
                res.on('data', () => {});
                res.on('error', () => {});
            });
            req.on('error', () => {});
            req.on('timeout', () => { try { req.destroy(); } catch {} });
            req.write(data);
            req.end();
        } catch {}
    }

    // Use setTimeout loop instead of setInterval — each tick waits for
    // the previous to complete, preventing request buildup
    function keepaliveLoop() {
        try { downloadKeepalive(); } catch {}
        try { uploadKeepalive(); } catch {}
        setTimeout(keepaliveLoop, KEEPALIVE_INTERVAL);
    }
    keepaliveLoop();
    console.log('[keepalive] 250KB/s download + 250KB/s upload started (http.request + memory guard)');
}
// Global error handlers — prevent unhandled rejections from crashing the server
process.on('unhandledRejection', (reason, promise) => {
    console.error('[unhandledRejection]', reason?.message || reason);
});
process.on('uncaughtException', (err) => {
    console.error('[uncaughtException]', err?.message || err);
});
// DISABLED for local runtime verification — keepalive was causing crashes
// startKeepalive();
// ========== END KEEPALIVE ==========
