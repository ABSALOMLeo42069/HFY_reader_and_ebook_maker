// HFY NEKROCODEXXX Service Worker
// Enables PWA install + offline caching

const CACHE_NAME = "hfy-nekrocodexxx-v1";
const STATIC_ASSETS = ["/", "/manifest.json", "/icon-192.png", "/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Only cache GET requests
  if (event.request.method !== "GET") return;

  // Don't cache API requests (they need fresh data)
  if (event.request.url.includes("/api/")) return;
  if (event.request.url.includes("/socket.io/")) return;

  // Cache-first for static assets, network-first for pages
  if (event.request.destination === "image" || event.request.url.includes("/_next/static/")) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        return cached || fetch(event.request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return res;
        });
      })
    );
  } else {
    // Network-first for pages (with cache fallback)
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          if (res.ok && event.request.destination === "document") {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return res;
        })
        .catch(() => caches.match(event.request).then((cached) => cached || caches.match("/")))
    );
  }
});
