HFY NEKROCODEXXX — Windows Standalone App
==========================================

WHAT THIS IS:
A Reddit r/HFY (and other subreddit) novel/story reader with offline JSONL archive support.
Includes all 14 parts of the JSONL reader integration:
  - Folder access for JSONL files
  - Indexing of 200K+ posts
  - Chapter discovery (follows Next/Previous links)
  - Custom series creation
  - Download/merge to HTML
  - Persistence audit and repair
  - Performance optimization (trigram search)
  - File replacement at runtime
  - Cross-subreddit search
  - RSS feed engine for new posts

HOW TO USE:
1. Download JSONL dump files from:
   https://gofile.io/d/PZH1xo
   (Files: r_hfy_posts.jsonl, r_natureofpredators_posts.jsonl,
    r_sexyspacebabes_posts.jsonl, r_TheCryopodToHell_posts.jsonl)

2. Put the JSONL files in a folder on your computer (e.g., C:\HFY-Data\)

3. Double-click start.bat

4. The app will open in Chrome/Edge automatically

5. Go to Settings → SUBREDDIT JSONL DATA → SELECT FOLDER
   Select the folder where you put the JSONL files

6. Wait for indexing (162K posts takes ~30 seconds)

7. Use the Archive tab to browse posts, Discover tab for auto-discovered series

SYSTEM REQUIREMENTS:
  - Windows 10/11 (64-bit)
  - 2GB RAM (4GB recommended for all 4 JSONL files)
  - 5GB disk space (for app + JSONL files)
  - Chrome or Edge browser

INCLUDED:
  - node/node.exe — Node.js runtime (no installation needed)
  - server/ — The Next.js app (pre-built)
  - start.bat — Starts the server and opens the browser
  - stop.bat — Stops the server

TROUBLESHOOTING:
  - If the app doesn't open: check server.log for errors
  - If indexing is slow: use SSD storage for JSONL files
  - If port 3000 is in use: edit start.bat and change PORT=3000 to another port

VERSION: FX45 v31 + Parts 1-14 JSONL Integration (Audited)
DATE: 2026-07-30
