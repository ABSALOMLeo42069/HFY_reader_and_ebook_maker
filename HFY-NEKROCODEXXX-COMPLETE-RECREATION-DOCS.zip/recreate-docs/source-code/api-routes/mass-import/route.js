(() => {
var exports = {};
exports.id = 4924;
exports.ids = [4924];
exports.modules = {

/***/ 261:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 1934:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/mass-import/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST),
  dynamic: () => (dynamic),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: ./src/lib/hfy-data.ts
var hfy_data = __webpack_require__(7101);
// EXTERNAL MODULE: ./src/lib/user-chapters.ts
var user_chapters = __webpack_require__(4945);
;// ./src/app/api/mass-import/route.ts
// POST /api/mass-import
// Accepts a text body containing multiple Reddit URLs (one per line, or CSV format).
// Automatically sorts URLs into series based on the wiki series list.
//
// Body: { text: string } where text contains URLs like:
//   https://www.reddit.com/r/HFY/comments/abc123/series_name_chapter_1/
//   https://www.reddit.com/r/HFY/comments/def456/series_name_chapter_2/
//   ...
//
// Returns: { ok, seriesCount, totalChapters, series: [{ slug, title, chaptersAdded }] }



const runtime = "nodejs";
const dynamic = "force-dynamic";
const REDDIT_URL_RE = /https?:\/\/[^\s"'<>,]+reddit\.com\/r\/\w+\/comments\/([a-z0-9]+)\/([a-z0-9_]+)/gi;
async function POST(req) {
    let body;
    try {
        body = await req.json();
    } catch  {
        return server.NextResponse.json({
            ok: false,
            error: "Invalid JSON"
        }, {
            status: 400
        });
    }
    const text = body?.text || "";
    if (!text || text.trim().length === 0) {
        return server.NextResponse.json({
            ok: false,
            error: "No text provided"
        }, {
            status: 400
        });
    }
    // Extract all Reddit URLs with post IDs and slugs
    const matches = [];
    let m;
    while((m = REDDIT_URL_RE.exec(text)) !== null){
        matches.push({
            postId: m[1],
            slug: m[2],
            url: m[0].replace(/[?#].*$/, "").replace(/\/$/, "")
        });
    }
    if (matches.length === 0) {
        return server.NextResponse.json({
            ok: false,
            error: "No Reddit chapter URLs found in the text"
        }, {
            status: 400
        });
    }
    // Build a lookup of series by ID (lowercase) and title (lowercase)
    const seriesById = new Map();
    const seriesByTitle = new Map();
    for (const s of hfy_data/* REAL_SERIES */.jo){
        seriesById.set(s.id.toLowerCase(), s);
        seriesByTitle.set(s.title.toLowerCase(), s);
    }
    // Group URLs by series
    const seriesChapters = new Map();
    const seriesInfo = new Map();
    for (const match of matches){
        // Try to match the URL slug to a series
        // The slug is like "out_of_cruel_space_part_1" or "99_9_of_the_universe_chapter_2"
        // We try to find a series whose ID is a prefix of the slug
        let matchedSeries = null;
        // Strategy 1: Check if any series ID is a prefix of the slug
        for (const [sid, s] of seriesById){
            if (match.slug.startsWith(sid) || match.slug.startsWith(sid.replace(/_/g, ""))) {
                matchedSeries = s;
                break;
            }
        }
        // Strategy 2: Check if the slug contains a series title (with underscores)
        if (!matchedSeries) {
            for (const [stitle, s] of seriesByTitle){
                const titleSlug = stitle.replace(/[^a-z0-9]/gi, "_").toLowerCase();
                if (match.slug.includes(titleSlug) && titleSlug.length > 3) {
                    matchedSeries = s;
                    break;
                }
            }
        }
        // Strategy 3: If no match, create a "generic" series from the slug prefix
        if (!matchedSeries) {
            // Extract series name from slug: remove "part_N", "chapter_N", "ep_N" suffixes
            const seriesSlug = match.slug.replace(/_?(part|chapter|ch|ep|episode)_?\d+.*$/i, "").replace(/_+$/, "");
            if (seriesSlug.length > 2) {
                matchedSeries = {
                    id: seriesSlug,
                    title: seriesSlug.replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase())
                };
            }
        }
        if (!matchedSeries) continue;
        const sid = matchedSeries.id;
        if (!seriesChapters.has(sid)) {
            seriesChapters.set(sid, []);
            seriesInfo.set(sid, matchedSeries);
        }
        // Don't add duplicates
        const existing = seriesChapters.get(sid);
        if (!existing.find((c)=>c.postId === match.postId)) {
            existing.push({
                title: match.slug.replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase()),
                url: match.url,
                postId: match.postId
            });
        }
    }
    // Save each series' chapters
    const results = [];
    for (const [slug, chapters] of seriesChapters){
        const info = seriesInfo.get(slug);
        const existing = await (0,user_chapters/* getImportedChapters */.bV)(slug);
        const existingIds = new Set((existing?.chapters ?? []).map((c)=>c.postId));
        const newChapters = chapters.filter((c)=>!existingIds.has(c.postId));
        const merged = [
            ...existing?.chapters ?? [],
            ...newChapters
        ];
        await (0,user_chapters/* saveImportedChapters */.cK)(slug, merged, {
            source: "mass-import"
        });
        results.push({
            slug,
            title: info.title,
            chaptersAdded: newChapters.length,
            total: merged.length
        });
    }
    return server.NextResponse.json({
        ok: true,
        totalUrls: matches.length,
        seriesCount: results.length,
        totalChaptersAdded: results.reduce((sum, r)=>sum + r.chaptersAdded, 0),
        series: results.sort((a, b)=>b.chaptersAdded - a.chaptersAdded)
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fmass-import%2Froute&name=app%2Fapi%2Fmass-import%2Froute&pagePath=private-next-app-dir%2Fapi%2Fmass-import%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fmass-import%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/mass-import/route",
        pathname: "/api/mass-import",
        filename: "route",
        bundlePath: "app/api/mass-import/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/mass-import/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/mass-import/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 3033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 4945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bV: () => (/* binding */ getImportedChapters),
/* harmony export */   cK: () => (/* binding */ saveImportedChapters),
/* harmony export */   rj: () => (/* binding */ parseRedditWikiForChapters),
/* harmony export */   sortChaptersByNumber: () => (/* binding */ sortChaptersByNumber)
/* harmony export */ });
/* unused harmony export extractChapterNumber */
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
// HFY NEKROCODEXXX — User-Imported Chapter Cache
// =====================================================
// Stores chapter lists that the USER imports from their
// browser (which isn't IP-blocked by Reddit) via the
// bookmarklet or paste-HTML fallback.
//
// Storage strategy:
//   - In-memory Map for fast reads
//   - Filesystem persistence at /home/z/my-project/data/user-chapters/
//     so imports survive server restarts
//
// Endpoints use this:
//   POST /api/series/[slug]/chapters — writes
//   GET  /api/series/[slug]/chapters — reads


// CRITICAL: Use multiple path resolution strategies to ensure chapters persist
// across restarts. process.cwd() can change on Android, so we also try
// __dirname (relative to this file in the standalone build) and a fixed path.
const POSSIBLE_DATA_DIRS = [
    // Priority 1: HFY_DATA_DIR (Android persistent storage — getFilesDir/hfy-data)
    process.env.HFY_DATA_DIR ? path__WEBPACK_IMPORTED_MODULE_1___default().join(process.env.HFY_DATA_DIR, "user-chapters") : path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "..", "data", "user-chapters")
];
// Use the first directory that exists and has data, or create the first one
let DATA_DIR = POSSIBLE_DATA_DIRS[0];
for (const dir of POSSIBLE_DATA_DIRS){
    try {
        const files = (__webpack_require__(9021).readdirSync)(dir);
        if (files.length > 0) {
            DATA_DIR = dir;
            break;
        }
    } catch  {
    // Directory doesn't exist, try next
    }
}
// In-memory cache
const cache = new Map();
// Ensure data dir exists
async function ensureDir() {
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.mkdir(DATA_DIR, {
            recursive: true
        });
    } catch  {
    // ignore
    }
}
function filePath(slug) {
    // Sanitize slug — only allow alphanumeric + underscore + hyphen
    const safe = slug.replace(/[^a-zA-Z0-9_-]/g, "_");
    return path__WEBPACK_IMPORTED_MODULE_1___default().join(DATA_DIR, `${safe}.json`);
}
/** Get imported chapters for a series slug */ async function getImportedChapters(slug) {
    // Check memory first, but verify against filesystem mtime
    // (the auto-discover route may have updated the file in a different
    // Next.js worker process with its own in-memory cache)
    const fp = filePath(slug);
    try {
        const stat = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.stat(fp);
        const cached = cache.get(slug);
        if (cached && cached.importedAt >= stat.mtimeMs) {
            // Cache is fresh
            return cached;
        }
        // Cache is stale or missing — reload from filesystem
        const content = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(fp, "utf8");
        let parsed;
        try {
            parsed = JSON.parse(content);
        } catch (parseErr) {
            // Corrupted JSON file — delete it and return null
            console.warn(`[user-chapters] Corrupted file for ${slug}, deleting:`, parseErr);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Validate: ensure chapters array exists and isn't excessively large
        if (!parsed.chapters || !Array.isArray(parsed.chapters)) {
            console.warn(`[user-chapters] Invalid chapters for ${slug}, deleting`);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Cap at 50000 chapters to prevent OOM (was 2000 — too low, caused data loss)
        if (parsed.chapters.length > 50000) {
            console.warn(`[user-chapters] Truncating ${parsed.chapters.length} chapters to 50000 for ${slug}`);
            parsed.chapters = parsed.chapters.slice(0, 50000);
        }
        cache.set(slug, parsed);
        return parsed;
    } catch  {
        // File doesn't exist
        if (cache.has(slug)) return cache.get(slug);
        return null;
    }
}
/** Save imported chapters for a series slug */ async function saveImportedChapters(slug, chapters, options = {}) {
    await ensureDir();
    // DEDUPLICATION: remove duplicate chapters by postId AND by normalized URL.
    // This is critical because parallel stages (RSS crawler, Wayback crawler,
    // JSON crawler, hfy.foundation) may all discover the same chapter.
    // We normalize URLs to catch duplicates that differ only in trailing
    // slashes, www prefix, or http vs https.
    const seenPostIds = new Set();
    const seenUrlKeys = new Set();
    const deduped = [];
    for (const c of chapters){
        if (!c.postId) continue;
        // Normalize URL for dedup (strip protocol/www/trailing slash/query)
        const urlKey = normalizeUrlForDedup(c.url);
        if (seenPostIds.has(c.postId) || seenUrlKeys.has(urlKey)) {
            continue; // skip duplicate
        }
        seenPostIds.add(c.postId);
        seenUrlKeys.add(urlKey);
        deduped.push(c);
    }
    // Merge processedPostIds with any existing ones (for resume-crawl)
    const existing = cache.get(slug);
    const processedSet = new Set([
        ...existing?.processedPostIds ?? [],
        ...options.processedPostIds ?? []
    ]);
    const list = {
        slug,
        chapters: deduped,
        // Preserve existing synopsis if the caller doesn't provide one.
        // This prevents reparse/fetch-missing/add-chapter from wiping the
        // synopsis that was previously saved.
        synopsis: options.synopsis !== undefined ? options.synopsis : existing?.synopsis,
        importedAt: Date.now(),
        source: options.source || "manual",
        processedPostIds: Array.from(processedSet)
    };
    cache.set(slug, list);
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.writeFile(filePath(slug), JSON.stringify(list, null, 2), "utf8");
    } catch (err) {
        console.warn(`[user-chapters] Failed to persist ${slug}:`, err);
    }
    return list;
}
/**
 * Normalize a Reddit URL for deduplication purposes.
 * Strips: protocol, www/old/new prefix, trailing slash, query params, fragments.
 * "https://www.reddit.com/r/HFY/comments/abc123/chapter_1/" → "reddit.com/r/HFY/comments/abc123"
 */ /**
 * Extract a chapter number from a title for sorting.
 * Handles: "Chapter 42", "Part 3", "Episode 7", "Interlude 4", "Chapter 7.1"
 * Returns 999 for non-chapter posts (sorted to end).
 */ function extractChapterNumber(title) {
    // Try "Chapter N" or "Chapter N.M"
    let m = title.match(/[Cc]hapter\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Try "Part N"
    m = title.match(/[Pp]art\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Try "Episode N"
    m = title.match(/[Ee]pisode\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Interludes
    if (/interlude/i.test(title)) {
        m = title.match(/[Ii]nterlude\s+(\d+)/);
        if (m) return parseFloat(m[1]) + 0.5;
        return 999; // unnamed interlude
    }
    return 999; // unknown — sort to end
}
/**
 * CRITICAL: Do NOT sort chapters by extracted number.
 * The source CSV/JSON files already have chapters in the correct
 * chronological order. Sorting BREAKS the order because titles without
 * a number get parsed as 999 and pushed to the end.
 *
 * This function is a NO-OP — returns the array unchanged.
 */ function sortChaptersByNumber(chapters) {
    return chapters;
}
function normalizeUrlForDedup(url) {
    return url.replace(/^https?:\/\//, "").replace(/^(www\.|old\.|new\.|np\.)?reddit\.com/i, "reddit.com").replace(/[?#].*$/, "").replace(/\/$/, "").toLowerCase();
}
/** Parse a Reddit wiki page HTML (or markdown) for chapter links */ function parseRedditWikiForChapters(html) {
    const chapters = [];
    const seen = new Set();
    // Helper: strip Wayback Machine wrapper from URLs
    // http://web.archive.org/web/20250801/https://www.reddit.com/... → https://www.reddit.com/...
    function stripWayback(url) {
        const m = url.match(/https?:\/\/web\.archive\.org\/web\/\d+\/(https?:\/\/.+)/i);
        return m ? m[1] : url;
    }
    // Strategy 1: HTML anchor tags
    const aRe = /<a[^>]+href=["'](https?:\/\/[^"']*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^"']*)["'][^>]*>([^<]+)<\/a>/gi;
    let m;
    while((m = aRe.exec(html)) !== null){
        const url = stripWayback(m[1].trim());
        const title = m[2].trim() || "Chapter";
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                chapters.push({
                    title,
                    url,
                    postId
                });
            }
        }
    }
    // Strategy 2: Markdown links [text](url)
    const mdRe = /\[([^\]]+)\]\((https?:\/\/[^)]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^)]*)\)/gi;
    while((m = mdRe.exec(html)) !== null){
        const title = m[1].trim();
        const url = stripWayback(m[2].trim());
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                chapters.push({
                    title,
                    url,
                    postId
                });
            }
        }
    }
    // Strategy 3: Bare URLs — try to extract a title from surrounding text
    const bareRe = /(https?:\/\/[^\s"'<\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s"'<\]]*)/gi;
    while((m = bareRe.exec(html)) !== null){
        const url = stripWayback(m[1].trim());
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                // Try to grab surrounding text as the title.
                const start = Math.max(0, m.index - 80);
                const end = Math.min(html.length, m.index + url.length + 80);
                const context = html.slice(start, end).replace(m[1], " ").trim();
                const beforeMatch = context.match(/([^\n•\-*|]{3,80})\s*(?:—|–|-|:|\s)\s*$/);
                const afterMatch = context.match(/^\s*(?:—|–|-|:|\s)\s*([^\n•\-*|]{3,80})/);
                let title = "Chapter";
                if (beforeMatch && beforeMatch[1].trim().length > 2) {
                    title = beforeMatch[1].trim();
                } else if (afterMatch && afterMatch[1].trim().length > 2) {
                    title = afterMatch[1].trim();
                } else {
                    const chapRe = /Chapter\s+\d+[:\s-]*[^\n]{0,80}/i;
                    const chapM = context.match(chapRe);
                    if (chapM) title = chapM[0].trim();
                }
                if (title === "Chapter") {
                    const slugM = url.match(/\/comments\/[a-z0-9]+\/([^/?]+)\//i);
                    if (slugM) {
                        title = slugM[1].replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
                    }
                }
                chapters.push({
                    title: title.slice(0, 200).replace(/[—–\-:]\s*$/, "").trim() || "Chapter",
                    url,
                    postId
                });
            }
        }
    }
    // Extract synopsis — first paragraph of meaningful text
    let synopsis = "";
    // Strip HTML tags to get plain text
    const text = html.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, " ").trim();
    const sentences = text.split(/(?<=[.!?])\s+/);
    for (const s of sentences){
        if (s.length > 60 && s.length < 400 && !s.includes("http") && !s.includes("reddit.com")) {
            synopsis = s;
            break;
        }
    }
    return {
        chapters,
        synopsis
    };
}


/***/ }),

/***/ 6439:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 6487:
/***/ (() => {



/***/ }),

/***/ 8335:
/***/ (() => {



/***/ }),

/***/ 9021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813,7101], () => (__webpack_exec__(1934)));
module.exports = __webpack_exports__;

})();