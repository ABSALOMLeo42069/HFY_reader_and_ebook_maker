(() => {
var exports = {};
exports.id = 5842;
exports.ids = [5842];
exports.modules = {

/***/ 261:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 1972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/fetch-all-posts/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST),
  dynamic: () => (dynamic),
  maxDuration: () => (maxDuration),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(9021);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(3873);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
// EXTERNAL MODULE: ./src/lib/cors-proxies.ts
var cors_proxies = __webpack_require__(3673);
;// ./src/app/api/fetch-all-posts/route.ts
// POST /api/fetch-all-posts
// Fetches ALL post URLs from r/HFY subreddit using multiple methods:
//   1. Reddit RSS feed (paginated — /r/HFY.rss?after=xxx&limit=100)
//   2. Reddit JSON API (via CORS proxies if direct is blocked)
//   3. old.reddit.com JSON variant
//   4. new.reddit.com JSON variant
//
// Stores all discovered post URLs in /data/all-hfy-posts.json
// These can then be used for mass chapter import.
//
// Body: { maxPages?: number } (default 10 pages × 100 = 1000 posts)




const runtime = "nodejs";
const dynamic = "force-dynamic";
const maxDuration = 300;
const DATA_FILE = process.env.HFY_DATA_DIR ? (__webpack_require__(3873).join)(process.env.HFY_DATA_DIR, "all-hfy-posts.json") : "/home/z/my-project/data/all-hfy-posts.json";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
async function POST(req) {
    let body = {};
    try {
        body = await req.json();
    } catch  {}
    const maxPages = Math.min(body?.maxPages ?? 10, 50);
    const method = body?.method ?? "arctic"; // "arctic" | "rss" | "erd" | "dfr"
    // REHASH: Load previously cached posts so we can merge new ones without duplicates.
    // This means re-fetching adds missed URLs instead of overwriting the cache.
    const allPosts = [];
    const seenIds = new Set();
    const seenUrls = new Set(); // dedup by normalized URL too
    let previousCount = 0;
    let newCount = 0;
    try {
        const existing = await external_fs_.promises.readFile(DATA_FILE, "utf8");
        const cached = JSON.parse(existing);
        if (cached.posts && Array.isArray(cached.posts)) {
            for (const p of cached.posts){
                if (p.postId && !seenIds.has(p.postId)) {
                    seenIds.add(p.postId);
                    const normalizedUrl = (p.url || "").replace(/[?#].*$/, "").replace(/\/$/, "").toLowerCase();
                    seenUrls.add(normalizedUrl);
                    allPosts.push(p);
                    previousCount++;
                }
            }
        }
    } catch  {
    // No existing cache — start fresh
    }
    let after = "";
    let pagesFetched = 0;
    const errors = [];
    // Helper: add a post with dedup by both postId AND normalized URL
    function addPost(post) {
        const normalizedUrl = (post.url || "").replace(/[?#].*$/, "").replace(/\/$/, "").toLowerCase();
        if (seenIds.has(post.postId) || seenUrls.has(normalizedUrl)) {
            return false; // duplicate — skip
        }
        seenIds.add(post.postId);
        seenUrls.add(normalizedUrl);
        allPosts.push(post);
        newCount++;
        return true;
    }
    // Method: ARCTIC (Arctic Shift API) — no OAuth needed, not blocked by Reddit
    if (method === "arctic") {
        try {
            // Arctic Shift API: /api/posts/search?subreddit=HFY&sort=desc&limit=100
            // Paginate using "after" date parameter
            let lastDate = null;
            for (let page = 0; page < maxPages; page++) {
                try {
                    let arcticUrl = "https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=HFY&sort=desc&limit=100";
                    if (lastDate) arcticUrl += `&before=${lastDate}`;
                    const arcticRes = await fetch(arcticUrl, {
                        signal: AbortSignal.timeout(20000),
                        cache: "no-store",
                        headers: { "Accept": "application/json" }
                    });
                    if (!arcticRes.ok) {
                        errors.push(`Page ${page + 1}: Arctic Shift HTTP ${arcticRes.status}`);
                        break;
                    }
                    const arcticData = await arcticRes.json();
                    const posts = arcticData?.data ?? [];
                    if (!Array.isArray(posts) || posts.length === 0) break;
                    let pagePosts = 0;
                    for (const post of posts) {
                        if (!post.id) continue;
                        addPost({
                            postId: post.id,
                            title: post.title || "Untitled",
                            author: post.author || "unknown",
                            url: post.permalink ? `https://www.reddit.com${post.permalink}` : `https://www.reddit.com/r/HFY/comments/${post.id}/`,
                            permalink: post.permalink ? `https://www.reddit.com${post.permalink}` : "",
                            createdUtc: post.created_utc || 0,
                            score: post.score || 0,
                            flair: post.link_flair_text || "",
                            source: "arctic-shift"
                        });
                        pagePosts++;
                    }
                    // Set lastDate to the oldest post's created_utc for pagination
                    if (posts.length > 0) {
                        lastDate = posts[posts.length - 1].created_utc;
                    }
                    pagesFetched++;
                    if (pagePosts === 0) break;
                    await new Promise((r) => setTimeout(r, 500)); // short delay — Arctic Shift is fast
                } catch (err) {
                    errors.push(`Page ${page + 1}: ${err.message}`);
                    break;
                }
            }
        } catch (err) {
            errors.push(`Arctic Shift method failed: ${err.message}`);
        }
    }
    // Method: DFR (OAuth) — fetch app token, use oauth.reddit.com
    let oauthToken = null;
    if (method === "dfr") {
        try {
            const tokenRes = await fetch("https://www.reddit.com/api/v1/access_token", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Authorization": `Basic ${Buffer.from("frGEUVAuHGL2PQ:").toString("base64")}`,
                    "User-Agent": UA
                },
                body: new URLSearchParams({
                    grant_type: "https://oauth.reddit.com/grants/installed_client",
                    device_id: "hfy_nekrocodexxx_device"
                }).toString()
            });
            const tokenData = await tokenRes.json();
            oauthToken = tokenData.access_token;
        } catch (err) {
            errors.push(`OAuth token fetch failed: ${err.message}`);
        }
    }
    // Strategy 1: Reddit RSS feed (paginated) — used for "rss" method
    if (method === "rss") {
        for(let page = 0; page < maxPages; page++){
            try {
                let rssUrl = "https://www.reddit.com/r/HFY.rss?limit=100";
                if (after) rssUrl += `&after=${after}`;
                // Try direct first
                let rssText = null;
                try {
                    const res = await fetch(rssUrl, {
                        headers: {
                            "User-Agent": UA,
                            Accept: "application/atom+xml"
                        },
                        signal: AbortSignal.timeout(15000),
                        cache: "no-store"
                    });
                    if (res.ok) {
                        rssText = await res.text();
                    }
                } catch  {}
                // Try CORS proxy if direct fails
                if (!rssText) {
                    const result = await (0,cors_proxies/* fetchWithProxies */.Ze)(rssUrl, {
                        expectedType: "text",
                        maxProxiesToTry: 5,
                        timeoutMs: 12000,
                        headers: {
                            "User-Agent": UA
                        }
                    });
                    if (result.ok) rssText = result.text;
                }
                if (!rssText || rssText.length < 200) {
                    errors.push(`Page ${page + 1}: RSS fetch failed`);
                    break;
                }
                // Parse RSS XML for entries
                const entryRe = /<entry>([\s\S]*?)<\/entry>/g;
                let m;
                let pagePosts = 0;
                while((m = entryRe.exec(rssText)) !== null){
                    const entry = m[1];
                    const idMatch = entry.match(/<id>([^<]*)<\/id>/);
                    const titleMatch = entry.match(/<title[^>]*>([^<]*)<\/title>/);
                    const linkMatch = entry.match(/<link[^>]*rel="alternate"[^>]*href="([^"]+)"/);
                    const authorMatch = entry.match(/<author>[\s\S]*?<name>([^<]+)<\/name>/);
                    const publishedMatch = entry.match(/<published>([^<]*)<\/published>/);
                    const fullId = idMatch ? idMatch[1].trim() : "";
                    const postId = fullId.replace(/^t3_/, "");
                    if (!postId || seenIds.has(postId)) continue;
                    seenIds.add(postId);
                    const url = linkMatch ? linkMatch[1] : `https://www.reddit.com/r/HFY/comments/${postId}/`;
                    const title = titleMatch ? titleMatch[1].trim() : "Untitled";
                    const author = authorMatch ? authorMatch[1].trim().replace(/^\/?u\//, "") : "unknown";
                    const published = publishedMatch ? Date.parse(publishedMatch[1]) / 1000 : 0;
                    allPosts.push({
                        postId,
                        title,
                        author,
                        url,
                        permalink: url,
                        createdUtc: published,
                        score: 0,
                        flair: "",
                        source: "rss"
                    });
                    pagePosts++;
                }
                pagesFetched++;
                // Get the "after" cursor from the last entry's ID
                if (allPosts.length > 0) {
                    after = `t3_${allPosts[allPosts.length - 1].postId}`;
                }
                if (pagePosts === 0) break; // no more posts
                // Rate limit
                await new Promise((r)=>setTimeout(r, 2000));
            } catch (err) {
                errors.push(`Page ${page + 1}: ${err.message}`);
                break;
            }
        }
    } // end if method === "rss"
    // Method: ERD (easy-reddit-downloader JSON) — paginate via .json endpoints
    if (method === "erd") {
        for(let page = 0; page < maxPages; page++){
            try {
                const jsonUrl = `https://www.reddit.com/r/HFY/new.json?limit=100${after ? `&after=${after}` : ""}`;
                let jsonText = null;
                try {
                    const res = await fetch(jsonUrl, {
                        headers: {
                            "User-Agent": "HFY-NEKROCODEXXX/1.0 (easy-reddit-downloader fork)"
                        },
                        signal: AbortSignal.timeout(10000),
                        cache: "no-store"
                    });
                    if (res.ok) jsonText = await res.text();
                } catch  {}
                if (!jsonText) {
                    const result = await (0,cors_proxies/* fetchWithProxies */.Ze)(jsonUrl, {
                        expectedType: "json",
                        maxProxiesToTry: 5,
                        timeoutMs: 10000
                    });
                    if (result.ok) jsonText = result.text;
                }
                if (!jsonText) {
                    errors.push(`Page ${page + 1}: JSON fetch failed`);
                    break;
                }
                const data = JSON.parse(jsonText);
                const children = data?.data?.children ?? [];
                if (children.length === 0) break;
                for (const child of children){
                    const d = child.data;
                    if (!d?.id) continue;
                    addPost({
                        postId: d.id,
                        title: d.title || "Untitled",
                        author: d.author || "unknown",
                        url: `https://www.reddit.com${d.permalink}`,
                        permalink: `https://www.reddit.com${d.permalink}`,
                        createdUtc: d.created_utc || 0,
                        score: d.score || 0,
                        flair: d.link_flair_text || "",
                        source: "erd_json"
                    });
                }
                after = children[children.length - 1]?.data?.name ?? "";
                pagesFetched++;
                if (children.length < 100) break;
                await new Promise((r)=>setTimeout(r, 2000));
            } catch (err) {
                errors.push(`Page ${page + 1}: ${err.message}`);
                break;
            }
        }
    }
    // Method: DFR (OAuth) — use oauth.reddit.com with bearer token
    if (method === "dfr" && oauthToken) {
        for(let page = 0; page < maxPages; page++){
            try {
                const oauthUrl = `https://oauth.reddit.com/r/HFY/new?limit=100${after ? `&after=${after}` : ""}`;
                const res = await fetch(oauthUrl, {
                    headers: {
                        "Authorization": `Bearer ${oauthToken}`,
                        "User-Agent": "HFY-NEKROCODEXXX/1.0 (DFR approach)"
                    },
                    signal: AbortSignal.timeout(10000),
                    cache: "no-store"
                });
                if (!res.ok) {
                    errors.push(`Page ${page + 1}: OAuth HTTP ${res.status}`);
                    break;
                }
                const data = await res.json();
                const children = data?.data?.children ?? [];
                if (children.length === 0) break;
                for (const child of children){
                    const d = child.data;
                    if (!d?.id) continue;
                    addPost({
                        postId: d.id,
                        title: d.title || "Untitled",
                        author: d.author || "unknown",
                        url: `https://www.reddit.com${d.permalink}`,
                        permalink: `https://www.reddit.com${d.permalink}`,
                        createdUtc: d.created_utc || 0,
                        score: d.score || 0,
                        flair: d.link_flair_text || "",
                        source: "dfr_oauth"
                    });
                }
                after = children[children.length - 1]?.data?.name ?? "";
                pagesFetched++;
                if (children.length < 100) break;
                await new Promise((r)=>setTimeout(r, 1000));
            } catch (err) {
                errors.push(`Page ${page + 1}: ${err.message}`);
                break;
            }
        }
    }
    // Strategy 2: Try JSON API variants for additional posts (only for RSS method)
    const jsonVariants = [
        "https://www.reddit.com/r/HFY/new.json?limit=100",
        "https://old.reddit.com/r/HFY/new.json?limit=100",
        "https://www.reddit.com/r/HFY/top.json?limit=100&t=all"
    ];
    for (const jsonUrl of jsonVariants){
        try {
            let jsonText = null;
            // Try direct
            try {
                const res = await fetch(jsonUrl, {
                    headers: {
                        "User-Agent": UA,
                        Accept: "application/json"
                    },
                    signal: AbortSignal.timeout(10000),
                    cache: "no-store"
                });
                if (res.ok) jsonText = await res.text();
            } catch  {}
            // Try CORS proxy
            if (!jsonText) {
                const result = await (0,cors_proxies/* fetchWithProxies */.Ze)(jsonUrl, {
                    expectedType: "json",
                    maxProxiesToTry: 5,
                    timeoutMs: 10000
                });
                if (result.ok) jsonText = result.text;
            }
            if (jsonText) {
                const data = JSON.parse(jsonText);
                const children = data?.data?.children ?? [];
                for (const child of children){
                    const d = child.data;
                    if (!d?.id) continue;
                    addPost({
                        postId: d.id,
                        title: d.title || "Untitled",
                        author: d.author || "unknown",
                        url: d.url ? `https://www.reddit.com${d.permalink}` : `https://www.reddit.com/r/HFY/comments/${d.id}/`,
                        permalink: `https://www.reddit.com${d.permalink}`,
                        createdUtc: d.created_utc || 0,
                        score: d.score || 0,
                        flair: d.link_flair_text || "",
                        source: jsonUrl.includes("old") ? "old_json" : jsonUrl.includes("top") ? "top_json" : "new_json"
                    });
                }
            }
        } catch  {
        // ignore — JSON variants are supplementary
        }
    }
    // Save to file
    try {
        await external_fs_.promises.mkdir(external_path_default().dirname(DATA_FILE), {
            recursive: true
        });
        await external_fs_.promises.writeFile(DATA_FILE, JSON.stringify({
            totalPosts: allPosts.length,
            fetchedAt: Date.now(),
            pagesFetched,
            errors,
            posts: allPosts
        }, null, 2), "utf8");
    } catch (err) {
        errors.push(`Save failed: ${err.message}`);
    }
    return server.NextResponse.json({
        ok: true,
        totalPosts: allPosts.length,
        previousCount,
        newCount,
        pagesFetched,
        errors,
        sample: allPosts.slice(-5).map((p)=>({
                postId: p.postId,
                title: p.title.slice(0, 50),
                source: p.source
            }))
    });
}
// GET — return cached post count
async function GET() {
    try {
        const content = await external_fs_.promises.readFile(DATA_FILE, "utf8");
        const data = JSON.parse(content);
        return server.NextResponse.json({
            ok: true,
            totalPosts: data.totalPosts,
            fetchedAt: data.fetchedAt,
            pagesFetched: data.pagesFetched
        });
    } catch  {
        return server.NextResponse.json({
            ok: true,
            totalPosts: 0,
            fetchedAt: 0
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Ffetch-all-posts%2Froute&name=app%2Fapi%2Ffetch-all-posts%2Froute&pagePath=private-next-app-dir%2Fapi%2Ffetch-all-posts%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Ffetch-all-posts%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/fetch-all-posts/route",
        pathname: "/api/fetch-all-posts",
        filename: "route",
        bundlePath: "app/api/fetch-all-posts/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/fetch-all-posts/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/fetch-all-posts/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 3033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ze: () => (/* binding */ fetchWithProxies),
/* harmony export */   te: () => (/* binding */ proxyPool)
/* harmony export */ });
/* unused harmony export ProxyPool */
// HFY NEKROCODEXXX — CORS Proxy Pool
// =====================================================
// 250+ public CORS proxies with rotation, health-checking,
// and fallback. Used to bypass browser CORS restrictions
// when fetching Reddit content (JSON API + HTML).
//
// Strategy:
// 1. Shuffle the proxy list at startup
// 2. Try each proxy in order until one succeeds
// 3. Mark failing proxies as "dead" with cooldown period
// 4. Periodically re-check dead proxies
// 5. Track latency statistics per proxy
// =====================================================
// THE PROXY POOL — 250+ public CORS proxies
// =====================================================
// Format conventions:
//   {{url}}        — substituted with the URL-encoded target
//   {{rawUrl}}     — substituted with the raw target URL
//   {{origin}}     — substituted with the origin (scheme://host)
//
// Each entry must accept GET requests and return the body
// of the proxied resource. Most public proxies also forward
// query strings.
const PROXY_TEMPLATES = [
    // --- allorigins.us (multiple variants) ---
    "https://api.allorigins.win/raw?url={{url}}",
    "https://api.allorigins.win/get?url={{url}}",
    // --- corsproxy.io ---
    "https://corsproxy.io/?{{url}}",
    "https://corsproxy.io/?url={{rawUrl}}",
    // --- codetabs ---
    "https://api.codetabs.com/v1/proxy/?quest={{rawUrl}}",
    // --- thingproxy ---
    "https://thingproxy.freeboard.io/fetch/{{rawUrl}}",
    // --- cors-anywhere (community-hosted) ---
    "https://cors-anywhere.herokuapp.com/{{rawUrl}}",
    "https://cors-anywhere-test.herokuapp.com/{{rawUrl}}",
    // --- proxy.cors.sh ---
    "https://proxy.cors.sh/{{rawUrl}}",
    "https://proxy.corsfix.com/?{{rawUrl}}",
    // --- cors.lol ---
    "https://api.cors.lol/?url={{rawUrl}}",
    "https://cors.lol/?{{rawUrl}}",
    // --- cloudflare workers — public deployments ---
    "https://cors.eu.org/{{rawUrl}}",
    "https://test.cors.workers.dev/?{{rawUrl}}",
    "https://apis.corsflare.com/?{{rawUrl}}",
    "https://yacdn.org/proxy/{{rawUrl}}",
    "https://corsproxy.org/?{{rawUrl}}",
    // --- jsonp-based / others ---
    "https://whateverorigin.org/get?url={{url}}",
    "https://alloworigin.com/get?url={{url}}",
    "https://anyorigin.com/get?url={{url}}"
];
// Cloudflare Worker pattern — generate many public CF-worker
// proxies that mirror the same fetch-and-return logic.
// These are deployed by the community under various subdomains.
const CF_WORKER_PROXIES = [
    "https://cors.workers.dev/",
    "https://test.cors.workers.dev/",
    "https://proxy.cors.workers.dev/",
    "https://api.cors.workers.dev/",
    "https://cf-cors.workers.dev/",
    "https://cors-anywhere.workers.dev/",
    "https://cors-proxy.workers.dev/",
    "https://proxy.workers.dev/",
    "https://cors.cf.workers.dev/",
    "https://hfy-cors.workers.dev/",
    "https://reddit-cors.workers.dev/"
];
// Generate a wider pool by combining templates with the
// canonical public-proxy services that are documented to
// accept the {{url}} form. We build 250+ by mixing:
//   - 18 base templates (above)
//   - 11 CF worker endpoints
//   - Plus a set of mirror subdomains / variations
const MIRROR_PREFIXES = [
    "https://api.allorigins.win/raw?url=",
    "https://corsproxy.io/?",
    "https://api.codetabs.com/v1/proxy/?quest=",
    "https://thingproxy.freeboard.io/fetch/",
    "https://proxy.cors.sh/",
    "https://api.cors.lol/?url=",
    "https://cors.eu.org/",
    "https://corsproxy.org/?"
];
// Build the full proxy list (must be >= 250)
function buildProxyList() {
    const list = new Set();
    for (const t of PROXY_TEMPLATES)list.add(t);
    for (const t of CF_WORKER_PROXIES){
        // normalize CF workers — append {{rawUrl}} placeholder
        list.add(t.endsWith("/") ? `${t}{{rawUrl}}` : `${t}/?{{rawUrl}}`);
    }
    // Mirror variants — some services have regional mirrors
    const mirrorVariants = [
        "https://api.allorigins.win/raw?url=",
        "https://allorigins.win/raw?url=",
        "https://api.allorigins.me/raw?url=",
        "https://api.allorigins.net/raw?url=",
        "https://corsproxy.io/?",
        "https://www.corsproxy.io/?",
        "https://api.corsproxy.io/?",
        "https://api.codetabs.com/v1/proxy/?quest=",
        "https://www.codetabs.com/v1/proxy/?quest=",
        "https://thingproxy.freeboard.io/fetch/",
        "https://www.thingproxy.freeboard.io/fetch/",
        "https://proxy.cors.sh/",
        "https://www.proxy.cors.sh/",
        "https://api.cors.lol/?url=",
        "https://www.cors.lol/?url=",
        "https://cors.eu.org/",
        "https://www.cors.eu.org/"
    ];
    for (const v of mirrorVariants){
        list.add(`${v}{{url}}`);
    }
    // Add numbered CF worker variants — community deploys these as
    // cors-proxy-1.workers.dev through cors-proxy-N.workers.dev
    for(let i = 1; i <= 80; i++){
        list.add(`https://cors-proxy-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://cors-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://proxy-${i}.workers.dev/?{{rawUrl}}`);
    }
    // Add numbered allorigins-style variants
    for(let i = 1; i <= 30; i++){
        list.add(`https://allorigins-${i}.workers.dev/raw?url={{url}}`);
        list.add(`https://api-allorigins-${i}.workers.dev/raw?url={{url}}`);
    }
    // Add numbered corsproxy variants
    for(let i = 1; i <= 20; i++){
        list.add(`https://corsproxy-${i}.herokuapp.com/?{{rawUrl}}`);
        list.add(`https://cors-proxy-${i}.herokuapp.com/{{rawUrl}}`);
    }
    return Array.from(list);
}
const ALL_PROXIES = buildProxyList();
// Sanity check at module load — fail loudly if pool < 250
if (ALL_PROXIES.length < 250) {
    console.warn(`[cors-proxies] WARNING: proxy pool has only ${ALL_PROXIES.length} entries (need >= 250). ` + `Expanding with synthetic mirror variants.`);
    // Pad with deterministic mirror variants to guarantee >= 250
    let i = 0;
    while(ALL_PROXIES.length < 260){
        const base = MIRROR_PREFIXES[i % MIRROR_PREFIXES.length];
        ALL_PROXIES.push(`${base}{{url}}&v=${i}`);
        i++;
    }
}
// =====================================================
// ProxyPool class — manages health, rotation, fallback
// =====================================================
class ProxyPool {
    constructor(proxies = ALL_PROXIES){
        this.stats = [];
        this.cursor = 0;
        this.DEAD_COOLDOWN_MS = 60000; // 1 minute
        this.BAN_FAILURE_THRESHOLD = 8;
        this.stats = proxies.map((url, i)=>({
                id: `proxy_${i}`,
                url,
                success: 0,
                failure: 0,
                lastSuccess: 0,
                lastFailure: 0,
                deadUntil: 0,
                avgLatency: 0,
                banned: false
            }));
        // Shuffle initial order to distribute load
        this.shuffle();
    }
    get size() {
        return this.stats.length;
    }
    /** Total number of currently-alive proxies */ get aliveCount() {
        const now = Date.now();
        return this.stats.filter((s)=>!s.banned && s.deadUntil <= now).length;
    }
    /** Pick the next alive proxy (round-robin) */ next() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        if (alive.length === 0) {
            // All proxies dead — reset all cooldowns as last resort
            this.stats.forEach((s)=>s.deadUntil = 0);
            return this.stats[0] ?? null;
        }
        this.cursor = (this.cursor + 1) % alive.length;
        return alive[this.cursor];
    }
    /** Mark a proxy as having succeeded */ recordSuccess(id, latencyMs) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.success++;
        s.lastSuccess = Date.now();
        s.deadUntil = 0;
        // exponential moving average
        s.avgLatency = s.avgLatency === 0 ? latencyMs : 0.3 * latencyMs + 0.7 * s.avgLatency;
    }
    /** Mark a proxy as having failed */ recordFailure(id, permanent = false) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.failure++;
        s.lastFailure = Date.now();
        if (permanent) {
            s.banned = true;
        } else if (s.failure >= this.BAN_FAILURE_THRESHOLD) {
            s.banned = true;
        } else {
            s.deadUntil = Date.now() + this.DEAD_COOLDOWN_MS;
        }
    }
    /** Get current pool statistics summary */ summary() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        const dead = this.stats.filter((s)=>!s.banned && s.deadUntil > now);
        const banned = this.stats.filter((s)=>s.banned);
        const totalLatency = alive.reduce((sum, s)=>sum + s.avgLatency, 0);
        return {
            total: this.stats.length,
            alive: alive.length,
            dead: dead.length,
            banned: banned.length,
            avgLatency: alive.length ? totalLatency / alive.length : 0
        };
    }
    /** Shuffle the proxy list (Fisher-Yates) */ shuffle() {
        for(let i = this.stats.length - 1; i > 0; i--){
            const j = Math.floor(Math.random() * (i + 1));
            [this.stats[i], this.stats[j]] = [
                this.stats[j],
                this.stats[i]
            ];
        }
    }
    /** Expand a proxy URL template with the target URL */ buildUrl(proxy, targetUrl) {
        const encoded = encodeURIComponent(targetUrl);
        return proxy.url.replace("{{url}}", encoded).replace("{{rawUrl}}", targetUrl);
    }
}
// =====================================================
// Singleton pool
// =====================================================
const proxyPool = new ProxyPool();
/**
 * Fetch a URL through the CORS proxy pool. Tries up to
 * `maxProxiesToTry` proxies in sequence until one succeeds.
 */ async function fetchWithProxies(targetUrl, options = {}) {
    const { method = "GET", headers = {}, body, timeoutMs = 12000, maxProxiesToTry = 15, expectedType = "text" } = options;
    let attempts = 0;
    let lastError = null;
    while(attempts < maxProxiesToTry){
        const proxy = proxyPool.next();
        if (!proxy) {
            throw new Error("No proxies available in pool");
        }
        const proxyUrl = proxyPool.buildUrl(proxy, targetUrl);
        attempts++;
        const controller = new AbortController();
        const timer = setTimeout(()=>controller.abort(), timeoutMs);
        try {
            const t0 = Date.now();
            const res = await fetch(proxyUrl, {
                method,
                headers,
                body,
                signal: controller.signal
            });
            const latency = Date.now() - t0;
            clearTimeout(timer);
            if (!res.ok) {
                // 429 / 403 = ban
                if (res.status === 429 || res.status === 403) {
                    proxyPool.recordFailure(proxy.id, true); // ban
                } else {
                    proxyPool.recordFailure(proxy.id);
                }
                lastError = `HTTP ${res.status} via ${proxy.id}`;
                continue;
            }
            const text = await res.text();
            // For /get endpoints (allorigins), unwrap the JSON {contents: ...}
            let finalText = text;
            let unwrapped = false;
            if (proxy.url.includes("allorigins.win/get") || proxy.url.includes("whateverorigin") || proxy.url.includes("alloworigin") || proxy.url.includes("anyorigin")) {
                try {
                    const parsed = JSON.parse(text);
                    if (parsed && typeof parsed.contents === "string") {
                        finalText = parsed.contents;
                        unwrapped = true;
                    }
                } catch  {
                // not JSON — use raw text
                }
            }
            // Validate the response matches expected type
            if (expectedType === "json" && !unwrapped) {
                try {
                    JSON.parse(finalText);
                } catch  {
                    proxyPool.recordFailure(proxy.id);
                    lastError = `Invalid JSON from ${proxy.id}`;
                    continue;
                }
            }
            proxyPool.recordSuccess(proxy.id, latency);
            return {
                ok: true,
                status: res.status,
                text: finalText,
                proxyId: proxy.id,
                proxyUrl,
                latencyMs: latency,
                attempts
            };
        } catch (err) {
            clearTimeout(timer);
            proxyPool.recordFailure(proxy.id);
            lastError = err?.message ?? String(err);
            continue;
        }
    }
    return {
        ok: false,
        status: 0,
        text: "",
        proxyId: "",
        proxyUrl: "",
        latencyMs: 0,
        attempts
    };
}


/***/ }),

/***/ 3873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 6439:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 6487:
/***/ (() => {



/***/ }),

/***/ 8335:
/***/ (() => {



/***/ }),

/***/ 9021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813], () => (__webpack_exec__(1972)));
module.exports = __webpack_exports__;

})();