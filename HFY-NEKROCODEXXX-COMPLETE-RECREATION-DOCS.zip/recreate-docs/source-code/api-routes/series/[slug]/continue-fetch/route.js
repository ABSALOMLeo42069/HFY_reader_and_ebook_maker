"use strict";
(() => {
var exports = {};
exports.id = 4322;
exports.ids = [4322];
exports.modules = {

/***/ 261:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 2280:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
Object.defineProperty(exports, "I", ({
    enumerable: true,
    get: function() {
        return sendResponse;
    }
}));
const _helpers = __webpack_require__(8208);
const _pipereadable = __webpack_require__(7617);
const _utils = __webpack_require__(2018);
async function sendResponse(req, res, response, waitUntil) {
    if (// The type check here ensures that `req` is correctly typed, and the
    // environment variable check provides dead code elimination.
     true && (0, _helpers.isNodeNextResponse)(res)) {
        var // Copy over the response headers.
        _response_headers;
        // Copy over the response status.
        res.statusCode = response.status;
        res.statusMessage = response.statusText;
        // TODO: this is not spec-compliant behavior and we should not restrict
        // headers that are allowed to appear many times.
        //
        // See:
        // https://github.com/vercel/next.js/pull/70127
        const headersWithMultipleValuesAllowed = [
            // can add more headers to this list if needed
            'set-cookie',
            'www-authenticate',
            'proxy-authenticate',
            'vary'
        ];
        (_response_headers = response.headers) == null ? void 0 : _response_headers.forEach((value, name)=>{
            // `x-middleware-set-cookie` is an internal header not needed for the response
            if (name.toLowerCase() === 'x-middleware-set-cookie') {
                return;
            }
            // The append handling is special cased for `set-cookie`.
            if (name.toLowerCase() === 'set-cookie') {
                // TODO: (wyattjoh) replace with native response iteration when we can upgrade undici
                for (const cookie of (0, _utils.splitCookiesString)(value)){
                    res.appendHeader(name, cookie);
                }
            } else {
                // only append the header if it is either not present in the outbound response
                // or if the header supports multiple values
                const isHeaderPresent = typeof res.getHeader(name) !== 'undefined';
                if (headersWithMultipleValuesAllowed.includes(name.toLowerCase()) || !isHeaderPresent) {
                    res.appendHeader(name, value);
                }
            }
        });
        /**
     * The response can't be directly piped to the underlying response. The
     * following is duplicated from the edge runtime handler.
     *
     * See packages/next/server/next-server.ts
     */ const { originalResponse } = res;
        // A response body must not be sent for HEAD requests. See https://httpwg.org/specs/rfc9110.html#HEAD
        if (response.body && req.method !== 'HEAD') {
            await (0, _pipereadable.pipeToNodeResponse)(response.body, originalResponse, waitUntil);
        } else {
            originalResponse.end();
        }
    }
}

//# sourceMappingURL=send-response.js.map

/***/ }),

/***/ 3033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 4987:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/series/[slug]/continue-fetch/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST),
  dynamic: () => (dynamic),
  maxDuration: () => (maxDuration),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./src/lib/reddit-scraper.ts
var reddit_scraper = __webpack_require__(4034);
// FX45 v30: JSONL reader for chapter discovery (RSS CRAWL)
const fs = require("fs");
const path = require("path");
let _jsonlIdx = null;
function _findJsonlDir() {
    const candidates = [
        process.env.HFY_DATA_DIR ? path.join(process.env.HFY_DATA_DIR, "jsonl") : null,
        path.join(process.cwd(), "data", "jsonl"),
        path.join(process.cwd(), "..", "jsonl"),
        "/home/z/my-project/data/jsonl",
    ].filter(Boolean);
    for (const dir of candidates) {
        try { if (fs.existsSync(dir)) { const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl")); if (files.length > 0) return dir; } } catch {}
    }
    return null;
}
function _buildJsonlIdx() {
    if (_jsonlIdx) return;
    const dir = _findJsonlDir();
    if (!dir) return;
    _jsonlIdx = new Map();
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl"));
    for (const fileName of files) {
        try {
            const stat = fs.statSync(path.join(dir, fileName));
            if (stat.size > 500 * 1024 * 1024) continue; // Skip >500MB files
            const content = fs.readFileSync(path.join(dir, fileName), "utf8");
            for (const line of content.split("\n")) {
                if (!line.trim()) continue;
                try {
                    const post = JSON.parse(line);
                    const pid = (post.id || "").toLowerCase();
                    if (pid) _jsonlIdx.set(pid, { title: post.title || "", score: post.score || 0, created_utc: post.created_utc || 0, subreddit: post.subreddit || "", permalink: post.permalink || "" });
                } catch {}
            }
        } catch {}
    }
    console.log("[continue-fetch] JSONL index: " + _jsonlIdx.size + " posts from " + files.length + " files");
}
function _searchJsonlNextChapter(titlePrefix, currentPart) {
    if (!_jsonlIdx) _buildJsonlIdx();
    if (!_jsonlIdx) return null;
    const nextPart = currentPart + 1;
    const prefix = titlePrefix.toLowerCase().replace(/[,]/g, " ").replace(/\s+/g, " ").trim();
    // Search for posts with the same title prefix and next part number
    for (const [pid, meta] of _jsonlIdx) {
        const title = (meta.title || "").toLowerCase();
        if (title.includes(prefix) && title.includes("part " + nextPart)) {
            return { id: pid, title: meta.title, permalink: meta.permalink, url: "https://www.reddit.com/r/" + meta.subreddit + "/comments/" + pid + "/" };
        }
    }
    // Also try just the number without "part"
    for (const [pid, meta] of _jsonlIdx) {
        const title = (meta.title || "").toLowerCase();
        if (title.includes(prefix) && title.match(new RegExp("\\b0*" + nextPart + "\\b"))) {
            return { id: pid, title: meta.title, permalink: meta.permalink, url: "https://www.reddit.com/r/" + meta.subreddit + "/comments/" + pid + "/" };
        }
    }
    return null;
}

// EXTERNAL MODULE: ./src/lib/user-chapters.ts
var user_chapters = __webpack_require__(4945);
// EXTERNAL MODULE: ./src/lib/hfy-hardcoded-chapters.ts + 23 modules
var hfy_hardcoded_chapters = __webpack_require__(1781);
// EXTERNAL MODULE: external "crypto"
var external_crypto_ = __webpack_require__(5511);
;// ./src/app/api/series/[slug]/continue-fetch/route.ts
// POST /api/series/[slug]/continue-fetch
// Starts from the last known chapter and crawls forward via next-chapter links
// to discover NEW chapters beyond the current list. Also fetches body text + score
// for each discovered chapter. Persists new chapters to user-chapters storage.
//
// Request body:
//   { startPostId: string, startUrl?: string, maxChapters?: number, existingPostIds?: string[] }
//
// Response (NDJSON stream):
//   { type: "start", total: "unknown" }
//   { type: "chapter", postId, title, author, score, selftext, createdUtc, hash, url, permalink, isNew: boolean }
//   { type: "progress", discovered: number, fetched: number, errors: number }
//   { type: "summary", discovered: number, fetched: number, errors: number, savedToServer: boolean }
//   { type: "done" }




const runtime = "nodejs";
const dynamic = "force-dynamic";
const maxDuration = 300;
function computeHash(selftext) {
    return (0,external_crypto_.createHash)("sha256").update(selftext || "").digest("hex").slice(0, 16);
}
function normalizeChapterId(id) {
    let s = (id || "").trim();
    if (/^t3_/i.test(s)) s = s.slice(3);
    return s.toLowerCase();
}
async function POST(req, { params }) {
    const { slug } = await params;
    if (!slug) {
        return new Response(JSON.stringify({
            ok: false,
            error: "Missing slug"
        }), {
            status: 400,
            headers: {
                "Content-Type": "application/json"
            }
        });
    }
    let body;
    try {
        body = await req.json();
    } catch  {
        return new Response(JSON.stringify({
            ok: false,
            error: "Invalid JSON body"
        }), {
            status: 400,
            headers: {
                "Content-Type": "application/json"
            }
        });
    }
    if (!body.startPostId) {
        return new Response(JSON.stringify({
            ok: false,
            error: "Missing startPostId"
        }), {
            status: 400,
            headers: {
                "Content-Type": "application/json"
            }
        });
    }
    const maxChapters = Math.min(body.maxChapters || 2000, 2000);
    const existingPostIds = new Set((body.existingPostIds || []).map((id)=>normalizeChapterId(id)));
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
        async start (controller) {
            const sendLine = (obj)=>{
                try {
                    controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
                } catch (e) {}
            };
            let discovered = 0;
            let fetched = 0;
            let errors = 0;
            const newChapters = [];
            sendLine({
                type: "start",
                slug,
                startPostId: body.startPostId,
                maxChapters
            });
            // Start from the given chapter and follow next-chapter links
            let currentUrl = body.startUrl && body.startUrl.startsWith("http") ? body.startUrl : `https://www.reddit.com/r/HFY/comments/${normalizeChapterId(body.startPostId)}`;
            let currentPostId = normalizeChapterId(body.startPostId);
            const visitedPostIds = new Set([
                currentPostId
            ]);
            let consecutiveFailures = 0;
            while(currentUrl && discovered < maxChapters){
                try {
                    const content = await (0,reddit_scraper/* fetchPostContent */.iL)(currentUrl);
                    consecutiveFailures = 0;
                    const hash = computeHash(content.selftext || "");
                    const postId = normalizeChapterId(content.postId || currentPostId);
                    // Check if this is a new chapter (not in existing list)
                    const isNew = !existingPostIds.has(postId) && !visitedPostIds.has(postId + "_reported");
                    if (isNew) {
                        discovered++;
                        const chapterUrl = content.url || currentUrl;
                        const chapter = {
                            title: content.title || `Chapter ${discovered}`,
                            url: chapterUrl,
                            postId: content.postId || currentPostId
                        };
                        newChapters.push(chapter);
                        sendLine({
                            type: "chapter",
                            postId: content.postId || currentPostId,
                            title: content.title,
                            author: content.author,
                            score: content.score ?? 0,
                            selftext: content.selftext || "",
                            selftextHtml: content.selftextHtml || "",
                            createdUtc: content.createdUtc ?? 0,
                            url: chapterUrl,
                            permalink: content.permalink || chapterUrl,
                            hash,
                            isNew: true,
                            discovered: discovered
                        });
                    } else {
                        // Already known chapter — still send it (for rehash purposes)
                        sendLine({
                            type: "chapter",
                            postId: content.postId || currentPostId,
                            title: content.title,
                            author: content.author,
                            score: content.score ?? 0,
                            selftext: content.selftext || "",
                            selftextHtml: content.selftextHtml || "",
                            createdUtc: content.createdUtc ?? 0,
                            url: content.url || currentUrl,
                            permalink: content.permalink || currentUrl,
                            hash,
                            isNew: false
                        });
                    }
                    visitedPostIds.add(postId + "_reported");
                    fetched++;
                    sendLine({
                        type: "progress",
                        discovered,
                        fetched,
                        errors
                    });
                    // Find next chapter link
                    const nextLinks = content.nextChapterLinks || [];
                    if (nextLinks.length === 0) {
                        // No next-chapter links — try Arctic Shift bulk search
                        // FX45 v30: Try JSONL first for chapter discovery
                        const partMatch = content.title.match(/[Pp]art\s+(\d+)/) || content.title.match(/[,\s]+0*(\d{2,})\s*$/);
                        if (partMatch) {
                            const currentPart = parseInt(partMatch[1]);
                            const titlePrefix = content.title.split(/[Pp]art\s+\d+/)[0].trim().replace(/[,]/g, " ").replace(/\s+/g, " ").trim();
                            const jsonlResult = _searchJsonlNextChapter(titlePrefix, currentPart);
                            if (jsonlResult) {
                                console.log("[continue-fetch] JSONL found next chapter: " + jsonlResult.title);
                                currentUrl = jsonlResult.url;
                                currentPostId = jsonlResult.id;
                                continue;
                            }
                        }
                        sendLine({
                            type: "info",
                            message: "No next-chapter links — trying Arctic Shift bulk search..."
                        });
                        // Extract the part number from the current title
                        // Handle both "Part 001" and "001" (without "Part" prefix)
                                                if (partMatch) {
                            const currentPart = parseInt(partMatch[1]);
                            const nextPart = currentPart + 1;
                            const seriesName = slug.replace(/_/g, " ");
                            // Extract the title prefix before the part number
                            // e.g., "OOCS, Into A Wider Galaxy, Part 001" → "OOCS Into A Wider Galaxy"
                            const titlePrefix = content.title.split(/[Pp]art\s+\d+/)[0].trim().replace(/[,]/g, " ").replace(/\s+/g, " ").trim();
                            // FX45 v10: Use Arctic Shift bulk search to find ALL chapters with the same title prefix
                            // Then find the next part number in the sorted results
                            // Cache search results to avoid re-searching for every chapter
                            if (!global.__arcticSearchCache) global.__arcticSearchCache = new Map();
                            const cacheKey = titlePrefix.toLowerCase();
                            let partPosts = global.__arcticSearchCache.get(cacheKey);
                            let foundNext = false;
                            try {
                                if (!partPosts) {
                                    // Search for the title prefix (e.g., "Out of Cruel Space")
                                    // FIX (task): Use the `title` parameter instead of `query`.
                                    // `query` searches both title AND selftext, returning posts that
                                    // merely mention the series name in their body (irrelevant results).
                                    // `title` searches titles only — much more precise.
                                    // Also use sort=desc (newest first) since OCS chapters are recent.
                                    // Limit to 100 to get enough chapters for the next-part lookup.
                                    const arcticSearchUrl = `https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=HFY&title=${encodeURIComponent(titlePrefix)}&limit=100&sort=desc`;
                                    const arcticSearchRes = await fetch(arcticSearchUrl, {
                                        signal: AbortSignal.timeout(30000),
                                        cache: "no-store",
                                        headers: { "Accept": "application/json" }
                                    });
                                    if (arcticSearchRes.ok) {
                                    const arcticSearchData = await arcticSearchRes.json();
                                    const allPosts = arcticSearchData?.data ?? [];
                                    // FIX (audit): Removed hardcoded "into a wider galaxy" and "oocs"
                                    // substring checks that were polluting search results for EVERY
                                    // series. Now only matches posts whose title contains the actual
                                    // titlePrefix of the current series being crawled.
                                    const titlePrefixLower = titlePrefix.toLowerCase();
                                    const matchingPosts = allPosts.filter(p => {
                                        const t = (p.title || "").toLowerCase();
                                        return t.includes(titlePrefixLower);
                                    });
                                    // Extract part numbers and find the next one
                                    partPosts = matchingPosts.map(p => {
                                        const m = p.title.match(/[Pp]art\s+0*(\d+)/) || p.title.match(/[,\s]+0*(\d{2,})\s*$/);
                                        return { post: p, partNum: m ? parseInt(m[1]) : 0 };
                                    }).filter(p => p.partNum > 0);
                                    // Sort by part number
                                    partPosts.sort((a, b) => a.partNum - b.partNum);
                                    // Cache the results
                                    global.__arcticSearchCache.set(cacheKey, partPosts);
                                    } // end if arcticSearchRes.ok
                                } // end if (!partPosts)
                                // Find the post with the next part number (from cache or fresh)
                                const nextPost = partPosts ? partPosts.find(p => p.partNum === nextPart) : null;
                                if (nextPost) {
                                    const permalink = nextPost.post.permalink || "";
                                    const url = permalink.startsWith("http") ? permalink : `https://www.reddit.com${permalink}`;
                                    const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
                                    const nextPostId = postIdMatch ? postIdMatch[1] : nextPost.post.id;
                                    if (nextPostId && !visitedPostIds.has(nextPostId.toLowerCase())) {
                                        sendLine({
                                            type: "info",
                                            message: `Found Part ${nextPart} via Arctic Shift bulk search: ${nextPost.post.title}`
                                        });
                                        currentUrl = url;
                                        currentPostId = nextPostId;
                                        visitedPostIds.add(nextPostId.toLowerCase());
                                        foundNext = true;
                                    }
                                }
                            } catch (e) {
                                sendLine({ type: "info", message: `Arctic Shift bulk search error: ${e.message}` });
                            }
                            sendLine({ type: "info", message: `DEBUG: after bulk search, foundNext=${foundNext}, partMatch=${partMatch ? partMatch[1] : 'null'}` });
                            if (!foundNext) {
                                // FX45 v10: Sequel transition — when no next part found, try searching for sequel
                                // FIX (audit): Run sequel transition for OCS and OOCS series.
                                // The OOCS sequel ("Into A Wider Galaxy") continues from OCS chapter 927.
                                // When crawling OCS and reaching the last chapter (927), we need to
                                // transition to the OOCS sequel. When crawling OOCS itself, we also
                                // need this to find "Part 1" if starting mid-series.
                                // Previously gated to OOCS only, which meant crawling OCS could not
                                // discover the sequel. Now fires for both OCS and OOCS.
                                const slugLower = (slug || '').toLowerCase();
                                const isOcsOrOocsSeries = slugLower.includes('oocs') ||
                                    slugLower.includes('out_of_cruel_space') ||
                                    slugLower.includes('into_a_wider_galaxy') ||
                                    slugLower.includes('into a wider galaxy');
                                sendLine({ type: "info", message: `Sequel transition check: slug="${slug}", isOcsOrOocsSeries=${isOcsOrOocsSeries}, foundNext=${foundNext}` });
                                if (isOcsOrOocsSeries) {
                                    try {
                                        // FIX (task): Updated sequel queries to use formats that
                                        // Arctic Shift API accepts. "Into A Wider Galaxy Part 1"
                                        // returns HTTP 422 (internal server error) — probably too
                                        // generic. "OOCS Into A Wider Galaxy Part 001" works.
                                        const sequelQueries = [
                                            "OOCS Into A Wider Galaxy Part 001",
                                            "OOCS Into A Wider Galaxy Part 1",
                                            "OOCS Into A Wider Galaxy Part 002",
                                            "Into A Wider Galaxy Part 001"
                                        ];
                                        sendLine({ type: "info", message: `Sequel transition: trying ${sequelQueries.length} queries to find OOCS Part 1...` });
                                        for (const sq of sequelQueries) {
                                            const sUrl = `https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=HFY&query=${encodeURIComponent(sq)}&limit=10`;
                                            const sRes = await fetch(sUrl, {
                                                signal: AbortSignal.timeout(15000),
                                                cache: "no-store",
                                                headers: { "Accept": "application/json" }
                                            });
                                            if (sRes.ok) {
                                                const sData = await sRes.json();
                                                const sPosts = sData?.data ?? [];
                                                for (const post of sPosts) {
                                                    const title = (post.title || "").toLowerCase();
                                                    // FIX (task): Use word-boundary regex to match "part 1" or "part 001"
                                                    // precisely. Previously `title.includes("part 1")` would also match
                                                    // "part 100", "part 12", etc. — causing false positives.
                                                    const isPart1 = /\bpart\s+0*1\b/i.test(title) || /\bpart\s+001\b/i.test(title);
                                                    if (title.includes("into a wider galaxy") && isPart1) {
                                                        const permalink = post.permalink || "";
                                                        const url = permalink.startsWith("http") ? permalink : `https://www.reddit.com${permalink}`;
                                                        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
                                                    const nextPostId = postIdMatch ? postIdMatch[1] : post.id;
                                                    if (nextPostId && !visitedPostIds.has(nextPostId.toLowerCase())) {
                                                        sendLine({
                                                            type: "info",
                                                            message: `Found sequel chapter: ${post.title}`
                                                        });
                                                        currentUrl = url;
                                                        currentPostId = nextPostId;
                                                        visitedPostIds.add(nextPostId.toLowerCase());
                                                        foundNext = true;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        if (foundNext) break;
                                    }
                                    if (!foundNext) {
                                        sendLine({ type: "info", message: "Sequel transition: no OOCS Part 1 found in any query" });
                                    }
                                } catch (e) {
                                    sendLine({ type: "info", message: `Sequel transition error: ${e.message}` });
                                }
                                } // end if (isOcsOrOocsSeries)
                            }
                            if (!foundNext) {
                                sendLine({
                                    type: "info",
                                    message: "Could not find next chapter via search — reached end of discoverable chapters"
                                });
                                break;
                            }
                            continue;
                        } else {
                            sendLine({
                                type: "info",
                                message: "No part number in title — reached end of series"
                            });
                            break;
                        }
                    }
                    // Pick the best next-chapter link that we haven't visited
                    // Prioritize links that match the series slug (e.g., "oocs_into_a_wider_galaxy")
                    // over links to other series (e.g., "out_of_cruel_space")
                    let nextUrl = null;
                    let nextPostId = null;
                    const slugLower = slug.toLowerCase();
                    const slugWords = slugLower.split("_").filter((w)=>w.length > 2);
                    // Sort links: prioritize ones containing the series slug words
                    const sortedLinks = [
                        ...nextLinks
                    ].sort((a, b)=>{
                        const aUrl = typeof a === "string" ? a : a.url || "";
                        const bUrl = typeof b === "string" ? b : b.url || "";
                        const aUrlLower = aUrl.toLowerCase();
                        const bUrlLower = bUrl.toLowerCase();
                        // Check if URL contains the slug or slug words
                        const aMatch = aUrlLower.includes(slugLower) || slugWords.some((w)=>aUrlLower.includes(w));
                        const bMatch = bUrlLower.includes(slugLower) || slugWords.some((w)=>bUrlLower.includes(w));
                        if (aMatch && !bMatch) return -1; // a first
                        if (!aMatch && bMatch) return 1; // b first
                        return 0;
                    });
                    for (const link of sortedLinks){
                        const linkUrl = typeof link === "string" ? link : link.url || "";
                        const linkPostIdMatch = linkUrl.match(/\/comments\/([a-z0-9]+)/i);
                        const linkPostId = linkPostIdMatch ? normalizeChapterId(linkPostIdMatch[1]) : "";
                        if (linkPostId && !visitedPostIds.has(linkPostId)) {
                            nextUrl = linkUrl;
                            nextPostId = linkPostId;
                            break;
                        }
                    }
                    if (!nextUrl || !nextPostId) {
                        sendLine({
                            type: "info",
                            message: "All next-chapter links already visited"
                        });
                        break;
                    }
                    currentUrl = nextUrl;
                    currentPostId = nextPostId;
                    visitedPostIds.add(nextPostId);
                    // Small delay to avoid rate limiting
                    await new Promise((r)=>setTimeout(r, 500));
                } catch (err) {
                    errors++;
                    consecutiveFailures++;
                    sendLine({
                        type: "error",
                        url: currentUrl,
                        error: err?.message?.slice(0, 200) || "Fetch failed",
                        consecutiveFailures
                    });
                    if (consecutiveFailures >= 3) {
                        sendLine({
                            type: "info",
                            message: "3 consecutive failures — stopping"
                        });
                        break;
                    }
                    // Retry after a short delay instead of stopping on first error
                    sendLine({
                        type: "info",
                        message: `Retrying in 2s (failure ${consecutiveFailures}/3)...`
                    });
                    await new Promise((r)=>setTimeout(r, 2000));
                    continue;
                }
            }
            // Persist newly discovered chapters to server storage
            let savedToServer = false;
            if (newChapters.length > 0) {
                try {
                    // Get existing imported chapters
                    const existing = await (0,user_chapters/* getImportedChapters */.bV)(slug);
                    const existingChapters = existing?.chapters || [];
                    const hardcoded = hfy_hardcoded_chapters/* HARDCODED_SERIES */.jb[slug];
                    const hardcodedChapters = hardcoded?.chapters || [];
                    // Merge: existing imported + new chapters (dedup by postId)
                    const allChapters = [
                        ...existingChapters,
                        ...hardcodedChapters.map((hc)=>({
                                title: hc.title,
                                url: hc.url,
                                postId: hc.postId
                            }))
                    ];
                    const seenPostIds = new Set(allChapters.map((c)=>c.postId));
                    const uniqueNew = newChapters.filter((c)=>!seenPostIds.has(c.postId));
                    if (uniqueNew.length > 0) {
                        const merged = [
                            ...existingChapters,
                            ...uniqueNew
                        ];
                        await (0,user_chapters/* saveImportedChapters */.cK)(slug, merged, {
                            source: "mixed",
                            synopsis: existing?.synopsis,
                            processedPostIds: existing?.processedPostIds
                        });
                        savedToServer = true;
                        sendLine({
                            type: "info",
                            message: `Saved ${uniqueNew.length} new chapters to server`
                        });
                    }
                } catch (err) {
                    sendLine({
                        type: "error",
                        error: `Failed to save chapters: ${err?.message}`
                    });
                }
            }
            sendLine({
                type: "summary",
                discovered,
                fetched,
                errors,
                savedToServer,
                newChapters: newChapters.length
            });
            sendLine({
                type: "done"
            });
            controller.close();
        }
    });
    return new Response(stream, {
        headers: {
            "Content-Type": "application/x-ndjson; charset=utf-8",
            "Cache-Control": "no-store, no-transform",
            "X-Accel-Buffering": "no"
        }
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch%2Froute&name=app%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch%2Froute&pagePath=private-next-app-dir%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/series/[slug]/continue-fetch/route",
        pathname: "/api/series/[slug]/continue-fetch",
        filename: "route",
        bundlePath: "app/api/series/[slug]/continue-fetch/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/series/[slug]/continue-fetch/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/series/[slug]/continue-fetch/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 5511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6439:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 9021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 9225:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


if (false) {} else {
    if (false) {} else {
        if (false) {} else {
            if (false) {} else {
                module.exports = __webpack_require__(4870);
            }
        }
    }
}

//# sourceMappingURL=module.compiled.js.map

/***/ }),

/***/ 9294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,4857,7101,4034], () => (__webpack_exec__(4987)));
module.exports = __webpack_exports__;

})();