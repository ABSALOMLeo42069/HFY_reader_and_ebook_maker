"use strict";
(() => {
var exports = {};
exports.id = 3697;
exports.ids = [3697];
exports.modules = {

/***/ 261:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ap: () => (/* binding */ extractChapterNumber)
/* harmony export */ });
/* unused harmony exports sortChaptersByNumber, normalizeUrlForDedup */
/**
 * Extract a chapter number from a title for DISPLAY purposes only.
 * Returns 0 if no number found — does NOT push to end.
 * Used for showing "Ch N" badges and gap detection, NOT for sorting.
 */ function extractChapterNumber(title) {
    let m = title.match(/[Cc]hapter\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    m = title.match(/[Pp]art\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    m = title.match(/[Ee]pisode\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    m = title.match(/\b(\d+\.?\d*)\b/);
    if (m) return parseFloat(m[1]);
    return 0;
}
/**
 * CRITICAL: Do NOT sort chapters by extracted number.
 * The source CSV/JSON files already have chapters in the correct
 * chronological order. Sorting by extractChapterNumber(title) BREAKS
 * the order because titles without a number (like "You learned nothing")
 * get parsed as 0/999 and pushed to the end.
 *
 * This function is a NO-OP — returns the array unchanged.
 */ function sortChaptersByNumber(chapters) {
    return chapters;
}
function normalizeUrlForDedup(url) {
    return url.replace(/^https?:\/\//, "").replace(/^(www\.|old\.|new\.|np\.)?reddit\.com/i, "reddit.com").replace(/[?#].*$/, "").replace(/\/$/, "").toLowerCase();
}


/***/ }),

/***/ 3033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4383:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Gz: () => (/* binding */ clearUserToken),
/* harmony export */   KN: () => (/* binding */ fetchWithOAuth),
/* harmony export */   R_: () => (/* binding */ setUserToken),
/* harmony export */   U2: () => (/* binding */ fetchWikiPageJson),
/* harmony export */   VH: () => (/* binding */ getRedditOAuthToken),
/* harmony export */   dE: () => (/* binding */ fetchWithRedDownloader),
/* harmony export */   fetchWithCookies: () => (/* binding */ fetchWithCookies),
/* harmony export */   searchSubreddit: () => (/* binding */ searchSubreddit)
/* harmony export */ });
/* unused harmony exports getUserToken, getUserRefreshToken, getAppOnlyToken, fetchWithProxyBrowser, fetchPostJson, fetchSubredditFeedJson */
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5511);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
// HFY NEKROCODEXXX — Reddit Downloaders Integration
// =====================================================
// Integrates 5 Reddit downloaders as a multi-tier fallback system:
//
//   1. DownloaderForReddit (DFR) — bundled client_id OAuth (frGEUVAuHGL2PQ)
//      Source: github.com/MalloyDelacroix/DownloaderForReddit
//      Type: OAuth (Installed App, app-only)
//
//   2. easy-reddit-downloader — authless .json with browser UA
//      Source: github.com/josephrcox/easy-reddit-downloader
//      Type: Authless (no OAuth, no login)
//      Approach: fetches www.reddit.com/.../.json with browser User-Agent
//
//   3. RedDownloader — authless .json (RedDownloader approach)
//      Source: github.com/Jackhammer9/RedDownloader
//      Type: Authless
//      Approach: same as easy-reddit-downloader (browser UA + .json)
//
//   4. reddit-json-scraper — authless .json
//      Source: github.com/0anxt/reddit-json-scraper
//      Type: Authless
//      Approach: public .json API, no auth
//
//   5. reddit-dl — OAuth + proxy support
//      Source: github.com/patrickkfkan/reddit-dl
//      Type: OAuth (user-provided) or proxy
//      Approach: supports account-specific content (saved posts, joined subs)
//
// TIER SYSTEM:
//   Tier B (PRIMARY): User OAuth (user logs in, 600 QPM, NSFW access)
//   Tier A (SECONDARY): DFR App-Only OAuth (bundled client_id, 100 QPM, public)
//   Tier R (TERTIARY): RedDownloader/easy-reddit-downloader/reddit-json-scraper
//                       (authless .json, no rate limit tracking, browser UA)
//   Tier P (QUATERNARY): reddit-dl proxy support (CORS proxy pool)
//   Tier S (LAST RESORT): RSS feeds (.rss endpoints, not blocked)

// =====================================================
// Client IDs (from DownloaderForReddit — pre-approved by Reddit)
// =====================================================
const BUNDLED_CLIENT_ID = process.env.REDDIT_BUNDLED_CLIENT_ID || "frGEUVAuHGL2PQ";
const USER_AGENT_DFR = "HFY-NEKROCODEXXX/1.0 (Reddit HFY series reader; fork of DownloaderForReddit approach)";
// easy-reddit-downloader uses a generic browser UA
const USER_AGENT_EASY = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
// reddit-json-scraper uses a Python UA
const USER_AGENT_RJS = "python:reddit-json-scraper:v1.0 (by /u/hfy_nekrocodexxx)";
// =====================================================
// Token management (Tier A + Tier B)
// =====================================================
let appTokenCache = null;
let userTokenCache = null;
function setUserToken(token, expiresIn, refreshToken) {
    userTokenCache = {
        token,
        expiresAt: Date.now() + expiresIn * 1000,
        refreshToken
    };
}
function clearUserToken() {
    userTokenCache = null;
}
function getUserToken() {
    if (userTokenCache && userTokenCache.expiresAt > Date.now() + 60000) {
        return userTokenCache.token;
    }
    return null;
}
function getUserRefreshToken() {
    return userTokenCache?.refreshToken || null;
}
// Tier A: App-Only OAuth (DFR bundled client_id)
async function getAppOnlyToken() {
    if (appTokenCache && appTokenCache.expiresAt > Date.now() + 60000) {
        return appTokenCache.token;
    }
    if (!BUNDLED_CLIENT_ID) return null;
    try {
        const deviceId = crypto__WEBPACK_IMPORTED_MODULE_0___default().randomBytes(15).toString("base64url").slice(0, 25);
        const res = await fetch("https://www.reddit.com/api/v1/access_token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Authorization: `Basic ${Buffer.from(`${BUNDLED_CLIENT_ID}:`).toString("base64")}`,
                "User-Agent": USER_AGENT_DFR
            },
            body: new URLSearchParams({
                grant_type: "https://oauth.reddit.com/grants/installed_client",
                device_id: deviceId
            }).toString(),
            signal: AbortSignal.timeout(10000),
            cache: "no-store"
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (!data.access_token) return null;
        appTokenCache = {
            token: data.access_token,
            expiresAt: Date.now() + (data.expires_in ?? 3600) * 1000
        };
        return data.access_token;
    } catch  {
        return null;
    }
}
function getMultiTokenStore() {
    if (!global.redditMultiTokens) {
        global.redditMultiTokens = new Map();
        global.redditTokenRotationIndex = 0;
    }
    return global.redditMultiTokens;
}
// Get the next token from the multi-account rotation (round-robin).
// Skips expired tokens (with 5-min buffer). Returns null if no live tokens.
function getNextMultiToken() {
    const store = getMultiTokenStore();
    if (store.size === 0) return null;
    const accounts = Array.from(store.entries()).filter(([, v])=>v.accessToken && Date.now() < v.expiresAt - 5 * 60 * 1000);
    if (accounts.length === 0) return null;
    const idx = (global.redditTokenRotationIndex || 0) % accounts.length;
    global.redditTokenRotationIndex = idx + 1;
    const [, tokenData] = accounts[idx];
    return {
        token: tokenData.accessToken,
        username: tokenData.username
    };
}
// Get best available OAuth token.
// Priority: multi-account rotation → userTokenCache → appTokenCache.
async function getRedditOAuthToken() {
    // Tier B (multi-account rotation) — preferred, gives 600 QPM × N accounts
    const multi = getNextMultiToken();
    if (multi) return {
        token: multi.token,
        tier: "user"
    };
    // Tier B (single user token from /api/reddit-user-token)
    const userToken = getUserToken();
    if (userToken) return {
        token: userToken,
        tier: "user"
    };
    // Tier A (anonymous app-only, 100 QPM)
    const appToken = await getAppOnlyToken();
    if (appToken) return {
        token: appToken,
        tier: "app"
    };
    return null;
}
async function fetchWithOAuth(url, options = {}) {
    const auth = await getRedditOAuthToken();
    let oauthUrl = url;
    // Convert www.reddit.com → oauth.reddit.com (only for .json/wiki/search, NOT .rss)
    if (!url.includes(".rss")) {
        oauthUrl = url.replace("://www.reddit.com", "://oauth.reddit.com").replace("://old.reddit.com", "://oauth.reddit.com").replace("://new.reddit.com", "://oauth.reddit.com").replace("://np.reddit.com", "://oauth.reddit.com");
    }
    const headers = {
        "User-Agent": USER_AGENT_DFR,
        Accept: "application/json",
        ...options.headers || {}
    };
    if (auth) headers["Authorization"] = `Bearer ${auth.token}`;
    try {
        const res = await fetch(oauthUrl, {
            method: options.method || "GET",
            headers,
            body: options.body,
            signal: AbortSignal.timeout(options.timeoutMs || 15000),
            cache: "no-store"
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text,
            tier: auth?.tier || "none",
            headers: res.headers
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed",
            tier: auth?.tier || "none",
            headers: new Headers()
        };
    }
}
// =====================================================
// Tier R: Authless fallback (RedDownloader + easy-reddit-downloader + reddit-json-scraper)
// =====================================================
// All three of these downloaders use the same approach: fetch .json endpoints
// directly with a browser-like User-Agent. No OAuth needed.
//
// We try multiple User-Agents in case Reddit blocks one:
//   1. easy-reddit-downloader UA (Chrome browser)
//   2. reddit-json-scraper UA (Python bot)
//   3. RedDownloader UA (generic browser)
const AUTHLESS_UAS = [
    USER_AGENT_EASY,
    USER_AGENT_RJS,
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
];
async function fetchWithRedDownloader(url, timeoutMs = 12000) {
    let jsonUrl = url;
    if (!jsonUrl.endsWith(".json")) {
        jsonUrl = jsonUrl.replace(/[?#].*$/, "").replace(/\/$/, "") + ".json";
    }
    // Try each User-Agent until one works
    for (const ua of AUTHLESS_UAS){
        try {
            const res = await fetch(jsonUrl, {
                headers: {
                    "User-Agent": ua,
                    Accept: "application/json, text/html",
                    "Accept-Language": "en-US,en;q=0.9"
                },
                signal: AbortSignal.timeout(timeoutMs),
                cache: "no-store"
            });
            if (res.ok) {
                const text = await res.text();
                // Verify it's actually JSON (not an error page)
                if (text.trim().startsWith("{") || text.trim().startsWith("[")) {
                    return {
                        ok: true,
                        status: res.status,
                        text
                    };
                }
            }
        } catch  {
        // try next UA
        }
    }
    return {
        ok: false,
        status: 0,
        text: "all authless UAs failed"
    };
}
// =====================================================
// Tier P+: Proxy Browser fallback
// =====================================================
// Routes the fetch through our own /api/proxy-browser endpoint,
// which maintains a server-side cookie jar. Once the user has
// logged in to Reddit through the InAppBrowser, every subsequent
// request here will carry their session cookies and behave like a
// residential-IP request (no Reddit IP block).
//
// NOTE: this is a server-side fetch (called from API routes), so
// the relative URL is resolved against the app's own origin.
// =====================================================
async function fetchWithProxyBrowser(url, timeoutMs = 15000) {
    try {
        // We can't read process.env.NEXT_PUBLIC_APP_URL reliably across
        // every deployment, so fall back to a relative URL. Inside an
        // API route, fetch() with a relative URL resolves against the
        // current request origin — which is what we want.
        const proxyUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
        const target = proxyUrl ? `${proxyUrl.replace(/\/$/, "")}/api/proxy-browser?url=${encodeURIComponent(url)}` : `/api/proxy-browser?url=${encodeURIComponent(url)}`;
        const res = await fetch(target, {
            signal: AbortSignal.timeout(timeoutMs),
            cache: "no-store",
            headers: {
                "User-Agent": USER_AGENT_EASY,
                Accept: "application/json, text/html, */*"
            }
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed"
        };
    }
}
// =====================================================
// Convenience helpers (with full tier cascade)
// =====================================================
async function fetchWikiPageJson(subreddit, wikiSlug) {
    const cleanSlug = wikiSlug.replace(/^\/+|\/+$/g, "");
    const url = `https://www.reddit.com/r/${subreddit}/wiki/${cleanSlug}`;
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 15000
    });
    if (res.ok) {
        try {
            return JSON.parse(res.text);
        } catch  {}
    }
    // Tier R: RedDownloader/easy-reddit-downloader/reddit-json-scraper
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            return JSON.parse(rd.text);
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            return JSON.parse(pb.text);
        } catch  {}
    }
    return null;
}
async function fetchPostJson(postIdOrUrl) {
    let url;
    if (postIdOrUrl.startsWith("http")) {
        url = postIdOrUrl.replace(/[?#].*$/, "").replace(/\/$/, "");
    } else {
        url = `https://www.reddit.com/r/HFY/comments/${postIdOrUrl}/`;
    }
    // Tier A/B: OAuth
    const res = await fetchWithOAuth(url, {
        timeoutMs: 15000
    });
    if (res.ok) {
        try {
            return JSON.parse(res.text);
        } catch  {}
    }
    // Tier R: authless
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            return JSON.parse(rd.text);
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            return JSON.parse(pb.text);
        } catch  {}
    }
    return null;
}
async function searchSubreddit(subreddit, query, sort = "relevance", limit = 100) {
    // FX45 v30: JSONL PRIMARY
    try {
        const jsonlResults = _searchJsonlFM(query, subreddit, limit);
        if (jsonlResults && jsonlResults.length > 0) {
            console.log("[fetch-missing] JSONL search: " + jsonlResults.length + " results");
            return jsonlResults;
        }
    } catch (e) { console.log("[fetch-missing] JSONL search failed: " + e.message); }
    // FALLBACK: Arctic Shift
    try {
        const arcticUrl = "https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=" + encodeURIComponent(subreddit) + "&query=" + encodeURIComponent(query) + "&limit=" + limit;
        const arcticRes = await fetch(arcticUrl, { signal: AbortSignal.timeout(15000), cache: "no-store" });
        if (arcticRes.ok) {
            const arcticData = await arcticRes.json();
            const posts = arcticData?.data ?? arcticData;
            if (Array.isArray(posts) && posts.length > 0) return posts.map(p => ({ data: { id: p.id, postId: p.id, title: p.title, author: p.author, score: p.score || 0, created_utc: p.created_utc, subreddit: p.subreddit, permalink: p.permalink } }));
        }
    } catch (e) { console.log("[fetch-missing] Arctic Shift search failed: " + e.message); }
    // FALLBACK: Authless JSON
    const params = new URLSearchParams({ q: query, sort, restrict_sr: "1", limit: String(limit) });
    const url = "https://www.reddit.com/r/" + subreddit + "/search?" + params;
    const rd = await fetchWithRedDownloader(url, 12000);
    if (res.ok) {
        try {
            const data = JSON.parse(res.text);
            return data?.data?.children ?? [];
        } catch  {}
    }
    // Tier R: authless
    const rd = await fetchWithRedDownloader(url, 12000);
    if (rd.ok) {
        try {
            const data = JSON.parse(rd.text);
            return data?.data?.children ?? [];
        } catch  {}
    }
    // Tier P+: proxy browser fallback (carries user cookies)
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            const data = JSON.parse(pb.text);
            return data?.data?.children ?? [];
        } catch  {}
    }
    return null;
}
async function fetchSubredditFeedJson(subreddit, sort = "new", limit = 100, after) {
    const params = new URLSearchParams({
        sort,
        limit: String(limit)
    });
    if (after) params.set("after", after);
    const url = `https://www.reddit.com/r/${subreddit}/${sort}?${params}`;
    const res = await fetchWithOAuth(url, {
        timeoutMs: 12000
    });
    if (res.ok) {
        try {
            const data = JSON.parse(res.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    // Tier P+: proxy browser fallback
    const pb = await fetchWithProxyBrowser(url, 15000);
    if (pb.ok) {
        try {
            const data = JSON.parse(pb.text);
            return {
                posts: data?.data?.children ?? [],
                after: data?.data?.after ?? null
            };
        } catch  {}
    }
    return null;
}
// =====================================================
// Cookie-based fetch — uses user-provided Reddit session cookies
// to bypass rate limits. Cookies are loaded from data/reddit-cookies.json
// =====================================================


let cachedCookieString = null;
let cookieCheckTime = 0;
function getRedditCookies() {
    // Re-check every 30 seconds (in case cookies were added after startup)
    if (cachedCookieString !== null && Date.now() - cookieCheckTime < 30000) {
        return cachedCookieString || null;
    }
    cachedCookieString = null;
    cookieCheckTime = Date.now();
    try {
        const cookiePaths = [
            process.env.HFY_DATA_DIR ? (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.env.HFY_DATA_DIR, "reddit-cookies.json") : (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(process.cwd(), "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "..", "data", "reddit-cookies.json"),
            (0,path__WEBPACK_IMPORTED_MODULE_2__.join)(__dirname, "..", "..", "data", "reddit-cookies.json")
        ];
        for (const cookiePath of cookiePaths){
            try {
                const content = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(cookiePath, "utf8");
                const cookies = JSON.parse(content);
                if (Array.isArray(cookies) && cookies.length > 0) {
                    cachedCookieString = cookies.filter((c)=>c.name && c.value).map((c)=>`${c.name}=${c.value}`).join("; ");
                    if (cachedCookieString) return cachedCookieString;
                }
            } catch  {}
        }
    } catch  {}
    cachedCookieString = "";
    return null;
}
async function fetchWithCookies(url, options = {}) {
    const cookieStr = getRedditCookies();
    if (!cookieStr) return {
        ok: false,
        status: 0,
        text: "No cookies"
    };
    try {
        const res = await fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Cookie": cookieStr,
                "Accept": "application/json, text/html, */*"
            },
            signal: AbortSignal.timeout(options.timeoutMs || 12000),
            cache: "no-store"
        });
        const text = await res.text();
        return {
            ok: res.ok,
            status: res.status,
            text
        };
    } catch (err) {
        return {
            ok: false,
            status: 0,
            text: err?.message || "fetch failed"
        };
    }
}


/***/ }),

/***/ 4870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 4945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bV: () => (/* binding */ getImportedChapters),
/* harmony export */   cK: () => (/* binding */ saveImportedChapters),
/* harmony export */   rj: () => (/* binding */ parseRedditWikiForChapters),
/* harmony export */   sortChaptersByNumber: () => (/* binding */ sortChaptersByNumber)
/* harmony export */ });
/* unused harmony export extractChapterNumber */
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9021);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3873);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
// HFY NEKROCODEXXX — User-Imported Chapter Cache
// =====================================================
// Stores chapter lists that the USER imports from their
// browser (which isn't IP-blocked by Reddit) via the
// bookmarklet or paste-HTML fallback.
//
// Storage strategy:
//   - In-memory Map for fast reads
//   - Filesystem persistence at /home/z/my-project/data/user-chapters/
//     so imports survive server restarts
//
// Endpoints use this:
//   POST /api/series/[slug]/chapters — writes
//   GET  /api/series/[slug]/chapters — reads


// CRITICAL: Use multiple path resolution strategies to ensure chapters persist
// across restarts. process.cwd() can change on Android, so we also try
// __dirname (relative to this file in the standalone build) and a fixed path.
const POSSIBLE_DATA_DIRS = [
    // Priority 1: HFY_DATA_DIR (Android persistent storage — getFilesDir/hfy-data)
    process.env.HFY_DATA_DIR ? path__WEBPACK_IMPORTED_MODULE_1___default().join(process.env.HFY_DATA_DIR, "user-chapters") : path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "data", "user-chapters"),
    path__WEBPACK_IMPORTED_MODULE_1___default().join(__dirname, "..", "..", "data", "user-chapters")
];
// Use the first directory that exists and has data, or create the first one
let DATA_DIR = POSSIBLE_DATA_DIRS[0];
for (const dir of POSSIBLE_DATA_DIRS){
    try {
        const files = (__webpack_require__(9021).readdirSync)(dir);
        if (files.length > 0) {
            DATA_DIR = dir;
            break;
        }
    } catch  {
    // Directory doesn't exist, try next
    }
}
// In-memory cache
const cache = new Map();
// Ensure data dir exists
async function ensureDir() {
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.mkdir(DATA_DIR, {
            recursive: true
        });
    } catch  {
    // ignore
    }
}
function filePath(slug) {
    // Sanitize slug — only allow alphanumeric + underscore + hyphen
    const safe = slug.replace(/[^a-zA-Z0-9_-]/g, "_");
    return path__WEBPACK_IMPORTED_MODULE_1___default().join(DATA_DIR, `${safe}.json`);
}
/** Get imported chapters for a series slug */ async function getImportedChapters(slug) {
    // Check memory first, but verify against filesystem mtime
    // (the auto-discover route may have updated the file in a different
    // Next.js worker process with its own in-memory cache)
    const fp = filePath(slug);
    try {
        const stat = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.stat(fp);
        const cached = cache.get(slug);
        if (cached && cached.importedAt >= stat.mtimeMs) {
            // Cache is fresh
            return cached;
        }
        // Cache is stale or missing — reload from filesystem
        const content = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(fp, "utf8");
        let parsed;
        try {
            parsed = JSON.parse(content);
        } catch (parseErr) {
            // Corrupted JSON file — delete it and return null
            console.warn(`[user-chapters] Corrupted file for ${slug}, deleting:`, parseErr);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Validate: ensure chapters array exists and isn't excessively large
        if (!parsed.chapters || !Array.isArray(parsed.chapters)) {
            console.warn(`[user-chapters] Invalid chapters for ${slug}, deleting`);
            try {
                await fs__WEBPACK_IMPORTED_MODULE_0__.promises.unlink(fp);
            } catch  {}
            return null;
        }
        // Cap at 50000 chapters to prevent OOM (was 2000 — too low, caused data loss)
        if (parsed.chapters.length > 50000) {
            console.warn(`[user-chapters] Truncating ${parsed.chapters.length} chapters to 50000 for ${slug}`);
            parsed.chapters = parsed.chapters.slice(0, 50000);
        }
        cache.set(slug, parsed);
        return parsed;
    } catch  {
        // File doesn't exist
        if (cache.has(slug)) return cache.get(slug);
        return null;
    }
}
/** Save imported chapters for a series slug */ async function saveImportedChapters(slug, chapters, options = {}) {
    await ensureDir();
    // DEDUPLICATION: remove duplicate chapters by postId AND by normalized URL.
    // This is critical because parallel stages (RSS crawler, Wayback crawler,
    // JSON crawler, hfy.foundation) may all discover the same chapter.
    // We normalize URLs to catch duplicates that differ only in trailing
    // slashes, www prefix, or http vs https.
    const seenPostIds = new Set();
    const seenUrlKeys = new Set();
    const deduped = [];
    for (const c of chapters){
        if (!c.postId) continue;
        // Normalize URL for dedup (strip protocol/www/trailing slash/query)
        const urlKey = normalizeUrlForDedup(c.url);
        if (seenPostIds.has(c.postId) || seenUrlKeys.has(urlKey)) {
            continue; // skip duplicate
        }
        seenPostIds.add(c.postId);
        seenUrlKeys.add(urlKey);
        deduped.push(c);
    }
    // Merge processedPostIds with any existing ones (for resume-crawl)
    const existing = cache.get(slug);
    const processedSet = new Set([
        ...existing?.processedPostIds ?? [],
        ...options.processedPostIds ?? []
    ]);
    const list = {
        slug,
        chapters: deduped,
        // Preserve existing synopsis if the caller doesn't provide one.
        // This prevents reparse/fetch-missing/add-chapter from wiping the
        // synopsis that was previously saved.
        synopsis: options.synopsis !== undefined ? options.synopsis : existing?.synopsis,
        importedAt: Date.now(),
        source: options.source || "manual",
        processedPostIds: Array.from(processedSet)
    };
    cache.set(slug, list);
    try {
        await fs__WEBPACK_IMPORTED_MODULE_0__.promises.writeFile(filePath(slug), JSON.stringify(list, null, 2), "utf8");
    } catch (err) {
        console.warn(`[user-chapters] Failed to persist ${slug}:`, err);
    }
    return list;
}
/**
 * Normalize a Reddit URL for deduplication purposes.
 * Strips: protocol, www/old/new prefix, trailing slash, query params, fragments.
 * "https://www.reddit.com/r/HFY/comments/abc123/chapter_1/" → "reddit.com/r/HFY/comments/abc123"
 */ /**
 * Extract a chapter number from a title for sorting.
 * Handles: "Chapter 42", "Part 3", "Episode 7", "Interlude 4", "Chapter 7.1"
 * Returns 999 for non-chapter posts (sorted to end).
 */ function extractChapterNumber(title) {
    // Try "Chapter N" or "Chapter N.M"
    let m = title.match(/[Cc]hapter\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Try "Part N"
    m = title.match(/[Pp]art\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Try "Episode N"
    m = title.match(/[Ee]pisode\s+(\d+\.?\d*)/);
    if (m) return parseFloat(m[1]);
    // Interludes
    if (/interlude/i.test(title)) {
        m = title.match(/[Ii]nterlude\s+(\d+)/);
        if (m) return parseFloat(m[1]) + 0.5;
        return 999; // unnamed interlude
    }
    return 999; // unknown — sort to end
}
/**
 * CRITICAL: Do NOT sort chapters by extracted number.
 * The source CSV/JSON files already have chapters in the correct
 * chronological order. Sorting BREAKS the order because titles without
 * a number get parsed as 999 and pushed to the end.
 *
 * This function is a NO-OP — returns the array unchanged.
 */ function sortChaptersByNumber(chapters) {
    return chapters;
}
function normalizeUrlForDedup(url) {
    return url.replace(/^https?:\/\//, "").replace(/^(www\.|old\.|new\.|np\.)?reddit\.com/i, "reddit.com").replace(/[?#].*$/, "").replace(/\/$/, "").toLowerCase();
}
/** Parse a Reddit wiki page HTML (or markdown) for chapter links */ function parseRedditWikiForChapters(html) {
    const chapters = [];
    const seen = new Set();
    // Helper: strip Wayback Machine wrapper from URLs
    // http://web.archive.org/web/20250801/https://www.reddit.com/... → https://www.reddit.com/...
    function stripWayback(url) {
        const m = url.match(/https?:\/\/web\.archive\.org\/web\/\d+\/(https?:\/\/.+)/i);
        return m ? m[1] : url;
    }
    // Strategy 1: HTML anchor tags
    const aRe = /<a[^>]+href=["'](https?:\/\/[^"']*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^"']*)["'][^>]*>([^<]+)<\/a>/gi;
    let m;
    while((m = aRe.exec(html)) !== null){
        const url = stripWayback(m[1].trim());
        const title = m[2].trim() || "Chapter";
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                chapters.push({
                    title,
                    url,
                    postId
                });
            }
        }
    }
    // Strategy 2: Markdown links [text](url)
    const mdRe = /\[([^\]]+)\]\((https?:\/\/[^)]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^)]*)\)/gi;
    while((m = mdRe.exec(html)) !== null){
        const title = m[1].trim();
        const url = stripWayback(m[2].trim());
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                chapters.push({
                    title,
                    url,
                    postId
                });
            }
        }
    }
    // Strategy 3: Bare URLs — try to extract a title from surrounding text
    const bareRe = /(https?:\/\/[^\s"'<\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s"'<\]]*)/gi;
    while((m = bareRe.exec(html)) !== null){
        const url = stripWayback(m[1].trim());
        const postIdMatch = url.match(/\/comments\/([a-z0-9]+)/i);
        if (postIdMatch) {
            const postId = postIdMatch[1];
            if (!seen.has(postId)) {
                seen.add(postId);
                // Try to grab surrounding text as the title.
                const start = Math.max(0, m.index - 80);
                const end = Math.min(html.length, m.index + url.length + 80);
                const context = html.slice(start, end).replace(m[1], " ").trim();
                const beforeMatch = context.match(/([^\n•\-*|]{3,80})\s*(?:—|–|-|:|\s)\s*$/);
                const afterMatch = context.match(/^\s*(?:—|–|-|:|\s)\s*([^\n•\-*|]{3,80})/);
                let title = "Chapter";
                if (beforeMatch && beforeMatch[1].trim().length > 2) {
                    title = beforeMatch[1].trim();
                } else if (afterMatch && afterMatch[1].trim().length > 2) {
                    title = afterMatch[1].trim();
                } else {
                    const chapRe = /Chapter\s+\d+[:\s-]*[^\n]{0,80}/i;
                    const chapM = context.match(chapRe);
                    if (chapM) title = chapM[0].trim();
                }
                if (title === "Chapter") {
                    const slugM = url.match(/\/comments\/[a-z0-9]+\/([^/?]+)\//i);
                    if (slugM) {
                        title = slugM[1].replace(/_/g, " ").replace(/\b\w/g, (c)=>c.toUpperCase());
                    }
                }
                chapters.push({
                    title: title.slice(0, 200).replace(/[—–\-:]\s*$/, "").trim() || "Chapter",
                    url,
                    postId
                });
            }
        }
    }
    // Extract synopsis — first paragraph of meaningful text
    let synopsis = "";
    // Strip HTML tags to get plain text
    const text = html.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, " ").trim();
    const sentences = text.split(/(?<=[.!?])\s+/);
    for (const s of sentences){
        if (s.length > 60 && s.length < 400 && !s.includes("http") && !s.includes("reddit.com")) {
            synopsis = s;
            break;
        }
    }
    return {
        chapters,
        synopsis
    };
}


/***/ }),

/***/ 5511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6439:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 7748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/series/[slug]/fetch-missing/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST),
  dynamic: () => (dynamic),
  maxDuration: () => (maxDuration),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: ./src/lib/user-chapters.ts
var user_chapters = __webpack_require__(4945);
// EXTERNAL MODULE: ./src/lib/hfy-hardcoded-chapters.ts + 23 modules
var hfy_hardcoded_chapters = __webpack_require__(1781);
// EXTERNAL MODULE: ./src/lib/chapter-utils.ts
var chapter_utils = __webpack_require__(924);
// EXTERNAL MODULE: ./src/lib/reddit-oauth.ts
var reddit_oauth = __webpack_require__(4383);
// FX45 v9 (task): easy-reddit-downloader JSON fallback for gap-fill search.
// The easy-reddit-downloader module (7614) only exports downloadFromPostUrl
// for single-post fetches. For SEARCH, we use reddit_scraper.searchSeries
// which internally falls back through: Arctic Shift → cookies → CORS proxy
// pool (the easy-reddit-downloader JSON approach via /r/HFY/search.json).
// EXTERNAL MODULE: ./src/lib/easy-reddit-downloader.ts
var easy_reddit_downloader = __webpack_require__(7614);
// EXTERNAL MODULE: ./src/lib/reddit-scraper.ts (for searchSeries fallback)
var reddit_scraper = __webpack_require__(4034);
// FX45 v30: JSONL reader for GAPS/fetch-missing
const fs = require("fs");
const path = require("path");
let _jsonlIdxFM = null;
function _findJsonlDirFM() {
    const candidates = [
        process.env.HFY_DATA_DIR ? path.join(process.env.HFY_DATA_DIR, "jsonl") : null,
        path.join(process.cwd(), "data", "jsonl"),
        path.join(process.cwd(), "..", "jsonl"),
        "/home/z/my-project/data/jsonl",
    ].filter(Boolean);
    for (const dir of candidates) {
        try { if (fs.existsSync(dir)) { const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl")); if (files.length > 0) return dir; } } catch {}
    }
    return null;
}
function _buildJsonlIdxFM() {
    if (_jsonlIdxFM) return;
    const dir = _findJsonlDirFM();
    if (!dir) return;
    _jsonlIdxFM = new Map();
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl"));
    for (const fileName of files) {
        try {
            const stat = fs.statSync(path.join(dir, fileName));
            if (stat.size > 500 * 1024 * 1024) continue;
            const content = fs.readFileSync(path.join(dir, fileName), "utf8");
            for (const line of content.split("\n")) {
                if (!line.trim()) continue;
                try {
                    const post = JSON.parse(line);
                    const pid = (post.id || "").toLowerCase();
                    if (pid) _jsonlIdxFM.set(pid, { title: post.title || "", score: post.score || 0, created_utc: post.created_utc || 0, subreddit: post.subreddit || "", permalink: post.permalink || "" });
                } catch {}
            }
        } catch {}
    }
    console.log("[fetch-missing] JSONL index: " + _jsonlIdxFM.size + " posts from " + files.length + " files");
}
function _searchJsonlFM(query, subreddit, limit) {
    if (!_jsonlIdxFM) _buildJsonlIdxFM();
    if (!_jsonlIdxFM) return [];
    const q = (query || "").toLowerCase();
    const results = [];
    for (const [pid, meta] of _jsonlIdxFM) {
        if (subreddit && meta.subreddit.toLowerCase() !== subreddit.toLowerCase()) continue;
        if (q && !(meta.title || "").toLowerCase().includes(q)) continue;
        results.push({ data: { id: pid, postId: pid, title: meta.title, author: meta.author, score: meta.score, created_utc: meta.created_utc, subreddit: meta.subreddit, permalink: meta.permalink } });
        if (results.length >= limit) break;
    }
    results.sort((a, b) => (b.data.score || 0) - (a.data.score || 0));
    return results;
}

;// ./src/app/api/series/[slug]/fetch-missing/route.ts
// POST /api/series/[slug]/fetch-missing
// Searches Reddit via Arctic Shift (primary) + easy-reddit-downloader JSON (fallback)
// for missing chapters, adds to user cache.





const runtime = "nodejs";
const dynamic = "force-dynamic";
const maxDuration = 300;
async function POST(_req, { params }) {
    const { slug } = await params;
    if (!slug) return server.NextResponse.json({
        ok: false,
        error: "Missing slug"
    }, {
        status: 400
    });
    const existingChapters = [];
    const hardcoded = hfy_hardcoded_chapters/* HARDCODED_SERIES */.jb[slug];
    if (hardcoded) {
        for (const ch of hardcoded.chapters){
            const num = (0,chapter_utils/* extractChapterNumber */.ap)(ch.title);
            if (num > 0 && num < 100000) existingChapters.push({
                num,
                title: ch.title,
                url: ch.url,
                postId: ch.postId
            });
        }
    }
    const imported = await (0,user_chapters/* getImportedChapters */.bV)(slug);
    if (imported) {
        for (const ch of imported.chapters){
            const num = (0,chapter_utils/* extractChapterNumber */.ap)(ch.title);
            if (num > 0 && num < 100000 && !existingChapters.some((c)=>c.num === num)) {
                existingChapters.push({
                    num,
                    title: ch.title,
                    url: ch.url,
                    postId: ch.postId
                });
            }
        }
    }
    if (existingChapters.length === 0) {
        return server.NextResponse.json({
            ok: false,
            error: "No existing chapters with numbers"
        });
    }
    existingChapters.sort((a, b)=>a.num - b.num);
    const maxChapter = existingChapters[existingChapters.length - 1].num;
    const foundNumbers = new Set(existingChapters.map((c)=>c.num));
    const missing = [];
    for(let i = 1; i <= maxChapter; i++){
        if (!foundNumbers.has(i)) missing.push(i);
    }
    if (missing.length === 0) {
        return server.NextResponse.json({
            ok: true,
            slug,
            message: "No gaps detected",
            found: 0,
            stillMissing: 0
        });
    }
    // FX45 v8: Use Arctic Shift API for search (no OAuth needed)
    // Arctic Shift is not blocked by Reddit and returns real data
    const seriesName = hardcoded?.title || slug.replace(/_/g, " ");
    const seriesNameLower = seriesName.toLowerCase();
    const slugWords = slug.replace(/_/g, " ").toLowerCase();
    // FIX (audit): removed hardcoded "OOCS" queries that were polluting search
    // results for every non-OOCS series. The queries below are now derived
    // solely from the actual series name + slug, plus generic "part N" variants.
    const foundChapters = [];
    const stillMissing = [];
    let searchCount = 0;
    for (const missingNum of missing){
        searchCount++;
        if (searchCount % 30 === 0) await new Promise((r)=>setTimeout(r, 2000));
        const queries = [
            `${seriesName} ${missingNum}`,
            `${seriesName} part ${missingNum}`,
            `${seriesName} chapter ${missingNum}`,
            `${slugWords} ${missingNum}`,
            `${slugWords} part ${missingNum}`
        ];
        let found = false;
        for (const query of queries){
            try {
                // FX45 v8: Arctic Shift API search (no OAuth needed)
                const arcticUrl = `https://arctic-shift.photon-reddit.com/api/posts/search?subreddit=HFY&query=${encodeURIComponent(query)}&limit=25`;
                const arcticRes = await fetch(arcticUrl, {
                    signal: AbortSignal.timeout(15000),
                    cache: "no-store",
                    headers: { "Accept": "application/json" }
                });
                if (arcticRes.ok) {
                    const arcticData = await arcticRes.json();
                    const posts = arcticData?.data ?? [];
                    if (Array.isArray(posts) && posts.length > 0) {
                        for (const post of posts){
                            const title = (post.title || "").toLowerCase();
                            const partMatch = new RegExp(`\\bpart\\s+0*${missingNum}\\b`, "i").test(title) || new RegExp(`\\b0*${missingNum}\\b`).test(title);
                            const chMatch = new RegExp(`\\bch(apter)?\\s+0*${missingNum}\\b`, "i").test(title);
                            // FIX (audit): removed `|| title.includes("oocs")` from hasSeriesName —
                            // that check matched ANY post mentioning "oocs" regardless of the
                            // actual series being searched.
                            const hasSeriesName = title.includes(seriesNameLower) || title.includes(slugWords);
                            if ((partMatch || chMatch) && hasSeriesName) {
                                const permalink = post.permalink || "";
                                const url = permalink.startsWith("http") ? permalink : `https://www.reddit.com${permalink}`;
                                const postId = post.id || permalink.match(/\/comments\/([a-z0-9]+)/i)?.[1] || "";
                                foundChapters.push({
                                    title: post.title || `Part ${missingNum}`,
                                    url,
                                    postId
                                });
                                found = true;
                                break;
                            }
                        }
                    }
                }
                if (found) break;
            } catch {}

            // FX45 v9 (task): easy-reddit-downloader JSON fallback.
            // If Arctic Shift direct search fails or finds no match for this
            // query, fall back to reddit_scraper.searchSeries which internally
            // tries: Arctic Shift → cookies → CORS proxy pool (the easy-reddit-
            // downloader JSON approach via /r/HFY/search.json with browser UAs).
            if (!found) {
                try {
                    const results = await (0,reddit_scraper/* searchSeries */.mG)(query, "relevance");
                    if (Array.isArray(results) && results.length > 0) {
                        for (const post of results) {
                            const title = (post.title || "").toLowerCase();
                            const partMatch = new RegExp(`\\bpart\\s+0*${missingNum}\\b`, "i").test(title) || new RegExp(`\\b0*${missingNum}\\b`).test(title);
                            const chMatch = new RegExp(`\\bch(apter)?\\s+0*${missingNum}\\b`, "i").test(title);
                            const hasSeriesName = title.includes(seriesNameLower) || title.includes(slugWords);
                            if ((partMatch || chMatch) && hasSeriesName) {
                                const url = post.wikiUrl || "";
                                const postId = post.id || url.match(/\/comments\/([a-z0-9]+)/i)?.[1] || "";
                                foundChapters.push({
                                    title: post.title || `Part ${missingNum}`,
                                    url,
                                    postId
                                });
                                found = true;
                                break;
                            }
                        }
                    }
                } catch (e) {
                    console.log(`[fetch-missing] easy-reddit-downloader JSON fallback failed for "${query}": ${e?.message}`);
                }
            }
            if (found) break;
        }
        if (!found) stillMissing.push(missingNum);
    }
    if (foundChapters.length > 0) {
        const existingCache = imported?.chapters || [];
        const existingUrls = new Set(existingCache.map((c)=>c.url));
        const newChapters = foundChapters.filter((c)=>!existingUrls.has(c.url));
        const merged = [
            ...existingCache,
            ...newChapters
        ];
        await (0,user_chapters/* saveImportedChapters */.cK)(slug, merged, {
            source: "mixed",
            processedPostIds: imported?.processedPostIds
        });
    }
    return server.NextResponse.json({
        ok: true,
        slug,
        seriesName,
        maxChapter,
        existingChapters: existingChapters.length,
        missingCount: missing.length,
        found: foundChapters.length,
        stillMissing: stillMissing.length,
        stillMissingNumbers: stillMissing.slice(0, 50),
        foundChapters: foundChapters.map((c)=>({
                title: c.title,
                url: c.url,
                postId: c.postId
            }))
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing%2Froute&name=app%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing%2Froute&pagePath=private-next-app-dir%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/series/[slug]/fetch-missing/route",
        pathname: "/api/series/[slug]/fetch-missing",
        filename: "route",
        bundlePath: "app/api/series/[slug]/fetch-missing/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/series/[slug]/fetch-missing/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/series/[slug]/fetch-missing/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 9021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813,4857], () => (__webpack_exec__(7748)));
module.exports = __webpack_exports__;

})();