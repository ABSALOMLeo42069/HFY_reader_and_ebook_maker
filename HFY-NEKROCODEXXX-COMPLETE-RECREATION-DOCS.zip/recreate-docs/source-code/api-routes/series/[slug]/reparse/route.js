"use strict";
(() => {
var exports = {};
exports.id = 8094;
exports.ids = [2022,5044,8094];
exports.modules = {

/***/ 261:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 3033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchFromHfyFoundation: () => (/* binding */ fetchFromHfyFoundation)
/* harmony export */ });
/* unused harmony exports searchSeries, fetchSeriesChapters */
// HFY NEKROCODEXXX — hfy.foundation Scraper (4th fallback in the cascade)
// =====================================================
// hfy.foundation is a community-maintained index of r/HFY stories.
// It has a REST API at https://api.hfy.foundation that returns:
//   - Series metadata (name, author, total chapter count)
//   - All chapters with live Reddit permalinks
//
// The data is ~2 years out of date (last updated ~Feb 2024) but covers
// many series with hundreds of chapters that the wiki only partially lists.
//
// Usage in the 5-stage cascade:
//   Stage 1: Reddit RSS (live, current)
//   Stage 2: Reddit wiki via Wayback Machine (archived wiki pages)
//   Stage 3: BFS crawl via RSS (follows "next chapter" links)
//   Stage 4: hfy.foundation (this module — indexed search engine)
//   Stage 5: Reddit live search (finds newest chapters after hfy.foundation)
//
// hfy.foundation serves as a "chapter index" — it gives us 800+ chapter URLs
// for series where the wiki only lists 50-60. We extract the live Reddit
// permalinks and use them as starting points for further crawling.
const HFY_API = "https://api.hfy.foundation";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
/**
 * Search hfy.foundation for a series by name.
 * Returns the series ID if found.
 *
 * The search API is at /search/stories and requires:
 *   q=<query> — search terms
 *   type=series — filter to series only
 *   nsfw=all — include NSFW
 *   sort=random — sort order (required by the API, but we try multiple sorts)
 *
 * Since sort=random returns random results, we paginate through multiple
 * pages to find the series.
 */ async function searchSeries(query) {
    const queryLower = query.toLowerCase().replace(/_/g, " ").trim();
    // Try multiple sort options + pages to find the series
    const sorts = [
        "random",
        "random",
        "random"
    ]; // try 3 random pages
    for (const sort of sorts){
        for(let page = 1; page <= 3; page++){
            try {
                const params = new URLSearchParams({
                    q: query,
                    type: "series",
                    nsfw: "all",
                    sort,
                    page: String(page)
                });
                const url = `${HFY_API}/search/stories?${params}`;
                const res = await fetch(url, {
                    headers: {
                        "User-Agent": UA,
                        Accept: "application/json"
                    },
                    signal: AbortSignal.timeout(10000),
                    cache: "no-store"
                });
                if (!res.ok) continue;
                const data = await res.json();
                const results = Array.isArray(data) ? data : data?.data ?? [];
                if (!Array.isArray(results)) continue;
                // Find the best match
                for (const r of results){
                    const series = r.series;
                    if (!series) continue;
                    const name = (series.name || "").toLowerCase();
                    // Exact match
                    if (name === queryLower) {
                        return {
                            found: true,
                            seriesId: series.id,
                            seriesName: series.name,
                            storyCount: series.story_count
                        };
                    }
                }
            } catch  {
            // try next page
            }
        }
    }
    // Fallback: try a more targeted search with just the first few words
    const shortQuery = queryLower.split(" ").slice(0, 3).join(" ");
    if (shortQuery !== queryLower) {
        try {
            const params = new URLSearchParams({
                q: shortQuery,
                type: "series",
                nsfw: "all",
                sort: "random"
            });
            const url = `${HFY_API}/search/stories?${params}`;
            const res = await fetch(url, {
                headers: {
                    "User-Agent": UA,
                    Accept: "application/json"
                },
                signal: AbortSignal.timeout(10000),
                cache: "no-store"
            });
            if (res.ok) {
                const data = await res.json();
                const results = Array.isArray(data) ? data : data?.data ?? [];
                if (Array.isArray(results)) {
                    // Find contains match
                    for (const r of results){
                        const series = r.series;
                        if (!series) continue;
                        const name = (series.name || "").toLowerCase();
                        if (name.includes(queryLower) || queryLower.includes(name)) {
                            return {
                                found: true,
                                seriesId: series.id,
                                seriesName: series.name,
                                storyCount: series.story_count
                            };
                        }
                    }
                }
            }
        } catch  {
        // give up
        }
    }
    return {
        found: false
    };
}
/**
 * Fetch all chapters for a series from hfy.foundation.
 * Returns the full chapter list with live Reddit permalinks.
 *
 * @param seriesId - the hfy.foundation series ID
 */ async function fetchSeriesChapters(seriesId) {
    try {
        const url = `${HFY_API}/series/${seriesId}`;
        const res = await fetch(url, {
            headers: {
                "User-Agent": UA,
                Accept: "application/json"
            },
            signal: AbortSignal.timeout(30000),
            cache: "no-store"
        });
        if (!res.ok) {
            return null;
        }
        const data = await res.json();
        const stories = data?.stories ?? [];
        if (stories.length === 0) {
            return null;
        }
        // Sort by created_at (oldest first)
        stories.sort((a, b)=>{
            const da = new Date(a.created_at || 0).getTime();
            const db = new Date(b.created_at || 0).getTime();
            return da - db;
        });
        const chapters = stories.map((s)=>{
            const permalink = s.reddit_permalink || "";
            const url = permalink.startsWith("http") ? permalink : `https://www.reddit.com${permalink}`;
            return {
                title: s.title || `Chapter ${s.reddit_id}`,
                url,
                postId: s.reddit_id
            };
        });
        const snapshotDate = stories[stories.length - 1]?.created_at || "";
        return {
            id: data.id,
            name: data.name,
            author: data.author?.username || "unknown",
            storyCount: data.story_count,
            totalWords: data.total_words,
            chapters,
            snapshotDate
        };
    } catch  {
        return null;
    }
}
/**
 * Full pipeline: search for a series by name, then fetch all chapters.
 * Returns the chapter list if found.
 *
 * This is the main entry point for the 4th-stage fallback.
 */ async function fetchFromHfyFoundation(seriesName) {
    // Search for the series
    const search = await searchSeries(seriesName);
    if (!search.found || !search.seriesId) {
        return {
            found: false,
            chapters: [],
            error: search.error || "Series not found on hfy.foundation"
        };
    }
    // Fetch all chapters
    const series = await fetchSeriesChapters(search.seriesId);
    if (!series || series.chapters.length === 0) {
        return {
            found: false,
            chapters: [],
            error: "Series found but no chapters available"
        };
    }
    return {
        found: true,
        chapters: series.chapters,
        seriesId: series.id,
        seriesName: series.name,
        author: series.author,
        snapshotDate: series.snapshotDate
    };
}


/***/ }),

/***/ 5511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6081:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/series/[slug]/reparse/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST),
  dynamic: () => (dynamic),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: ./src/lib/user-chapters.ts
var user_chapters = __webpack_require__(4945);
// EXTERNAL MODULE: ./src/lib/hfy-foundation.ts
var hfy_foundation = __webpack_require__(5044);
// EXTERNAL MODULE: ./src/lib/wayback.ts
var wayback = __webpack_require__(9641);
// EXTERNAL MODULE: ./src/lib/hfy-hardcoded-chapters.ts + 23 modules
var hfy_hardcoded_chapters = __webpack_require__(1781);
;// ./src/app/api/series/[slug]/reparse/route.ts
// POST /api/series/[slug]/reparse
// Re-fetches chapters from all sources + merges with hardcoded CSV data.
// Hardcoded data ALWAYS survives — it's merged back in after any purge.





const runtime = "nodejs";
const dynamic = "force-dynamic";
async function POST(_req, { params }) {
    const { slug } = await params;
    // 1. Get current chapters
    const cached = await (0,user_chapters/* getImportedChapters */.bV)(slug);
    const currentChapters = cached?.chapters ?? [];
    const currentPostIds = new Set(currentChapters.map((c)=>c.postId));
    const allFound = new Map();
    const sources = [];
    // 2. ALWAYS merge hardcoded chapters first — these survive purge/reparse
    const hardcoded = hfy_hardcoded_chapters/* HARDCODED_SERIES */.jb[slug];
    if (hardcoded && hardcoded.chapters.length > 0) {
        sources.push(`Hardcoded CSV: ${hardcoded.chapters.length} chapters`);
        for (const c of hardcoded.chapters){
            allFound.set(c.postId, {
                title: c.title,
                url: c.url,
                postId: c.postId
            });
        }
    }
    // 3. Re-fetch from hfy.foundation
    const seriesName = slug.replace(/_/g, " ");
    try {
        const hfyResult = await (0,hfy_foundation.fetchFromHfyFoundation)(seriesName);
        if (hfyResult.found && hfyResult.chapters.length > 0) {
            sources.push(`hfy.foundation: ${hfyResult.chapters.length} chapters`);
            for (const c of hfyResult.chapters){
                if (!allFound.has(c.postId)) allFound.set(c.postId, c);
            }
        }
    } catch  {}
    // 4. Re-fetch from Wayback Machine
    try {
        const waybackResult = await (0,wayback.fetchFromWayback)(slug, {
            save: false
        });
        if (waybackResult.found && waybackResult.chapters.length > 0) {
            sources.push(`Wayback: ${waybackResult.chapters.length} chapters`);
            for (const c of waybackResult.chapters){
                if (!allFound.has(c.postId)) allFound.set(c.postId, c);
            }
        }
    } catch  {}
    // 5. Keep current chapters that aren't in the sources (user-added chapters)
    for (const c of currentChapters){
        if (!allFound.has(c.postId)) allFound.set(c.postId, c);
    }
    // 6. Find newly added chapters (in allFound but not in current)
    const missing = [];
    for (const [postId, chapter] of allFound){
        if (!currentPostIds.has(postId)) {
            missing.push(chapter);
        }
    }
    // 7. Save merged result (sorted by chapter number)
    const { sortChaptersByNumber } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4945));
    const merged = sortChaptersByNumber(Array.from(allFound.values()));
    await (0,user_chapters/* saveImportedChapters */.cK)(slug, merged, {
        source: "mixed",
        processedPostIds: cached?.processedPostIds
    });
    return server.NextResponse.json({
        ok: true,
        slug,
        before: currentChapters.length,
        after: merged.length,
        added: missing.length,
        sources,
        missing: missing.map((c)=>({
                title: c.title,
                url: c.url,
                postId: c.postId
            })),
        totalFound: allFound.size,
        hardcodedCount: hardcoded?.chapters.length ?? 0
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse%2Froute&name=app%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse%2Froute&pagePath=private-next-app-dir%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/series/[slug]/reparse/route",
        pathname: "/api/series/[slug]/reparse",
        filename: "route",
        bundlePath: "app/api/series/[slug]/reparse/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/series/[slug]/reparse/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/series/[slug]/reparse/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 6439:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 9021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 9641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchFromWayback: () => (/* binding */ fetchFromWayback),
/* harmony export */   gb: () => (/* binding */ fetchChapterFromWayback)
/* harmony export */ });
/* unused harmony exports checkWayback, batchFetchFromWayback */
/* harmony import */ var _user_chapters__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4945);
/* harmony import */ var _reddit_scraper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4034);
// HFY NEKROCODEXXX — Wayback Machine Auto-Fetcher
// =====================================================
// Reddit blocks server-side requests from this sandbox IP.
// But archive.org's Wayback Machine has snapshots of many
// r/HFY wiki pages AND individual chapter posts — and Wayback
// is NOT blocked.
//
// Strategy:
//   1. Check Wayback availability API for the wiki URL
//   2. If a snapshot exists, fetch the HTML directly
//   3. Parse the HTML for Reddit comments links
//   4. Return the chapter list
//
// Also: fetchChapterFromWayback() can fetch individual chapter
// post content from Wayback snapshots when Reddit's RSS is
// rate-limited. This keeps the BFS crawler working even when
// Reddit blocks our IP.


const WAYBACK_AVAILABLE = "https://archive.org/wayback/available?url=";
const WAYBACK_CDX = "http://web.archive.org/cdx/search/cdx?url=";
const WAYBACK_BASE = "https://web.archive.org/web/";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
/**
 * Check if Wayback has a snapshot of the given Reddit wiki URL.
 * Returns the snapshot URL + timestamp if found.
 *
 * We run the availability API and CDX API in RACE mode — whichever
 * returns first with a hit wins. The CDX API is more reliable but
 * slightly slower; the availability API is faster but misses many
 * snapshots due to URL format pickiness.
 */ async function checkWayback(wikiUrl) {
    // Run both strategies in parallel — first hit wins
    const [availResult, cdxResult] = await Promise.allSettled([
        checkWaybackAvailability(wikiUrl),
        checkWaybackCDX(wikiUrl)
    ]);
    // Prefer availability API result if it found something (faster path)
    if (availResult.status === "fulfilled" && availResult.value.found) {
        return availResult.value;
    }
    // Fall back to CDX result
    if (cdxResult.status === "fulfilled" && cdxResult.value.found) {
        return cdxResult.value;
    }
    return {
        found: false
    };
}
/**
 * Availability API strategy — tries multiple URL normalizations.
 * Fast but misses many snapshots.
 */ async function checkWaybackAvailability(wikiUrl) {
    const variants = new Set();
    variants.add(wikiUrl);
    const noProto = wikiUrl.replace(/^https?:\/\//, "");
    variants.add(noProto);
    variants.add(noProto.replace(/^www\./, ""));
    const noSlash = wikiUrl.replace(/\/$/, "");
    variants.add(noSlash);
    variants.add(noSlash.replace(/^https?:\/\//, ""));
    variants.add(noSlash.replace(/^https?:\/\/www\./, ""));
    // Try all variants concurrently — first hit wins
    const promises = Array.from(variants).map(async (variant)=>{
        try {
            const url = `${WAYBACK_AVAILABLE}${encodeURIComponent(variant)}`;
            const res = await fetch(url, {
                headers: {
                    "User-Agent": UA
                },
                signal: AbortSignal.timeout(8000),
                cache: "no-store"
            });
            if (!res.ok) return null;
            const data = await res.json();
            const snapshot = data?.archived_snapshots?.closest;
            if (snapshot?.available && snapshot?.url) {
                return {
                    found: true,
                    snapshotUrl: snapshot.url,
                    timestamp: snapshot.timestamp
                };
            }
            return null;
        } catch  {
            return null;
        }
    });
    const results = await Promise.all(promises);
    const hit = results.find((r)=>r !== null);
    return hit ?? {
        found: false
    };
}
/**
 * Query the CDX API to find the most recent snapshot of a URL.
 * The CDX API is more reliable than the availability API — it lists
 * ALL snapshots, not just the "closest" one.
 */ async function checkWaybackCDX(wikiUrl) {
    // Normalize URL for CDX — strip protocol and www, keep path
    const normalized = wikiUrl.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "");
    const cdxUrl = `${WAYBACK_CDX}${normalized}&output=json&limit=1&filter=statuscode:200&collapse=timestamp:8`;
    try {
        const res = await fetch(cdxUrl, {
            headers: {
                "User-Agent": UA
            },
            signal: AbortSignal.timeout(15000),
            cache: "no-store"
        });
        if (!res.ok) return {
            found: false
        };
        const text = await res.text();
        // CDX returns [["urlkey","timestamp","original",...], [row1], [row2], ...]
        const rows = JSON.parse(text);
        if (!Array.isArray(rows) || rows.length < 2) return {
            found: false
        };
        // First row is the header, second row is the most recent snapshot
        const header = rows[0];
        const data = rows[1];
        const timestampIdx = header.indexOf("timestamp");
        const originalIdx = header.indexOf("original");
        if (timestampIdx < 0 || originalIdx < 0) return {
            found: false
        };
        const timestamp = data[timestampIdx];
        const original = data[originalIdx];
        if (!timestamp || !original) return {
            found: false
        };
        return {
            found: true,
            snapshotUrl: `${WAYBACK_BASE}${timestamp}/${original}`,
            timestamp
        };
    } catch  {
        return {
            found: false
        };
    }
}
/**
 * Fetch a wiki page from Wayback Machine and extract chapter links.
 * Returns the chapter list (also persists to user-chapters store).
 *
 * @param slug - series slug (e.g. "out_of_cruel_space")
 * @param options - { save: whether to persist to user-chapters store (default true) }
 */ async function fetchFromWayback(slug, options = {}) {
    const { save = true } = options;
    const wikiUrl = `https://www.reddit.com/r/HFY/wiki/series/${slug}/`;
    // Step 1: check Wayback availability
    const availability = await checkWayback(wikiUrl);
    if (!availability.found || !availability.snapshotUrl) {
        return {
            ok: true,
            slug,
            found: false,
            chapterCount: 0,
            chapters: []
        };
    }
    // Step 2: fetch the snapshot HTML
    let html;
    try {
        const res = await fetch(availability.snapshotUrl, {
            headers: {
                "User-Agent": UA,
                Accept: "text/html"
            },
            signal: AbortSignal.timeout(30000),
            cache: "no-store"
        });
        if (!res.ok) {
            return {
                ok: false,
                slug,
                found: false,
                chapterCount: 0,
                chapters: [],
                error: `Wayback returned HTTP ${res.status}`
            };
        }
        html = await res.text();
    } catch (err) {
        return {
            ok: false,
            slug,
            found: false,
            chapterCount: 0,
            chapters: [],
            error: err?.message ?? "Failed to fetch Wayback snapshot"
        };
    }
    // Step 3: parse the HTML for chapter links
    const { chapters, synopsis } = (0,_user_chapters__WEBPACK_IMPORTED_MODULE_0__/* .parseRedditWikiForChapters */ .rj)(html);
    if (chapters.length === 0) {
        return {
            ok: true,
            slug,
            found: true,
            chapterCount: 0,
            chapters: [],
            snapshotUrl: availability.snapshotUrl,
            snapshotTimestamp: availability.timestamp
        };
    }
    // Step 4: persist to user-chapters store
    if (save) {
        await (0,_user_chapters__WEBPACK_IMPORTED_MODULE_0__/* .saveImportedChapters */ .cK)(slug, chapters, {
            synopsis,
            source: "wayback"
        });
    }
    return {
        ok: true,
        slug,
        found: true,
        chapterCount: chapters.length,
        chapters,
        snapshotUrl: availability.snapshotUrl,
        snapshotTimestamp: availability.timestamp
    };
}
/**
 * Try to fetch from Wayback for a list of slugs in parallel.
 * Returns a map of slug → WaybackResult.
 *
 * Useful for batch pre-populating the chapter cache for many series.
 */ async function batchFetchFromWayback(slugs, options = {}) {
    const { concurrency = 3, onProgress } = options;
    const results = new Map();
    let done = 0;
    // Process in batches of `concurrency` to avoid hammering Wayback
    for(let i = 0; i < slugs.length; i += concurrency){
        const batch = slugs.slice(i, i + concurrency);
        const batchResults = await Promise.all(batch.map(async (slug)=>{
            const r = await fetchFromWayback(slug);
            return [
                slug,
                r
            ];
        }));
        for (const [slug, r] of batchResults){
            results.set(slug, r);
            done++;
            onProgress?.(done, slugs.length);
        }
    }
    return results;
}
/**
 * Fetch a single chapter's content from a Wayback Machine snapshot.
 * Used as a fallback when Reddit's RSS endpoint is rate-limited/blocked.
 *
 * @param postUrl - full Reddit post URL (e.g. https://www.reddit.com/r/HFY/comments/ol1gnm/...)
 * @returns chapter content including title, author, selftext, and next-chapter links
 */ async function fetchChapterFromWayback(postUrl) {
    const postIdMatch = postUrl.match(/\/comments\/([a-z0-9]+)/i);
    const postId = postIdMatch ? postIdMatch[1] : "";
    if (!postId) {
        return {
            ok: false,
            postId: "",
            title: "",
            author: "",
            createdUtc: 0,
            selftext: "",
            selftextHtml: "",
            nextChapterLinks: [],
            error: "Invalid post URL"
        };
    }
    // Step 1: check Wayback availability
    const availability = await checkWayback(postUrl);
    if (!availability.found || !availability.snapshotUrl) {
        return {
            ok: false,
            postId,
            title: "",
            author: "",
            createdUtc: 0,
            selftext: "",
            selftextHtml: "",
            nextChapterLinks: [],
            error: "No Wayback snapshot"
        };
    }
    // Step 2: fetch the snapshot HTML
    let html;
    try {
        const res = await fetch(availability.snapshotUrl, {
            headers: {
                "User-Agent": UA,
                Accept: "text/html"
            },
            signal: AbortSignal.timeout(30000),
            cache: "no-store"
        });
        if (!res.ok) {
            return {
                ok: false,
                postId,
                title: "",
                author: "",
                createdUtc: 0,
                selftext: "",
                selftextHtml: "",
                nextChapterLinks: [],
                error: `Wayback HTTP ${res.status}`
            };
        }
        html = await res.text();
    } catch (err) {
        return {
            ok: false,
            postId,
            title: "",
            author: "",
            createdUtc: 0,
            selftext: "",
            selftextHtml: "",
            nextChapterLinks: [],
            error: err?.message ?? "Fetch failed"
        };
    }
    // Step 3: parse the Wayback-wrapped Reddit page
    // Wayback wraps the page in its toolbar — the actual Reddit content is inside.
    // Reddit stores the post selftext in a <div class="md"> within the post body.
    return parseWaybackRedditPost(html, postId, postUrl, availability.snapshotUrl, availability.timestamp);
}
/**
 * Parse a Wayback-wrapped Reddit post page to extract chapter content.
 * Wayback pages include the full Reddit HTML — we extract:
 *   - Post title (from <h1> or <title>)
 *   - Author (from the post metadata)
 *   - Selftext (from <div class="usertext-body"> or <div class="md">)
 *   - Next-chapter links (from the selftext)
 */ function parseWaybackRedditPost(html, postId, postUrl, snapshotUrl, timestamp) {
    // Extract title — Reddit uses <h1 class="title"> or the page <title>
    let title = "";
    const titleMatch = html.match(/<h1[^>]*class="[^"]*title[^"]*"[^>]*>([\s\S]*?)<\/h1>/i);
    if (titleMatch) {
        title = stripTags(titleMatch[1]).trim();
    }
    if (!title) {
        const pageTitleMatch = html.match(/<title>([^<]+)<\/title>/i);
        if (pageTitleMatch) {
            title = pageTitleMatch[1].replace(/\s*[|:]\s*HFY\s*$/i, "").replace(/\s*:?\s*r\/HFY\s*$/i, "").trim();
        }
    }
    // Extract author — Reddit shows "u/username" or "/u/username"
    let author = "unknown";
    const authorMatch = html.match(/\/u\/([A-Za-z0-9_-]+)/);
    if (authorMatch) {
        author = authorMatch[1];
    }
    // Extract selftext — Reddit wraps post body in <div class="usertext-body"> or <div class="md">
    let selftextHtml = "";
    const usertextMatch = html.match(/<div[^>]*class="[^"]*usertext-body[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
    if (usertextMatch) {
        selftextHtml = usertextMatch[1];
    } else {
        const mdMatch = html.match(/<div[^>]*class="[^"]*md[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
        if (mdMatch) {
            selftextHtml = mdMatch[1];
        }
    }
    // Convert HTML to markdown-like text
    const selftext = htmlToMarkdown(selftextHtml);
    // Find next-chapter links in the selftext
    const nextChapterLinks = (0,_reddit_scraper__WEBPACK_IMPORTED_MODULE_1__/* .findChapterLinks */ .A3)(selftext, selftextHtml, _reddit_scraper__WEBPACK_IMPORTED_MODULE_1__/* .NEXT_LINK_PATTERNS */ .nP);
    return {
        ok: true,
        postId,
        title: title || `Chapter ${postId}`,
        author,
        createdUtc: 0,
        selftext,
        selftextHtml,
        nextChapterLinks,
        snapshotUrl,
        snapshotTimestamp: timestamp
    };
}
function stripTags(html) {
    return html.replace(/<[^>]+>/g, "");
}
function htmlToMarkdown(html) {
    let md = html;
    md = md.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, (_, t)=>`# ${stripTags(t)}\n\n`);
    md = md.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, (_, t)=>`## ${stripTags(t)}\n\n`);
    md = md.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, (_, t)=>`### ${stripTags(t)}\n\n`);
    md = md.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, (_, t)=>`*${stripTags(t)}*`);
    md = md.replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, (_, t)=>`*${stripTags(t)}*`);
    md = md.replace(/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, (_, href, t)=>`[${stripTags(t)}](${href})`);
    md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_, t)=>`> ${stripTags(t).replace(/\n/g, "\n> ")}\n\n`);
    md = md.replace(/<hr[^>]*>/gi, "\n---\n\n");
    md = md.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_, t)=>`\`${stripTags(t)}\``);
    md = md.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, t)=>`\`\`\`\n${stripTags(t)}\n\`\`\`\n\n`);
    md = md.replace(/<p[^>]*>/gi, "\n\n");
    md = md.replace(/<\/p>/gi, "");
    md = md.replace(/<br\s*\/?>/gi, "\n");
    md = md.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_, t)=>`- ${stripTags(t).trim()}\n`);
    md = md.replace(/<\/?(ul|ol)[^>]*>/gi, "\n");
    md = stripTags(md);
    md = md.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
    md = md.replace(/\n{3,}/g, "\n\n\n").trim();
    return md;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813,4857,7101,4034], () => (__webpack_exec__(6081)));
module.exports = __webpack_exports__;

})();