const fs = require('fs');
const path = require('path');

async function GET(req) {
  const file = path.join(process.cwd(), 'public', 'r_tiny_test.jsonl');
  try {
    const text = fs.readFileSync(file, 'utf8');
    return new Response(text, { headers: { 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500 });
  }
}
module.exports = { GET };
