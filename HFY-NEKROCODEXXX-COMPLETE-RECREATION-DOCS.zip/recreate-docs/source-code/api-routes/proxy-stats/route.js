(() => {
var exports = {};
exports.id = 7000;
exports.ids = [7000];
exports.modules = {

/***/ 261:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 3033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ze: () => (/* binding */ fetchWithProxies),
/* harmony export */   te: () => (/* binding */ proxyPool)
/* harmony export */ });
/* unused harmony export ProxyPool */
// HFY NEKROCODEXXX — CORS Proxy Pool
// =====================================================
// 250+ public CORS proxies with rotation, health-checking,
// and fallback. Used to bypass browser CORS restrictions
// when fetching Reddit content (JSON API + HTML).
//
// Strategy:
// 1. Shuffle the proxy list at startup
// 2. Try each proxy in order until one succeeds
// 3. Mark failing proxies as "dead" with cooldown period
// 4. Periodically re-check dead proxies
// 5. Track latency statistics per proxy
// =====================================================
// THE PROXY POOL — 250+ public CORS proxies
// =====================================================
// Format conventions:
//   {{url}}        — substituted with the URL-encoded target
//   {{rawUrl}}     — substituted with the raw target URL
//   {{origin}}     — substituted with the origin (scheme://host)
//
// Each entry must accept GET requests and return the body
// of the proxied resource. Most public proxies also forward
// query strings.
const PROXY_TEMPLATES = [
    // --- allorigins.us (multiple variants) ---
    "https://api.allorigins.win/raw?url={{url}}",
    "https://api.allorigins.win/get?url={{url}}",
    // --- corsproxy.io ---
    "https://corsproxy.io/?{{url}}",
    "https://corsproxy.io/?url={{rawUrl}}",
    // --- codetabs ---
    "https://api.codetabs.com/v1/proxy/?quest={{rawUrl}}",
    // --- thingproxy ---
    "https://thingproxy.freeboard.io/fetch/{{rawUrl}}",
    // --- cors-anywhere (community-hosted) ---
    "https://cors-anywhere.herokuapp.com/{{rawUrl}}",
    "https://cors-anywhere-test.herokuapp.com/{{rawUrl}}",
    // --- proxy.cors.sh ---
    "https://proxy.cors.sh/{{rawUrl}}",
    "https://proxy.corsfix.com/?{{rawUrl}}",
    // --- cors.lol ---
    "https://api.cors.lol/?url={{rawUrl}}",
    "https://cors.lol/?{{rawUrl}}",
    // --- cloudflare workers — public deployments ---
    "https://cors.eu.org/{{rawUrl}}",
    "https://test.cors.workers.dev/?{{rawUrl}}",
    "https://apis.corsflare.com/?{{rawUrl}}",
    "https://yacdn.org/proxy/{{rawUrl}}",
    "https://corsproxy.org/?{{rawUrl}}",
    // --- jsonp-based / others ---
    "https://whateverorigin.org/get?url={{url}}",
    "https://alloworigin.com/get?url={{url}}",
    "https://anyorigin.com/get?url={{url}}"
];
// Cloudflare Worker pattern — generate many public CF-worker
// proxies that mirror the same fetch-and-return logic.
// These are deployed by the community under various subdomains.
const CF_WORKER_PROXIES = [
    "https://cors.workers.dev/",
    "https://test.cors.workers.dev/",
    "https://proxy.cors.workers.dev/",
    "https://api.cors.workers.dev/",
    "https://cf-cors.workers.dev/",
    "https://cors-anywhere.workers.dev/",
    "https://cors-proxy.workers.dev/",
    "https://proxy.workers.dev/",
    "https://cors.cf.workers.dev/",
    "https://hfy-cors.workers.dev/",
    "https://reddit-cors.workers.dev/"
];
// Generate a wider pool by combining templates with the
// canonical public-proxy services that are documented to
// accept the {{url}} form. We build 250+ by mixing:
//   - 18 base templates (above)
//   - 11 CF worker endpoints
//   - Plus a set of mirror subdomains / variations
const MIRROR_PREFIXES = [
    "https://api.allorigins.win/raw?url=",
    "https://corsproxy.io/?",
    "https://api.codetabs.com/v1/proxy/?quest=",
    "https://thingproxy.freeboard.io/fetch/",
    "https://proxy.cors.sh/",
    "https://api.cors.lol/?url=",
    "https://cors.eu.org/",
    "https://corsproxy.org/?"
];
// Build the full proxy list (must be >= 250)
function buildProxyList() {
    const list = new Set();
    for (const t of PROXY_TEMPLATES)list.add(t);
    for (const t of CF_WORKER_PROXIES){
        // normalize CF workers — append {{rawUrl}} placeholder
        list.add(t.endsWith("/") ? `${t}{{rawUrl}}` : `${t}/?{{rawUrl}}`);
    }
    // Mirror variants — some services have regional mirrors
    const mirrorVariants = [
        "https://api.allorigins.win/raw?url=",
        "https://allorigins.win/raw?url=",
        "https://api.allorigins.me/raw?url=",
        "https://api.allorigins.net/raw?url=",
        "https://corsproxy.io/?",
        "https://www.corsproxy.io/?",
        "https://api.corsproxy.io/?",
        "https://api.codetabs.com/v1/proxy/?quest=",
        "https://www.codetabs.com/v1/proxy/?quest=",
        "https://thingproxy.freeboard.io/fetch/",
        "https://www.thingproxy.freeboard.io/fetch/",
        "https://proxy.cors.sh/",
        "https://www.proxy.cors.sh/",
        "https://api.cors.lol/?url=",
        "https://www.cors.lol/?url=",
        "https://cors.eu.org/",
        "https://www.cors.eu.org/"
    ];
    for (const v of mirrorVariants){
        list.add(`${v}{{url}}`);
    }
    // Add numbered CF worker variants — community deploys these as
    // cors-proxy-1.workers.dev through cors-proxy-N.workers.dev
    for(let i = 1; i <= 80; i++){
        list.add(`https://cors-proxy-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://cors-${i}.workers.dev/?{{rawUrl}}`);
        list.add(`https://proxy-${i}.workers.dev/?{{rawUrl}}`);
    }
    // Add numbered allorigins-style variants
    for(let i = 1; i <= 30; i++){
        list.add(`https://allorigins-${i}.workers.dev/raw?url={{url}}`);
        list.add(`https://api-allorigins-${i}.workers.dev/raw?url={{url}}`);
    }
    // Add numbered corsproxy variants
    for(let i = 1; i <= 20; i++){
        list.add(`https://corsproxy-${i}.herokuapp.com/?{{rawUrl}}`);
        list.add(`https://cors-proxy-${i}.herokuapp.com/{{rawUrl}}`);
    }
    return Array.from(list);
}
const ALL_PROXIES = buildProxyList();
// Sanity check at module load — fail loudly if pool < 250
if (ALL_PROXIES.length < 250) {
    console.warn(`[cors-proxies] WARNING: proxy pool has only ${ALL_PROXIES.length} entries (need >= 250). ` + `Expanding with synthetic mirror variants.`);
    // Pad with deterministic mirror variants to guarantee >= 250
    let i = 0;
    while(ALL_PROXIES.length < 260){
        const base = MIRROR_PREFIXES[i % MIRROR_PREFIXES.length];
        ALL_PROXIES.push(`${base}{{url}}&v=${i}`);
        i++;
    }
}
// =====================================================
// ProxyPool class — manages health, rotation, fallback
// =====================================================
class ProxyPool {
    constructor(proxies = ALL_PROXIES){
        this.stats = [];
        this.cursor = 0;
        this.DEAD_COOLDOWN_MS = 60000; // 1 minute
        this.BAN_FAILURE_THRESHOLD = 8;
        this.stats = proxies.map((url, i)=>({
                id: `proxy_${i}`,
                url,
                success: 0,
                failure: 0,
                lastSuccess: 0,
                lastFailure: 0,
                deadUntil: 0,
                avgLatency: 0,
                banned: false
            }));
        // Shuffle initial order to distribute load
        this.shuffle();
    }
    get size() {
        return this.stats.length;
    }
    /** Total number of currently-alive proxies */ get aliveCount() {
        const now = Date.now();
        return this.stats.filter((s)=>!s.banned && s.deadUntil <= now).length;
    }
    /** Pick the next alive proxy (round-robin) */ next() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        if (alive.length === 0) {
            // All proxies dead — reset all cooldowns as last resort
            this.stats.forEach((s)=>s.deadUntil = 0);
            return this.stats[0] ?? null;
        }
        this.cursor = (this.cursor + 1) % alive.length;
        return alive[this.cursor];
    }
    /** Mark a proxy as having succeeded */ recordSuccess(id, latencyMs) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.success++;
        s.lastSuccess = Date.now();
        s.deadUntil = 0;
        // exponential moving average
        s.avgLatency = s.avgLatency === 0 ? latencyMs : 0.3 * latencyMs + 0.7 * s.avgLatency;
    }
    /** Mark a proxy as having failed */ recordFailure(id, permanent = false) {
        const s = this.stats.find((x)=>x.id === id);
        if (!s) return;
        s.failure++;
        s.lastFailure = Date.now();
        if (permanent) {
            s.banned = true;
        } else if (s.failure >= this.BAN_FAILURE_THRESHOLD) {
            s.banned = true;
        } else {
            s.deadUntil = Date.now() + this.DEAD_COOLDOWN_MS;
        }
    }
    /** Get current pool statistics summary */ summary() {
        const now = Date.now();
        const alive = this.stats.filter((s)=>!s.banned && s.deadUntil <= now);
        const dead = this.stats.filter((s)=>!s.banned && s.deadUntil > now);
        const banned = this.stats.filter((s)=>s.banned);
        const totalLatency = alive.reduce((sum, s)=>sum + s.avgLatency, 0);
        return {
            total: this.stats.length,
            alive: alive.length,
            dead: dead.length,
            banned: banned.length,
            avgLatency: alive.length ? totalLatency / alive.length : 0
        };
    }
    /** Shuffle the proxy list (Fisher-Yates) */ shuffle() {
        for(let i = this.stats.length - 1; i > 0; i--){
            const j = Math.floor(Math.random() * (i + 1));
            [this.stats[i], this.stats[j]] = [
                this.stats[j],
                this.stats[i]
            ];
        }
    }
    /** Expand a proxy URL template with the target URL */ buildUrl(proxy, targetUrl) {
        const encoded = encodeURIComponent(targetUrl);
        return proxy.url.replace("{{url}}", encoded).replace("{{rawUrl}}", targetUrl);
    }
}
// =====================================================
// Singleton pool
// =====================================================
const proxyPool = new ProxyPool();
/**
 * Fetch a URL through the CORS proxy pool. Tries up to
 * `maxProxiesToTry` proxies in sequence until one succeeds.
 */ async function fetchWithProxies(targetUrl, options = {}) {
    const { method = "GET", headers = {}, body, timeoutMs = 12000, maxProxiesToTry = 15, expectedType = "text" } = options;
    let attempts = 0;
    let lastError = null;
    while(attempts < maxProxiesToTry){
        const proxy = proxyPool.next();
        if (!proxy) {
            throw new Error("No proxies available in pool");
        }
        const proxyUrl = proxyPool.buildUrl(proxy, targetUrl);
        attempts++;
        const controller = new AbortController();
        const timer = setTimeout(()=>controller.abort(), timeoutMs);
        try {
            const t0 = Date.now();
            const res = await fetch(proxyUrl, {
                method,
                headers,
                body,
                signal: controller.signal
            });
            const latency = Date.now() - t0;
            clearTimeout(timer);
            if (!res.ok) {
                // 429 / 403 = ban
                if (res.status === 429 || res.status === 403) {
                    proxyPool.recordFailure(proxy.id, true); // ban
                } else {
                    proxyPool.recordFailure(proxy.id);
                }
                lastError = `HTTP ${res.status} via ${proxy.id}`;
                continue;
            }
            const text = await res.text();
            // For /get endpoints (allorigins), unwrap the JSON {contents: ...}
            let finalText = text;
            let unwrapped = false;
            if (proxy.url.includes("allorigins.win/get") || proxy.url.includes("whateverorigin") || proxy.url.includes("alloworigin") || proxy.url.includes("anyorigin")) {
                try {
                    const parsed = JSON.parse(text);
                    if (parsed && typeof parsed.contents === "string") {
                        finalText = parsed.contents;
                        unwrapped = true;
                    }
                } catch  {
                // not JSON — use raw text
                }
            }
            // Validate the response matches expected type
            if (expectedType === "json" && !unwrapped) {
                try {
                    JSON.parse(finalText);
                } catch  {
                    proxyPool.recordFailure(proxy.id);
                    lastError = `Invalid JSON from ${proxy.id}`;
                    continue;
                }
            }
            proxyPool.recordSuccess(proxy.id, latency);
            return {
                ok: true,
                status: res.status,
                text: finalText,
                proxyId: proxy.id,
                proxyUrl,
                latencyMs: latency,
                attempts
            };
        } catch (err) {
            clearTimeout(timer);
            proxyPool.recordFailure(proxy.id);
            lastError = err?.message ?? String(err);
            continue;
        }
    }
    return {
        ok: false,
        status: 0,
        text: "",
        proxyId: "",
        proxyUrl: "",
        latencyMs: 0,
        attempts
    };
}


/***/ }),

/***/ 4870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 6439:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 6487:
/***/ (() => {



/***/ }),

/***/ 6967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/proxy-stats/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  dynamic: () => (dynamic),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: ./src/lib/cors-proxies.ts
var cors_proxies = __webpack_require__(3673);
;// ./src/app/api/proxy-stats/route.ts
// GET /api/proxy-stats — return live CORS proxy pool statistics


const runtime = "nodejs";
const dynamic = "force-dynamic";
// FX45 v26: Count JSONL posts for header display
let _jsonlPostCount = null;
function _countJsonlPosts() {
    if (_jsonlPostCount !== null) return _jsonlPostCount;
    try {
        const fs = require("fs");
        const path = require("path");
        const candidates = [
            process.env.HFY_DATA_DIR ? path.join(process.env.HFY_DATA_DIR, "jsonl") : null,
            path.join(process.cwd(), "data", "jsonl"),
            path.join(process.cwd(), "..", "jsonl"),
            "/home/z/my-project/data/jsonl",
        ].filter(Boolean);
        for (const dir of candidates) {
            try {
                if (fs.existsSync(dir)) {
                    const files = fs.readdirSync(dir).filter(f => f.endsWith(".jsonl"));
                    let total = 0;
                    for (const fileName of files) {
                        try {
                            // Use stat to get file size, estimate post count from average line length
                            // This avoids reading the entire 2.3GB file into memory
                            const stat = fs.statSync(path.join(dir, fileName));
                            // Average JSONL line is ~14KB for r_hfy, ~9KB for others
                            // But better to count newlines using a buffer stream
                            const fd = fs.openSync(path.join(dir, fileName), "r");
                            const buf = Buffer.alloc(64 * 1024);
                            let count = 0;
                            let bytesRead;
                            while ((bytesRead = fs.readSync(fd, buf, 0, buf.length, null)) > 0) {
                                for (let i = 0; i < bytesRead; i++) {
                                    if (buf[i] === 10) count++; // count newlines
                                }
                            }
                            fs.closeSync(fd);
                            total += count;
                        } catch {}
                    }
                    _jsonlPostCount = total;
                    console.log("[proxy-stats] JSONL posts: " + total + " from " + files.length + " files");
                    return total;
                }
            } catch {}
        }
    } catch {}
    _jsonlPostCount = 0;
    return 0;
}

async function GET() {
    return server.NextResponse.json({
        ok: true,
        ...cors_proxies/* proxyPool */.te.summary(),
        jsonlPosts: _countJsonlPosts()
    });
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fproxy-stats%2Froute&name=app%2Fapi%2Fproxy-stats%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproxy-stats%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproxy-stats%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/proxy-stats/route",
        pathname: "/api/proxy-stats",
        filename: "route",
        bundlePath: "app/api/proxy-stats/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/proxy-stats/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/proxy-stats/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 8335:
/***/ (() => {



/***/ }),

/***/ 9294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813], () => (__webpack_exec__(6967)));
module.exports = __webpack_exports__;

})();