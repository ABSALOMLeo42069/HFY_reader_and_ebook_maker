"use strict";
(() => {
var exports = {};
exports.id = 5853;
exports.ids = [2022,5044,5853];
exports.modules = {

/***/ 261:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LR: () => (/* binding */ jobs),
/* harmony export */   ax: () => (/* binding */ getJob),
/* harmony export */   iO: () => (/* binding */ newJob),
/* harmony export */   lh: () => (/* binding */ updateJob)
/* harmony export */ });
// Shared auto-discover job store — imported by both POST and GET routes
// This ensures both routes see the same Map (Turbopack gives each route
// its own module scope, so globalThis alone doesn't work reliably)
// Use globalThis to persist across hot reloads, but initialize here
// so both routes get the same instance
const globalForJobs = globalThis;
if (!globalForJobs.__autoDiscoverJobs) {
    globalForJobs.__autoDiscoverJobs = new Map();
}
const jobs = globalForJobs.__autoDiscoverJobs;
function newJob(slug) {
    const id = `job_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const job = {
        id,
        slug,
        status: "queued",
        stage: "starting",
        startedAt: Date.now(),
        updatedAt: Date.now(),
        progress: {
            cacheChapters: 0,
            waybackChapters: 0,
            hfyFoundationChapters: 0,
            crawledChapters: 0,
            waybackCrawlChapters: 0,
            redditJsonCrawlChapters: 0,
            redditSearchChapters: 0,
            discoveredChapters: 0,
            totalChapters: 0,
            currentlyFetching: null,
            errors: 0,
            stageLog: []
        }
    };
    jobs.set(id, job);
    return job;
}
function updateJob(id, patch) {
    const job = jobs.get(id);
    if (!job) return;
    Object.assign(job, patch, {
        updatedAt: Date.now()
    });
}
function getJob(id) {
    return jobs.get(id);
}


/***/ }),

/***/ 846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 1157:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/auto-discover/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST),
  dynamic: () => (dynamic),
  maxDuration: () => (maxDuration),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: ./src/lib/user-chapters.ts
var user_chapters = __webpack_require__(4945);
// EXTERNAL MODULE: ./src/lib/wayback.ts
var wayback = __webpack_require__(9641);
// EXTERNAL MODULE: ./src/lib/hfy-foundation.ts
var hfy_foundation = __webpack_require__(5044);
// EXTERNAL MODULE: ./src/lib/reddit-scraper.ts
var reddit_scraper = __webpack_require__(4034);
// EXTERNAL MODULE: ./src/lib/easy-reddit-downloader.ts
var easy_reddit_downloader = __webpack_require__(7614);
// EXTERNAL MODULE: ./src/lib/auto-discover-jobs.ts
var auto_discover_jobs = __webpack_require__(805);
;// ./src/app/api/auto-discover/route.ts
// POST /api/auto-discover — start an auto-discovery job for a series
// GET  /api/auto-discover/[jobId] — poll job status
//
// Auto-discovery strategy (in order):
//   1. Check user-imported cache — if already has chapters, return immediately
//   2. Check Wayback Machine for a wiki snapshot — if found, extract chapters
//   3. BFS-crawl from any known chapters via RSS to discover more
//      (follows "next chapter" links — handles series with 1000+ chapters
//      where the wiki only lists 50-60)
//
// Job state is held in-memory (Map). Jobs run in the background.






const runtime = "nodejs";
const dynamic = "force-dynamic";
const maxDuration = 300;

// Wrapper: updateProgress merges into job.progress
function updateProgress(jobId, progress) {
    const job = auto_discover_jobs/* jobs */.LR.get(jobId);
    if (job) {
        job.progress = {
            ...job.progress,
            ...progress
        };
    }
}
async function POST(req) {
    let body;
    try {
        body = await req.json();
    } catch  {
        return server.NextResponse.json({
            ok: false,
            error: "Invalid JSON"
        }, {
            status: 400
        });
    }
    const slug = body?.slug;
    const crawlDepth = (body?.crawlDepth ?? 200);
    const useCrawler = body?.useCrawler ?? true;
    const customStages = body?.stages;
    const singleStage = body?.stage;
    const startUrl = body?.startUrl || body?.customStartUrl;
    if (!slug) {
        return server.NextResponse.json({
            ok: false,
            error: "Missing slug"
        }, {
            status: 400
        });
    }
    const job = (0,auto_discover_jobs/* newJob */.iO)(slug);
    runAutoDiscover(job.id, slug, crawlDepth, useCrawler, customStages, singleStage, startUrl).catch((err)=>{
        (0,auto_discover_jobs/* updateJob */.lh)(job.id, {
            status: "failed",
            error: err?.message ?? "Unknown error"
        });
    });
    return server.NextResponse.json({
        ok: true,
        jobId: job.id,
        slug
    });
}
async function runAutoDiscover(jobId, slug, crawlDepth, useCrawler, customStages, singleStage, startUrl) {
    try {
        // Hoist seriesName to function scope so all stages can use it
        const seriesName = (slug || "").replace(/_/g, " ");
        // Determine which stages to run.
        // Default (no customStages, no singleStage): run ALL stages in order.
        // If singleStage is set: run ONLY that one stage.
        // If customStages is set: run those stages in the given order.
        const allStages = [
            "cache",
            "wayback",
            "hfy-foundation",
            "crawl",
            "wayback-crawl",
            "reddit-json",
            "reddit-search"
        ];
        const stagesToRun = singleStage ? [
            singleStage
        ] : customStages && customStages.length > 0 ? customStages : allStages;
        const shouldRun = (stage)=>stagesToRun.includes(stage);
        (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
            status: "running",
            stage: "checking-cache"
        });
        // Stage 1: check user-imported cache
        const cached = await (0,user_chapters/* getImportedChapters */.bV)(slug);
        let knownChapters = cached?.chapters ?? [];
        const knownPostIds = new Set(knownChapters.map((c)=>c.postId));
        const stageLog = [];
        updateProgress(jobId, {
            cacheChapters: knownChapters.length,
            totalChapters: knownChapters.length
        });
        if (knownChapters.length > 0) {
            stageLog.push(`Cache: ${knownChapters.length} chapters`);
            updateProgress(jobId, {
                stageLog: [
                    ...stageLog
                ]
            });
        }
        // Stage 2: check Wayback Machine (only if cache is empty)
        if (shouldRun("wayback") && knownChapters.length === 0) {
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "checking-wayback"
            });
            const waybackResult = await (0,wayback.fetchFromWayback)(slug, {
                save: true
            });
            if (waybackResult.found && waybackResult.chapters.length > 0) {
                for (const c of waybackResult.chapters){
                    if (!knownPostIds.has(c.postId)) {
                        knownChapters.push(c);
                        knownPostIds.add(c.postId);
                    }
                }
                stageLog.push(`Wayback: +${waybackResult.chapters.length} chapters (snapshot ${waybackResult.snapshotTimestamp?.slice(0, 8)})`);
                updateProgress(jobId, {
                    waybackChapters: knownChapters.length,
                    totalChapters: knownChapters.length,
                    stageLog: [
                        ...stageLog
                    ]
                });
                await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
                    source: "wayback"
                });
            }
        }
        // Stage 3: hfy.foundation — indexed chapter database
        if (shouldRun("hfy-foundation")) {
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "checking-hfy-foundation"
            });
            const hfyResult = await (0,hfy_foundation.fetchFromHfyFoundation)(seriesName);
            if (hfyResult.found && hfyResult.chapters.length > 0) {
                const beforeCount = knownChapters.length;
                for (const c of hfyResult.chapters){
                    if (!knownPostIds.has(c.postId)) {
                        knownChapters.push(c);
                        knownPostIds.add(c.postId);
                    }
                }
                const added = knownChapters.length - beforeCount;
                if (added > 0) {
                    stageLog.push(`hfy.foundation: +${added} chapters (of ${hfyResult.chapters.length} total, up to ${hfyResult.snapshotDate?.slice(0, 10)})`);
                    updateProgress(jobId, {
                        hfyFoundationChapters: knownChapters.length,
                        totalChapters: knownChapters.length,
                        stageLog: [
                            ...stageLog
                        ]
                    });
                    await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
                        source: "mixed"
                    });
                } else {
                    stageLog.push(`hfy.foundation: already have all ${hfyResult.chapters.length} chapters`);
                    updateProgress(jobId, {
                        stageLog: [
                            ...stageLog
                        ]
                    });
                }
            } else {
                stageLog.push(`hfy.foundation: ${hfyResult.error || "not found"}`);
                updateProgress(jobId, {
                    stageLog: [
                        ...stageLog
                    ]
                });
            }
        } // end if shouldRun("hfy-foundation")
        // Stage 4: BFS crawl via RSS
        if (shouldRun("crawl") && useCrawler && crawlDepth > 0 && (knownChapters.length > 0 || startUrl)) {
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "crawling"
            });
            // RESUME LOGIC: load previously-processed chapter IDs from the
            // persistent store. This way, if the crawler stopped at chapter 500
            // and the user presses crawl again, we skip chapters 1-500 (already
            // processed) and continue from chapter 500's next-links.
            const persistedProcessed = new Set(cached?.processedPostIds ?? []);
            const discoveredPostIds = new Set(knownChapters.map((c)=>c.postId));
            const processedPostIds = new Set(persistedProcessed);
            // Find chapters that are DISCOVERED but NOT YET PROCESSED.
            // These are chapters we know exist but haven't followed their next-links.
            // Start from the LAST unprocessed chapter (most likely to have forward
            // "next" links to chapters we haven't discovered yet).
            const unprocessedChapters = knownChapters.filter((c)=>!processedPostIds.has(c.postId));
            let startUrls;
            // If startUrl is provided (from long-press "crawl from here"), use it directly
            if (startUrl) {
                startUrls = [
                    startUrl
                ];
                console.log(`[auto-discover] Crawl from specific chapter: ${startUrl}`);
            } else if (unprocessedChapters.length > 0) {
                // Resume: start from the last few unprocessed chapters
                const startCandidates = unprocessedChapters.slice(-3);
                startUrls = Array.from(new Set(startCandidates.map((c)=>c.url)));
                console.log(`[auto-discover] Resuming: ${unprocessedChapters.length} unprocessed chapters, starting from ${startUrls.length} URLs`);
            } else {
                // All known chapters have been processed — start from the last one
                // (it might have new "next" links pointing to chapters published since
                // the last crawl)
                startUrls = [
                    knownChapters[knownChapters.length - 1].url
                ];
                console.log(`[auto-discover] All ${knownChapters.length} chapters already processed, re-checking last chapter for new content`);
            }
            const queue = [
                ...startUrls
            ];
            let crawled = 0;
            let newDiscovered = 0;
            const newChapters = [];
            while(queue.length > 0 && crawled < crawlDepth){
                const url = queue.shift();
                const normalized = normalizeRedditUrl(url);
                const postId = extractPostId(normalized);
                if (!postId) continue;
                // Skip if we've already PROCESSED this chapter (followed its next-links).
                // But DON'T skip just because it's in `discoveredPostIds` — start URLs
                // are in `discoveredPostIds` but still need to be fetched for their
                // next-links.
                if (processedPostIds.has(postId)) continue;
                processedPostIds.add(postId);
                updateProgress(jobId, {
                    currentlyFetching: normalized
                });
                // Fetch chapter content directly via fetchPostContent.
                // Includes RSS → CORS proxy → .json → Wayback fallback chain.
                let nextUrls = [];
                let title = "";
                let selftext = "";
                let selftextHtml = "";
                let fetchOk = false;
                try {
                    const content = await (0,reddit_scraper/* fetchPostContent */.iL)(normalized);
                    title = content.title;
                    selftext = content.selftext;
                    selftextHtml = content.selftextHtml;
                    nextUrls = content.nextChapterLinks;
                    fetchOk = true;
                    console.log(`[auto-discover] Fetched ${postId} via ${content.source}: title="${title.slice(0, 40)}" nextUrls=${nextUrls.length}`);
                } catch (err) {
                    console.log(`[auto-discover] fetchPostContent failed for ${postId}: ${err?.message}`);
                    // Fallback: Wayback Machine
                    try {
                        const waybackContent = await (0,wayback/* fetchChapterFromWayback */.gb)(normalized);
                        if (waybackContent.ok) {
                            title = waybackContent.title;
                            selftext = waybackContent.selftext;
                            selftextHtml = waybackContent.selftextHtml;
                            nextUrls = waybackContent.nextChapterLinks;
                            fetchOk = true;
                            console.log(`[auto-discover] Fetched ${postId} via Wayback (${waybackContent.snapshotTimestamp}): nextUrls=${nextUrls.length}`);
                        } else {
                            console.log(`[auto-discover] Wayback failed for ${postId}: ${waybackContent.error}`);
                        }
                    } catch (err3) {
                        console.log(`[auto-discover] Wayback exception for ${postId}: ${err3?.message}`);
                    }
                    if (!fetchOk) {
                        updateProgress(jobId, {
                            errors: (auto_discover_jobs/* jobs */.LR.get(jobId)?.progress.errors ?? 0) + 1
                        });
                    }
                }
                crawled++;
                // SMART NEXT-LINK DISCOVERY (handles abbreviated series names like "OOCS"):
                // If the explicit NEXT_LINK_PATTERNS didn't find any next links,
                // fall back to a heuristic: look for ANY reddit comments URL in the
                // post body that we haven't discovered yet. Authors often write
                // "[Part 61](url)" or just bare URLs without "next" keywords,
                // and series names get abbreviated (OOCS, etc.).
                if (fetchOk && nextUrls.length === 0) {
                    nextUrls = findAnyUnvisitedRedditLinks(selftext, selftextHtml, discoveredPostIds);
                }
                // If this is a NEW chapter (not in the original known list), add it
                if (fetchOk && title && !discoveredPostIds.has(postId)) {
                    const newChapter = {
                        title,
                        url: normalized,
                        postId
                    };
                    newChapters.push(newChapter);
                    discoveredPostIds.add(postId);
                    newDiscovered++;
                    // Save progress every 5 new chapters (including processedPostIds for resume)
                    if (newChapters.length % 5 === 0) {
                        await (0,user_chapters/* saveImportedChapters */.cK)(slug, [
                            ...knownChapters,
                            ...newChapters
                        ], {
                            source: "mixed",
                            processedPostIds: Array.from(processedPostIds)
                        });
                    }
                }
                updateProgress(jobId, {
                    crawledChapters: crawled,
                    discoveredChapters: newDiscovered,
                    totalChapters: knownChapters.length + newChapters.length
                });
                // Enqueue newly-discovered next-chapter URLs.
                // hfy2epub approach: only follow the FIRST unvisited next link per page.
                // This prevents mixing prequel and sequel chapters — the "next" link
                // typically appears before "previous" links in the post body, so taking
                // only the first match gives us the correct sequential chain.
                let enqueuedCount = 0;
                let firstEnqueued = false;
                for (const nextUrl of nextUrls){
                    const nextNormalized = normalizeRedditUrl(nextUrl);
                    const nextPostId = extractPostId(nextNormalized);
                    if (nextPostId && !processedPostIds.has(nextPostId) && // not yet processed
                    !queue.includes(nextNormalized) // not already queued
                    ) {
                        queue.push(nextNormalized);
                        enqueuedCount++;
                        firstEnqueued = true;
                        break; // Only enqueue the FIRST unvisited next link (hfy2epub approach)
                    }
                }
                console.log(`[auto-discover] ${postId}: enqueued ${enqueuedCount} new URLs, queue size=${queue.length}, crawled=${crawled}/${crawlDepth}`);
                // Respectful rate limit — Reddit RSS allows ~60 req/min but
                // aggressive calling triggers IP-level blocking that lasts
                // several minutes. We use 3s between requests to stay safe.
                await sleep(3000);
            }
            // Final save with all discovered chapters
            // Always save (even if no new chapters) to persist processedPostIds for resume
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "saving"
            });
            const all = [
                ...knownChapters,
                ...newChapters
            ];
            const seen = new Set();
            const deduped = all.filter((c)=>{
                if (seen.has(c.postId)) return false;
                seen.add(c.postId);
                return true;
            });
            await (0,user_chapters/* saveImportedChapters */.cK)(slug, deduped, {
                source: "mixed",
                processedPostIds: Array.from(processedPostIds)
            });
            knownChapters = deduped;
        }
        // =====================================================
        // Stage 4b: Wayback Chapter Crawl (parallel instance)
        // =====================================================
        // After hfy.foundation gives us 925 chapters, continue crawling from
        // chapter 925 via Wayback Machine snapshots. Wayback has archived
        // copies of individual Reddit posts — we fetch each chapter's
        // Wayback snapshot, parse its "next chapter" links, and continue
        // the BFS chain through Wayback until no more snapshots are found.
        //
        // This runs IN PARALLEL with the RSS crawler — both contribute
        // new chapters to the same `knownChapters` list. Deduplication
        // by postId prevents duplicates.
        if (shouldRun("wayback-crawl") && useCrawler && crawlDepth > 0 && (knownChapters.length > 0 || startUrl)) {
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "wayback-chapter-crawl"
            });
            const waybackStartChapter = startUrl ? {
                url: startUrl,
                postId: ""
            } : knownChapters[knownChapters.length - 1];
            const waybackQueue = [
                waybackStartChapter.url
            ];
            const waybackProcessed = new Set();
            let waybackCrawled = 0;
            const waybackDepth = Math.min(crawlDepth, 200); // cap Wayback crawl
            while(waybackQueue.length > 0 && waybackCrawled < waybackDepth){
                const url = waybackQueue.shift();
                const normalized = normalizeRedditUrl(url);
                const postId = extractPostId(normalized);
                if (!postId || waybackProcessed.has(postId) || knownPostIds.has(postId)) {
                    // If already known but not processed via Wayback, still process it
                    if (postId && knownPostIds.has(postId) && !waybackProcessed.has(postId)) {
                    // fall through to process
                    } else {
                        continue;
                    }
                }
                waybackProcessed.add(postId);
                updateProgress(jobId, {
                    currentlyFetching: `[WB] ${normalized}`
                });
                // Fetch chapter content from Wayback Machine snapshot
                try {
                    const waybackContent = await (0,wayback/* fetchChapterFromWayback */.gb)(normalized);
                    if (waybackContent.ok) {
                        waybackCrawled++;
                        // Add as new chapter if not already known
                        if (!knownPostIds.has(postId)) {
                            knownChapters.push({
                                title: waybackContent.title,
                                url: normalized,
                                postId
                            });
                            knownPostIds.add(postId);
                            updateProgress(jobId, {
                                waybackCrawlChapters: waybackCrawled,
                                totalChapters: knownChapters.length
                            });
                        }
                        // Enqueue next-chapter links found in the Wayback snapshot
                        for (const nextUrl of waybackContent.nextChapterLinks){
                            const nextNormalized = normalizeRedditUrl(nextUrl);
                            const nextPostId = extractPostId(nextNormalized);
                            if (nextPostId && !waybackProcessed.has(nextPostId) && !waybackQueue.includes(nextNormalized)) {
                                waybackQueue.push(nextNormalized);
                            }
                        }
                    } else {
                        break;
                    }
                } catch  {
                    updateProgress(jobId, {
                        errors: (auto_discover_jobs/* jobs */.LR.get(jobId)?.progress.errors ?? 0) + 1
                    });
                }
                await sleep(1500);
            }
            if (waybackCrawled > 0) {
                stageLog.push(`Wayback crawl: +${waybackCrawled} chapters via archived snapshots`);
                updateProgress(jobId, {
                    stageLog: [
                        ...stageLog
                    ]
                });
                await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
                    source: "mixed",
                    processedPostIds: Array.from(waybackProcessed)
                });
            }
        }
        // =====================================================
        // Stage 4c: Reddit JSON Crawl (easy-reddit-downloader method)
        // =====================================================
        // When Wayback stops (no more snapshots), continue crawling from
        // the last chapter via easy-reddit-downloader's JSON method.
        // This fetches the Reddit post .json endpoint (via CORS proxies)
        // and follows "next chapter" links in the post body.
        //
        // This catches the newest chapters that are too recent for
        // Wayback to have archived.
        if (shouldRun("reddit-json") && useCrawler && crawlDepth > 0 && (knownChapters.length > 0 || startUrl)) {
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "reddit-json-crawl"
            });
            const jsonStartChapter = startUrl ? {
                url: startUrl
            } : knownChapters[knownChapters.length - 1];
            const jsonQueue = [
                jsonStartChapter.url
            ];
            const jsonProcessed = new Set();
            let jsonCrawled = 0;
            const jsonDepth = Math.min(crawlDepth, 100);
            while(jsonQueue.length > 0 && jsonCrawled < jsonDepth){
                const url = jsonQueue.shift();
                const normalized = normalizeRedditUrl(url);
                const postId = extractPostId(normalized);
                if (!postId || jsonProcessed.has(postId)) continue;
                jsonProcessed.add(postId);
                // Skip if already known — but still check for next links
                const isAlreadyKnown = knownPostIds.has(postId);
                updateProgress(jobId, {
                    currentlyFetching: `[JSON] ${normalized}`
                });
                try {
                    // Use easy-reddit-downloader's downloadFromPostUrl (JSON method)
                    const result = await (0,easy_reddit_downloader/* downloadFromPostUrl */.cp)(normalized);
                    if (result?.post) {
                        jsonCrawled++;
                        // Add as new chapter if not already known
                        if (!isAlreadyKnown) {
                            knownChapters.push({
                                title: result.post.title,
                                url: normalized,
                                postId
                            });
                            knownPostIds.add(postId);
                            updateProgress(jobId, {
                                redditJsonCrawlChapters: jsonCrawled,
                                totalChapters: knownChapters.length
                            });
                        }
                        // Find next-chapter links in the post body
                        const selftext = result.post.selftext ?? "";
                        const html = result.post.selftext_html ?? "";
                        const nextUrls = (0,reddit_scraper/* findChapterLinks */.A3)(selftext, html, (0,reddit_scraper/* getActiveLinkPatterns */.yx)());
                        // Also use smart fallback: find any unvisited Reddit link
                        if (nextUrls.length === 0) {
                            const REDDIT_URL_RE = /https?:\/\/[^\s"'<\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s"'<\]]*/gi;
                            const allUrls = (selftext.match(REDDIT_URL_RE) || []).map((u)=>u.trim());
                            for (const u of allUrls){
                                const pid = extractPostId(u);
                                if (pid && !knownPostIds.has(pid) && !nextUrls.includes(u)) {
                                    nextUrls.push(u);
                                }
                            }
                        }
                        for (const nextUrl of nextUrls){
                            const nextNormalized = normalizeRedditUrl(nextUrl);
                            const nextPostId = extractPostId(nextNormalized);
                            if (nextPostId && !jsonProcessed.has(nextPostId) && !jsonQueue.includes(nextNormalized)) {
                                jsonQueue.push(nextNormalized);
                            }
                        }
                    } else {
                        // JSON method failed — try RSS as fallback
                        try {
                            const content = await (0,reddit_scraper/* fetchPostContent */.iL)(normalized);
                            if (content && !isAlreadyKnown) {
                                knownChapters.push({
                                    title: content.title,
                                    url: normalized,
                                    postId
                                });
                                knownPostIds.add(postId);
                                jsonCrawled++;
                                updateProgress(jobId, {
                                    redditJsonCrawlChapters: jsonCrawled,
                                    totalChapters: knownChapters.length
                                });
                            }
                            for (const nextUrl of content.nextChapterLinks){
                                const nextNormalized = normalizeRedditUrl(nextUrl);
                                const nextPostId = extractPostId(nextNormalized);
                                if (nextPostId && !jsonProcessed.has(nextPostId) && !jsonQueue.includes(nextNormalized)) {
                                    jsonQueue.push(nextNormalized);
                                }
                            }
                        } catch  {
                            break; // both methods failed — stop
                        }
                    }
                } catch  {
                    updateProgress(jobId, {
                        errors: (auto_discover_jobs/* jobs */.LR.get(jobId)?.progress.errors ?? 0) + 1
                    });
                }
                await sleep(2000);
            }
            if (jsonCrawled > 0) {
                stageLog.push(`Reddit JSON crawl: +${jsonCrawled} chapters via easy-reddit-downloader method`);
                updateProgress(jobId, {
                    stageLog: [
                        ...stageLog
                    ]
                });
                await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
                    source: "mixed",
                    processedPostIds: Array.from(jsonProcessed)
                });
            }
        }
        // Stage 5a: BACKWARD CRAWL — follow "previous chapter" links from the
        // first known chapter to discover chapters BEFORE the starting point.
        // This fixes the missing-first-chapter bug where hfy.foundation or the
        // wiki starts at chapter 2. Reddit search is usually blocked, so we
        // can't search for "chapter 1" — but we CAN fetch chapter 2's RSS
        // and look for "previous" links in the body.
        if (knownChapters.length > 0) {
            const beforeCount5a = knownChapters.length;
            const backwardProcessed = new Set();
            const backwardQueue = [
                knownChapters[0].url
            ]; // start from FIRST chapter
            let backwardCount = 0;
            const PREV_PATTERNS = [
                /previous\s*chapter/i,
                /\[prev\]/i,
                /previous\s*part/i,
                /previous\s*$/i,
                /\bprev\b/i,
                /previous/i,
                /\[previous\]/i,
                /last\s*chapter/i,
                /prior\s*chapter/i
            ];
            while(backwardQueue.length > 0 && backwardCount < 50){
                const url = backwardQueue.shift();
                const normalized = normalizeRedditUrl(url);
                const postId = extractPostId(normalized);
                if (!postId || backwardProcessed.has(postId)) continue;
                backwardProcessed.add(postId);
                updateProgress(jobId, {
                    currentlyFetching: `[PREV] ${normalized}`
                });
                try {
                    const content = await (0,reddit_scraper/* fetchPostContent */.iL)(normalized);
                    backwardCount++;
                    // Look for "previous" links in the body
                    const selftext = content.selftext || "";
                    const selftextHtml = content.selftextHtml || "";
                    // Find ALL reddit links in the body
                    const REDDIT_URL_RE = /https?:\/\/[^\s"'<\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s"'<\]]*/gi;
                    const allUrls = (selftext.match(REDDIT_URL_RE) || []).map((u)=>u.trim());
                    // Also parse markdown links [text](url) for previous patterns
                    const mdLinkRe = /\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g;
                    let m;
                    while((m = mdLinkRe.exec(selftext)) !== null){
                        const text = m[1];
                        const linkUrl = m[2];
                        if (PREV_PATTERNS.some((p)=>p.test(text)) && REDDIT_POST_URL_PATTERN_RE.test(linkUrl)) {
                            allUrls.push(linkUrl);
                        }
                    }
                    // Check which URLs are "previous" (not already known)
                    for (const u of allUrls){
                        const prevNormalized = normalizeRedditUrl(u);
                        const prevPostId = extractPostId(prevNormalized);
                        if (prevPostId && !knownPostIds.has(prevPostId) && !backwardQueue.includes(prevNormalized)) {
                            // This is a previous chapter we haven't found yet!
                            try {
                                const prevContent = await (0,reddit_scraper/* fetchPostContent */.iL)(prevNormalized);
                                if (prevContent) {
                                    // Insert at the BEGINNING of the chapter list
                                    knownChapters.unshift({
                                        title: prevContent.title,
                                        url: prevNormalized,
                                        postId: prevPostId
                                    });
                                    knownPostIds.add(prevPostId);
                                    // Continue backward from this chapter
                                    backwardQueue.push(prevNormalized);
                                    updateProgress(jobId, {
                                        totalChapters: knownChapters.length,
                                        stageLog: [
                                            ...stageLog,
                                            `Backward: found "${prevContent.title.slice(0, 40)}"`
                                        ]
                                    });
                                }
                            } catch  {
                            // can't fetch this previous chapter — skip
                            }
                        }
                    }
                } catch  {
                // can't fetch — skip
                }
                await sleep(2000);
            }
            const added5a = knownChapters.length - beforeCount5a;
            if (added5a > 0) {
                stageLog.push(`Backward crawl: +${added5a} early chapters found (including chapter 1)`);
                updateProgress(jobId, {
                    totalChapters: knownChapters.length,
                    stageLog: [
                        ...stageLog
                    ]
                });
                await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
                    source: "mixed",
                    processedPostIds: cached?.processedPostIds
                });
            }
        }
        // Stage 5: Reddit Live Search — find the NEWEST chapters that are more
        // recent than hfy.foundation's cutoff (Feb 2024). Search r/HFY for the
        // series name and add any chapters we don't already have.
        if (shouldRun("reddit-search")) {
            (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
                stage: "reddit-search"
            });
            try {
                const searchResults = await (0,reddit_scraper/* searchSeries */.mG)(seriesName, "new");
                const beforeCount = knownChapters.length;
                for (const result of searchResults){
                    // searchReddit returns SeriesStub with id, title, wikiUrl
                    // The wikiUrl is actually the Reddit post permalink
                    const permalink = result.wikiUrl;
                    if (!permalink) continue;
                    const postIdMatch = permalink.match(/\/comments\/([a-z0-9]+)/i);
                    if (!postIdMatch) continue;
                    const postId = postIdMatch[1];
                    if (!knownPostIds.has(postId)) {
                        knownChapters.push({
                            title: result.title,
                            url: permalink,
                            postId
                        });
                        knownPostIds.add(postId);
                    }
                }
                const added = knownChapters.length - beforeCount;
                if (added > 0) {
                    stageLog.push(`Reddit search: +${added} new chapters found`);
                    updateProgress(jobId, {
                        redditSearchChapters: added,
                        totalChapters: knownChapters.length,
                        stageLog: [
                            ...stageLog
                        ]
                    });
                    await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
                        source: "mixed",
                        processedPostIds: cached?.processedPostIds
                    });
                } else {
                    stageLog.push(`Reddit search: no new chapters found`);
                    updateProgress(jobId, {
                        stageLog: [
                            ...stageLog
                        ]
                    });
                }
            } catch (err) {
                stageLog.push(`Reddit search: failed (${err?.message?.slice(0, 40)})`);
                updateProgress(jobId, {
                    stageLog: [
                        ...stageLog
                    ]
                });
            }
        }
        // Final stage: SORT chapters by chapter number
        (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
            stage: "saving"
        });
        const { sortChaptersByNumber } = await Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 4945));
        knownChapters = sortChaptersByNumber(knownChapters);
        await (0,user_chapters/* saveImportedChapters */.cK)(slug, knownChapters, {
            source: "mixed",
            processedPostIds: cached?.processedPostIds
        });
        stageLog.push(`Sorted: ${knownChapters.length} chapters by chapter number`);
        updateProgress(jobId, {
            totalChapters: knownChapters.length,
            stageLog: [
                ...stageLog
            ]
        });
        // Done
        (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
            status: "completed",
            stage: "done",
            result: {
                chapters: knownChapters,
                source: (cached?.chapters?.length ?? 0) > 0 ? "cache" : knownChapters.length > (auto_discover_jobs/* jobs */.LR.get(jobId)?.progress.waybackChapters ?? 0) ? "mixed" : "wayback"
            }
        });
    } catch (err) {
        (0,auto_discover_jobs/* updateJob */.lh)(jobId, {
            status: "failed",
            error: err?.message ?? "Unknown error"
        });
    }
}
// =====================================================
// Helpers
// =====================================================
const REDDIT_POST_URL_PATTERN_RE = /reddit\.com\/r\/\w+\/comments\/([a-z0-9]+)/i;
function normalizeRedditUrl(url) {
    if (!url || typeof url !== "string") return "";
    try {
        // Strip Wayback Machine wrapper if present
        let cleaned = url;
        const waybackMatch = url.match(/https?:\/\/web\.archive\.org\/web\/\d+\/(https?:\/\/.+)/i);
        if (waybackMatch) {
            cleaned = waybackMatch[1];
        }
        return cleaned.replace(/[?#].*$/, "").replace(/\/$/, "").replace(/^https?:\/\/(www\.|old\.|new\.|np\.)?reddit\.com/i, "https://www.reddit.com").replace(/\/r\/HFY\//i, "/r/HFY/").replace(/\/r\/hfy\//i, "/r/HFY/").replace(/\/comments\//i, "/comments/").toLowerCase();
    } catch  {
        return url || "";
    }
}
function extractPostId(url) {
    const m = url.match(/\/comments\/([a-z0-9]+)/i);
    return m ? m[1] : null;
}
/**
 * SMART NEXT-LINK DISCOVERY for abbreviated series (OOCS, etc.)
 *
 * When the explicit NEXT_LINK_PATTERNS don't match (because the author
 * wrote "[Part 61](url)" or "[OOCS 61](url)" instead of "[Next](url)"),
 * fall back to finding ANY reddit comments URL in the post body that
 * we haven't discovered yet.
 *
 * Strategy:
 *   1. Find all reddit comments URLs in the post body (HTML + markdown)
 *   2. Filter out "previous chapter" links (URLs we've already discovered)
 *   3. Filter out the current post's own URL
 *   4. Return the remaining URLs as candidate "next" links
 *
 * This handles series where:
 *   - The name is abbreviated in later chapters (OOCS, etc.)
 *   - The author uses non-standard link text ("Part 61", ">>", "→")
 *   - The author posts bare URLs without any link text
 */ // Words that indicate a link is to a PREQUEL or ORIGINAL series, not the
// current series' next chapter. When the crawler finds these words near a
// Reddit link, it should NOT follow that link (it would crawl the wrong series).
const PREQUEL_INDICATORS = [
    /previous\s*chapter/i,
    /\bprev\b/i,
    /\bfirst\s*chapter/i,
    /\boriginal\s*series/i,
    /\bprequel\b/i,
    /\bbook\s*1\b/i,
    /\bpart\s*1\b/i,
    /\bbeginning\b/i,
    /\bstart\s*here/i,
    /\bfrom\s*the\s*start/i,
    /\bbefore\s*this/i,
    /\bearlier/i
];
function findAnyUnvisitedRedditLinks(markdown, html, discoveredPostIds) {
    const found = new Set();
    const REDDIT_POST_URL_RE = /https?:\/\/[^\s"'<\]]*reddit\.com\/r\/\w+\/comments\/[a-z0-9]+[^\s"'<\]]*/gi;
    // Build a map of URL → surrounding context (the text near the link)
    // so we can filter out prequel/previous/original links.
    const urlContexts = new Map();
    // Collect all reddit comments URLs from markdown + their context
    // Look at the ~100 chars before each URL to check for prequel indicators
    const mdMatches = markdown.match(REDDIT_POST_URL_RE) || [];
    for (const url of mdMatches){
        const trimmed = url.trim();
        found.add(trimmed);
        // Find context (100 chars before the URL in the markdown)
        const idx = markdown.indexOf(url);
        if (idx >= 0) {
            const start = Math.max(0, idx - 100);
            const context = markdown.slice(start, idx + url.length + 50);
            urlContexts.set(trimmed, context);
        } else {
            urlContexts.set(trimmed, "");
        }
    }
    // Collect from HTML (decode entities first)
    if (html) {
        const decoded = html.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
        const htmlMatches = decoded.match(REDDIT_POST_URL_RE) || [];
        for (const url of htmlMatches){
            const trimmed = url.trim();
            found.add(trimmed);
            if (!urlContexts.has(trimmed)) {
                const idx = decoded.indexOf(url);
                if (idx >= 0) {
                    const start = Math.max(0, idx - 100);
                    const context = decoded.slice(start, idx + url.length + 50);
                    urlContexts.set(trimmed, context);
                } else {
                    urlContexts.set(trimmed, "");
                }
            }
        }
    }
    // Filter: only keep URLs whose postId is NOT in discoveredPostIds
    // AND whose context doesn't contain prequel indicators
    const result = [];
    for (const url of found){
        const postId = extractPostId(url);
        if (postId && !discoveredPostIds.has(postId)) {
            // Check if the link context indicates this is a prequel/previous link
            const context = urlContexts.get(url) || "";
            const isPrequelLink = PREQUEL_INDICATORS.some((re)=>re.test(context));
            if (!isPrequelLink) {
                result.push(url);
            } else {
                console.log(`[auto-discover] Skipping prequel link: ${postId} (context: "${context.slice(0, 60)}...")`);
            }
        }
    }
    return result;
}
function sleep(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fauto-discover%2Froute&name=app%2Fapi%2Fauto-discover%2Froute&pagePath=private-next-app-dir%2Fapi%2Fauto-discover%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fauto-discover%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/auto-discover/route",
        pathname: "/api/auto-discover",
        filename: "route",
        bundlePath: "app/api/auto-discover/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/auto-discover/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/auto-discover/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 3033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchFromHfyFoundation: () => (/* binding */ fetchFromHfyFoundation)
/* harmony export */ });
/* unused harmony exports searchSeries, fetchSeriesChapters */
// HFY NEKROCODEXXX — hfy.foundation Scraper (4th fallback in the cascade)
// =====================================================
// hfy.foundation is a community-maintained index of r/HFY stories.
// It has a REST API at https://api.hfy.foundation that returns:
//   - Series metadata (name, author, total chapter count)
//   - All chapters with live Reddit permalinks
//
// The data is ~2 years out of date (last updated ~Feb 2024) but covers
// many series with hundreds of chapters that the wiki only partially lists.
//
// Usage in the 5-stage cascade:
//   Stage 1: Reddit RSS (live, current)
//   Stage 2: Reddit wiki via Wayback Machine (archived wiki pages)
//   Stage 3: BFS crawl via RSS (follows "next chapter" links)
//   Stage 4: hfy.foundation (this module — indexed search engine)
//   Stage 5: Reddit live search (finds newest chapters after hfy.foundation)
//
// hfy.foundation serves as a "chapter index" — it gives us 800+ chapter URLs
// for series where the wiki only lists 50-60. We extract the live Reddit
// permalinks and use them as starting points for further crawling.
const HFY_API = "https://api.hfy.foundation";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
/**
 * Search hfy.foundation for a series by name.
 * Returns the series ID if found.
 *
 * The search API is at /search/stories and requires:
 *   q=<query> — search terms
 *   type=series — filter to series only
 *   nsfw=all — include NSFW
 *   sort=random — sort order (required by the API, but we try multiple sorts)
 *
 * Since sort=random returns random results, we paginate through multiple
 * pages to find the series.
 */ async function searchSeries(query) {
    const queryLower = query.toLowerCase().replace(/_/g, " ").trim();
    // Try multiple sort options + pages to find the series
    const sorts = [
        "random",
        "random",
        "random"
    ]; // try 3 random pages
    for (const sort of sorts){
        for(let page = 1; page <= 3; page++){
            try {
                const params = new URLSearchParams({
                    q: query,
                    type: "series",
                    nsfw: "all",
                    sort,
                    page: String(page)
                });
                const url = `${HFY_API}/search/stories?${params}`;
                const res = await fetch(url, {
                    headers: {
                        "User-Agent": UA,
                        Accept: "application/json"
                    },
                    signal: AbortSignal.timeout(10000),
                    cache: "no-store"
                });
                if (!res.ok) continue;
                const data = await res.json();
                const results = Array.isArray(data) ? data : data?.data ?? [];
                if (!Array.isArray(results)) continue;
                // Find the best match
                for (const r of results){
                    const series = r.series;
                    if (!series) continue;
                    const name = (series.name || "").toLowerCase();
                    // Exact match
                    if (name === queryLower) {
                        return {
                            found: true,
                            seriesId: series.id,
                            seriesName: series.name,
                            storyCount: series.story_count
                        };
                    }
                }
            } catch  {
            // try next page
            }
        }
    }
    // Fallback: try a more targeted search with just the first few words
    const shortQuery = queryLower.split(" ").slice(0, 3).join(" ");
    if (shortQuery !== queryLower) {
        try {
            const params = new URLSearchParams({
                q: shortQuery,
                type: "series",
                nsfw: "all",
                sort: "random"
            });
            const url = `${HFY_API}/search/stories?${params}`;
            const res = await fetch(url, {
                headers: {
                    "User-Agent": UA,
                    Accept: "application/json"
                },
                signal: AbortSignal.timeout(10000),
                cache: "no-store"
            });
            if (res.ok) {
                const data = await res.json();
                const results = Array.isArray(data) ? data : data?.data ?? [];
                if (Array.isArray(results)) {
                    // Find contains match
                    for (const r of results){
                        const series = r.series;
                        if (!series) continue;
                        const name = (series.name || "").toLowerCase();
                        if (name.includes(queryLower) || queryLower.includes(name)) {
                            return {
                                found: true,
                                seriesId: series.id,
                                seriesName: series.name,
                                storyCount: series.story_count
                            };
                        }
                    }
                }
            }
        } catch  {
        // give up
        }
    }
    return {
        found: false
    };
}
/**
 * Fetch all chapters for a series from hfy.foundation.
 * Returns the full chapter list with live Reddit permalinks.
 *
 * @param seriesId - the hfy.foundation series ID
 */ async function fetchSeriesChapters(seriesId) {
    try {
        const url = `${HFY_API}/series/${seriesId}`;
        const res = await fetch(url, {
            headers: {
                "User-Agent": UA,
                Accept: "application/json"
            },
            signal: AbortSignal.timeout(30000),
            cache: "no-store"
        });
        if (!res.ok) {
            return null;
        }
        const data = await res.json();
        const stories = data?.stories ?? [];
        if (stories.length === 0) {
            return null;
        }
        // Sort by created_at (oldest first)
        stories.sort((a, b)=>{
            const da = new Date(a.created_at || 0).getTime();
            const db = new Date(b.created_at || 0).getTime();
            return da - db;
        });
        const chapters = stories.map((s)=>{
            const permalink = s.reddit_permalink || "";
            const url = permalink.startsWith("http") ? permalink : `https://www.reddit.com${permalink}`;
            return {
                title: s.title || `Chapter ${s.reddit_id}`,
                url,
                postId: s.reddit_id
            };
        });
        const snapshotDate = stories[stories.length - 1]?.created_at || "";
        return {
            id: data.id,
            name: data.name,
            author: data.author?.username || "unknown",
            storyCount: data.story_count,
            totalWords: data.total_words,
            chapters,
            snapshotDate
        };
    } catch  {
        return null;
    }
}
/**
 * Full pipeline: search for a series by name, then fetch all chapters.
 * Returns the chapter list if found.
 *
 * This is the main entry point for the 4th-stage fallback.
 */ async function fetchFromHfyFoundation(seriesName) {
    // Search for the series
    const search = await searchSeries(seriesName);
    if (!search.found || !search.seriesId) {
        return {
            found: false,
            chapters: [],
            error: search.error || "Series not found on hfy.foundation"
        };
    }
    // Fetch all chapters
    const series = await fetchSeriesChapters(search.seriesId);
    if (!series || series.chapters.length === 0) {
        return {
            found: false,
            chapters: [],
            error: "Series found but no chapters available"
        };
    }
    return {
        found: true,
        chapters: series.chapters,
        seriesId: series.id,
        seriesName: series.name,
        author: series.author,
        snapshotDate: series.snapshotDate
    };
}


/***/ }),

/***/ 5511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6439:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 7614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cp: () => (/* binding */ downloadFromPostUrl)
/* harmony export */ });
/* unused harmony exports MAX_POSTS_PER_REQUEST, MAX_FILENAME_LENGTH, DEFAULT_REQUEST_TIMEOUT, POST_DELAY_MS, MEDIA_FORMATS, sanitizeFileName, getFileName, getPostType, getMediaDownloadInfo, isUserProfile, isSearchQuery, extractName, buildRedditApiUrl, redditJsonFetch, downloadSubredditPosts, iterateAllPosts, parsePostListFile */
/* harmony import */ var _cors_proxies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3673);
// HFY NEKROCODEXXX — Secondary Fallback Scraper
// =====================================================
// Faithful TypeScript port of josephrcox/easy-reddit-downloader
// (https://github.com/josephrcox/easy-reddit-downloader) — MIT licensed.
//
// Used as a SECONDARY FALLBACK when the primary Reddit scraper
// (reddit-scraper.ts) fails. The upstream project is a Node.js CLI
// that consumes Reddit's public JSON API (no OAuth, no auth needed)
// by appending `.json` to any Reddit page URL.
//
// Improvements made over upstream:
//   1. Custom User-Agent (upstream sends axios default — Reddit throttles that)
//   2. Real 429/503 backoff with Retry-After respect (upstream has none)
//   3. Exponential backoff retry on network errors
//   4. All requests go through the 250+ CORS proxy pool so the
//      scraper works from the browser
//
// Key upstream logic preserved:
//   - URL building: buildRedditApiUrl() with sorting/time/limit/after
//   - Pagination: cursor-based using `after` = last child's `name` fullname
//   - Post type detection: getPostType() priority order (self/media/poll/gallery/link)
//   - Comments: data[1].data.children (1 level of replies)
//   - MAX_POSTS_PER_REQUEST = 100

// =====================================================
// Constants ported from upstream lib/utils.js
// =====================================================
const MAX_POSTS_PER_REQUEST = 100;
const MAX_FILENAME_LENGTH = 240;
const DEFAULT_REQUEST_TIMEOUT = 30000;
const POST_DELAY_MS = 250; // upstream sleep between posts
const MEDIA_FORMATS = (/* unused pure expression or super */ null && ([
    "jpeg",
    "jpg",
    "gif",
    "png",
    "mp4",
    "webm",
    "gifv"
]));
// Custom UA — diverges from upstream (which sends axios default).
// Reddit's API guidelines require a descriptive, unique UA.
const USER_AGENT = "HFY-NEKROCODEXXX/1.0 (Reddit series reader; +https://github.com/josephrcox/easy-reddit-downloader fork)";
// =====================================================
// utils.js faithful port
// =====================================================
function sanitizeFileName(fileName) {
    return fileName.replace(/[/\\?%*:|"<>]/g, "-").replace(/([^/])\/([^/])/g, "$1_$2");
}
function getFileName(post, config = {}) {
    let fileName = "";
    const created = post.created_utc ?? post.created ?? 0;
    if (config.showDate ?? true) {
        const date = new Date(created * 1000);
        fileName += `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    }
    if (config.showScore ?? true) fileName += `_score=${post.score}`;
    if (config.showSubreddit ?? true) fileName += `_${post.subreddit}`;
    if (config.showAuthor ?? true) fileName += `_${post.author}`;
    if (config.showTitle ?? true) fileName += `_${sanitizeFileName(post.title)}`;
    fileName = fileName.replace(/(?:\r\n|\r|\n|\t)/g, "").replace(/\ufe0e/g, "").replace(/\ufe0f/g, "");
    if (fileName.length > MAX_FILENAME_LENGTH) {
        fileName = fileName.substring(0, MAX_FILENAME_LENGTH);
    }
    return fileName;
}
/** Post-type detection — faithful priority order from upstream */ function getPostType(post) {
    if (post.post_hint === "self" || post.is_self) return 0;
    if (post.post_hint === "image" || post.post_hint === "rich:video" && !(post.domain ?? "").includes("youtu") || post.post_hint === "hosted:video" || post.post_hint === "link" && (post.domain ?? "").includes("imgur") && !(post.url_overridden_by_dest ?? "").includes("gallery") || (post.domain ?? "").includes("i.redd.it") || (post.domain ?? "").includes("i.reddituploads.com")) {
        return 1;
    }
    if (post.poll_data !== undefined) return 3;
    if ((post.domain ?? "").includes("reddit.com") && post.is_gallery) return 4;
    return 2;
}
function getMediaDownloadInfo(post) {
    let downloadURL = post.url ?? "";
    let fileType = downloadURL.split(".").pop() ?? "";
    if (post.preview !== undefined) {
        if (post.preview.reddit_video_preview !== undefined) {
            downloadURL = post.preview.reddit_video_preview.fallback_url;
            fileType = "mp4";
        } else if ((post.url_overridden_by_dest ?? "").includes(".gifv")) {
            downloadURL = (post.url_overridden_by_dest ?? "").replace(".gifv", ".mp4");
            fileType = "mp4";
        } else if (post.preview.images?.[0]?.source?.url) {
            const sourceURL = post.preview.images[0].source.url;
            for (const format of MEDIA_FORMATS){
                if (sourceURL.toLowerCase().includes(format.toLowerCase())) {
                    fileType = format;
                    break;
                }
            }
            if (downloadURL.includes("i.reddituploads.com")) {
                downloadURL = sourceURL.replaceAll("&amp;", "&");
            }
        }
    }
    if (post.media !== undefined && post.post_hint === "hosted:video") {
        downloadURL = post.media.reddit_video.fallback_url;
        fileType = "mp4";
    } else if (post.media !== undefined && post.post_hint === "rich:video" && post.media.oembed?.thumbnail_url !== undefined) {
        downloadURL = post.media.oembed.thumbnail_url;
        fileType = "gif";
    }
    return {
        downloadURL,
        fileType
    };
}
function isUserProfile(target) {
    return target.includes("u/") || target.includes("user/") || target.includes("/u/");
}
function isSearchQuery(target) {
    return target.startsWith("search:");
}
function extractName(target) {
    if (isUserProfile(target)) {
        if (target.includes("user/")) return target.split("user/").pop() ?? "";
        return target.split("u/").pop() ?? "";
    } else if (isSearchQuery(target)) {
        return target.split("search:").pop().replaceAll(" ", "+");
    }
    return target;
}
/** Faithful port of buildRedditApiUrl */ function buildRedditApiUrl(opts) {
    const { target, isUser, isSearch, sorting, time, limit, after = "" } = opts;
    if (isUser) {
        return `https://www.reddit.com/user/${target}/submitted/.json?limit=${limit}&after=${after}`;
    } else if (isSearch) {
        const encoded = target.replaceAll(":", "%3A");
        return `https://www.reddit.com/search/.json?q=${encoded}&type=post&include_over_18=on&sort=${sorting}&limit=${limit}&after=${after}`;
    }
    return `https://www.reddit.com/r/${target}/${sorting}/.json?sort=${sorting}&t=${time}&limit=${limit}&after=${after}`;
}
async function sleep(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * Fetch a Reddit JSON URL with exponential backoff + Retry-After respect.
 * Goes through the CORS proxy pool.
 */ async function redditJsonFetch(url, opts = {}) {
    const { maxAttempts = 4, initialDelayMs = 1000 } = opts;
    for(let attempt = 0; attempt < maxAttempts; attempt++){
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(url, {
            expectedType: "json",
            timeoutMs: DEFAULT_REQUEST_TIMEOUT,
            maxProxiesToTry: 12,
            headers: {
                "User-Agent": USER_AGENT,
                Accept: "application/json, text/plain, */*"
            }
        });
        if (result.ok) {
            try {
                return JSON.parse(result.text);
            } catch  {
            // fall through to retry
            }
        }
        // Reddit rate-limit backoff
        const delay = initialDelayMs * Math.pow(2, attempt);
        await sleep(Math.min(delay, 16000));
    }
    return null;
}
/**
 * Faithful port of downloadSubredditPosts — returns one page of posts.
 * Caller loops with `afterCursor` until `isLastPage === true`.
 */ async function downloadSubredditPosts(target, opts = {}) {
    const sorting = opts.sorting ?? "new";
    const time = opts.time ?? "all";
    const limit = Math.min(opts.limit ?? MAX_POSTS_PER_REQUEST, MAX_POSTS_PER_REQUEST);
    const after = opts.after ?? "";
    const isUser = isUserProfile(target);
    const isSearch = isSearchQuery(target);
    const name = extractName(target);
    if (!name) return null;
    const reqUrl = buildRedditApiUrl({
        target: name,
        isUser,
        isSearch,
        sorting,
        time,
        limit,
        after
    });
    const data = await redditJsonFetch(reqUrl);
    if (!data) return null;
    if (data.message === "Not Found" || !data?.data?.children?.length) {
        return null;
    }
    const children = data.data.children;
    let postsRemaining = limit;
    if (children.length < postsRemaining) {
        postsRemaining = children.length;
    }
    const posts = children.map((c)=>c.data);
    const lastChild = children[children.length - 1];
    const afterCursor = lastChild?.data?.name ?? null;
    const isLastPage = children.length < limit;
    return {
        posts,
        afterCursor,
        isLastPage,
        subreddit: posts[0]?.subreddit ?? name
    };
}
/**
 * Faithful port of downloadFromPostUrl — fetches a single post by URL.
 * Returns the post data + its top-level comments.
 */ async function downloadFromPostUrl(url) {
    const jsonUrl = url.endsWith(".json") ? url : `${url.replace(/\?.*$/, "")}.json`;
    const data = await redditJsonFetch(jsonUrl);
    if (!data || !Array.isArray(data) || data.length < 2) return null;
    const post = data[0]?.data?.children?.[0]?.data ?? null;
    if (!post) return null;
    const commentChildren = data[1]?.data?.children ?? [];
    const comments = commentChildren.filter((c)=>c.kind === "t1" && c.data?.body).map((c)=>extractComment(c.data));
    return {
        post,
        comments
    };
}
function extractComment(d) {
    const replies = [];
    try {
        const replyChildren = d?.replies?.data?.children ?? [];
        // Upstream only reads the first reply — preserve that behavior
        if (replyChildren[0]?.data?.body) {
            replies.push(extractComment(replyChildren[0].data));
        }
    } catch  {
    // ignore
    }
    return {
        author: d.author ?? "",
        body: d.body ?? "",
        created_utc: d.created_utc ?? 0,
        score: d.score ?? 0,
        replies
    };
}
/**
 * Iterate all posts in a subreddit/user/search — handles pagination.
 * Calls onBatch for each page; respects MAX_POSTS_PER_REQUEST.
 *
 * Upstream's checkIfDone loop: when downloaded % MAX === 0 and !lastAPICall,
 * request next page using lastChild's name as `after`.
 */ async function iterateAllPosts(target, onBatch, opts = {}) {
    const { sorting = "new", time = "all", maxPages = 50, delayMs = POST_DELAY_MS } = opts;
    let after = "";
    let page = 0;
    let totalPosts = 0;
    let subreddit = null;
    while(page < maxPages){
        const result = await downloadSubredditPosts(target, {
            sorting,
            time,
            limit: MAX_POSTS_PER_REQUEST,
            after
        });
        if (!result) break;
        if (!subreddit) subreddit = result.subreddit;
        await onBatch(result.posts, result.subreddit);
        totalPosts += result.posts.length;
        page++;
        if (result.isLastPage || !result.afterCursor) break;
        after = result.afterCursor;
        await sleep(delayMs);
    }
    return {
        totalPages: page,
        totalPosts,
        subreddit
    };
}
/**
 * Parse a download_post_list.txt-style file content — faithful port.
 * Returns Reddit post URLs only (skip blanks/comments/non-reddit/non-comments).
 */ function parsePostListFile(content) {
    return content.split("\n").map((l)=>l.trim()).filter((l)=>l && !l.startsWith("#") && l.startsWith("https://www.reddit.com") && l.includes("/comments/"));
}


/***/ }),

/***/ 9021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ 9641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchFromWayback: () => (/* binding */ fetchFromWayback),
/* harmony export */   gb: () => (/* binding */ fetchChapterFromWayback)
/* harmony export */ });
/* unused harmony exports checkWayback, batchFetchFromWayback */
/* harmony import */ var _user_chapters__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4945);
/* harmony import */ var _reddit_scraper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4034);
// HFY NEKROCODEXXX — Wayback Machine Auto-Fetcher
// =====================================================
// Reddit blocks server-side requests from this sandbox IP.
// But archive.org's Wayback Machine has snapshots of many
// r/HFY wiki pages AND individual chapter posts — and Wayback
// is NOT blocked.
//
// Strategy:
//   1. Check Wayback availability API for the wiki URL
//   2. If a snapshot exists, fetch the HTML directly
//   3. Parse the HTML for Reddit comments links
//   4. Return the chapter list
//
// Also: fetchChapterFromWayback() can fetch individual chapter
// post content from Wayback snapshots when Reddit's RSS is
// rate-limited. This keeps the BFS crawler working even when
// Reddit blocks our IP.


const WAYBACK_AVAILABLE = "https://archive.org/wayback/available?url=";
const WAYBACK_CDX = "http://web.archive.org/cdx/search/cdx?url=";
const WAYBACK_BASE = "https://web.archive.org/web/";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
/**
 * Check if Wayback has a snapshot of the given Reddit wiki URL.
 * Returns the snapshot URL + timestamp if found.
 *
 * We run the availability API and CDX API in RACE mode — whichever
 * returns first with a hit wins. The CDX API is more reliable but
 * slightly slower; the availability API is faster but misses many
 * snapshots due to URL format pickiness.
 */ async function checkWayback(wikiUrl) {
    // Run both strategies in parallel — first hit wins
    const [availResult, cdxResult] = await Promise.allSettled([
        checkWaybackAvailability(wikiUrl),
        checkWaybackCDX(wikiUrl)
    ]);
    // Prefer availability API result if it found something (faster path)
    if (availResult.status === "fulfilled" && availResult.value.found) {
        return availResult.value;
    }
    // Fall back to CDX result
    if (cdxResult.status === "fulfilled" && cdxResult.value.found) {
        return cdxResult.value;
    }
    return {
        found: false
    };
}
/**
 * Availability API strategy — tries multiple URL normalizations.
 * Fast but misses many snapshots.
 */ async function checkWaybackAvailability(wikiUrl) {
    const variants = new Set();
    variants.add(wikiUrl);
    const noProto = wikiUrl.replace(/^https?:\/\//, "");
    variants.add(noProto);
    variants.add(noProto.replace(/^www\./, ""));
    const noSlash = wikiUrl.replace(/\/$/, "");
    variants.add(noSlash);
    variants.add(noSlash.replace(/^https?:\/\//, ""));
    variants.add(noSlash.replace(/^https?:\/\/www\./, ""));
    // Try all variants concurrently — first hit wins
    const promises = Array.from(variants).map(async (variant)=>{
        try {
            const url = `${WAYBACK_AVAILABLE}${encodeURIComponent(variant)}`;
            const res = await fetch(url, {
                headers: {
                    "User-Agent": UA
                },
                signal: AbortSignal.timeout(8000),
                cache: "no-store"
            });
            if (!res.ok) return null;
            const data = await res.json();
            const snapshot = data?.archived_snapshots?.closest;
            if (snapshot?.available && snapshot?.url) {
                return {
                    found: true,
                    snapshotUrl: snapshot.url,
                    timestamp: snapshot.timestamp
                };
            }
            return null;
        } catch  {
            return null;
        }
    });
    const results = await Promise.all(promises);
    const hit = results.find((r)=>r !== null);
    return hit ?? {
        found: false
    };
}
/**
 * Query the CDX API to find the most recent snapshot of a URL.
 * The CDX API is more reliable than the availability API — it lists
 * ALL snapshots, not just the "closest" one.
 */ async function checkWaybackCDX(wikiUrl) {
    // Normalize URL for CDX — strip protocol and www, keep path
    const normalized = wikiUrl.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "");
    const cdxUrl = `${WAYBACK_CDX}${normalized}&output=json&limit=1&filter=statuscode:200&collapse=timestamp:8`;
    try {
        const res = await fetch(cdxUrl, {
            headers: {
                "User-Agent": UA
            },
            signal: AbortSignal.timeout(15000),
            cache: "no-store"
        });
        if (!res.ok) return {
            found: false
        };
        const text = await res.text();
        // CDX returns [["urlkey","timestamp","original",...], [row1], [row2], ...]
        const rows = JSON.parse(text);
        if (!Array.isArray(rows) || rows.length < 2) return {
            found: false
        };
        // First row is the header, second row is the most recent snapshot
        const header = rows[0];
        const data = rows[1];
        const timestampIdx = header.indexOf("timestamp");
        const originalIdx = header.indexOf("original");
        if (timestampIdx < 0 || originalIdx < 0) return {
            found: false
        };
        const timestamp = data[timestampIdx];
        const original = data[originalIdx];
        if (!timestamp || !original) return {
            found: false
        };
        return {
            found: true,
            snapshotUrl: `${WAYBACK_BASE}${timestamp}/${original}`,
            timestamp
        };
    } catch  {
        return {
            found: false
        };
    }
}
/**
 * Fetch a wiki page from Wayback Machine and extract chapter links.
 * Returns the chapter list (also persists to user-chapters store).
 *
 * @param slug - series slug (e.g. "out_of_cruel_space")
 * @param options - { save: whether to persist to user-chapters store (default true) }
 */ async function fetchFromWayback(slug, options = {}) {
    const { save = true } = options;
    const wikiUrl = `https://www.reddit.com/r/HFY/wiki/series/${slug}/`;
    // Step 1: check Wayback availability
    const availability = await checkWayback(wikiUrl);
    if (!availability.found || !availability.snapshotUrl) {
        return {
            ok: true,
            slug,
            found: false,
            chapterCount: 0,
            chapters: []
        };
    }
    // Step 2: fetch the snapshot HTML
    let html;
    try {
        const res = await fetch(availability.snapshotUrl, {
            headers: {
                "User-Agent": UA,
                Accept: "text/html"
            },
            signal: AbortSignal.timeout(30000),
            cache: "no-store"
        });
        if (!res.ok) {
            return {
                ok: false,
                slug,
                found: false,
                chapterCount: 0,
                chapters: [],
                error: `Wayback returned HTTP ${res.status}`
            };
        }
        html = await res.text();
    } catch (err) {
        return {
            ok: false,
            slug,
            found: false,
            chapterCount: 0,
            chapters: [],
            error: err?.message ?? "Failed to fetch Wayback snapshot"
        };
    }
    // Step 3: parse the HTML for chapter links
    const { chapters, synopsis } = (0,_user_chapters__WEBPACK_IMPORTED_MODULE_0__/* .parseRedditWikiForChapters */ .rj)(html);
    if (chapters.length === 0) {
        return {
            ok: true,
            slug,
            found: true,
            chapterCount: 0,
            chapters: [],
            snapshotUrl: availability.snapshotUrl,
            snapshotTimestamp: availability.timestamp
        };
    }
    // Step 4: persist to user-chapters store
    if (save) {
        await (0,_user_chapters__WEBPACK_IMPORTED_MODULE_0__/* .saveImportedChapters */ .cK)(slug, chapters, {
            synopsis,
            source: "wayback"
        });
    }
    return {
        ok: true,
        slug,
        found: true,
        chapterCount: chapters.length,
        chapters,
        snapshotUrl: availability.snapshotUrl,
        snapshotTimestamp: availability.timestamp
    };
}
/**
 * Try to fetch from Wayback for a list of slugs in parallel.
 * Returns a map of slug → WaybackResult.
 *
 * Useful for batch pre-populating the chapter cache for many series.
 */ async function batchFetchFromWayback(slugs, options = {}) {
    const { concurrency = 3, onProgress } = options;
    const results = new Map();
    let done = 0;
    // Process in batches of `concurrency` to avoid hammering Wayback
    for(let i = 0; i < slugs.length; i += concurrency){
        const batch = slugs.slice(i, i + concurrency);
        const batchResults = await Promise.all(batch.map(async (slug)=>{
            const r = await fetchFromWayback(slug);
            return [
                slug,
                r
            ];
        }));
        for (const [slug, r] of batchResults){
            results.set(slug, r);
            done++;
            onProgress?.(done, slugs.length);
        }
    }
    return results;
}
/**
 * Fetch a single chapter's content from a Wayback Machine snapshot.
 * Used as a fallback when Reddit's RSS endpoint is rate-limited/blocked.
 *
 * @param postUrl - full Reddit post URL (e.g. https://www.reddit.com/r/HFY/comments/ol1gnm/...)
 * @returns chapter content including title, author, selftext, and next-chapter links
 */ async function fetchChapterFromWayback(postUrl) {
    const postIdMatch = postUrl.match(/\/comments\/([a-z0-9]+)/i);
    const postId = postIdMatch ? postIdMatch[1] : "";
    if (!postId) {
        return {
            ok: false,
            postId: "",
            title: "",
            author: "",
            createdUtc: 0,
            selftext: "",
            selftextHtml: "",
            nextChapterLinks: [],
            error: "Invalid post URL"
        };
    }
    // Step 1: check Wayback availability
    const availability = await checkWayback(postUrl);
    if (!availability.found || !availability.snapshotUrl) {
        return {
            ok: false,
            postId,
            title: "",
            author: "",
            createdUtc: 0,
            selftext: "",
            selftextHtml: "",
            nextChapterLinks: [],
            error: "No Wayback snapshot"
        };
    }
    // Step 2: fetch the snapshot HTML
    let html;
    try {
        const res = await fetch(availability.snapshotUrl, {
            headers: {
                "User-Agent": UA,
                Accept: "text/html"
            },
            signal: AbortSignal.timeout(30000),
            cache: "no-store"
        });
        if (!res.ok) {
            return {
                ok: false,
                postId,
                title: "",
                author: "",
                createdUtc: 0,
                selftext: "",
                selftextHtml: "",
                nextChapterLinks: [],
                error: `Wayback HTTP ${res.status}`
            };
        }
        html = await res.text();
    } catch (err) {
        return {
            ok: false,
            postId,
            title: "",
            author: "",
            createdUtc: 0,
            selftext: "",
            selftextHtml: "",
            nextChapterLinks: [],
            error: err?.message ?? "Fetch failed"
        };
    }
    // Step 3: parse the Wayback-wrapped Reddit page
    // Wayback wraps the page in its toolbar — the actual Reddit content is inside.
    // Reddit stores the post selftext in a <div class="md"> within the post body.
    return parseWaybackRedditPost(html, postId, postUrl, availability.snapshotUrl, availability.timestamp);
}
/**
 * Parse a Wayback-wrapped Reddit post page to extract chapter content.
 * Wayback pages include the full Reddit HTML — we extract:
 *   - Post title (from <h1> or <title>)
 *   - Author (from the post metadata)
 *   - Selftext (from <div class="usertext-body"> or <div class="md">)
 *   - Next-chapter links (from the selftext)
 */ function parseWaybackRedditPost(html, postId, postUrl, snapshotUrl, timestamp) {
    // Extract title — Reddit uses <h1 class="title"> or the page <title>
    let title = "";
    const titleMatch = html.match(/<h1[^>]*class="[^"]*title[^"]*"[^>]*>([\s\S]*?)<\/h1>/i);
    if (titleMatch) {
        title = stripTags(titleMatch[1]).trim();
    }
    if (!title) {
        const pageTitleMatch = html.match(/<title>([^<]+)<\/title>/i);
        if (pageTitleMatch) {
            title = pageTitleMatch[1].replace(/\s*[|:]\s*HFY\s*$/i, "").replace(/\s*:?\s*r\/HFY\s*$/i, "").trim();
        }
    }
    // Extract author — Reddit shows "u/username" or "/u/username"
    let author = "unknown";
    const authorMatch = html.match(/\/u\/([A-Za-z0-9_-]+)/);
    if (authorMatch) {
        author = authorMatch[1];
    }
    // Extract selftext — Reddit wraps post body in <div class="usertext-body"> or <div class="md">
    let selftextHtml = "";
    const usertextMatch = html.match(/<div[^>]*class="[^"]*usertext-body[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
    if (usertextMatch) {
        selftextHtml = usertextMatch[1];
    } else {
        const mdMatch = html.match(/<div[^>]*class="[^"]*md[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
        if (mdMatch) {
            selftextHtml = mdMatch[1];
        }
    }
    // Convert HTML to markdown-like text
    const selftext = htmlToMarkdown(selftextHtml);
    // Find next-chapter links in the selftext
    const nextChapterLinks = (0,_reddit_scraper__WEBPACK_IMPORTED_MODULE_1__/* .findChapterLinks */ .A3)(selftext, selftextHtml, _reddit_scraper__WEBPACK_IMPORTED_MODULE_1__/* .NEXT_LINK_PATTERNS */ .nP);
    return {
        ok: true,
        postId,
        title: title || `Chapter ${postId}`,
        author,
        createdUtc: 0,
        selftext,
        selftextHtml,
        nextChapterLinks,
        snapshotUrl,
        snapshotTimestamp: timestamp
    };
}
function stripTags(html) {
    return html.replace(/<[^>]+>/g, "");
}
function htmlToMarkdown(html) {
    let md = html;
    md = md.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, (_, t)=>`# ${stripTags(t)}\n\n`);
    md = md.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, (_, t)=>`## ${stripTags(t)}\n\n`);
    md = md.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, (_, t)=>`### ${stripTags(t)}\n\n`);
    md = md.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, (_, t)=>`**${stripTags(t)}**`);
    md = md.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, (_, t)=>`*${stripTags(t)}*`);
    md = md.replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, (_, t)=>`*${stripTags(t)}*`);
    md = md.replace(/<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi, (_, href, t)=>`[${stripTags(t)}](${href})`);
    md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_, t)=>`> ${stripTags(t).replace(/\n/g, "\n> ")}\n\n`);
    md = md.replace(/<hr[^>]*>/gi, "\n---\n\n");
    md = md.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_, t)=>`\`${stripTags(t)}\``);
    md = md.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, t)=>`\`\`\`\n${stripTags(t)}\n\`\`\`\n\n`);
    md = md.replace(/<p[^>]*>/gi, "\n\n");
    md = md.replace(/<\/p>/gi, "");
    md = md.replace(/<br\s*\/?>/gi, "\n");
    md = md.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_, t)=>`- ${stripTags(t).trim()}\n`);
    md = md.replace(/<\/?(ul|ol)[^>]*>/gi, "\n");
    md = stripTags(md);
    md = md.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
    md = md.replace(/\n{3,}/g, "\n\n\n").trim();
    return md;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813,4857,7101,4034], () => (__webpack_exec__(1157)));
module.exports = __webpack_exports__;

})();