"use strict";
(() => {
var exports = {};
exports.id = 975;
exports.ids = [975];
exports.modules = {

/***/ 261:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 1828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/crawl/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  POST: () => (POST),
  dynamic: () => (dynamic),
  maxDuration: () => (maxDuration),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: ./src/lib/reddit-scraper.ts
var reddit_scraper = __webpack_require__(4034);
// EXTERNAL MODULE: ./src/lib/easy-reddit-downloader.ts
var easy_reddit_downloader = __webpack_require__(7614);
;// ./src/lib/chapter-crawler.ts
// HFY NEKROCODEXXX — Chapter Crawler
// =====================================================
// BFS crawler that discovers all chapters in a series by
// following "next chapter" links embedded in post bodies.
//
// The r/HFY wiki only lists a subset of chapters for long
// series (e.g. "Out of Cruel Space" has 1000+ chapters but
// only ~59 are listed on the wiki). This crawler starts from
// the known chapter URLs and follows "next" links to discover
// the rest.
//
// Strategy:
//   1. Start with chapter URLs from the wiki page
//   2. For each chapter, fetch its content (via primary scraper,
//      fall back to easy-reddit-downloader port)
//   3. Parse the body for "next chapter" links
//   4. Add undiscovered URLs to the BFS queue
//   5. Continue until queue is empty or crawl-depth limit hit


// =====================================================
// Crawl — BFS through "next chapter" links
// =====================================================
async function crawlAllChapters(options) {
    const { startUrls, maxChapters = 2000, delayMs = 600, onProgress, signal } = options;
    const t0 = Date.now();
    const visited = new Set();
    const chapters = [];
    const errors = [];
    const queue = [
        ...startUrls
    ];
    let orderIndex = 0;
    const progress = {
        discovered: 0,
        queued: queue.length,
        processed: 0,
        total: queue.length,
        currentPostId: null,
        currentTitle: null,
        errors: 0,
        source: "primary"
    };
    // Mark starting URLs as known (not "discovered")
    const knownStart = new Set(startUrls.map(normalizeRedditUrl));
    while(queue.length > 0 && chapters.length < maxChapters){
        if (signal?.aborted) break;
        const url = queue.shift();
        const normalized = normalizeRedditUrl(url);
        if (visited.has(normalized)) continue;
        visited.add(normalized);
        progress.queued = queue.length;
        progress.currentPostId = extractPostId(normalized);
        // Try primary scraper first
        let content = null;
        let source = "primary";
        try {
            content = await (0,reddit_scraper/* fetchPostContent */.iL)(normalized);
        } catch (err) {
            // Fall back to easy-reddit-downloader port
            try {
                const result = await (0,easy_reddit_downloader/* downloadFromPostUrl */.cp)(normalized);
                if (result?.post) {
                    const post = result.post;
                    content = {
                        postId: post.id,
                        title: post.title,
                        author: post.author,
                        createdUtc: post.created_utc,
                        score: post.score,
                        selftext: post.selftext ?? "",
                        selftextHtml: post.selftext_html ?? "",
                        url: post.url ?? normalized,
                        permalink: `https://www.reddit.com${post.permalink}`,
                        subreddit: post.subreddit,
                        flair: post.link_flair_text,
                        numComments: post.num_comments ?? 0,
                        nextChapterLinks: (0,reddit_scraper/* findChapterLinks */.A3)(post.selftext ?? "", post.selftext_html, (0,reddit_scraper/* getActiveLinkPatterns */.yx)()).slice(0, 1),
                        prevChapterLinks: []
                    };
                    source = "fallback";
                }
            } catch (err2) {
                errors.push(1);
                progress.errors = errors.length;
            }
        }
        if (!content) {
            // Could not fetch — skip but continue
            onProgress?.(progress);
            await sleep(delayMs);
            continue;
        }
        progress.source = source;
        progress.currentTitle = content.title;
        progress.processed = chapters.length + 1;
        // hfy2epub approach: only follow the FIRST unvisited next link
        // This prevents mixing prequel and sequel chapters (e.g., "Out of Cruel Space"
        // prequel links appearing when crawling "Into A Wider Galaxy" sequel).
        // The "next" link typically appears before "previous" links in the post body,
        // so taking the first match gives us the correct next chapter.
        let nextUrls = content.nextChapterLinks.map(normalizeRedditUrl);
        // Filter to only unvisited URLs
        const unvisitedNextUrls = nextUrls.filter((u)=>{
            const pid = extractPostId(u);
            return pid && !visited.has(u);
        });
        // Only follow the FIRST unvisited next link (hfy2epub approach)
        if (unvisitedNextUrls.length > 0) {
            nextUrls = [
                unvisitedNextUrls[0]
            ];
        } else {
            nextUrls = [];
        }
        const chapter = {
            postId: content.postId,
            url: normalized,
            title: content.title,
            author: content.author,
            createdUtc: content.createdUtc,
            score: content.score,
            selftext: content.selftext,
            orderIndex,
            nextChapterUrls: nextUrls,
            discovered: !knownStart.has(normalized)
        };
        chapters.push(chapter);
        orderIndex++;
        // Enqueue only the single next URL (not all matching links)
        for (const nextUrl of nextUrls){
            if (!visited.has(nextUrl) && !queue.includes(nextUrl)) {
                queue.push(nextUrl);
                progress.discovered++;
            }
        }
        progress.queued = queue.length;
        progress.total = chapters.length + queue.length;
        progress.discovered = chapters.filter((c)=>c.discovered).length;
        onProgress?.(progress);
        // Respectful rate limit
        await sleep(delayMs);
    }
    return {
        chapters,
        totalDiscovered: chapters.length,
        errors: errors.length,
        durationMs: Date.now() - t0
    };
}
// =====================================================
// Helpers
// =====================================================
function normalizeRedditUrl(url) {
    if (!url || typeof url !== "string") return "";
    try {
        return url.replace(/[?#].*$/, "").replace(/\/$/, "").replace(/^https?:\/\/(www\.|old\.|new\.|np\.)?reddit\.com/i, "https://www.reddit.com").toLowerCase();
    } catch  {
        return url || "";
    }
}
function extractPostId(url) {
    if (!url || typeof url !== "string") return null;
    try {
        const m = url.match(/\/comments\/([a-z0-9]+)/i);
        return m ? m[1] : null;
    } catch  {
        return null;
    }
}
function sleep(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}

;// ./src/app/api/crawl/route.ts
// POST /api/crawl — start a chapter crawl for a series
// Body: { startUrls: string[], maxChapters?: number, delayMs?: number }
// Returns: CrawlResult (with all discovered chapters)
//
// Note: This is a synchronous endpoint. For long crawls the client
// should pass maxChapters to limit the response time. A future
// improvement would use a streaming response or WebSocket.


const runtime = "nodejs";
const dynamic = "force-dynamic";
const maxDuration = 300; // 5 minutes — Vercel limit
async function POST(req) {
    let body;
    try {
        body = await req.json();
    } catch  {
        return server.NextResponse.json({
            ok: false,
            error: "Invalid JSON body"
        }, {
            status: 400
        });
    }
    const startUrls = body?.startUrls ?? [];
    if (!Array.isArray(startUrls) || startUrls.length === 0) {
        return server.NextResponse.json({
            ok: false,
            error: "startUrls must be a non-empty array"
        }, {
            status: 400
        });
    }
    const maxChapters = Math.min(body?.maxChapters ?? 2000, 2000);
    const delayMs = Math.max(body?.delayMs ?? 200, 100);
    try {
        const result = await crawlAllChapters({
            startUrls,
            maxChapters,
            delayMs
        });
        return server.NextResponse.json({
            ok: true,
            ...result
        });
    } catch (err) {
        return server.NextResponse.json({
            ok: false,
            error: err?.message ?? "Crawl failed"
        }, {
            status: 500
        });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fcrawl%2Froute&name=app%2Fapi%2Fcrawl%2Froute&pagePath=private-next-app-dir%2Fapi%2Fcrawl%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fcrawl%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/crawl/route",
        pathname: "/api/crawl",
        filename: "route",
        bundlePath: "app/api/crawl/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/crawl/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/crawl/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 3033:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 5511:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6439:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 7614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cp: () => (/* binding */ downloadFromPostUrl)
/* harmony export */ });
/* unused harmony exports MAX_POSTS_PER_REQUEST, MAX_FILENAME_LENGTH, DEFAULT_REQUEST_TIMEOUT, POST_DELAY_MS, MEDIA_FORMATS, sanitizeFileName, getFileName, getPostType, getMediaDownloadInfo, isUserProfile, isSearchQuery, extractName, buildRedditApiUrl, redditJsonFetch, downloadSubredditPosts, iterateAllPosts, parsePostListFile */
/* harmony import */ var _cors_proxies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3673);
// HFY NEKROCODEXXX — Secondary Fallback Scraper
// =====================================================
// Faithful TypeScript port of josephrcox/easy-reddit-downloader
// (https://github.com/josephrcox/easy-reddit-downloader) — MIT licensed.
//
// Used as a SECONDARY FALLBACK when the primary Reddit scraper
// (reddit-scraper.ts) fails. The upstream project is a Node.js CLI
// that consumes Reddit's public JSON API (no OAuth, no auth needed)
// by appending `.json` to any Reddit page URL.
//
// Improvements made over upstream:
//   1. Custom User-Agent (upstream sends axios default — Reddit throttles that)
//   2. Real 429/503 backoff with Retry-After respect (upstream has none)
//   3. Exponential backoff retry on network errors
//   4. All requests go through the 250+ CORS proxy pool so the
//      scraper works from the browser
//
// Key upstream logic preserved:
//   - URL building: buildRedditApiUrl() with sorting/time/limit/after
//   - Pagination: cursor-based using `after` = last child's `name` fullname
//   - Post type detection: getPostType() priority order (self/media/poll/gallery/link)
//   - Comments: data[1].data.children (1 level of replies)
//   - MAX_POSTS_PER_REQUEST = 100

// =====================================================
// Constants ported from upstream lib/utils.js
// =====================================================
const MAX_POSTS_PER_REQUEST = 100;
const MAX_FILENAME_LENGTH = 240;
const DEFAULT_REQUEST_TIMEOUT = 30000;
const POST_DELAY_MS = 250; // upstream sleep between posts
const MEDIA_FORMATS = (/* unused pure expression or super */ null && ([
    "jpeg",
    "jpg",
    "gif",
    "png",
    "mp4",
    "webm",
    "gifv"
]));
// Custom UA — diverges from upstream (which sends axios default).
// Reddit's API guidelines require a descriptive, unique UA.
const USER_AGENT = "HFY-NEKROCODEXXX/1.0 (Reddit series reader; +https://github.com/josephrcox/easy-reddit-downloader fork)";
// =====================================================
// utils.js faithful port
// =====================================================
function sanitizeFileName(fileName) {
    return fileName.replace(/[/\\?%*:|"<>]/g, "-").replace(/([^/])\/([^/])/g, "$1_$2");
}
function getFileName(post, config = {}) {
    let fileName = "";
    const created = post.created_utc ?? post.created ?? 0;
    if (config.showDate ?? true) {
        const date = new Date(created * 1000);
        fileName += `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    }
    if (config.showScore ?? true) fileName += `_score=${post.score}`;
    if (config.showSubreddit ?? true) fileName += `_${post.subreddit}`;
    if (config.showAuthor ?? true) fileName += `_${post.author}`;
    if (config.showTitle ?? true) fileName += `_${sanitizeFileName(post.title)}`;
    fileName = fileName.replace(/(?:\r\n|\r|\n|\t)/g, "").replace(/\ufe0e/g, "").replace(/\ufe0f/g, "");
    if (fileName.length > MAX_FILENAME_LENGTH) {
        fileName = fileName.substring(0, MAX_FILENAME_LENGTH);
    }
    return fileName;
}
/** Post-type detection — faithful priority order from upstream */ function getPostType(post) {
    if (post.post_hint === "self" || post.is_self) return 0;
    if (post.post_hint === "image" || post.post_hint === "rich:video" && !(post.domain ?? "").includes("youtu") || post.post_hint === "hosted:video" || post.post_hint === "link" && (post.domain ?? "").includes("imgur") && !(post.url_overridden_by_dest ?? "").includes("gallery") || (post.domain ?? "").includes("i.redd.it") || (post.domain ?? "").includes("i.reddituploads.com")) {
        return 1;
    }
    if (post.poll_data !== undefined) return 3;
    if ((post.domain ?? "").includes("reddit.com") && post.is_gallery) return 4;
    return 2;
}
function getMediaDownloadInfo(post) {
    let downloadURL = post.url ?? "";
    let fileType = downloadURL.split(".").pop() ?? "";
    if (post.preview !== undefined) {
        if (post.preview.reddit_video_preview !== undefined) {
            downloadURL = post.preview.reddit_video_preview.fallback_url;
            fileType = "mp4";
        } else if ((post.url_overridden_by_dest ?? "").includes(".gifv")) {
            downloadURL = (post.url_overridden_by_dest ?? "").replace(".gifv", ".mp4");
            fileType = "mp4";
        } else if (post.preview.images?.[0]?.source?.url) {
            const sourceURL = post.preview.images[0].source.url;
            for (const format of MEDIA_FORMATS){
                if (sourceURL.toLowerCase().includes(format.toLowerCase())) {
                    fileType = format;
                    break;
                }
            }
            if (downloadURL.includes("i.reddituploads.com")) {
                downloadURL = sourceURL.replaceAll("&amp;", "&");
            }
        }
    }
    if (post.media !== undefined && post.post_hint === "hosted:video") {
        downloadURL = post.media.reddit_video.fallback_url;
        fileType = "mp4";
    } else if (post.media !== undefined && post.post_hint === "rich:video" && post.media.oembed?.thumbnail_url !== undefined) {
        downloadURL = post.media.oembed.thumbnail_url;
        fileType = "gif";
    }
    return {
        downloadURL,
        fileType
    };
}
function isUserProfile(target) {
    return target.includes("u/") || target.includes("user/") || target.includes("/u/");
}
function isSearchQuery(target) {
    return target.startsWith("search:");
}
function extractName(target) {
    if (isUserProfile(target)) {
        if (target.includes("user/")) return target.split("user/").pop() ?? "";
        return target.split("u/").pop() ?? "";
    } else if (isSearchQuery(target)) {
        return target.split("search:").pop().replaceAll(" ", "+");
    }
    return target;
}
/** Faithful port of buildRedditApiUrl */ function buildRedditApiUrl(opts) {
    const { target, isUser, isSearch, sorting, time, limit, after = "" } = opts;
    if (isUser) {
        return `https://www.reddit.com/user/${target}/submitted/.json?limit=${limit}&after=${after}`;
    } else if (isSearch) {
        const encoded = target.replaceAll(":", "%3A");
        return `https://www.reddit.com/search/.json?q=${encoded}&type=post&include_over_18=on&sort=${sorting}&limit=${limit}&after=${after}`;
    }
    return `https://www.reddit.com/r/${target}/${sorting}/.json?sort=${sorting}&t=${time}&limit=${limit}&after=${after}`;
}
async function sleep(ms) {
    return new Promise((r)=>setTimeout(r, ms));
}
/**
 * Fetch a Reddit JSON URL with exponential backoff + Retry-After respect.
 * Goes through the CORS proxy pool.
 */ async function redditJsonFetch(url, opts = {}) {
    const { maxAttempts = 4, initialDelayMs = 1000 } = opts;
    for(let attempt = 0; attempt < maxAttempts; attempt++){
        const result = await (0,_cors_proxies__WEBPACK_IMPORTED_MODULE_0__/* .fetchWithProxies */ .Ze)(url, {
            expectedType: "json",
            timeoutMs: DEFAULT_REQUEST_TIMEOUT,
            maxProxiesToTry: 12,
            headers: {
                "User-Agent": USER_AGENT,
                Accept: "application/json, text/plain, */*"
            }
        });
        if (result.ok) {
            try {
                return JSON.parse(result.text);
            } catch  {
            // fall through to retry
            }
        }
        // Reddit rate-limit backoff
        const delay = initialDelayMs * Math.pow(2, attempt);
        await sleep(Math.min(delay, 16000));
    }
    return null;
}
/**
 * Faithful port of downloadSubredditPosts — returns one page of posts.
 * Caller loops with `afterCursor` until `isLastPage === true`.
 */ async function downloadSubredditPosts(target, opts = {}) {
    const sorting = opts.sorting ?? "new";
    const time = opts.time ?? "all";
    const limit = Math.min(opts.limit ?? MAX_POSTS_PER_REQUEST, MAX_POSTS_PER_REQUEST);
    const after = opts.after ?? "";
    const isUser = isUserProfile(target);
    const isSearch = isSearchQuery(target);
    const name = extractName(target);
    if (!name) return null;
    const reqUrl = buildRedditApiUrl({
        target: name,
        isUser,
        isSearch,
        sorting,
        time,
        limit,
        after
    });
    const data = await redditJsonFetch(reqUrl);
    if (!data) return null;
    if (data.message === "Not Found" || !data?.data?.children?.length) {
        return null;
    }
    const children = data.data.children;
    let postsRemaining = limit;
    if (children.length < postsRemaining) {
        postsRemaining = children.length;
    }
    const posts = children.map((c)=>c.data);
    const lastChild = children[children.length - 1];
    const afterCursor = lastChild?.data?.name ?? null;
    const isLastPage = children.length < limit;
    return {
        posts,
        afterCursor,
        isLastPage,
        subreddit: posts[0]?.subreddit ?? name
    };
}
/**
 * Faithful port of downloadFromPostUrl — fetches a single post by URL.
 * Returns the post data + its top-level comments.
 */ async function downloadFromPostUrl(url) {
    const jsonUrl = url.endsWith(".json") ? url : `${url.replace(/\?.*$/, "")}.json`;
    const data = await redditJsonFetch(jsonUrl);
    if (!data || !Array.isArray(data) || data.length < 2) return null;
    const post = data[0]?.data?.children?.[0]?.data ?? null;
    if (!post) return null;
    const commentChildren = data[1]?.data?.children ?? [];
    const comments = commentChildren.filter((c)=>c.kind === "t1" && c.data?.body).map((c)=>extractComment(c.data));
    return {
        post,
        comments
    };
}
function extractComment(d) {
    const replies = [];
    try {
        const replyChildren = d?.replies?.data?.children ?? [];
        // Upstream only reads the first reply — preserve that behavior
        if (replyChildren[0]?.data?.body) {
            replies.push(extractComment(replyChildren[0].data));
        }
    } catch  {
    // ignore
    }
    return {
        author: d.author ?? "",
        body: d.body ?? "",
        created_utc: d.created_utc ?? 0,
        score: d.score ?? 0,
        replies
    };
}
/**
 * Iterate all posts in a subreddit/user/search — handles pagination.
 * Calls onBatch for each page; respects MAX_POSTS_PER_REQUEST.
 *
 * Upstream's checkIfDone loop: when downloaded % MAX === 0 and !lastAPICall,
 * request next page using lastChild's name as `after`.
 */ async function iterateAllPosts(target, onBatch, opts = {}) {
    const { sorting = "new", time = "all", maxPages = 50, delayMs = POST_DELAY_MS } = opts;
    let after = "";
    let page = 0;
    let totalPosts = 0;
    let subreddit = null;
    while(page < maxPages){
        const result = await downloadSubredditPosts(target, {
            sorting,
            time,
            limit: MAX_POSTS_PER_REQUEST,
            after
        });
        if (!result) break;
        if (!subreddit) subreddit = result.subreddit;
        await onBatch(result.posts, result.subreddit);
        totalPosts += result.posts.length;
        page++;
        if (result.isLastPage || !result.afterCursor) break;
        after = result.afterCursor;
        await sleep(delayMs);
    }
    return {
        totalPages: page,
        totalPosts,
        subreddit
    };
}
/**
 * Parse a download_post_list.txt-style file content — faithful port.
 * Returns Reddit post URLs only (skip blanks/comments/non-reddit/non-comments).
 */ function parsePostListFile(content) {
    return content.split("\n").map((l)=>l.trim()).filter((l)=>l && !l.startsWith("#") && l.startsWith("https://www.reddit.com") && l.includes("/comments/"));
}


/***/ }),

/***/ 9021:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813,4857,7101,4034], () => (__webpack_exec__(1828)));
module.exports = __webpack_exports__;

})();