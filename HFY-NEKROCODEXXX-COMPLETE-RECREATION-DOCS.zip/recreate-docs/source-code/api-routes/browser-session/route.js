(() => {
var exports = {};
exports.id = 8617;
exports.ids = [8617];
exports.modules = {

/***/ 261:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 3033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 3873:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 4870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 4935:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/store-scores-all/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST),
  DELETE: () => (DELETE),
  dynamic: () => (dynamic),
  fetchCache: () => (fetchCache),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(9021);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(3873);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
;// ./src/app/api/browser-session/route.ts
// Browser Session API — launches a REAL headless/headed browser via puppeteer-core
// Allows the user to log into Reddit with Google/credentials in a real Chrome/Edge
// window, then captures the session cookies for use in fetchWithCookies().

const runtime = "nodejs";
const dynamic = "force-dynamic";
const fetchCache = "force-no-store";

// Global browser instance (persists across requests)
let browserInstance = null;
let browserPage = null;

// Find Chrome/Edge executable on the system
function findChromePath() {
    const fs = eval('require')('fs');
    const path = eval('require')('path');
    const candidates = [];
    if (process.platform === "win32") {
        candidates.push(
            process.env.CHROME_PATH,
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
            "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe"
        );
    } else if (process.platform === "darwin") {
        candidates.push(
            process.env.CHROME_PATH,
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
        );
    } else {
        candidates.push(
            process.env.CHROME_PATH,
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium"
        );
    }
    for (const c of candidates) {
        if (c) {
            try { if (fs.existsSync(c)) return c; } catch {}
        }
    }
    return null;
}

// POST — launch a headed browser and navigate to Reddit login
async function POST(req) {
    try {
        // If browser is already running, return status
        if (browserInstance && browserPage) {
            try {
                const url = browserPage.url();
                return server.NextResponse.json({ ok: true, status: "running", url, message: "Browser already open. Log in to Reddit, then click CAPTURE COOKIES." });
            } catch {
                // Browser may have been closed — fall through to relaunch
            }
        }

        const chromePath = findChromePath();
        if (!chromePath) {
            return server.NextResponse.json({
                ok: false,
                error: "Chrome/Edge not found. Install Google Chrome or Microsoft Edge, or set CHROME_PATH env variable."
            }, { status: 500 });
        }

        // Dynamically require puppeteer-core (not in webpack graph)
        let puppeteer;
        try {
            puppeteer = eval('require')('puppeteer-core');
        } catch (e) {
            return server.NextResponse.json({
                ok: false,
                error: "puppeteer-core not installed: " + e.message
            }, { status: 500 });
        }

        const body = await req.json().catch(() => ({}));
        const startUrl = body.url || "https://www.reddit.com/login/";

        // Launch browser in HEADED mode (visible window) so user can interact
        browserInstance = await puppeteer.launch({
            executablePath: chromePath,
            headless: false, // SHOW the browser window
            args: [
                '--no-first-run',
                '--no-default-browser-check',
                '--disable-popup-blocking',
                '--start-maximized',
                '--disable-blink-features=AutomationControlled'
            ],
            defaultViewport: null,
            userDataDir: undefined // use temp profile
        });

        browserPage = (await browserInstance.pages())[0] || await browserInstance.newPage();
        await browserPage.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
        await browserPage.goto(startUrl, { waitUntil: "networkidle2", timeout: 30000 });

        return server.NextResponse.json({
            ok: true,
            status: "launched",
            url: startUrl,
            message: "Browser opened. Log in to Reddit (Google or credentials), then click CAPTURE COOKIES."
        });
    } catch (err) {
        // Clean up browser on launch failure to prevent zombie Chrome processes
        try { if (browserInstance) await browserInstance.close(); } catch {}
        browserInstance = null;
        browserPage = null;
        return server.NextResponse.json({
            ok: false,
            error: err?.message || "Failed to launch browser"
        }, { status: 500 });
    }
}

// GET — check browser session status
async function GET() {
    try {
        if (!browserInstance || !browserPage) {
            return server.NextResponse.json({ ok: true, status: "idle" });
        }
        try {
            const url = await browserPage.url();
            const title = await browserPage.title();
            return server.NextResponse.json({ ok: true, status: "running", url, title });
        } catch {
            return server.NextResponse.json({ ok: true, status: "idle" });
        }
    } catch (err) {
        return server.NextResponse.json({ ok: false, error: err?.message });
    }
}

// DELETE — capture cookies, close browser, store cookies
async function DELETE() {
    try {
        if (!browserInstance || !browserPage) {
            return server.NextResponse.json({ ok: false, error: "No browser session active" }, { status: 400 });
        }

        // Capture all cookies from the browser
        const cookies = await browserPage.cookies();
        const redditCookies = cookies.filter(c => c.domain && c.domain.includes("reddit.com"));

        // Check for cookies BEFORE closing the browser — if none found, let the
        // user retry without having to relaunch the browser
        if (redditCookies.length === 0) {
            return server.NextResponse.json({
                ok: false,
                error: "No Reddit cookies found. Make sure you logged in to reddit.com before capturing."
            }, { status: 400 });
        }

        // Close the browser now that we have cookies
        try { await browserInstance.close(); } catch {}
        browserInstance = null;
        browserPage = null;

        // Format cookies for the reddit-cookies API
        const cookieStr = redditCookies.map(c => `${c.name}=${c.value}`).join("; ");
        const username = redditCookies.find(c => c.name === "redditUserName")?.value ||
                         redditCookies.find(c => c.name === "reddit_session")?.value ||
                         "browser_user";

        // Store cookies via the reddit-cookies API
        try {
            await fetch("http://127.0.0.1:3000/api/reddit-cookies", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ cookies: cookieStr, username })
            });
        } catch {}

        return server.NextResponse.json({
            ok: true,
            cookieCount: redditCookies.length,
            username,
            message: `Captured ${redditCookies.length} Reddit cookies. Cookie session active for C-FETCH.`
        });
    } catch (err) {
        // Force cleanup on error
        try { if (browserInstance) await browserInstance.close(); } catch {}
        browserInstance = null;
        browserPage = null;
        return server.NextResponse.json({ ok: false, error: err?.message }, { status: 500 });
    }
}


;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fstore-scores-all%2Froute&name=app%2Fapi%2Fstore-scores-all%2Froute&pagePath=private-next-app-dir%2Fapi%2Fstore-scores-all%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fstore-scores-all%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/store-scores-all/route",
        pathname: "/api/store-scores-all",
        filename: "route",
        bundlePath: "app/api/store-scores-all/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/store-scores-all/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/store-scores-all/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 6439:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 6487:
/***/ (() => {



/***/ }),

/***/ 8335:
/***/ (() => {



/***/ }),

/***/ 9021:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 9294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813], () => (__webpack_exec__(4935)));
module.exports = __webpack_exports__;

})();