(() => {
var exports = {};
exports.id = 5345;
exports.ids = [5345];
exports.modules = {

/***/ 261:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/app-paths");

/***/ }),

/***/ 846:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");

/***/ }),

/***/ 3033:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ 4870:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.prod.js");

/***/ }),

/***/ 6439:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-fallback-error.external");

/***/ }),

/***/ 6487:
/***/ (() => {



/***/ }),

/***/ 6983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  handler: () => (/* binding */ handler),
  patchFetch: () => (/* binding */ patchFetch),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  workAsyncStorage: () => (/* binding */ workAsyncStorage),
  workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)
});

// NAMESPACE OBJECT: ./src/app/api/proxy-browser/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST),
  DELETE: () => (DELETE),
  dynamic: () => (dynamic),
  runtime: () => (runtime)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/route-modules/app-route/module.compiled.js
var module_compiled = __webpack_require__(9225);
// EXTERNAL MODULE: ./node_modules/next/dist/server/route-kind.js
var route_kind = __webpack_require__(4006);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/patch-fetch.js
var patch_fetch = __webpack_require__(8317);
// EXTERNAL MODULE: ./node_modules/next/dist/server/request-meta.js
var request_meta = __webpack_require__(9373);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/tracer.js
var trace_tracer = __webpack_require__(4775);
// EXTERNAL MODULE: ./node_modules/next/dist/server/app-render/manifests-singleton.js
var manifests_singleton = __webpack_require__(4235);
// EXTERNAL MODULE: external "next/dist/shared/lib/router/utils/app-paths"
var app_paths_ = __webpack_require__(261);
// EXTERNAL MODULE: ./node_modules/next/dist/server/base-http/node.js
var node = __webpack_require__(4365);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/spec-extension/adapters/next-request.js
var next_request = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/trace/constants.js
var constants = __webpack_require__(3461);
// EXTERNAL MODULE: ./node_modules/next/dist/server/instrumentation/utils.js
var utils = __webpack_require__(7798);
// EXTERNAL MODULE: ./node_modules/next/dist/server/send-response.js
var send_response = __webpack_require__(2280);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/utils.js
var web_utils = __webpack_require__(2018);
// EXTERNAL MODULE: ./node_modules/next/dist/server/lib/cache-control.js
var cache_control = __webpack_require__(5696);
// EXTERNAL MODULE: ./node_modules/next/dist/lib/constants.js
var lib_constants = __webpack_require__(7929);
// EXTERNAL MODULE: external "next/dist/shared/lib/no-fallback-error.external"
var no_fallback_error_external_ = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/dist/server/response-cache/index.js
var response_cache = __webpack_require__(7527);
// EXTERNAL MODULE: ./node_modules/next/dist/api/server.js
var server = __webpack_require__(3211);
;// ./src/app/api/proxy-browser/route.ts
// GET/POST /api/proxy-browser?url=...
// Server-side proxy browser that fetches ANY URL, strips X-Frame-Options,
// rewrites all links/forms to go through the proxy, and maintains a cookie jar.
// This allows the InAppBrowser iframe to load Reddit pages and login.
//
// The cookie jar persists for the server's lifetime, so once the user logs in
// to Reddit through the proxy, all subsequent requests include their session cookies.

const runtime = "nodejs";
const dynamic = "force-dynamic";
const globalCookieJar = global.redditCookieJar ?? (global.redditCookieJar = new Map());
function getCookies(domain) {
    // Return cookies for this domain and parent domains
    const parts = domain.split(".");
    const cookies = [];
    for(let i = 0; i < parts.length - 1; i++){
        const d = parts.slice(i).join(".");
        const c = globalCookieJar.get(d);
        if (c) cookies.push(c);
    }
    return cookies.join("; ");
}
function setCookies(domain, setCookieHeaders) {
    for (const sc of setCookieHeaders){
        const cookiePart = sc.split(";")[0]; // name=value
        if (!cookiePart.includes("=")) continue;
        // Determine cookie domain
        let cookieDomain = domain;
        const domainMatch = sc.match(/domain=([^;]+)/i);
        if (domainMatch) {
            cookieDomain = domainMatch[1].trim().replace(/^\./, "");
        }
        const existing = globalCookieJar.get(cookieDomain) || "";
        const existingCookies = existing ? existing.split("; ").filter((c)=>c.trim()) : [];
        const cookieName = cookiePart.split("=")[0];
        const filtered = existingCookies.filter((c)=>!c.startsWith(cookieName + "="));
        filtered.push(cookiePart);
        globalCookieJar.set(cookieDomain, filtered.join("; "));
    }
}
async function handleProxy(req, method) {
    const targetUrl = req.nextUrl.searchParams.get("url");
    if (!targetUrl) {
        return new server.NextResponse("Missing url parameter", {
            status: 400
        });
    }
    let fetchUrl;
    try {
        fetchUrl = decodeURIComponent(targetUrl);
    } catch  {
        return new server.NextResponse("Invalid url encoding", {
            status: 400
        });
    }
    // ─────────────────────────────────────────────────────────────
    // TIER 1: Real headed Chrome browser (primary for HTML pages)
    // ─────────────────────────────────────────────────────────────
    // Route HTML page loads through the persistent Chrome browser.
    // This makes Reddit (and other sites) see real browser traffic,
    // enables Google sign-in (which requires JS + a real browser
    // fingerprint), and persists cookies in Chrome's profile so the
    // user stays logged in across requests.
    //
    // Non-HTML assets (images, CSS, JS, fonts) bypass Chrome and use
    // fetch() directly — they don't need cookies/JS and going through
    // Chrome would be 10x slower for no benefit.
    // ─────────────────────────────────────────────────────────────
    const urlObj = new URL(fetchUrl);
    const isHtmlLikely = !fetchUrl.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|mp4|webm|mp3|pdf|zip)(\?|$)/i);
    if (isHtmlLikely && method === "GET") {
        try {
            const browserResult = await handleBrowserFetch(req);
            const data = await browserResult.json();
            if (data && data.ok !== undefined) {
                // Sync Chrome's cookies into our legacy cookie jar
                if (data.url) {
                    try {
                        const chromeCookiesUrl = new URL(data.url);
                        const browser = persistentBrowserState.browser;
                        if (browser) {
                            const chromeCookies = await browser.cookies({ url: chromeCookiesUrl.href });
                            const setCookieHeaders = chromeCookies.map(c => `${c.name}=${c.value}; domain=${c.domain}; path=${c.path}`);
                            if (setCookieHeaders.length > 0) {
                                setCookies(chromeCookiesUrl.hostname, setCookieHeaders);
                            }
                        }
                    } catch {}
                }
                // Handle redirects from Chrome
                if (data.status >= 300 && data.status < 400 && data.url && data.url !== fetchUrl) {
                    const proxyUrl = new URL("/api/proxy-browser", req.nextUrl.origin);
                    proxyUrl.searchParams.set("url", data.url);
                    return server.NextResponse.redirect(proxyUrl, { status: 302 });
                }
                // Non-HTML response from Chrome — return as-is
                const contentType = data.contentType || "";
                if (!contentType.includes("text/html")) {
                    return new server.NextResponse(data.body || "", {
                        status: data.status,
                        headers: {
                            "Content-Type": contentType || "application/octet-stream",
                            "Cache-Control": "public, max-age=3600"
                        }
                    });
                }
                // HTML response — rewrite URLs (base tag injected AFTER rewriting to avoid self-rewrite)
                const html = data.body || "";
                const origin = urlObj.origin;
                let rewritten = html;
                rewritten = rewritten.replace(/<base[^>]*>/gi, "");
                rewritten = rewritten.replace(/href="(https?:\/\/([^"]+))"/gi, (match, fullUrl)=>{
                    if (fullUrl.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf)(\?|$)/i)) {
                        return match;
                    }
                    return `href="/api/proxy-browser?url=${encodeURIComponent(fullUrl)}"`;
                });
                rewritten = rewritten.replace(/href="(\/[^"]*)"/gi, (match, path)=>{
                    if (path.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf)(\?|$)/i)) {
                        return match;
                    }
                    return `href="/api/proxy-browser?url=${encodeURIComponent(origin + path)}"`;
                });
                rewritten = rewritten.replace(/action="(https?:\/\/[^"]+)"/gi, (match, url)=>`action="/api/proxy-browser?url=${encodeURIComponent(url)}"`);
                rewritten = rewritten.replace(/action="(\/[^"]*)"/gi, (match, path)=>`action="/api/proxy-browser?url=${encodeURIComponent(origin + path)}"`);
                // Inject base tag AFTER href rewriting so it doesn't get rewritten itself
                const baseTag = `<base href="${origin}/">`;
                if (rewritten.includes("<head>")) {
                    rewritten = rewritten.replace("<head>", `<head>${baseTag}`);
                } else if (rewritten.includes("<head ")) {
                    rewritten = rewritten.replace(/<head /, `<head ${baseTag}`);
                } else {
                    rewritten = baseTag + rewritten;
                }
                const interceptorScript = `
<script>
document.addEventListener('submit', function(e) {
  var form = e.target;
  if (form.action && !form.action.includes('/api/proxy-browser')) {
    var action = form.getAttribute('action') || window.location.href;
    if (action.startsWith('/')) { action = window.location.origin + action; }
    form.setAttribute('action', '/api/proxy-browser?url=' + encodeURIComponent(action));
  }
}, true);
document.addEventListener('click', function(e) {
  var link = e.target.closest('a');
  if (link && link.href && !link.href.includes('/api/proxy-browser') && !link.href.startsWith('javascript:') && !link.href.startsWith('#')) {
    e.preventDefault();
    var url = link.href;
    if (url.startsWith('/') ) { url = window.location.origin + url; }
    window.location.href = '/api/proxy-browser?url=' + encodeURIComponent(url);
  }
}, true);
var origFetch = window.fetch;
window.fetch = function(url, opts) {
  if (typeof url === 'string' && url.startsWith('/') && !url.startsWith('/api/')) { url = window.location.origin + url; }
  if (typeof url === 'string' && !url.includes('/api/proxy-browser') && url.includes('reddit')) { url = '/api/proxy-browser?url=' + encodeURIComponent(url); }
  return origFetch.call(this, url, opts);
};
var origXHROpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function(method, url) {
  if (url && url.startsWith('/') && !url.startsWith('/api/')) { url = window.location.origin + url; }
  if (url && !url.includes('/api/proxy-browser') && typeof url === 'string' && url.includes('reddit')) { url = '/api/proxy-browser?url=' + encodeURIComponent(url); }
  return origXHROpen.apply(this, arguments);
};
</script>`;
                if (rewritten.includes("</body>")) {
                    rewritten = rewritten.replace("</body>", interceptorScript + "</body>");
                } else {
                    rewritten += interceptorScript;
                }
                const response = new server.NextResponse(rewritten, {
                    status: data.status,
                    headers: { "Content-Type": "text/html; charset=utf-8" }
                });
                response.headers.delete("X-Frame-Options");
                response.headers.delete("Content-Security-Policy");
                response.headers.delete("Content-Security-Policy-Report-Only");
                response.headers.delete("X-Content-Type-Options");
                response.headers.delete("Strict-Transport-Security");
                return response;
            }
        } catch (chromeErr) {
            console.log(`[proxy-browser] Chrome tier failed for ${fetchUrl}, falling back to fetch: ${chromeErr?.message || chromeErr}`);
        }
    }
    // ─────────────────────────────────────────────────────────────
    // TIER 2: Legacy fetch() fallback (for non-HTML assets or if Chrome failed)
    // ─────────────────────────────────────────────────────────────
    try {
        const domain = urlObj.hostname;
        const headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Cookie": getCookies(domain),
            "Referer": urlObj.origin
        };
        let body;
        if (method === "POST") {
            const ct = req.headers.get("content-type") || "application/x-www-form-urlencoded";
            headers["Content-Type"] = ct;
            body = await req.text();
        }
        const fetchRes = await fetch(fetchUrl, {
            method,
            headers,
            body,
            redirect: "manual",
            signal: AbortSignal.timeout(20000)
        });
        // Capture Set-Cookie headers
        const setCookieHeaders = fetchRes.headers.getSetCookie?.() || [];
        if (setCookieHeaders.length > 0) {
            setCookies(domain, setCookieHeaders);
        }
        // Handle redirects
        if (fetchRes.status >= 300 && fetchRes.status < 400) {
            const location = fetchRes.headers.get("location");
            if (location) {
                const redirectUrl = location.startsWith("http") ? location : new URL(location, fetchUrl).href;
                const proxyUrl = new URL("/api/proxy-browser", req.nextUrl.origin);
                proxyUrl.searchParams.set("url", redirectUrl);
                return server.NextResponse.redirect(proxyUrl, {
                    status: 302
                });
            }
        }
        const contentType = fetchRes.headers.get("content-type") || "";
        // For non-HTML responses (images, CSS, JS), proxy directly
        if (!contentType.includes("text/html")) {
            const buffer = await fetchRes.arrayBuffer();
            const response = new server.NextResponse(buffer, {
                status: fetchRes.status,
                headers: {
                    "Content-Type": contentType,
                    "Cache-Control": "public, max-age=3600"
                }
            });
            response.headers.delete("X-Frame-Options");
            response.headers.delete("Content-Security-Policy");
            return response;
        }
        // HTML response — rewrite URLs (base tag injected AFTER rewriting to avoid self-rewrite)
        const html = await fetchRes.text();
        const origin = urlObj.origin;
        let rewritten = html;
        rewritten = rewritten.replace(/<base[^>]*>/gi, "");
        rewritten = rewritten.replace(/href="(https?:\/\/([^"]+))"/gi, (match, fullUrl)=>{
            if (fullUrl.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf)(\?|$)/i)) {
                return match;
            }
            return `href="/api/proxy-browser?url=${encodeURIComponent(fullUrl)}"`;
        });
        rewritten = rewritten.replace(/href="(\/[^"]*)"/gi, (match, path)=>{
            if (path.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf)(\?|$)/i)) {
                return match;
            }
            return `href="/api/proxy-browser?url=${encodeURIComponent(origin + path)}"`;
        });
        rewritten = rewritten.replace(/action="(https?:\/\/[^"]+)"/gi, (match, url)=>`action="/api/proxy-browser?url=${encodeURIComponent(url)}"`);
        rewritten = rewritten.replace(/action="(\/[^"]*)"/gi, (match, path)=>`action="/api/proxy-browser?url=${encodeURIComponent(origin + path)}"`);
        // Inject base tag AFTER href rewriting
        const baseTag = `<base href="${origin}/">`;
        if (rewritten.includes("<head>")) {
            rewritten = rewritten.replace("<head>", `<head>${baseTag}`);
        } else if (rewritten.includes("<head ")) {
            rewritten = rewritten.replace(/<head /, `<head ${baseTag}`);
        } else {
            rewritten = baseTag + rewritten;
        }
        // Add a script that intercepts form submissions and fetch/XHR
        const interceptorScript = `
<script>
// Intercept form submissions to go through proxy
document.addEventListener('submit', function(e) {
  var form = e.target;
  if (form.action && !form.action.includes('/api/proxy-browser')) {
    var action = form.getAttribute('action') || window.location.href;
    if (action.startsWith('/')) {
      action = window.location.origin + action;
    }
    form.setAttribute('action', '/api/proxy-browser?url=' + encodeURIComponent(action));
  }
}, true);

// Intercept link clicks
document.addEventListener('click', function(e) {
  var link = e.target.closest('a');
  if (link && link.href && !link.href.includes('/api/proxy-browser') && !link.href.startsWith('javascript:') && !link.href.startsWith('#')) {
    e.preventDefault();
    var url = link.href;
    if (url.startsWith('/') ) {
      url = window.location.origin + url;
    }
    window.location.href = '/api/proxy-browser?url=' + encodeURIComponent(url);
  }
}, true);

// Intercept fetch/XHR to rewrite Reddit API calls
var origFetch = window.fetch;
window.fetch = function(url, opts) {
  if (typeof url === 'string' && url.startsWith('/') && !url.startsWith('/api/')) {
    url = window.location.origin + url;
  }
  if (typeof url === 'string' && !url.includes('/api/proxy-browser') && url.includes('reddit')) {
    url = '/api/proxy-browser?url=' + encodeURIComponent(url);
  }
  return origFetch.call(this, url, opts);
};

var origXHROpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function(method, url) {
  if (url && url.startsWith('/') && !url.startsWith('/api/')) {
    url = window.location.origin + url;
  }
  if (url && !url.includes('/api/proxy-browser') && typeof url === 'string' && url.includes('reddit')) {
    url = '/api/proxy-browser?url=' + encodeURIComponent(url);
  }
  return origXHROpen.apply(this, arguments);
};
</script>`;
        // Inject before </body> or at end
        if (rewritten.includes("</body>")) {
            rewritten = rewritten.replace("</body>", interceptorScript + "</body>");
        } else {
            rewritten += interceptorScript;
        }
        const response = new server.NextResponse(rewritten, {
            status: fetchRes.status,
            headers: {
                "Content-Type": "text/html; charset=utf-8"
            }
        });
        // Strip all security headers
        response.headers.delete("X-Frame-Options");
        response.headers.delete("Content-Security-Policy");
        response.headers.delete("Content-Security-Policy-Report-Only");
        response.headers.delete("X-Content-Type-Options");
        response.headers.delete("Strict-Transport-Security");
        return response;
    } catch (err) {
        return server.NextResponse.json({
            error: err?.message || "Proxy fetch failed"
        }, {
            status: 502
        });
    }
}
async function GET(req) {
    // Check for browser-session action
    const action = req.nextUrl.searchParams.get("action");
    if (action === "browser-session") {
        return handleBrowserSession(req, "GET");
    }
    if (action === "browser-fetch") {
        return handleBrowserFetch(req);
    }
    if (action === "browser-status") {
        return handleBrowserStatus();
    }
    if (action === "browser-close") {
        return handleBrowserClose();
    }
    if (action === "browser-cookies") {
        return handleBrowserCookies(req);
    }
    if (action === "browser-cookies-sync") {
        return handleBrowserCookiesSync(req);
    }
    if (action === "open-external") {
        return handleOpenExternal(req);
    }
    return handleProxy(req, "GET");
}
async function POST(req) {
    const action = req.nextUrl.searchParams.get("action");
    if (action === "browser-session") {
        return handleBrowserSession(req, "POST");
    }
    if (action === "browser-fetch") {
        return handleBrowserFetch(req);
    }
    if (action === "browser-launch") {
        return handleBrowserLaunch();
    }
    if (action === "browser-cookies-sync") {
        return handleBrowserCookiesSync(req);
    }
    return handleProxy(req, "POST");
}
async function DELETE(req) {
    const action = req.nextUrl.searchParams.get("action");
    if (action === "browser-session") {
        return handleBrowserSession(req, "DELETE");
    }
    if (action === "browser-close") {
        return handleBrowserClose();
    }
    return server.NextResponse.json({ ok: false, error: "Method not allowed" }, { status: 405 });
}
// =====================================================
// PERSISTENT HEADED CHROME BROWSER POOL
// =====================================================
const persistentBrowserState = global.hfyPersistentBrowser ?? (global.hfyPersistentBrowser = {
    browser: null,
    launchPromise: null,
    lastActivity: 0,
    launchTime: 0,
    activeFetches: 0,
    maxConcurrentFetches: parseInt(process.env.HFY_BROWSER_MAX_CONCURRENT || '3', 10),
    fetchQueue: [],
});
function waitForBrowserSlot() {
    return new Promise((resolve) => {
        if (persistentBrowserState.activeFetches < persistentBrowserState.maxConcurrentFetches) {
            persistentBrowserState.activeFetches++;
            resolve();
            return;
        }
        persistentBrowserState.fetchQueue.push(resolve);
    });
}
function releaseBrowserSlot() {
    persistentBrowserState.activeFetches--;
    if (persistentBrowserState.fetchQueue.length > 0 && persistentBrowserState.activeFetches < persistentBrowserState.maxConcurrentFetches) {
        const next = persistentBrowserState.fetchQueue.shift();
        persistentBrowserState.activeFetches++;
        next();
    }
}
function detectHeadlessMode() {
    if (process.env.DISPLAY) {
        try {
            const fs = eval('require')('fs');
            const x11Socket = '/tmp/.X11-unix/X' + process.env.DISPLAY.replace(':', '');
            if (fs.existsSync(x11Socket)) return false;
        } catch {}
    }
    if (process.env.ANDROID_CONTENT_DIR || process.platform === 'android') return false;
    if (process.platform === 'win32' || process.platform === 'darwin') return false;
    return 'new';
}
async function launchPersistentBrowser() {
    if (persistentBrowserState.browser) {
        try {
            await persistentBrowserState.browser.pages();
            return persistentBrowserState.browser;
        } catch {
            persistentBrowserState.browser = null;
            persistentBrowserState.launchPromise = null;
        }
    }
    if (persistentBrowserState.launchPromise) {
        return persistentBrowserState.launchPromise;
    }
    persistentBrowserState.launchPromise = (async () => {
        const chromePath = findChromePath();
        if (!chromePath) {
            throw new Error("Chrome/Edge not found. Install Google Chrome or set CHROME_PATH env.");
        }
        let puppeteer;
        try { puppeteer = eval('require')('puppeteer-core'); } catch (e) {
            throw new Error("puppeteer-core not installed: " + e.message);
        }
        const fs = eval('require')('fs');
        const path = eval('require')('path');
        const dataDir = process.env.HFY_DATA_DIR
            ? path.join(process.env.HFY_DATA_DIR, 'chrome-profile')
            : path.join(process.cwd(), 'data', 'chrome-profile');
        try { fs.mkdirSync(dataDir, { recursive: true }); } catch {}
        const headlessMode = detectHeadlessMode();
        const browser = await puppeteer.launch({
            executablePath: chromePath,
            headless: headlessMode,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--no-first-run',
                '--no-default-browser-check',
                '--disable-popup-blocking',
                '--disable-blink-features=AutomationControlled',
                `--user-data-dir=${dataDir}`,
                '--disable-features=IsolateOrigins,site-per-process',
                '--disable-site-isolation-trials',
                '--disable-dev-shm-usage',
            ],
            defaultViewport: null,
            ignoreDefaultArgs: ['--enable-automation'],
        });
        persistentBrowserState.browser = browser;
        persistentBrowserState.launchTime = Date.now();
        persistentBrowserState.lastActivity = Date.now();
        const idleTimeoutMs = parseInt(process.env.HFY_BROWSER_IDLE_TIMEOUT || '0', 10);
        if (idleTimeoutMs > 0) {
            setInterval(async () => {
                if (persistentBrowserState.browser &&
                    Date.now() - persistentBrowserState.lastActivity > idleTimeoutMs) {
                    try { await persistentBrowserState.browser.close(); } catch {}
                    persistentBrowserState.browser = null;
                    persistentBrowserState.launchPromise = null;
                }
            }, 60000).unref();
        }
        return browser;
    })();
    try {
        const browser = await persistentBrowserState.launchPromise;
        persistentBrowserState.launchPromise = null;
        return browser;
    } catch (e) {
        persistentBrowserState.launchPromise = null;
        throw e;
    }
}
async function handleBrowserLaunch() {
    try {
        const browser = await launchPersistentBrowser();
        const version = await browser.version();
        return server.NextResponse.json({
            ok: true, status: "launched", version,
            launchTime: persistentBrowserState.launchTime,
            message: "Persistent Chrome browser launched."
        });
    } catch (err) {
        return server.NextResponse.json({ ok: false, error: err?.message || "Launch failed" }, { status: 500 });
    }
}
async function handleBrowserStatus() {
    if (!persistentBrowserState.browser) {
        return server.NextResponse.json({ ok: true, status: "idle" });
    }
    try {
        const version = await persistentBrowserState.browser.version();
        const pages = await persistentBrowserState.browser.pages();
        return server.NextResponse.json({
            ok: true, status: "running", version, pages: pages.length,
            launchTime: persistentBrowserState.launchTime,
            lastActivity: persistentBrowserState.lastActivity,
            uptime: Date.now() - persistentBrowserState.launchTime
        });
    } catch {
        return server.NextResponse.json({ ok: true, status: "idle" });
    }
}
async function handleBrowserClose() {
    if (persistentBrowserState.browser) {
        try { await persistentBrowserState.browser.close(); } catch {}
        persistentBrowserState.browser = null;
        persistentBrowserState.launchPromise = null;
    }
    return server.NextResponse.json({ ok: true, status: "closed" });
}
async function handleBrowserFetch(req) {
    const targetUrl = req.nextUrl.searchParams.get("url");
    if (!targetUrl) {
        return server.NextResponse.json({ ok: false, error: "Missing url parameter" }, { status: 400 });
    }
    let fetchUrl;
    try { fetchUrl = decodeURIComponent(targetUrl); } catch {
        return server.NextResponse.json({ ok: false, error: "Invalid url encoding" }, { status: 400 });
    }
    const timeoutMs = parseInt(req.nextUrl.searchParams.get("timeout") || "30000", 10);
    const waitUntil = req.nextUrl.searchParams.get("waitUntil") || "networkidle2";
    await waitForBrowserSlot();
    try {
        const browser = await launchPersistentBrowser();
        persistentBrowserState.lastActivity = Date.now();
        const page = await browser.newPage();
        try {
            await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
            await page.evaluateOnNewDocument(() => {
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
                Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
                window.chrome = { runtime: {} };
            });
            const response = await page.goto(fetchUrl, { waitUntil, timeout: timeoutMs });
            if (!response) {
                return server.NextResponse.json({ ok: false, status: 0, error: "No response" }, { status: 502 });
            }
            const status = response.status();
            const headers = response.headers();
            const contentType = headers['content-type'] || '';
            let body;
            if (contentType.includes('application/json') || fetchUrl.includes('.json')) {
                body = await page.evaluate(() => document.body.innerText);
            } else {
                body = await page.content();
            }
            const cookies = await page.cookies();
            return server.NextResponse.json({
                ok: status < 400, status, url: page.url(),
                contentType, headers, body, bodyLength: body.length,
                cookieCount: cookies.length
            });
        } finally {
            try { await page.close(); } catch {}
        }
    } catch (err) {
        if (err.message && (err.message.includes('Target closed') || err.message.includes('Session closed') || err.message.includes('Browser closed'))) {
            persistentBrowserState.browser = null;
            persistentBrowserState.launchPromise = null;
        }
        return server.NextResponse.json({ ok: false, error: err?.message || "Browser fetch failed" }, { status: 500 });
    } finally {
        releaseBrowserSlot();
    }
}
async function handleBrowserCookies(req) {
    if (!persistentBrowserState.browser) {
        return server.NextResponse.json({ ok: false, error: "Browser not launched" }, { status: 400 });
    }
    try {
        const allCookies = await persistentBrowserState.browser.cookies();
        const redditCookies = allCookies.filter(c =>
            c.domain && (c.domain.includes("reddit.com") || c.domain.includes("redditmedia.com"))
        );
        const cookieNames = redditCookies.map(c => c.name);
        const username = redditCookies.find(c => c.name === "redditUserName")?.value
            || redditCookies.find(c => c.name === "rsegraphql_username")?.value
            || null;
        return server.NextResponse.json({
            ok: true, count: redditCookies.length, username, cookieNames,
            cookieString: redditCookies.map(c => `${c.name}=${c.value}`).join("; ")
        });
    } catch (err) {
        return server.NextResponse.json({ ok: false, error: err?.message || "Cookie capture failed" }, { status: 500 });
    }
}
async function handleBrowserCookiesSync(req) {
    if (!persistentBrowserState.browser) {
        return server.NextResponse.json({ ok: false, error: "Browser not launched. Open the in-app browser and log in first." }, { status: 400 });
    }
    try {
        const allCookies = await persistentBrowserState.browser.cookies();
        const redditCookies = allCookies.filter(c =>
            c.domain && (c.domain.includes("reddit.com") || c.domain.includes("redditmedia.com"))
        );
        if (redditCookies.length === 0) {
            return server.NextResponse.json({
                ok: false,
                error: "No Reddit cookies found in Chrome. Open the in-app browser, log in to Reddit, then try again."
            }, { status: 400 });
        }
        const cookieStr = redditCookies.map(c => `${c.name}=${c.value}`).join("; ");
        const username = redditCookies.find(c => c.name === "redditUserName")?.value
            || redditCookies.find(c => c.name === "rsegraphql_username")?.value
            || "browser_user";
        setCookies("reddit.com", redditCookies.map(c => `${c.name}=${c.value}; domain=${c.domain}; path=${c.path}`));
        try {
            const syncRes = await fetch("http://127.0.0.1:3000/api/reddit-cookies", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ cookies: cookieStr, username }),
                signal: AbortSignal.timeout(10000)
            });
            const syncData = await syncRes.json().catch(() => ({}));
            return server.NextResponse.json({
                ok: true, cookieCount: redditCookies.length, username,
                synced: syncData.ok === true,
                cookieNames: redditCookies.map(c => c.name)
            });
        } catch (syncErr) {
            return server.NextResponse.json({
                ok: true, cookieCount: redditCookies.length, username,
                synced: false, syncError: syncErr?.message,
                cookieNames: redditCookies.map(c => c.name)
            });
        }
    } catch (err) {
        return server.NextResponse.json({ ok: false, error: err?.message || "Cookie sync failed" }, { status: 500 });
    }
}
// Browser session handler — launches a real Chrome/Edge browser via puppeteer-core
let browserInstance = null;
let browserPage = null;
async function handleOpenExternal(req) {
    const targetUrl = req.nextUrl.searchParams.get("url");
    if (!targetUrl) return server.NextResponse.json({ ok: false, error: "Missing url" }, { status: 400 });
    try {
        const { exec } = eval('require')('child_process');
        let cmd;
        if (process.platform === "win32") {
            cmd = `start "" "${targetUrl}"`;
        } else if (process.platform === "darwin") {
            cmd = `open "${targetUrl}"`;
        } else if (process.env.ANDROID_CONTENT_DIR) {
            cmd = `am start -a android.intent.action.VIEW -d "${targetUrl}"`;
        } else {
            cmd = `xdg-open "${targetUrl}"`;
        }
        exec(cmd, (err) => { if (err) console.error('[open-external]', err.message); });
        return server.NextResponse.json({ ok: true });
    } catch (err) {
        return server.NextResponse.json({ ok: false, error: err?.message }, { status: 500 });
    }
}
function findChromePath() {
    const fs = eval('require')('fs');
    const candidates = [];
    if (process.platform === "win32") {
        candidates.push(
            process.env.CHROME_PATH,
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
            "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe"
        );
    } else if (process.platform === "darwin") {
        candidates.push(
            process.env.CHROME_PATH,
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
        );
    } else {
        candidates.push(
            process.env.CHROME_PATH,
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium"
        );
    }
    for (const c of candidates) {
        if (c) { try { if (fs.existsSync(c)) return c; } catch {} }
    }
    return null;
}
async function handleBrowserSession(req, method) {
    try {
        if (method === "GET") {
            // Use persistent browser for status check
            if (!persistentBrowserState.browser) {
                return server.NextResponse.json({ ok: true, status: "idle" });
            }
            try {
                const pages = await persistentBrowserState.browser.pages();
                if (pages.length === 0) {
                    return server.NextResponse.json({ ok: true, status: "idle" });
                }
                const page = pages[pages.length - 1];
                const url = await page.url();
                const title = await page.title();
                return server.NextResponse.json({ ok: true, status: "running", url, title });
            } catch {
                return server.NextResponse.json({ ok: true, status: "idle" });
            }
        }
        if (method === "POST") {
            // Use the PERSISTENT browser (shared cookie profile with scraper)
            const body = await req.json().catch(() => ({}));
            const startUrl = body.url || "https://www.reddit.com/login/";
            try {
                const browser = await launchPersistentBrowser();
                const page = await browser.newPage();
                await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
                await page.evaluateOnNewDocument(() => {
                    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                    window.chrome = { runtime: {} };
                });
                await page.goto(startUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
                return server.NextResponse.json({ ok: true, status: "launched", url: startUrl, message: "Browser opened in persistent session. Log in, then click CAPTURE COOKIES. Cookies will be shared with the scraper." });
            } catch (launchErr) {
                return server.NextResponse.json({ ok: false, error: launchErr?.message || "Failed to launch browser" }, { status: 500 });
            }
        }
        if (method === "DELETE") {
            // Capture cookies from the persistent browser
            if (!persistentBrowserState.browser) {
                return server.NextResponse.json({ ok: false, error: "No browser session active" }, { status: 400 });
            }
            const allCookies = await persistentBrowserState.browser.cookies();
            const redditCookies = allCookies.filter(c => c.domain && c.domain.includes("reddit.com"));
            if (redditCookies.length === 0) {
                return server.NextResponse.json({ ok: false, error: "No Reddit cookies found. Log in first." }, { status: 400 });
            }
            const cookieStr = redditCookies.map(c => `${c.name}=${c.value}`).join("; ");
            const username = redditCookies.find(c => c.name === "redditUserName")?.value || "browser_user";
            // Sync to legacy cookie jar
            setCookies("reddit.com", redditCookies.map(c => `${c.name}=${c.value}; domain=${c.domain}; path=${c.path}`));
            // Sync to /api/reddit-cookies
            try {
                await fetch("http://127.0.0.1:" + (process.env.PORT || 3000) + "/api/reddit-cookies", {
                    method: "POST", headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ cookies: cookieStr, username })
                });
            } catch {}
            // Don't close the persistent browser — just return the cookies
            return server.NextResponse.json({ ok: true, cookieCount: redditCookies.length, username, message: `Captured ${redditCookies.length} cookies. Scraper now uses your session.` });
        }
    } catch (err) {
        return server.NextResponse.json({ ok: false, error: err?.message || "Browser session failed" }, { status: 500 });
    }
}

;// ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?page=%2Fapi%2Fproxy-browser%2Froute&name=app%2Fapi%2Fproxy-browser%2Froute&pagePath=private-next-app-dir%2Fapi%2Fproxy-browser%2Froute.ts&appDir=%2Fhome%2Fz%2Fmy-project%2Fbuild%2Fv230-apk%2Fsrc%2Fapp&appPaths=%2Fapi%2Fproxy-browser%2Froute&allNormalizedAppPaths=%2F_not-found&allNormalizedAppPaths=%2F_global-error&allNormalizedAppPaths=%2Fapi%2Fauto-discover%2F%5BjobId%5D&allNormalizedAppPaths=%2Fapi%2Fauto-discover&allNormalizedAppPaths=%2Fapi%2Fchapter-cache%2F%5BpostId%5D&allNormalizedAppPaths=%2Fapi%2Fchapter%2F%5Bid%5D&allNormalizedAppPaths=%2Fapi%2Fcrawl&allNormalizedAppPaths=%2Fapi%2Fdownload&allNormalizedAppPaths=%2Fapi%2Ffetch-all-posts&allNormalizedAppPaths=%2Fapi%2Fhardcoded-chapters%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fhfy-foundation-search&allNormalizedAppPaths=%2Fapi%2Flive-wiki&allNormalizedAppPaths=%2Fapi%2Fmass-import&allNormalizedAppPaths=%2Fapi%2Fproxy-browser&allNormalizedAppPaths=%2Fapi%2Fproxy-stats&allNormalizedAppPaths=%2Fapi%2Fpurge-cache&allNormalizedAppPaths=%2Fapi%2Freddit-app-token&allNormalizedAppPaths=%2Fapi%2Freddit-auth&allNormalizedAppPaths=%2Fapi%2Freddit-cookies&allNormalizedAppPaths=%2Fapi%2Freddit-logout&allNormalizedAppPaths=%2Fapi%2Freddit-multi-token&allNormalizedAppPaths=%2Fapi%2Freddit-password-login&allNormalizedAppPaths=%2Fapi%2Freddit-token&allNormalizedAppPaths=%2Fapi%2Freddit-user-token&allNormalizedAppPaths=%2Fapi&allNormalizedAppPaths=%2Fapi%2Fsearch-series&allNormalizedAppPaths=%2Fapi%2Fsearch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fadd-chapter&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fchapters&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fcontinue-fetch&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Fdetect-gaps&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-cache&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Ffetch-missing&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D%2Freparse&allNormalizedAppPaths=%2Fapi%2Fseries%2F%5Bslug%5D&allNormalizedAppPaths=%2Fapi%2Fseries&allNormalizedAppPaths=%2Fapi%2Fstore-scores-all&allNormalizedAppPaths=%2Fapi%2Fstore%2F%5Bkey%5D&allNormalizedAppPaths=%2Fapi%2Fwayback-sync&allNormalizedAppPaths=%2F&allNormalizedAppPaths=%2Freddit-callback&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=standalone&preferredRegion=&middlewareConfig=e30%3D&isGlobalNotFoundEnabled=!


















// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = "standalone"
const routeModule = new module_compiled.AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/proxy-browser/route",
        pathname: "/api/proxy-browser",
        filename: "route",
        bundlePath: "app/api/proxy-browser/route"
    },
    distDir: ".next" || 0,
    relativeProjectDir:  false || '',
    resolvedPagePath: "/home/z/my-project/build/v230-apk/src/app/api/proxy-browser/route.ts",
    nextConfigOutput,
    // The static import is used for initialization (methods, dynamic, etc.).
    userland: route_namespaceObject,
    // In Turbopack dev mode, also provide a getter that calls require() on every
    // request. This re-reads from devModuleCache so HMR updates are picked up,
    // and the async wrapper unwraps async-module Promises (ESM-only
    // serverExternalPackages) automatically.
    ... false ? 0 : {}
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;
function patchFetch() {
    return (0,patch_fetch.patchFetch)({
        workAsyncStorage,
        workUnitAsyncStorage
    });
}

async function handler(req, res, ctx) {
    if (ctx.requestMeta) {
        (0,request_meta.setRequestMeta)(req, ctx.requestMeta);
    }
    if (routeModule.isDev) {
        (0,request_meta.addRequestMeta)(req, 'devRequestTimingInternalsEnd', process.hrtime.bigint());
    }
    let srcPage = "/api/proxy-browser/route";
    // turbopack doesn't normalize `/index` in the page name
    // so we need to to process dynamic routes properly
    // TODO: fix turbopack providing differing value from webpack
    if (false) {} else if (srcPage === '/index') {
        // we always normalize /index specifically
        srcPage = '/';
    }
    const multiZoneDraftMode = false;
    const prepareResult = await routeModule.prepare(req, res, {
        srcPage,
        multiZoneDraftMode
    });
    if (!prepareResult) {
        res.statusCode = 400;
        res.end('Bad Request');
        ctx.waitUntil == null ? void 0 : ctx.waitUntil.call(ctx, Promise.resolve());
        return null;
    }
    const { buildId, deploymentId, params, nextConfig, parsedUrl, isDraftMode, prerenderManifest, routerServerContext, isOnDemandRevalidate, revalidateOnlyGenerated, resolvedPathname, clientReferenceManifest, serverActionsManifest } = prepareResult;
    const normalizedSrcPage = (0,app_paths_.normalizeAppPath)(srcPage);
    let isIsr = Boolean(prerenderManifest.dynamicRoutes[normalizedSrcPage] || prerenderManifest.routes[resolvedPathname]);
    const render404 = async ()=>{
        // TODO: should route-module itself handle rendering the 404
        if (routerServerContext == null ? void 0 : routerServerContext.render404) {
            await routerServerContext.render404(req, res, parsedUrl, false);
        } else {
            res.end('This page could not be found');
        }
        return null;
    };
    if (isIsr && !isDraftMode) {
        const isPrerendered = Boolean(prerenderManifest.routes[resolvedPathname]);
        const prerenderInfo = prerenderManifest.dynamicRoutes[normalizedSrcPage];
        if (prerenderInfo) {
            if (prerenderInfo.fallback === false && !isPrerendered) {
                if (nextConfig.adapterPath) {
                    return await render404();
                }
                throw new no_fallback_error_external_.NoFallbackError();
            }
        }
    }
    let cacheKey = null;
    if (isIsr && !routeModule.isDev && !isDraftMode) {
        cacheKey = resolvedPathname;
        // ensure /index and / is normalized to one key
        cacheKey = cacheKey === '/index' ? '/' : cacheKey;
    }
    const supportsDynamicResponse = // If we're in development, we always support dynamic HTML
    routeModule.isDev === true || // If this is not SSG or does not have static paths, then it supports
    // dynamic HTML.
    !isIsr;
    // This is a revalidation request if the request is for a static
    // page and it is not being resumed from a postponed render and
    // it is not a dynamic RSC request then it is a revalidation
    // request.
    const isStaticGeneration = isIsr && !supportsDynamicResponse;
    // Before rendering (which initializes component tree modules), we have to
    // set the reference manifests to our global store so Server Action's
    // encryption util can access to them at the top level of the page module.
    if (serverActionsManifest && clientReferenceManifest) {
        (0,manifests_singleton.setManifestsSingleton)({
            page: srcPage,
            clientReferenceManifest,
            serverActionsManifest
        });
    }
    const method = req.method || 'GET';
    const tracer = (0,trace_tracer.getTracer)();
    const activeSpan = tracer.getActiveScopeSpan();
    const isWrappedByNextServer = Boolean(routerServerContext == null ? void 0 : routerServerContext.isWrappedByNextServer);
    const isMinimalMode = Boolean((0,request_meta.getRequestMeta)(req, 'minimalMode'));
    const incrementalCache = (0,request_meta.getRequestMeta)(req, 'incrementalCache') || await routeModule.getIncrementalCache(req, nextConfig, prerenderManifest, isMinimalMode);
    incrementalCache == null ? void 0 : incrementalCache.resetRequestCache();
    globalThis.__incrementalCache = incrementalCache;
    const context = {
        params,
        previewProps: prerenderManifest.preview,
        renderOpts: {
            experimental: {
                authInterrupts: Boolean(nextConfig.experimental.authInterrupts)
            },
            cacheComponents: Boolean(nextConfig.cacheComponents),
            supportsDynamicResponse,
            incrementalCache,
            cacheLifeProfiles: nextConfig.cacheLife,
            waitUntil: ctx.waitUntil,
            onClose: (cb)=>{
                res.on('close', cb);
            },
            onAfterTaskError: undefined,
            onInstrumentationRequestError: (error, _request, errorContext, silenceLog)=>routeModule.onRequestError(req, error, errorContext, silenceLog, routerServerContext)
        },
        sharedContext: {
            buildId,
            deploymentId
        }
    };
    const nodeNextReq = new node.NodeNextRequest(req);
    const nodeNextRes = new node.NodeNextResponse(res);
    const nextReq = next_request.NextRequestAdapter.fromNodeNextRequest(nodeNextReq, (0,next_request.signalFromNodeResponse)(res));
    try {
        let parentSpan;
        const invokeRouteModule = async (span)=>{
            return routeModule.handle(nextReq, context).finally(()=>{
                if (!span) return;
                span.setAttributes({
                    'http.status_code': res.statusCode,
                    'next.rsc': false
                });
                const rootSpanAttributes = tracer.getRootSpanAttributes();
                // We were unable to get attributes, probably OTEL is not enabled
                if (!rootSpanAttributes) {
                    return;
                }
                if (rootSpanAttributes.get('next.span_type') !== constants.BaseServerSpan.handleRequest) {
                    console.warn(`Unexpected root span type '${rootSpanAttributes.get('next.span_type')}'. Please report this Next.js issue https://github.com/vercel/next.js`);
                    return;
                }
                const route = rootSpanAttributes.get('next.route');
                if (route) {
                    const name = `${method} ${route}`;
                    span.setAttributes({
                        'next.route': route,
                        'http.route': route,
                        'next.span_name': name
                    });
                    span.updateName(name);
                    // Propagate http.route to the parent span if one exists (e.g.
                    // a platform-created HTTP span in adapter deployments).
                    if (parentSpan && parentSpan !== span) {
                        parentSpan.setAttribute('http.route', route);
                        parentSpan.updateName(name);
                    }
                } else {
                    span.updateName(`${method} ${srcPage}`);
                }
            });
        };
        const handleResponse = async (currentSpan)=>{
            var _cacheEntry_value;
            const responseGenerator = async ({ previousCacheEntry })=>{
                try {
                    if (!isMinimalMode && isOnDemandRevalidate && revalidateOnlyGenerated && !previousCacheEntry) {
                        res.statusCode = 404;
                        // on-demand revalidate always sets this header
                        res.setHeader('x-nextjs-cache', 'REVALIDATED');
                        res.end('This page could not be found');
                        return null;
                    }
                    const response = await invokeRouteModule(currentSpan);
                    req.fetchMetrics = context.renderOpts.fetchMetrics;
                    let pendingWaitUntil = context.renderOpts.pendingWaitUntil;
                    // Attempt using provided waitUntil if available
                    // if it's not we fallback to sendResponse's handling
                    if (pendingWaitUntil) {
                        if (ctx.waitUntil) {
                            ctx.waitUntil(pendingWaitUntil);
                            pendingWaitUntil = undefined;
                        }
                    }
                    const cacheTags = context.renderOpts.collectedTags;
                    // If the request is for a static response, we can cache it so long
                    // as it's not edge.
                    if (isIsr) {
                        const blob = await response.blob();
                        // Copy the headers from the response.
                        const headers = (0,web_utils.toNodeOutgoingHttpHeaders)(response.headers);
                        if (cacheTags) {
                            headers[lib_constants.NEXT_CACHE_TAGS_HEADER] = cacheTags;
                        }
                        if (!headers['content-type'] && blob.type) {
                            headers['content-type'] = blob.type;
                        }
                        const revalidate = typeof context.renderOpts.collectedRevalidate === 'undefined' || context.renderOpts.collectedRevalidate >= lib_constants.INFINITE_CACHE ? false : context.renderOpts.collectedRevalidate;
                        const expire = typeof context.renderOpts.collectedExpire === 'undefined' || context.renderOpts.collectedExpire >= lib_constants.INFINITE_CACHE ? undefined : context.renderOpts.collectedExpire;
                        // Create the cache entry for the response.
                        const cacheEntry = {
                            value: {
                                kind: response_cache.CachedRouteKind.APP_ROUTE,
                                status: response.status,
                                body: Buffer.from(await blob.arrayBuffer()),
                                headers
                            },
                            cacheControl: {
                                revalidate,
                                expire
                            }
                        };
                        return cacheEntry;
                    } else {
                        // send response without caching if not ISR
                        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, response, context.renderOpts.pendingWaitUntil);
                        return null;
                    }
                } catch (err) {
                    // if this is a background revalidate we need to report
                    // the request error here as it won't be bubbled
                    if (previousCacheEntry == null ? void 0 : previousCacheEntry.isStale) {
                        const silenceLog = false;
                        await routeModule.onRequestError(req, err, {
                            routerKind: 'App Router',
                            routePath: srcPage,
                            routeType: 'route',
                            revalidateReason: (0,utils/* getRevalidateReason */.c)({
                                isStaticGeneration,
                                isOnDemandRevalidate
                            })
                        }, silenceLog, routerServerContext);
                    }
                    throw err;
                }
            };
            const cacheEntry = await routeModule.handleResponse({
                req,
                nextConfig,
                cacheKey,
                routeKind: route_kind.RouteKind.APP_ROUTE,
                isFallback: false,
                prerenderManifest,
                isRoutePPREnabled: false,
                isOnDemandRevalidate,
                revalidateOnlyGenerated,
                responseGenerator,
                waitUntil: ctx.waitUntil,
                isMinimalMode
            });
            // we don't create a cacheEntry for ISR
            if (!isIsr) {
                return null;
            }
            if ((cacheEntry == null ? void 0 : (_cacheEntry_value = cacheEntry.value) == null ? void 0 : _cacheEntry_value.kind) !== response_cache.CachedRouteKind.APP_ROUTE) {
                var _cacheEntry_value1;
                throw Object.defineProperty(new Error(`Invariant: app-route received invalid cache entry ${cacheEntry == null ? void 0 : (_cacheEntry_value1 = cacheEntry.value) == null ? void 0 : _cacheEntry_value1.kind}`), "__NEXT_ERROR_CODE", {
                    value: "E701",
                    enumerable: false,
                    configurable: true
                });
            }
            if (!isMinimalMode) {
                res.setHeader('x-nextjs-cache', isOnDemandRevalidate ? 'REVALIDATED' : cacheEntry.isMiss ? 'MISS' : cacheEntry.isStale ? 'STALE' : 'HIT');
            }
            // Draft mode should never be cached
            if (isDraftMode) {
                res.setHeader('Cache-Control', 'private, no-cache, no-store, max-age=0, must-revalidate');
            }
            const headers = (0,web_utils.fromNodeOutgoingHttpHeaders)(cacheEntry.value.headers);
            if (!(isMinimalMode && isIsr)) {
                headers.delete(lib_constants.NEXT_CACHE_TAGS_HEADER);
            }
            // If cache control is already set on the response we don't
            // override it to allow users to customize it via next.config
            if (cacheEntry.cacheControl && !res.getHeader('Cache-Control') && !headers.get('Cache-Control')) {
                headers.set('Cache-Control', (0,cache_control.getCacheControlHeader)(cacheEntry.cacheControl));
            }
            await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, // @ts-expect-error - Argument of type 'Buffer<ArrayBufferLike>' is not assignable to parameter of type 'BodyInit | null | undefined'.
            new Response(cacheEntry.value.body, {
                headers,
                status: cacheEntry.value.status || 200
            }));
            return null;
        };
        // TODO: activeSpan code path is for when wrapped by
        // next-server can be removed when this is no longer used
        if (isWrappedByNextServer && activeSpan) {
            await handleResponse(activeSpan);
        } else {
            parentSpan = tracer.getActiveScopeSpan();
            await tracer.withPropagatedContext(req.headers, ()=>tracer.trace(constants.BaseServerSpan.handleRequest, {
                    spanName: `${method} ${srcPage}`,
                    kind: trace_tracer.SpanKind.SERVER,
                    attributes: {
                        'http.method': method,
                        'http.target': req.url
                    }
                }, handleResponse), undefined, !isWrappedByNextServer);
        }
    } catch (err) {
        if (!(err instanceof no_fallback_error_external_.NoFallbackError)) {
            const silenceLog = false;
            await routeModule.onRequestError(req, err, {
                routerKind: 'App Router',
                routePath: normalizedSrcPage,
                routeType: 'route',
                revalidateReason: (0,utils/* getRevalidateReason */.c)({
                    isStaticGeneration,
                    isOnDemandRevalidate
                })
            }, silenceLog, routerServerContext);
        }
        // rethrow so that we can handle serving error page
        // If this is during static generation, throw the error again.
        if (isIsr) throw err;
        // Otherwise, send a 500 response.
        await (0,send_response/* sendResponse */.I)(nodeNextReq, nodeNextRes, new Response(null, {
            status: 500
        }));
        return null;
    }
}

//# sourceMappingURL=app-route.js.map


/***/ }),

/***/ 8335:
/***/ (() => {



/***/ }),

/***/ 9294:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4741,1813], () => (__webpack_exec__(6983)));
module.exports = __webpack_exports__;

})();