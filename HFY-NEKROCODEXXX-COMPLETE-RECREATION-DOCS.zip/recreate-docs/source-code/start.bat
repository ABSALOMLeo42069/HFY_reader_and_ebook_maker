@echo off
title HFY NEKROCODEXXX
setlocal
set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"
set "NODE_EXE=%APP_DIR%\node\node.exe"
set "SERVER_DIR=%APP_DIR%\server"
set "PORT=3000"
set "URL=http://localhost:%PORT%"
if not exist "%NODE_EXE%" (echo Node.js not found & pause & exit /b 1)
if not exist "%SERVER_DIR%\server.js" (echo Server not found & pause & exit /b 1)
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (taskkill /F /PID %%a >nul 2>&1)
taskkill /FI "WINDOWTITLE eq HFY-NEKRO-Server*" /F >nul 2>&1
set "NODE_ENV=production"
set "PORT=%PORT%"
set "HOSTNAME=127.0.0.1"
echo Starting server...
start "HFY-NEKRO-Server" /min cmd /c ""%NODE_EXE%" "%SERVER_DIR%\server.js" > "%APP_DIR%\server.log" 2>&1"
echo Waiting 5 seconds...
timeout /t 5 /nobreak >nul
echo Opening app...
set "BROWSER="
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" set "BROWSER=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" set "BROWSER=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set "BROWSER=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" set "BROWSER=C:\Program Files\Microsoft\Edge\Application\msedge.exe"
if defined BROWSER (start "" "%BROWSER%" --app="%URL%" --new-window) else (start "" "%URL%")
echo HFY NEKROCODEXXX is running. Run stop.bat to stop.
exit /b 0
