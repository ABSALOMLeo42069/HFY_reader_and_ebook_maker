# HFY NEKROCODEXXX — Original Build Prompt and Specifications

This document contains the original build prompts and specifications that were used to design and build the HFY NEKROCODEXXX application. These documents define the requirements, UI/UX design, data sources, chapter discovery engine, download system, reader engine, theme system, font system, and all other aspects of the application.

---

## Part 1: Master Build Prompt and Technical Specification

# HFY NEKROCODEXXX — Master Build Prompt & Technical Specification
### Native Android APK · r/HFY Series Reader & Downloader · Cyberpunk 2077 UI
**Version 1.0 | June 2026 | English Only**

---

## TABLE OF CONTENTS

1. [Project Identity & Vision](#1-project-identity--vision)
2. [Required Software & Development Environment](#2-required-software--development-environment)
3. [Full Library & Dependency List](#3-full-library--dependency-list)
4. [Architecture Overview](#4-architecture-overview)
5. [UI/UX Design System — Cyberpunk Specification](#5-uiux-design-system--cyberpunk-specification)
6. [Data Sources & API Integration](#6-data-sources--api-integration)
7. [Chapter Discovery Engine — Full Crawler Spec](#7-chapter-discovery-engine--full-crawler-spec)
8. [Screen-by-Screen Feature Specification](#8-screen-by-screen-feature-specification)
9. [Download System & Export Engine](#9-download-system--export-engine)
10. [Reader Engine Specification](#10-reader-engine-specification)
11. [Theme System — 27 App Themes + 27 Reader Themes](#11-theme-system--27-app-themes--27-reader-themes)
12. [Font System — 20+ Bundled Fonts](#12-font-system--20-bundled-fonts)
13. [Local Library & Offline System](#13-local-library--offline-system)
14. [Error Handling & Network Resilience](#14-error-handling--network-resilience)
15. [Caching Strategy](#15-caching-strategy)
16. [Settings Screen — Full Specification](#16-settings-screen--full-specification)
17. [Phased Coding Plan](#17-phased-coding-plan)
18. [APK Build & Signing Instructions](#18-apk-build--signing-instructions)
19. [Testing Checklist](#19-testing-checklist)
20. [Reference Projects & Resources](#20-reference-projects--resources)

---

## 1. Project Identity & Vision

**App Name:** `HFY NEKROCODEXXX`
**Package ID:** `com.nekro.hfycyberdeck`
**Target SDK:** Android 15 (API 35)
**Minimum SDK:** Android 10 (API 29)
**Language:** Kotlin 2.x
**UI Framework:** Jetpack Compose (Material 3 base, fully custom-themed)
**Estimated APK size target:** 360–600 MB (fonts, assets, offline cache)
**Orientation:** Portrait primary, landscape reader mode supported
**Localization:** English only
**App Icon:** Angular cyberpunk symbol with neon red/cyan glow — inspired by the warning triangle, crosshair, and hexagon motifs from the reference PDFs

### Core Mission
HFY NEKROCODEXXX is a feature-complete, native Android application that serves as the definitive front end for `r/HFY` serialized fiction. It pulls the full series catalog from the Reddit wiki at `https://www.reddit.com/r/HFY/wiki/series/`, discovers all chapters of every series (including deep-linked chapters beyond the wiki listing via navigation link crawling), downloads content as EPUB or TXT, and provides a built-in reader with full font/theme customization.

Primary data source: **Reddit OAuth API** (authenticated user sessions preferred)
Secondary/fallback: **Jsoup HTML scraper** (no auth required, rate-limited)

The visual identity is derived entirely from **Cyberpunk 2077** — neon angularity, cut-corner panels, scanline overlays, glitch animations, and the exact palette described below.

---

## 2. Required Software & Development Environment

### 2.1 Operating System
- Windows 10/11 (64-bit), macOS 12+, or Ubuntu 20.04+

### 2.2 IDE
- **Android Studio Ladybug (2024.2.x) or newer** — required for Android 15 (API 35) SDK support
  - Download: https://developer.android.com/studio
  - Enable: Kotlin plugin, Compose plugin (bundled)

### 2.3 Java / JVM
- **JDK 17** (bundled with Android Studio, but verify it is selected in Project Structure)
- Do NOT use JDK 21 for compatibility reasons unless targeting AGP 8.7+

### 2.4 Android SDK Components (install via SDK Manager)
- Android SDK Platform 35 (Android 15)
- Android SDK Build-Tools 35.0.0
- Android Emulator
- Android SDK Platform-Tools (latest)
- Google Play Services (for testing OAuth flows)
- NDK (Side by Side) — 27.0.x (needed only if using any native libs)

### 2.5 Gradle
- Gradle 8.7+ (configured via `gradle-wrapper.properties`)
- Android Gradle Plugin (AGP) 8.5+

### 2.6 Additional Tools
- **Git** (version control)
- **ADB** (Android Debug Bridge — bundled in platform-tools)
- **Apksigner** (bundled in build-tools)
- **Zipalign** (bundled in build-tools)
- **KeyStore Explorer** (optional, for signing key management): https://keystore-explorer.org
- **Reddit Developer Account** — create an app at: https://www.reddit.com/prefs/apps
  - App type: **Installed App** (for OAuth PKCE flow on Android)
  - Redirect URI: `com.nekro.hfycyberdeck://oauth2redirect`

---

## 3. Full Library & Dependency List

Add all of the following to `build.gradle.kts` (module level). Use BOM where noted.

### 3.1 Core Android & Kotlin
```kotlin
// Kotlin
implementation("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")

// AndroidX Core
implementation("androidx.core:core-ktx:1.15.0")
implementation("androidx.appcompat:appcompat:1.7.0")
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
implementation("androidx.activity:activity-compose:1.9.3")
```

### 3.2 Jetpack Compose
```kotlin
val composeBom = platform("androidx.compose:compose-bom:2024.11.00")
implementation(composeBom)
implementation("androidx.compose.ui:ui")
implementation("androidx.compose.ui:ui-graphics")
implementation("androidx.compose.ui:ui-tooling-preview")
implementation("androidx.compose.material3:material3")
implementation("androidx.compose.animation:animation")
implementation("androidx.compose.animation:animation-graphics") // AnimatedVectorDrawable in Compose
implementation("androidx.compose.foundation:foundation")
implementation("androidx.compose.runtime:runtime-livedata")
debugImplementation("androidx.compose.ui:ui-tooling")
debugImplementation("androidx.compose.ui:ui-test-manifest")
```

### 3.3 Navigation
```kotlin
implementation("androidx.navigation:navigation-compose:2.8.4")
```

### 3.4 Dependency Injection — Hilt
```kotlin
implementation("com.google.dagger:hilt-android:2.52")
kapt("com.google.dagger:hilt-android-compiler:2.52")
implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
implementation("androidx.hilt:hilt-work:1.2.0")
kapt("androidx.hilt:hilt-compiler:1.2.0")
```

### 3.5 Networking
```kotlin
// Retrofit + OkHttp
implementation("com.squareup.retrofit2:retrofit:2.11.0")
implementation("com.squareup.retrofit2:converter-gson:2.11.0")
implementation("com.squareup.okhttp3:okhttp:4.12.0")
implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

// Jsoup (HTML scraper fallback)
implementation("org.jsoup:jsoup:1.18.1")
```

### 3.6 Reddit OAuth — Authorization Code + PKCE
```kotlin
// AppAuth-Android for OAuth 2.0 / PKCE
implementation("net.openid:appauth:0.11.1")
// OR manually implement PKCE with OkHttp (no third-party needed for simple flows)
// Recommended: use AppAuth for reliability
```

### 3.7 Room Database (local storage)
```kotlin
implementation("androidx.room:room-runtime:2.6.1")
implementation("androidx.room:room-ktx:2.6.1")
kapt("androidx.room:room-compiler:2.6.1")
implementation("androidx.room:room-paging:2.6.1")
```

### 3.8 Paging 3 (infinite scroll)
```kotlin
implementation("androidx.paging:paging-runtime-ktx:3.3.4")
implementation("androidx.paging:paging-compose:3.3.4")
```

### 3.9 WorkManager (download queue)
```kotlin
implementation("androidx.work:work-runtime-ktx:2.10.0")
```

### 3.10 DataStore (preferences/settings persistence)
```kotlin
implementation("androidx.datastore:datastore-preferences:1.1.1")
```

### 3.11 EPUB Generation
```kotlin
// epublib-core (Maven Central)
implementation("io.github.psiegman:epublib-core:4.1")
// XML for epub packaging
implementation("org.xmlpull:xmlpull:1.1.3.4d_b4_min")
```

### 3.12 File & Media
```kotlin
// Coil (image loading for cover art, future features)
implementation("io.coil-kt:coil-compose:2.7.0")

// Apache Commons IO (file utilities)
implementation("commons-io:commons-io:2.16.1")

// ZIP support (built-in Java, no dep needed)
```

### 3.13 WebView (for Reddit OAuth login flow)
```kotlin
// Built into Android — no external dep needed
// Use androidx.webkit for modern WebView features
implementation("androidx.webkit:webkit:1.12.1")
```

### 3.14 Animation & Glitch Effects
```kotlin
// Lottie (for animated loading indicators, glitch overlays)
implementation("com.airbnb.android:lottie-compose:6.5.2")

// Canvas-based custom animations are implemented manually in Compose
```

### 3.15 Permissions & Storage
```kotlin
// Modern file access — no extra dep, use Android Storage Access Framework
// For scoped storage on Android 10+: use MediaStore or SAF
implementation("androidx.documentfile:documentfile:1.0.1")
```

### 3.16 Testing
```kotlin
testImplementation("junit:junit:4.13.2")
androidTestImplementation("androidx.test.ext:junit:1.2.1")
androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
androidTestImplementation(composeBom)
androidTestImplementation("androidx.compose.ui:ui-test-junit4")
```

### 3.17 Fonts (bundled as assets)
All fonts are stored in `app/src/main/assets/fonts/` — no library needed. Load with `FontFamily` in Compose.

---

## 4. Architecture Overview

### 4.1 Pattern: MVI + Clean Architecture

```
app/
├── di/                         # Hilt modules
├── data/
│   ├── local/
│   │   ├── database/           # Room entities, DAOs, AppDatabase
│   │   └── datastore/          # User preferences (settings, themes)
│   ├── remote/
│   │   ├── reddit/
│   │   │   ├── RedditApiService.kt      # Retrofit interface (OAuth endpoints)
│   │   │   ├── RedditAuthManager.kt     # PKCE token management
│   │   │   └── RedditOAuthInterceptor.kt
│   │   └── scraper/
│   │       ├── HfyScraper.kt            # Jsoup-based fallback scraper
│   │       └── ChapterCrawler.kt        # "Next chapter" link crawler
│   ├── repository/
│   │   ├── SeriesRepository.kt
│   │   ├── ChapterRepository.kt
│   │   └── DownloadRepository.kt
│   └── model/
│       ├── Series.kt
│       ├── Chapter.kt
│       ├── DownloadJob.kt
│       └── ReadingProgress.kt
├── domain/
│   ├── usecase/
│   │   ├── GetSeriesListUseCase.kt
│   │   ├── GetChaptersUseCase.kt
│   │   ├── DiscoverAllChaptersUseCase.kt
│   │   ├── DownloadSeriesUseCase.kt
│   │   └── ExportEpubUseCase.kt
│   └── model/                  # Domain models (separate from data models)
├── presentation/
│   ├── theme/
│   │   ├── CyberpunkTheme.kt
│   │   ├── ThemeTokens.kt      # All 27 themes defined here
│   │   └── ReaderThemeTokens.kt
│   ├── components/             # Reusable Compose components
│   │   ├── CyberPanel.kt
│   │   ├── GlitchText.kt
│   │   ├── ScanlineOverlay.kt
│   │   ├── AnimatedCornerBrackets.kt
│   │   ├── CyberButton.kt
│   │   ├── NeonProgressBar.kt
│   │   └── ...
│   ├── screens/
│   │   ├── splash/
│   │   ├── browse/
│   │   ├── series_detail/
│   │   ├── chapter_list/
│   │   ├── reader/
│   │   ├── library/
│   │   ├── downloads/
│   │   └── settings/
│   └── navigation/
│       └── AppNavGraph.kt
└── worker/
    ├── ChapterDownloadWorker.kt
    └── ChapterCrawlWorker.kt
```

### 4.2 State Management
- Each screen has a `ViewModel` with a sealed `UiState` class
- Events flow: `UserAction → ViewModel → UseCase → Repository → Data Source`
- Compose `collectAsStateWithLifecycle()` for all flows
- `LazyPagingItems` for all list screens (Browse, Library)

---

## 5. UI/UX Design System — Cyberpunk Specification

Derived from the provided reference PDFs (Cyberpunk 2077 HUD art book, KLWP Cyberpunk widgets, CP2077 icon sheets).

### 5.1 Color Palette (Primary)

| Token Name | Hex | Usage |
|---|---|---|
| `CyberRed` | `#FF003C` | Primary accent, danger, selected states |
| `CyberCyan` | `#00FFF0` | Secondary accent, links, active indicators |
| `CyberYellow` | `#FFE600` | Warnings, highlights, chapter numbers |
| `CyberOrange` | `#FF6B00` | Download states, progress bars (alt) |
| `CyberPurple` | `#B200FF` | Special states, bookmarks |
| `NightBlack` | `#060608` | Primary background |
| `DarkPanel` | `#0D0F12` | Card/panel background |
| `GridLine` | `#1A1F26` | Subtle grid lines, dividers |
| `TextPrimary` | `#E8EDF2` | Main body text |
| `TextSecondary` | `#6B7A8D` | Metadata, subtitles |
| `ScanlineOverlay` | `#00000033` | Semi-transparent scanline stripe |

### 5.2 Shape System (Angular / Cut-Corner)
All panels and buttons use `CutCornerShape` — never rounded corners in the primary design:
```kotlin
// Small components (chips, badges)
val CyberShapeSmall = CutCornerShape(4.dp)

// Cards, panels
val CyberShapeMedium = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp)

// Large dialogs, full-width panels  
val CyberShapeLarge = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)

// Asymmetric — used for series cards
val CyberShapeAsymmetric = GenericShape { size, _ ->
    // Custom cut-corner path with diagonal slashes
}
```

### 5.3 Typography Scale
```kotlin
val CyberpunkTypography = Typography(
    displayLarge   = TextStyle(fontFamily = FontNekro,    fontSize = 48.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Black),
    displayMedium  = TextStyle(fontFamily = FontNekro,    fontSize = 32.sp, letterSpacing = 2.sp),
    headlineLarge  = TextStyle(fontFamily = FontCyberpunk, fontSize = 24.sp, letterSpacing = 1.sp),
    headlineMedium = TextStyle(fontFamily = FontOrbitron,  fontSize = 18.sp, letterSpacing = 0.5.sp),
    titleLarge     = TextStyle(fontFamily = FontOrbitron,  fontSize = 16.sp),
    bodyLarge      = TextStyle(fontFamily = FontShareTechMono, fontSize = 14.sp, lineHeight = 22.sp),
    bodyMedium     = TextStyle(fontFamily = FontShareTechMono, fontSize = 12.sp, lineHeight = 18.sp),
    labelSmall     = TextStyle(fontFamily = FontVT323,    fontSize = 10.sp, letterSpacing = 1.sp),
)
```

### 5.4 Mandatory UI Effects (Applied Globally)

**Scanline Overlay:**
```kotlin
@Composable
fun ScanlineOverlay(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val stripeHeight = 4.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawRect(
                color = Color(0x0A000000),
                topLeft = Offset(0f, y),
                size = Size(size.width, stripeHeight / 2)
            )
            y += stripeHeight
        }
    }
}
```

**Animated Corner Brackets** (appear on focused/hovered panels):
```kotlin
@Composable
fun AnimatedCornerBrackets(isActive: Boolean, color: Color = CyberCyan) {
    val animatedAlpha by animateFloatAsState(if (isActive) 1f else 0f)
    val animatedOffset by animateFloatAsState(if (isActive) 0f else 6f)
    // Draw 4 corner L-shapes using Canvas, animated inward on activation
}
```

**Glitch Effect** (applied to selected text elements):
```kotlin
@Composable
fun GlitchText(text: String, modifier: Modifier = Modifier, baseColor: Color = TextPrimary) {
    // Randomly offset a red ghost layer and a cyan ghost layer by 1-3px
    // Trigger randomly every 3-8 seconds with a 100-300ms duration
    // Use InfiniteTransition + randomized triggers
}
```

**Neon Glow** (applied to accent elements via shadow):
```kotlin
fun Modifier.neonGlow(color: Color, radius: Dp = 8.dp): Modifier = this.then(
    Modifier.graphicsLayer {
        renderEffect = BlurMaskFilter(radius.toPx(), BlurMaskFilter.Blur.OUTER)
        // Compose 1.7+: use RenderEffect
    }
)
```

### 5.5 Navigation Structure
Bottom navigation bar — 5 tabs, custom cyberpunk tab indicators:
1. **BROWSE** — Grid icon (series discovery)
2. **LIBRARY** — Database icon (favorites + local files)
3. **DOWNLOADS** — Download queue icon
4. **READER** — last-read shortcut
5. **SETTINGS** — Hex gear icon

Top bar: `HFY NEKROCODEXXX` logotype in display font, right-side connection status indicator (Reddit API / Scraper / Offline)

### 5.6 Animations Required
- **Splash screen**: Barcode scan animation, percentage counter (0→100%), glitch text reveal of app name
- **Page transitions**: Horizontal slide with glitch frame bleed
- **List item reveal**: Staggered fade-in from bottom with slight X offset
- **Download progress**: Neon progress bar with pulsing glow, scanline-style fill
- **Pull-to-refresh**: Neon spinner with angular rotation
- **Chapter loading**: "SCANNING..." text with animated ellipsis, hex code rain in background

---

## 6. Data Sources & API Integration

### 6.1 Reddit OAuth (Primary — Preferred)

**App registration:** `https://www.reddit.com/prefs/apps`
- Type: `installed app`
- Redirect URI: `com.nekro.hfycyberdeck://oauth2redirect`
- Scopes needed: `read`, `identity`, `history`

**OAuth Flow (PKCE):**
```kotlin
// RedditAuthManager.kt
class RedditAuthManager @Inject constructor(
    private val context: Context,
    private val dataStore: DataStore<Preferences>
) {
    private val clientId = BuildConfig.REDDIT_CLIENT_ID
    private val redirectUri = "com.nekro.hfycyberdeck://oauth2redirect"
    
    fun buildAuthorizationRequest(): AuthorizationRequest { /* AppAuth */ }
    suspend fun exchangeCodeForToken(code: String, codeVerifier: String): TokenResult { }
    suspend fun refreshToken(refreshToken: String): TokenResult { }
    suspend fun getValidAccessToken(): String? { }
    fun isAuthenticated(): Boolean { }
    suspend fun logout() { }
}
```

**Key Reddit API Endpoints:**
```
// Wiki page — series index
GET https://oauth.reddit.com/r/HFY/wiki/series
    Headers: Authorization: Bearer {token}
    Returns: JSON with wiki content_md (markdown)

// Series wiki page (individual series)
GET https://oauth.reddit.com/r/HFY/wiki/{series_slug}

// Post/submission details (chapter content)
GET https://oauth.reddit.com/r/HFY/comments/{post_id}
    Returns: Post selftext (markdown), metadata (score, created_utc, etc.)

// User's subreddit posts (for discovery)
GET https://oauth.reddit.com/r/HFY/search?q=flair:Series&sort=new&limit=100
```

**Rate limiting:** Reddit allows 60 authenticated requests/minute. Implement exponential backoff. Cache all responses.

### 6.2 Jsoup HTML Scraper (Fallback / Unauthenticated)

```kotlin
// HfyScraper.kt
class HfyScraper @Inject constructor(private val okHttpClient: OkHttpClient) {
    
    suspend fun fetchSeriesIndex(): List<SeriesStub> {
        val doc = Jsoup.connect("https://www.reddit.com/r/HFY/wiki/series/")
            .userAgent("HFY-NEKROCODEXXX/1.0 Android")
            .timeout(15_000)
            .get()
        // Parse: all <a> tags inside the wiki content div
        // Each link is a series page URL
        return doc.select(".wiki a[href*='/r/HFY/wiki/']").map { el ->
            SeriesStub(title = el.text(), wikiUrl = el.attr("href"))
        }
    }
    
    suspend fun fetchSeriesPage(wikiUrl: String): SeriesDetail {
        val doc = Jsoup.connect("https://www.reddit.com$wikiUrl").get()
        // Extract: synopsis, chapter links (all <a> tags pointing to reddit.com/r/HFY/comments/)
    }
    
    suspend fun fetchChapterContent(postUrl: String): ChapterContent {
        val doc = Jsoup.connect(postUrl).get()
        // Extract: post title, selftext div (.usertext-body), score, flair
    }
}
```

### 6.3 Wiki Parsing — Series Index

The wiki page at `https://www.reddit.com/r/HFY/wiki/series/` contains an alphabetical index of series. Each entry is a link to a per-series wiki page. Parse:
- Series title (link text)
- Series wiki URL
- Optional: author name if listed

Each series wiki page contains:
- Synopsis paragraph(s)
- A list of chapter links (these are Reddit post URLs)
- Sometimes: word count, status (ongoing/complete), author

**IMPORTANT:** The wiki only lists a subset of chapters for long-running series. Many series continue past what's listed. The Chapter Discovery Engine (Section 7) handles this.

### 6.4 Dual-Source Strategy Implementation

```kotlin
// SeriesRepository.kt
class SeriesRepository @Inject constructor(
    private val redditApi: RedditApiService,
    private val scraper: HfyScraper,
    private val authManager: RedditAuthManager,
    private val seriesDao: SeriesDao
) {
    suspend fun getSeriesIndex(page: Int): List<Series> {
        return if (authManager.isAuthenticated()) {
            try {
                val token = authManager.getValidAccessToken()!!
                redditApi.getWikiPage("series", token).toSeriesList()
            } catch (e: Exception) {
                scraper.fetchSeriesIndex() // fallback
            }
        } else {
            scraper.fetchSeriesIndex()
        }
    }
}
```

---

## 7. Chapter Discovery Engine — Full Crawler Spec

This is the most critical and complex component. The wiki only lists **partial chapter lists**. For series like "Out of Cruel Space" (1000+ chapters), only 59 may be listed. The crawler must follow "next chapter" links to discover all chapters.

### 7.1 The Problem
Each Reddit post for a chapter typically contains navigation links in the body text:
- "Next chapter" / "Next" / "[Next]" / "Next >" / "Part N+1" / "Episode N+1"
- "Previous" / "[Prev]" / "Previous chapter"
- These are hyperlinks embedded in the post's selftext/markdown

### 7.2 ChapterCrawler.kt
```kotlin
class ChapterCrawler @Inject constructor(
    private val redditApi: RedditApiService,
    private val scraper: HfyScraper,
    private val chapterDao: ChapterDao,
    private val authManager: RedditAuthManager
) {
    companion object {
        // All known "next" link text patterns (case-insensitive regex)
        val NEXT_LINK_PATTERNS = listOf(
            Regex("""next\s*chapter""", RegexOption.IGNORE_CASE),
            Regex("""\[next\]""", RegexOption.IGNORE_CASE),
            Regex("""next\s*>\s*$""", RegexOption.IGNORE_CASE),
            Regex("""next\s*part""", RegexOption.IGNORE_CASE),
            Regex("""next\s*episode""", RegexOption.IGNORE_CASE),
            Regex("""next\s*installment""", RegexOption.IGNORE_CASE),
            Regex("""part\s*\d+\s*$""", RegexOption.IGNORE_CASE),
            Regex("""chapter\s*\d+\s*$""", RegexOption.IGNORE_CASE),
            Regex("""episode\s*\d+\s*$""", RegexOption.IGNORE_CASE),
            Regex("""epilogue""", RegexOption.IGNORE_CASE),
            Regex("""next\s*$""", RegexOption.IGNORE_CASE),
            Regex("""continue""", RegexOption.IGNORE_CASE),
        )
        
        val REDDIT_POST_URL_PATTERN = Regex("""reddit\.com/r/HFY/comments/([a-z0-9]+)""")
    }
    
    // Crawl from a starting chapter URL, following "next" links breadth-first
    suspend fun crawlAllChapters(
        seriesId: String,
        knownChapterUrls: List<String>,
        onProgress: (discovered: Int) -> Unit
    ): List<Chapter> {
        val discovered = mutableSetOf<String>()
        val queue = ArrayDeque(knownChapterUrls)
        val results = mutableListOf<Chapter>()
        var crawlOrder = 0
        
        while (queue.isNotEmpty()) {
            val url = queue.removeFirst()
            if (url in discovered) continue
            discovered.add(url)
            
            val postId = REDDIT_POST_URL_PATTERN.find(url)?.groupValues?.get(1) ?: continue
            
            // Check local cache first
            val cached = chapterDao.getChapterByPostId(postId)
            if (cached != null) {
                results.add(cached)
                // Still need to check for next link even if content is cached
            }
            
            val postDetail = fetchPostDetail(postId)
            val chapter = postDetail.toChapter(seriesId, crawlOrder++)
            results.add(chapter)
            chapterDao.upsert(chapter)
            
            // Parse markdown/HTML for next links
            val nextUrl = findNextChapterLink(postDetail.selftext, postDetail.selftextHtml)
            if (nextUrl != null && nextUrl !in discovered) {
                queue.add(nextUrl)
            }
            
            onProgress(discovered.size)
            delay(500L) // Respectful rate limiting — 2 requests/sec max
        }
        
        return results.sortedBy { it.crawlOrder }
    }
    
    private fun findNextChapterLink(markdown: String, html: String?): String? {
        // Strategy 1: Parse markdown links [text](url)
        val mdLinks = Regex("""\[([^\]]+)\]\((https?://[^\)]+)\)""")
            .findAll(markdown)
            .filter { match -> NEXT_LINK_PATTERNS.any { it.containsMatchIn(match.groupValues[1]) } }
            .filter { REDDIT_POST_URL_PATTERN.containsMatchIn(it.groupValues[2]) }
            .firstOrNull()
        
        if (mdLinks != null) return mdLinks.groupValues[2]
        
        // Strategy 2: Parse rendered HTML for <a> tags
        if (html != null) {
            val doc = Jsoup.parse(html)
            val link = doc.select("a").firstOrNull { el ->
                NEXT_LINK_PATTERNS.any { it.containsMatchIn(el.text()) } &&
                REDDIT_POST_URL_PATTERN.containsMatchIn(el.attr("href"))
            }
            if (link != null) return link.attr("href")
        }
        
        return null
    }
}
```

### 7.3 Background Crawling with WorkManager
```kotlin
// ChapterCrawlWorker.kt
@HiltWorker
class ChapterCrawlWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val crawler: ChapterCrawler,
    private val seriesDao: SeriesDao
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result {
        val seriesId = inputData.getString("series_id") ?: return Result.failure()
        
        setForeground(createForegroundInfo("Scanning chapters for $seriesId..."))
        
        return try {
            val knownUrls = seriesDao.getChapterUrls(seriesId)
            crawler.crawlAllChapters(seriesId, knownUrls) { discovered ->
                // Update progress notification
            }
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}
```

### 7.4 UI: Chapter Discovery Status
When a user opens a series detail screen, show:
- "WIKI CHAPTERS: 59 | DISCOVERED: [scanning...]"
- Animated progress bar as crawl proceeds
- "TAP TO SCAN ALL CHAPTERS" button triggers manual crawl
- Previously discovered chapters are stored in Room and shown immediately

---

## 8. Screen-by-Screen Feature Specification

### 8.1 SPLASH SCREEN
- Duration: 2.5 seconds or until initial data loads
- Animation: Barcode scan line sweeps top-to-bottom across a dark background
- Text: `INITIALIZING HFY NEKROCODEXXX` in dot-matrix font with animated ellipsis
- Counter: percentage loading indicator (fake 0→100% over 2s)
- Binary rain: faint hex digits falling in background
- Logo reveal: glitch-in effect for app name at 80% load
- After splash: navigate to Browse if data ready, else show skeleton

### 8.2 BROWSE SCREEN
**URL:** `r/HFY/wiki/series/` — live, paginated, infinite scroll

**Features:**
- **Infinite scroll** via Paging 3: each page is one "page" of wiki results. As user scrolls to bottom, next batch loads automatically. No "Next page" button ever shown.
- **Series card** shows: title, author (if known), chapter count (wiki-listed + discovered), status badge (Ongoing/Complete/Unknown), upvote count (if available via API)
- **Pull-to-refresh** (SwipeRefresh): force-fetches updated series list and merges with local cache
- **Search bar** at top: debounced 300ms, searches both local cache AND makes live API calls to `r/HFY/search?q={query}&flair=Series`
- **Filter chips**: Sort by Title (A-Z), Chapters (most), New (date), Popular (upvotes)
- **Live catalog merge**: newly added series on the wiki appear without app update
- **Status indicators** in top bar: REDDIT API (green) / SCRAPER (yellow) / OFFLINE (red)
- Grid layout: 2-column on phones, 3-column on tablets

**Series Card Design (Cyberpunk):**
```
┌─────────────────────────────────┐ ←CutCornerShape
│ ◈ SERIES TITLE                  │ ←CyberCyan, uppercase
│ [author name]          ■ 342 ch │ ←chapter count badge
│ ████████████░░░░  [ONGOING]     │ ←progress/status
│ ▲ 14.2K                         │ ←upvotes
└─────────────────────────────────┘
```

### 8.3 SERIES DETAIL SCREEN
**Features:**
- **Header**: Large series title in display font, glitch animation on load
- **Synopsis**: Parsed from series wiki page, shown above chapter list
- **Meta stats panel**:
  - Wiki chapters listed
  - Total discovered chapters
  - Total word count (estimated)
  - Upvotes
  - Author (Reddit username, tappable → Reddit profile)
  - Status (ongoing/complete)
  - Date of first/last chapter
- **Chapter Discovery Button**: "SCAN ALL CHAPTERS [59 known → tap to discover more]"
- **Chapter list** (LazyColumn with Paging 3):
  - Each item: chapter number, post title, date, word count estimate, read status
  - Swipe right: download chapter
  - Swipe left: mark as read/unread
  - Long press: select for batch operations
- **Floating Action Buttons**:
  - Download all chapters
  - Download selected
  - Export as EPUB
  - Export as TXT (merged)
- **Pull-down in chapter list**: refresh chapters for new additions
- **Header scroll**: series info collapses as user scrolls down into chapter list

### 8.4 CHAPTER LIST ITEM (Component)
```
┌─ CHAPTER 001 ────────────────────────────────────┐
│  "First Contact"                          ◈ READ │
│  u/AuthorName · 2023-01-15 · ~3,200 words       │
│  ▓▓▓▓▓▓▓░░░░░ (reading progress 60%)           │
└──────────────────────────────────────────────────┘
```

### 8.5 READER SCREEN
Full-screen reading experience. See Section 10 for complete spec.

### 8.6 LIBRARY SCREEN
**Tabs**: FAVORITES | READING | DOWNLOADED | LOCAL FILES

**FAVORITES tab**:
- All bookmarked series
- Pull-down to refresh for new chapters
- Quick-stats: last read date, chapters remaining

**READING tab**:
- Series with reading progress > 0%
- Sorted by last-read date
- "CONTINUE" button per series → jumps to last-read chapter

**DOWNLOADED tab**:
- All series/chapters with offline content
- Storage size shown
- Available offline indicator
- Delete downloaded content button

**LOCAL FILES tab**:
- Scan designated folder: `/storage/emulated/0/HFY_NEKROCODEXXX/Import/`
- Supported formats: .epub, .txt
- Parse EPUB metadata (title, author from OPF)
- Add to library as "LOCAL" series
- Settings page explains where to place files

### 8.7 DOWNLOADS SCREEN
**Download Queue Panel:**
```
DOWNLOAD QUEUE ═══════════════════════ 3 ACTIVE / 47 PENDING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
◈ Out of Cruel Space          [########░░░░░] 347/1024 ch
◈ The Deathworlders           [##░░░░░░░░░░░]  23/312 ch
◈ Nature of Predators         [████████████] COMPLETE ✓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COMPLETED (12)
FAILED (2)
```
- Pause/Resume/Cancel per job
- Reorder queue via drag-handle
- Global pause all button
- WiFi-only option in settings
- Storage remaining indicator

---

## 9. Download System & Export Engine

### 9.1 ChapterDownloadWorker.kt
```kotlin
@HiltWorker
class ChapterDownloadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val chapterRepo: ChapterRepository,
    private val fileManager: DownloadFileManager
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result {
        val chapterId = inputData.getString("chapter_id") ?: return Result.failure()
        val chapter = chapterRepo.getChapter(chapterId) ?: return Result.failure()
        
        // 1. Fetch content (OAuth API or scraper fallback)
        val content = chapterRepo.fetchChapterContent(chapter.postUrl)
        
        // 2. Save raw content to Room
        chapterRepo.saveContent(chapterId, content.markdown)
        
        // 3. Save to file if format requested
        val format = inputData.getString("format") ?: "none"
        if (format == "txt") fileManager.saveTxt(chapter, content)
        if (format == "epub") fileManager.saveEpub(chapter, content)
        
        return Result.success()
    }
}
```

### 9.2 Export Formats

**Single Chapter TXT:**
```
HFY NEKROCODEXXX — Export
═══════════════════════════════════════
Series: [Series Name]
Chapter: [N] — [Post Title]
Author: u/[username]
Date: [post date]
Source: reddit.com/r/HFY/comments/[id]
Upvotes: [score]
═══════════════════════════════════════

[chapter content in plain text]
```

**Full Series EPUB:**
Uses `epublib-core` to generate a valid .epub with:
- OPF metadata: title (series name), author, description (synopsis), language=en
- NCX table of contents: one entry per chapter
- Each chapter as separate XHTML file
- Custom CSS for reader styling (minimal)
- Cover image: generated programmatically from series title text in cyberpunk style

**Full Series TXT (Merged):**
Chapters concatenated with clear dividers:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━
CHAPTER [N]: [POST TITLE]
[Date] | [Score] upvotes
━━━━━━━━━━━━━━━━━━━━━━━━━━
[content]
```

### 9.3 Download Options UI
- Download individual chapter (TXT, EPUB, or just cache for offline reading)
- Download all chapters (queued)
- Download selected chapters (multi-select mode)
- Merge all downloaded chapters into single EPUB
- Merge all downloaded chapters into single TXT
- Share exported file via system share sheet

### 9.4 File Storage Paths
```
/storage/emulated/0/HFY_NEKROCODEXXX/
├── Downloads/
│   ├── [SeriesName]/
│   │   ├── chapter_001.txt
│   │   ├── chapter_002.txt
│   │   └── ...
│   └── [SeriesName].epub
└── Import/          ← Drop local EPUB/TXT files here for library
```

---

## 10. Reader Engine Specification

### 10.1 Reader Architecture
- Full-screen Compose screen
- Content displayed in scrollable `LazyColumn` with one block per paragraph
- **Infinite vertical scroll**: at bottom of chapter, seamlessly load next chapter
- Chapter boundary shown as: `━━━ END OF CHAPTER N ━━━ BEGINNING OF CHAPTER N+1 ━━━`
- Tap left edge: previous chapter | Tap right edge: next chapter | Tap center: toggle UI chrome

### 10.2 Reader Controls (when chrome visible)
Top bar:
- Back arrow, series title, chapter number/total
- Bookmark button (saves position)

Bottom bar:
- Chapter slider (scrub to any chapter)
- Font size picker (3px → 48px, continuous slider)
- Font selector (opens font picker sheet)
- Theme selector (opens reader theme picker)
- Screen brightness (separate from system)
- Lock rotation toggle

### 10.3 Font Customization in Reader
- Font size: **3px minimum** (as requested) to 48px maximum, 1sp step
- Line height: auto-calculated or manual (1.0 → 3.0)
- Letter spacing: -0.05em to 0.5em
- Paragraph spacing: 0 → 32sp
- Text alignment: left, justified, right, center
- Font family: any of the 20+ bundled fonts (Section 12)
- Bold/italic toggle for body text
- Hyphenation: on/off

### 10.4 Reading Progress
- Position saved per chapter (paragraph index + character offset)
- Synced to Room database
- Shown as progress bar in chapter list
- "Resume reading" button on series detail screen

---

## 11. Theme System — 27 App Themes + 27 Reader Themes

### 11.1 App Themes (select in Settings → Appearance → App Theme)

| # | Name | Primary BG | Accent 1 | Accent 2 | Accent 3 |
|---|------|-----------|---------|---------|---------|
| 1 | **NIGHT CITY** (default) | `#060608` | `#FF003C` | `#00FFF0` | `#FFE600` |
| 2 | **BLOOD RED** | `#0A0004` | `#FF0000` | `#FF6600` | `#FFCCCC` |
| 3 | **NETRUNNER** | `#020A14` | `#00FFCC` | `#0080FF` | `#004466` |
| 4 | **CORPO STEEL** | `#0C0C0E` | `#C0C0C0` | `#4488CC` | `#002244` |
| 5 | **ARASAKA** | `#05000A` | `#AA00FF` | `#FF00AA` | `#220033` |
| 6 | **MILITECH** | `#060A04` | `#44FF00` | `#888800` | `#002200` |
| 7 | **MAELSTROM** | `#0A0008` | `#FF00FF` | `#CC0088` | `#440044` |
| 8 | **BIOTECHNICA** | `#000A08` | `#00FF88` | `#00CCAA` | `#003322` |
| 9 | **SOULKILLER** | `#080008` | `#FF44CC` | `#CC00FF` | `#330033` |
| 10 | **HEIST MODE** | `#050508` | `#FFAA00` | `#FF6600` | `#332200` |
| 11 | **ICE GRID** | `#020610` | `#88CCFF` | `#4488FF` | `#001122` |
| 12 | **THERMAL** | `#08040A` | `#FF4400` | `#FF8800` | `#442200` |
| 13 | **GHOST** | `#F0F4F8` | `#003366` | `#CC0000` | `#888888` |
| 14 | **VOID** | `#000000` | `#FFFFFF` | `#888888` | `#333333` |
| 15 | **PACIFICA** | `#060C08` | `#AAFFAA` | `#44AA44` | `#002200` |
| 16 | **DOGTOWN** | `#080806` | `#FFDD44` | `#CC8800` | `#333300` |
| 17 | **BADLANDS** | `#0A0808` | `#FF8844` | `#CC4400` | `#331100` |
| 18 | **RIPPERDOC** | `#04040A` | `#FF2244` | `#00AAFF` | `#220011` |
| 19 | **CHROME** | `#0A0C0E` | `#CCDDEE` | `#8899AA` | `#223344` |
| 20 | **NEON PURPLE** | `#06000E` | `#CC44FF` | `#8800CC` | `#220044` |
| 21 | **DEEP SEA** | `#000A12` | `#00CCFF` | `#0066AA` | `#001133` |
| 22 | **RUST** | `#0A0500` | `#FF7744` | `#BB4400` | `#331500` |
| 23 | **JADE** | `#000A06` | `#44FFAA` | `#00BB66` | `#003322` |
| 24 | **AMBER** | `#080600` | `#FFCC00` | `#FF8800` | `#332200` |
| 25 | **BLOOD MOON** | `#070002` | `#FF1144` | `#880022` | `#220008` |
| 26 | **TERMINAL** | `#000000` | `#00FF00` | `#004400` | `#001100` |
| 27 | **CUSTOM** | User-defined via color pickers |

### 11.2 Reader Themes (27 total)
Reader themes control: background color, text color, link color, highlight color, selection color.

Follows same naming convention. Examples:
| # | Name | BG | Text | Link |
|---|------|----|------|------|
| 1 | NIGHT MODE (default) | `#0A0A0E` | `#D4D8E0` | `#00FFF0` |
| 2 | DARK AMBER | `#0A0800` | `#FFCC88` | `#FF8800` |
| 3 | HACKER GREEN | `#001400` | `#00FF44` | `#88FF00` |
| 4 | BLOOD PAPER | `#1A0000` | `#FFCCCC` | `#FF4444` |
| 5 | CREAM PAPER | `#F4F0E8` | `#1A1A1A` | `#CC2200` |
| 6 | SEPIA | `#2A1800` | `#CC9966` | `#FF6600` |
| ... (27 total, including Custom) |

### 11.3 Custom Theme Builder
Settings → Appearance → Custom Theme Editor:
- Color picker (HSV wheel + hex input) for each of 4 colors: Background, Surface, Accent 1, Accent 2
- Live preview of all screens with chosen colors
- Save as named custom theme
- Share theme code (export as string)

---

## 12. Font System — 20+ Bundled Fonts

All fonts placed in `app/src/main/assets/fonts/`. Loaded via `FontFamily` in Compose.

### 12.1 Display/Cyberpunk Fonts
1. **Orbitron** (Google Fonts, SIL OFL) — geometric, futuristic
2. **Rajdhani** (Google Fonts, SIL OFL) — angular, condensed
3. **Share Tech Mono** (Google Fonts, SIL OFL) — monospace terminal
4. **VT323** (Google Fonts, SIL OFL) — retro bitmap
5. **Press Start 2P** (Google Fonts, SIL OFL) — 8-bit pixel
6. **Syncopate** (Google Fonts, SIL OFL) — uppercase display
7. **Audiowide** (Google Fonts, SIL OFL) — tech, sci-fi
8. **Russo One** (Google Fonts, SIL OFL) — bold, industrial
9. **Exo 2** (Google Fonts, SIL OFL) — clean, technical
10. **Sarpanch** (Google Fonts, SIL OFL) — angular, heavy

### 12.2 Stellaris-Inspired Fonts
11. **Cinzel** (Google Fonts, SIL OFL) — Roman, imperial
12. **Cinzel Decorative** (Google Fonts, SIL OFL) — ceremonial
13. **Uncial Antiqua** (Google Fonts, SIL OFL) — ancient script feel

### 12.3 Reader-Optimized Fonts (Legibility for Long Reading)
14. **Literata** (Google Fonts, SIL OFL) — eBook-optimized serif
15. **Merriweather** (Google Fonts, SIL OFL) — comfortable serif
16. **Source Serif 4** (Google Fonts, SIL OFL) — technical serif
17. **IBM Plex Sans** (Google Fonts, SIL OFL) — clean sans-serif
18. **IBM Plex Mono** (Google Fonts, SIL OFL) — monospace code-style
19. **Nunito** (Google Fonts, SIL OFL) — rounded sans, easy reading
20. **Roboto Slab** (Google Fonts, SIL OFL) — slab serif, strong

### 12.4 Bonus Fonts
21. **Nova Square** (Google Fonts, SIL OFL) — geometric squares
22. **Aldrich** (Google Fonts, SIL OFL) — tech military
23. **B612 Mono** (Google Fonts, SIL OFL) — aerospace monospace
24. **Chakra Petch** (Google Fonts, SIL OFL) — HUD/display
25. **Major Mono Display** (Google Fonts, SIL OFL) — geometric mono

**Font Picker UI**: Horizontal scrollable list in reader settings. Shows font name in its own face. Tap to apply. Remembers selection in DataStore.

---

## 13. Local Library & Offline System

### 13.1 Import from Local Storage
- Monitored folder: `/storage/emulated/0/HFY_NEKROCODEXXX/Import/`
- On app launch + on Library tab open: scan folder for new/changed files
- Supported: `.epub`, `.txt`, `.md`
- EPUB parsing: extract title, author, chapters from OPF/NCX using epublib
- TXT parsing: treat each file as a single-chapter series OR attempt auto-split on chapter headings (regex: `^Chapter \d+`, `^Part \d+`, etc.)
- Show in Library → LOCAL FILES tab with a "LOCAL" badge
- These files are never synced to Reddit — offline only

### 13.2 Offline Reading
- All downloaded chapter content stored in Room (text field, compressed if >10KB)
- All downloaded files stored at app storage path
- `NetworkMonitor` service detects connectivity changes
- Offline indicator in status bar
- In offline mode: browse only shows locally cached series, reader works fully
- Paging fallback to local Room data when network unavailable

### 13.3 Cache Management
- Settings → Storage → Show cache breakdown (series metadata, chapter content, downloaded files)
- Clear cache options: metadata only, chapter content only, all
- Auto-purge old cached content (configurable: never, 30 days, 7 days)

---

## 14. Error Handling & Network Resilience

### 14.1 Error Types & Responses

| Error | UI Response | Retry Strategy |
|-------|-------------|----------------|
| 401 Unauthorized | Prompt Reddit re-login | Refresh token first, then re-auth if failed |
| 429 Too Many Requests | "RATE LIMITED — waiting Xs" | Exponential backoff: 2s, 4s, 8s, 16s, max 64s |
| 503 Reddit Down | Switch to Jsoup scraper | Auto-switch, show "FALLBACK MODE" indicator |
| DNS failure | Show offline banner | Poll for connectivity with `NetworkMonitor` |
| Empty wiki response | "NO DATA — pull to refresh" | Manual retry only |
| Chapter parse failure | "PARSE ERROR — open in browser" | Provide link to original Reddit post |
| Storage full | Toast + Stop downloads | Prompt user to clear space |
| Scraper blocked | "SCRAPER BLOCKED — login required" | Prompt OAuth login |

### 14.2 Connection Status Indicator (Top Bar)
Three-state indicator always visible:
- `◈ API` — Green — Reddit OAuth working
- `◈ SCRAPER` — Yellow — OAuth failed, using Jsoup scraper
- `◈ OFFLINE` — Red, blinking — No connectivity, showing cached data

### 14.3 Retry Logic
```kotlin
suspend fun <T> withRetry(
    maxAttempts: Int = 3,
    initialDelayMs: Long = 1000L,
    block: suspend () -> T
): T {
    var lastException: Exception? = null
    repeat(maxAttempts) { attempt ->
        try { return block() }
        catch (e: IOException) {
            lastException = e
            delay(initialDelayMs * (2.0.pow(attempt)).toLong())
        }
        catch (e: HttpException) {
            if (e.code() == 429) {
                delay(initialDelayMs * (4.0.pow(attempt)).toLong())
                lastException = e
            } else throw e
        }
    }
    throw lastException!!
}
```

---

## 15. Caching Strategy

### 15.1 Multi-Level Cache

```
Level 1 — In-Memory (Kotlin StateFlow / MutableStateMap)
  └─ Currently active series list page (avoid re-render flicker)
  └─ Current reader chapter content (fast page-flip)

Level 2 — Room Database (persistent, indexed)
  └─ All series metadata
  └─ All known chapters per series
  └─ Chapter content text (downloaded)
  └─ Reading progress per chapter
  └─ Download job status

Level 3 — File System
  └─ Exported TXT/EPUB files
  └─ Imported local EPUB/TXT files
```

### 15.2 Cache Keys & TTL

| Data | Key Pattern | TTL |
|------|-------------|-----|
| Series index page | `wiki:series:page:{N}` | 6 hours |
| Individual series wiki | `wiki:series:{slug}` | 24 hours |
| Chapter metadata | `chapter:{postId}:meta` | 7 days |
| Chapter content | `chapter:{postId}:content` | Never expires (permanent cache) |
| Search results | `search:{query}:{sort}` | 15 minutes |

### 15.3 Cache Invalidation
- Pull-to-refresh: invalidate series index for that page
- Pull-down on chapter list: invalidate that series's chapter list
- Settings → Storage → Clear: invalidate by type
- New chapter crawl results: upsert to Room (never delete existing)

---

## 16. Settings Screen — Full Specification

```
SETTINGS ═══════════════════════════════════════

ACCOUNT
  ◈ Reddit Account: [Not logged in / u/username]
  ◈ Connect Reddit Account          [CONNECT]
  ◈ Reddit OAuth Status
  ◈ Logout

APPEARANCE
  ◈ App Theme                  [NIGHT CITY ▼]
  ◈ Reader Theme               [NIGHT MODE ▼]
  ◈ Custom Theme Builder       [OPEN EDITOR]
  ◈ Glitch Effects             [ON ▼]
  ◈ Scanline Overlay           [ON ▼]
  ◈ Animated Corners           [ON ▼]
  ◈ Reduce Motion              [OFF ▼]  (accessibility)

READER DEFAULTS
  ◈ Default Font               [Share Tech Mono ▼]
  ◈ Default Font Size          [16sp]
  ◈ Default Line Height        [1.6x]
  ◈ Default Letter Spacing     [0.02em]
  ◈ Text Alignment             [JUSTIFIED ▼]
  ◈ Chapter Transition         [SEAMLESS ▼]
  ◈ Screen Keep Awake          [ON ▼]

DOWNLOADS
  ◈ Default Export Format      [EPUB ▼]
  ◈ WiFi Only                  [ON ▼]
  ◈ Concurrent Downloads       [3]
  ◈ Storage Location           [/HFY_NEKROCODEXXX/]
  ◈ Max Storage Use            [Unlimited ▼]

BROWSING
  ◈ Auto-Discover Chapters     [ON ▼]
  ◈ Crawl Depth Limit          [2000 chapters]
  ◈ Request Delay (ms)         [500ms]
  ◈ Fallback to Scraper        [ON ▼]

LIBRARY
  ◈ Local Import Folder        [/HFY_NEKROCODEXXX/Import/]
  ◈ Auto-scan Imports          [ON ▼]
  ◈ Show Import Instructions   [→]

STORAGE
  ◈ Cache Size                 [42.3 MB]
  ◈ Downloaded Content         [1.2 GB]
  ◈ Clear Metadata Cache       [CLEAR]
  ◈ Clear Chapter Cache        [CLEAR]
  ◈ Clear All Data             [CLEAR ALL]

ABOUT
  ◈ App Version                [1.0.0]
  ◈ Data Sources               [Reddit OAuth, Jsoup]
  ◈ Licenses                   [→]
  ◈ GitHub Reference Projects  [→]
```

---

## 17. Phased Coding Plan

### PHASE 0 — Project Setup (Week 1)

**Day 1–2:**
1. Create new Android project in Android Studio: Empty Compose Activity
2. Set `compileSdk = 35`, `minSdk = 29`, `targetSdk = 35`
3. Enable `buildFeatures { compose = true }`, `buildConfig = true`
4. Add all Gradle dependencies from Section 3
5. Configure Hilt: add `@HiltAndroidApp` to `App.kt`, add `hilt-android-gradle-plugin`
6. Set up Room: create `AppDatabase.kt` with all entities (Series, Chapter, DownloadJob, ReadingProgress)
7. Create Hilt modules: `NetworkModule.kt`, `DatabaseModule.kt`, `RepositoryModule.kt`
8. Create `BuildConfig` fields: `REDDIT_CLIENT_ID` (read from `local.properties`)

**Day 3:**
9. Register Reddit app at reddit.com/prefs/apps → copy client ID → add to `local.properties`
10. Set up AppAuth or manual PKCE flow in `RedditAuthManager.kt`
11. Test OAuth flow: launch auth URL in Chrome Custom Tab → handle redirect → exchange code → store tokens in DataStore

**Day 4–5:**
12. Bundle all fonts in `assets/fonts/` (download all 25 from Google Fonts)
13. Define `CyberpunkTheme.kt` with colors, shapes, typography
14. Build core reusable components: `CyberPanel`, `CyberButton`, `GlitchText`, `ScanlineOverlay`, `AnimatedCornerBrackets`
15. Create `AppNavGraph.kt` with all screen routes
16. Create bottom navigation bar component

---

### PHASE 1 — Data Layer (Week 2)

**Day 6–8: Reddit API Integration**
1. Create `RedditApiService.kt` (Retrofit): define endpoints for wiki, comments, search
2. Implement `RedditOAuthInterceptor.kt` (auto-attaches Bearer token, refreshes on 401)
3. Implement `HfyScraper.kt` (Jsoup-based wiki + post scraping)
4. Implement dual-source `SeriesRepository.kt`
5. Test: manually call wiki endpoint, log results, verify series list parsing

**Day 9–10: Chapter Crawling**
1. Implement `ChapterCrawler.kt` with all NEXT_LINK_PATTERNS
2. Implement `ChapterCrawlWorker.kt` with WorkManager + foreground notification
3. Test on "Out of Cruel Space": start from chapter 1, verify crawler follows links past chapter 59
4. Verify chapter count keeps growing correctly, verify deduplication
5. Implement `ChapterRepository.kt` with upsert logic

---

### PHASE 2 — Browse & Series UI (Week 3)

**Day 11–13: Browse Screen**
1. Implement `BrowsePagingSource.kt` (Paging 3 data source reading from wiki + Room)
2. Implement `BrowseViewModel.kt` with search, filter, sort state
3. Build `BrowseScreen.kt` with:
   - LazyVerticalGrid (2-column)
   - Series card composable
   - Search bar with debounce
   - Filter chip row
   - Pull-to-refresh
   - End-of-list loading indicator

**Day 14–15: Series Detail Screen**
1. Implement `SeriesDetailViewModel.kt` (loads synopsis, triggers chapter crawl)
2. Build `SeriesDetailScreen.kt`:
   - Collapsing header with synopsis
   - Meta stats panel
   - Chapter list (LazyColumn, Paging 3)
   - Chapter discovery progress indicator
   - Floating action buttons
   - Swipe-to-download on chapter items

---

### PHASE 3 — Reader (Week 4)

**Day 16–18: Reader Core**
1. Implement `ReaderViewModel.kt` (loads chapter content, tracks progress, handles prev/next)
2. Build `ReaderScreen.kt`:
   - Full-screen LazyColumn
   - Paragraph-level rendering
   - Seamless chapter boundary loading (infinite vertical scroll)
   - Tap-to-toggle UI chrome
   - Progress saving on scroll position change

**Day 19–20: Reader Controls**
1. Bottom sheet: font picker, size slider, theme picker, line height
2. Top bar: chapter scrubber slider
3. Font rendering test with all 25 fonts at 3px minimum
4. Screen brightness control (system brightness adjustment)
5. Screen-keep-awake implementation

---

### PHASE 4 — Download & Export (Week 5)

**Day 21–23: Download System**
1. Implement `ChapterDownloadWorker.kt`
2. Implement `DownloadQueue` (WorkManager chained jobs)
3. Build `DownloadsScreen.kt` with queue display, progress, controls
4. Implement file management in `DownloadFileManager.kt`

**Day 24–25: Export Engine**
1. Implement TXT export (single chapter + merged series)
2. Implement EPUB export using epublib-core:
   - Build OPF, NCX, XHTML chapter files programmatically
   - Test with epub reader apps (Librera, Moon+ Reader)
3. Implement share sheet integration (export → share)
4. Test round-trip: download 5 chapters → merge → open EPUB in external app

---

### PHASE 5 — Library, Settings & Polish (Week 6)

**Day 26–27: Library Screen**
1. Build all 4 Library tabs (Favorites, Reading, Downloaded, Local Files)
2. Implement local file scanner (scan Import folder, parse EPUB/TXT)
3. Implement reading progress tracking UI

**Day 28–29: Settings Screen + Themes**
1. Build full Settings screen (Section 16)
2. Implement all 27 app themes + 27 reader themes
3. Implement custom theme builder with color pickers
4. Implement all settings persistence via DataStore

**Day 30: QA Pass 1**
1. Test all screens on physical Android 15 device or emulator
2. Test all 3 data modes: OAuth authenticated, Scraper fallback, Offline
3. Test chapter crawl on 5 different series
4. Test all export formats
5. Test font rendering at 3px minimum

---

### PHASE 6 — Animations, Glitch & Final Polish (Week 7)

**Day 31–33: Animations**
1. Implement Splash screen animation sequence
2. Implement page transition glitch effect
3. Implement staggered list item reveal
4. Implement download progress neon glow animation
5. Implement GlitchText random trigger system
6. Add Lottie loading spinner (cyberpunk scan animation)

**Day 34–35: Final QA**
1. Stress test: queue 100-chapter download, verify no memory leaks
2. Test all 5 series from r/HFY that are known edge cases
3. Verify APK size is in target range (360–600 MB)
4. Test on Android 10, 12, 15 (multiple API levels)
5. Verify offline mode fully functional

---

## 18. APK Build & Signing Instructions

### 18.1 Generate Signing Key (do this once)
```bash
# In a terminal (or use Android Studio's Generate Signed Bundle wizard)
keytool -genkey -v \
  -keystore nekrocodexxx.keystore \
  -alias nekro_key \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

# You will be prompted for: keystore password, key password, your name, org, etc.
# SAVE THE KEYSTORE FILE AND PASSWORDS — you need them for every future build
```

### 18.2 Configure Signing in build.gradle.kts
```kotlin
// In app/build.gradle.kts
android {
    signingConfigs {
        create("release") {
            storeFile = file("../nekrocodexxx.keystore")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: properties["keystorePassword"] as String
            keyAlias = "nekro_key"
            keyPassword = System.getenv("KEY_PASSWORD") ?: properties["keyPassword"] as String
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }
}
```

Add to `local.properties` (never commit this file to Git):
```
keystorePassword=yourKeystorePassword
keyPassword=yourKeyPassword
REDDIT_CLIENT_ID=your_reddit_client_id_here
```

### 18.3 ProGuard Rules (proguard-rules.pro)
```proguard
# Keep Gson serialization
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory { *; }
-keep class * implements com.google.gson.JsonSerializer { *; }
-keep class * implements com.google.gson.JsonDeserializer { *; }

# Keep Retrofit
-keepattributes RuntimeVisibleAnnotations, RuntimeInvisibleAnnotations
-keep,allowshrunken,allowoptimization interface com.squareup.retrofit2.** { *; }
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * { @retrofit2.http.* <methods>; }

# Keep epublib
-keep class nl.siegmann.epublib.** { *; }
-keep class org.xmlpull.** { *; }

# Keep data models (Room entities)
-keep class com.nekro.hfycyberdeck.data.model.** { *; }
-keep class com.nekro.hfycyberdeck.data.local.database.** { *; }

# AppAuth
-keep class net.openid.appauth.** { *; }

# Jsoup
-keep class org.jsoup.** { *; }

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
```

### 18.4 Build Release APK
```bash
# Option A: Android Studio
# Build → Generate Signed Bundle / APK → APK → Select release → Build

# Option B: Command Line
cd /path/to/HFY_NEKROCODEXXX
./gradlew assembleRelease

# APK will be at:
# app/build/outputs/apk/release/app-release.apk
```

### 18.5 Verify & Install
```bash
# Verify APK is signed
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk

# Check APK size
ls -lh app/build/outputs/apk/release/app-release.apk

# Install on connected device via ADB
adb install -r app/build/outputs/apk/release/app-release.apk

# OR: just copy APK to phone and open with file manager (enable Unknown Sources first)
# Settings → Security → Install Unknown Apps → File Manager → Allow
```

### 18.6 APK Size Management
Assets that add the most size:
- 25 font files: ~30–50 MB total
- Lottie animations: ~5 MB
- App code: ~10–20 MB
- ProGuard will reduce code size

If size is too small, add:
- More font variants (bold, italic)
- Pre-bundled offline sample chapters
- Higher-quality icon assets (vector drawables don't add much)

---

## 19. Testing Checklist

### 19.1 API / Data Layer
- [ ] Reddit OAuth login flow completes successfully
- [ ] Token refresh works automatically on 401
- [ ] Logout clears all tokens and prompts re-login
- [ ] Wiki series index loads (both OAuth and Scraper modes)
- [ ] Individual series page loads with synopsis and chapter links
- [ ] Chapter crawler discovers chapters beyond wiki listing
- [ ] "Out of Cruel Space" (target: 1000+ chapters discovered)
- [ ] "Nature of Predators" (large series, verify crawl)
- [ ] "The Deathworlders" (one of the longest series on HFY)
- [ ] Scraper fallback activates when OAuth fails
- [ ] Rate limiting triggers backoff correctly
- [ ] Offline mode shows cached data without crashing

### 19.2 UI / UX
- [ ] Splash animation runs correctly
- [ ] All 5 bottom navigation tabs navigate correctly
- [ ] Browse screen: infinite scroll loads more series at bottom
- [ ] Search returns results within 500ms (debounced)
- [ ] Series detail shows synopsis
- [ ] Chapter list shows crawled chapters (not just wiki-listed ones)
- [ ] Pull-to-refresh on Browse refreshes series list
- [ ] Pull-to-refresh on chapter list refreshes chapter list
- [ ] Reader renders text at minimum 3sp font size
- [ ] All 25 fonts load and display in reader
- [ ] All 27 app themes apply correctly
- [ ] All 27 reader themes apply correctly
- [ ] Custom theme builder saves and applies
- [ ] GlitchText effect triggers randomly
- [ ] Scanline overlay visible (subtle)
- [ ] Animated corner brackets appear on focused items

### 19.3 Downloads & Export
- [ ] Single chapter download queues and completes
- [ ] Bulk "download all" queues all chapters
- [ ] Download queue shows progress correctly
- [ ] Pause / Resume / Cancel download works
- [ ] Exported TXT file opens and reads correctly
- [ ] Exported EPUB opens in external reader (Librera, Moon+ Reader, etc.)
- [ ] Merged series EPUB contains all chapters with correct TOC
- [ ] Local Import folder: drop a .epub, it appears in Library
- [ ] Local import .txt file is parsed as series

### 19.4 Performance
- [ ] App launches in under 3 seconds on mid-range device
- [ ] Browse screen scrolls at 60fps
- [ ] Reader scrolls without jank (even on long chapters)
- [ ] No OOM crash when loading 1000+ chapter series
- [ ] Background crawl does not block UI thread
- [ ] App returns correctly from background after 1 hour

---

## 20. Reference Projects & Resources

### 20.1 GitHub Reference Projects
- **easy-reddit-downloader**: https://github.com/josephrcox/easy-reddit-downloader
  - Study: how it authenticates, which endpoints it calls
- **hfy2epub**: https://github.com/hacst/hfy2epub
  - Study: EPUB generation approach, chapter assembly
- **hfydl**: https://github.com/lizard-demon/hfydl
  - Study: chapter link following logic, "next" button detection
- **hfy-epub**: https://github.com/cpiber/hfy-epub
  - Study: Jsoup scraping patterns
- **hfyEbook**: https://github.com/stonewalljones/hfyEbook
  - Study: wiki parsing structure

### 20.2 Reddit API Documentation
- Reddit OAuth: https://www.reddit.com/dev/api/oauth
- API endpoint reference: https://www.reddit.com/dev/api
- Rate limits: https://support.reddithelp.com/hc/en-us/articles/16160319875092

### 20.3 Key URLs
- HFY Series Wiki: https://www.reddit.com/r/HFY/wiki/series/
- r/HFY subreddit: https://www.reddit.com/r/HFY/
- Reddit app registration: https://www.reddit.com/prefs/apps

### 20.4 Android Development References
- Compose Paging: https://developer.android.com/jetpack/compose/libraries#paging
- Room + Coroutines: https://developer.android.com/training/data-storage/room
- WorkManager: https://developer.android.com/topic/libraries/architecture/workmanager
- epublib-core: https://github.com/psiegman/epublib
- AppAuth for Android: https://github.com/openid/AppAuth-Android

### 20.5 Design References (from provided PDFs)
- Cyberpunk 2077 HUD art by Konrad Kłos — angular panels, neon grid overlays
- KLWP Cyberpunk Widget by OuttieFiveThou — data density, battery/network HUD style
- CP2077 icon sheets — use as inspiration for custom icon design in the app

---

*END OF HFY NEKROCODEXXX MASTER BUILD SPECIFICATION*
*Generated for native Android APK development — Kotlin + Jetpack Compose + Reddit OAuth*
*All content English only — No localization required*
*Target: Android 15 (API 35) — Minimum: Android 10 (API 29)*


---

## Part 2: Cyberdeck Build Specification

# HFY CYBERDECK — NATIVE ANDROID APK BUILD SPECIFICATION
### r/HFY Story Browser, Downloader & Reader · Cyberpunk Edition

> **DOCUMENT TYPE:** Complete Build Specification, Refined Prompt & Step-by-Step Implementation Plan  
> **TARGET PLATFORM:** Native Android (Kotlin + Jetpack Compose)  
> **MINIMUM SDK:** Android 15 (API 35)  
> **APP SIZE TARGET:** 360 MB minimum, no upper limit enforced  
> **LANGUAGE:** English only, no localization required  

---

## TABLE OF CONTENTS

1. [Project Vision](#1-project-vision)
2. [Technical Stack](#2-technical-stack)
3. [Architecture Overview](#3-architecture-overview)
4. [Data Models](#4-data-models)
5. [Networking & API Layer](#5-networking--api-layer)
6. [Reddit OAuth 2.0 Implementation](#6-reddit-oauth-20-implementation)
7. [Series Browser & Infinite Scroll](#7-series-browser--infinite-scroll)
8. [Search System](#8-search-system)
9. [Chapter Viewer & Reader](#9-chapter-viewer--reader)
10. [Download Engine & Queue](#10-download-engine--queue)
11. [EPUB / TXT Export Engine](#11-epub--txt-export-engine)
12. [Library, Favorites & Progress Tracking](#12-library-favorites--progress-tracking)
13. [Caching Strategy](#13-caching-strategy)
14. [UI / UX Design System — Cyberpunk Specification](#14-ui--ux-design-system--cyberpunk-specification)
15. [Themes & Customization](#15-themes--customization)
16. [Typography & Fonts](#16-typography--fonts)
17. [Animations & Motion Design](#17-animations--motion-design)
18. [Settings Screen](#18-settings-screen)
19. [Error Handling & Resilience](#19-error-handling--resilience)
20. [Build Configuration & APK Generation](#20-build-configuration--apk-generation)
21. [Dependency List (build.gradle)](#21-dependency-list-buildgradle)
22. [Project File Structure](#22-project-file-structure)
23. [Step-by-Step Coding Plan (Phased)](#23-step-by-step-coding-plan-phased)
24. [Reference Repositories & Integration Notes](#24-reference-repositories--integration-notes)
25. [Testing Checklist](#25-testing-checklist)

---

## 1. PROJECT VISION

**App Name:** `HFY CYBERDECK`  
**Tagline:** `ACCESS THE GRID. DOWNLOAD THE LEGENDS.`

Build a massive, feature-rich, native Android application that acts as a fully-functional front-end for the r/HFY subreddit series wiki at `https://www.reddit.com/r/HFY/wiki/series/`. The app must:

- **Browse** all HFY series with infinite scrolling directly from the live wiki page (no static snapshots — wiki updates daily)
- **Read** stories natively inside the app with a fully customizable reader
- **Download** individual chapters or entire series as EPUB or TXT files to local storage
- **Search** series by title and author, pulling live data from the wiki
- **Track** reading progress per series and per chapter
- **Manage** a personal favorites/library
- **Queue** multiple concurrent downloads with pause/resume/cancel
- Expose **two authentication modes**: Reddit OAuth (primary) and HTML scraper fallback (if OAuth unavailable)
- Look and feel **exactly like a Cyberpunk 2077 / Night City HUD** — angular neon UI, glitch effects, neon glow, scanline overlays, dynamic animations

The app draws deep visual inspiration from:
- Cyberpunk 2077 HUD / inventory / skill tree UI
- KWGT Cyberpunk widget packs (neon pink `#FF003C`, cyan `#00FFF0`, yellow `#FFE600`)
- Stellaris planet management UI (data-dense, scientific-looking panels)
- Angular paneling with clipped corners, neon borders, barcode decorators
- Glitch/scanline overlays, binary rain decorators, animated corner brackets

---

## 2. TECHNICAL STACK

| Layer | Technology |
|---|---|
| Language | Kotlin 2.x |
| UI Framework | Jetpack Compose (no XML layouts) |
| UI Design | Material 3 with fully custom Cyberpunk theme override |
| Navigation | Compose Navigation 2.x with animated transitions |
| HTTP Client | OkHttp 4.x + Retrofit 2.x |
| HTML Parsing | Jsoup 1.17.x |
| JSON Parsing | Kotlin Serialization + Moshi |
| Database | Room 2.6.x |
| Preferences | DataStore (Proto + Preferences) |
| Image Loading | Coil 2.x |
| Background Work | WorkManager 2.9.x |
| Pagination | Paging 3 |
| DI | Hilt 2.51.x |
| Coroutines | Kotlin Coroutines + Flow |
| EPUB Generation | Epublib-core (custom bundled JAR) |
| Fonts | Bundled TTF/OTF files (see Section 16) |
| OAuth | Reddit OAuth 2.0 (Authorization Code Flow via Chrome Custom Tabs) |
| File I/O | Android Scoped Storage (MediaStore + SAF) |
| Markdown | Markwon 4.x (for rendering Reddit post bodies) |
| Animations | Jetpack Compose Animate* APIs + Lottie Compose |
| Canvas Effects | Compose Canvas (glitch shader, scanlines, neon glow) |
| Min SDK | 35 (Android 15) |
| Target SDK | 35 |
| Compile SDK | 35 |

---

## 3. ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────────────┐
│                         PRESENTATION LAYER                       │
│  Compose UI Screens ◄──► ViewModels (Hilt-injected)             │
│  Navigation Graph    ◄──► SharedFlows / StateFlows               │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                          DOMAIN LAYER                            │
│  Use Cases (Pure Kotlin) · Repository Interfaces                 │
│  Series · Chapter · Download · Library · Search Use Cases        │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                           DATA LAYER                             │
│  ┌──────────────────┐   ┌──────────────────┐  ┌──────────────┐  │
│  │  Reddit API Repo  │   │  Scraper Repo     │  │  Local Repo  │  │
│  │  (OAuth / JSON)   │   │  (Jsoup / HTML)   │  │  (Room DB)   │  │
│  └──────────────────┘   └──────────────────┘  └──────────────┘  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │       EPUB / TXT Export Engine (WorkManager Jobs)         │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

**Pattern:** Clean Architecture (MVVM + Repository)  
**DI:** Hilt modules for network, database, use cases, repositories  
**State:** `UiState` sealed classes per screen, exposed via `StateFlow`  
**Effects:** `SharedFlow` for one-shot events (navigation, toasts, errors)

---

## 4. DATA MODELS

### 4.1 Room Entities

```kotlin
@Entity(tableName = "series")
data class SeriesEntity(
    @PrimaryKey val id: String,           // Derived from wiki slug
    val title: String,
    val author: String,
    val wikiUrl: String,
    val postUrl: String?,
    val chapterCount: Int,
    val isFavorite: Boolean = false,
    val lastReadChapterId: String? = null,
    val lastReadPosition: Int = 0,        // Scroll offset in reader
    val lastReadTimestamp: Long = 0L,
    val totalCharCount: Long = 0L,
    val thumbnailUrl: String? = null,
    val description: String? = null,
    val tags: String = "",                // Comma-separated
    val cachedAt: Long = 0L
)

@Entity(tableName = "chapters",
    foreignKeys = [ForeignKey(entity = SeriesEntity::class,
        parentColumns = ["id"], childColumns = ["seriesId"],
        onDelete = ForeignKey.CASCADE)])
data class ChapterEntity(
    @PrimaryKey val id: String,            // Reddit post ID
    val seriesId: String,
    val title: String,
    val redditPostUrl: String,
    val orderIndex: Int,
    val author: String,
    val createdUtc: Long,
    val score: Int = 0,
    val htmlContent: String? = null,       // Cached rendered content
    val rawMarkdown: String? = null,       // Raw Reddit markdown
    val wordCount: Int = 0,
    val isDownloaded: Boolean = false,
    val downloadPath: String? = null,
    val isRead: Boolean = false,
    val readProgress: Float = 0f,          // 0.0 to 1.0
    val cachedAt: Long = 0L
)

@Entity(tableName = "download_queue")
data class DownloadQueueEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val seriesId: String,
    val chapterId: String?,               // Null = entire series
    val format: String,                   // "epub" | "txt"
    val status: String,                   // "pending" | "running" | "paused" | "done" | "error"
    val progress: Float = 0f,
    val totalChapters: Int = 0,
    val completedChapters: Int = 0,
    val outputPath: String? = null,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val merge: Boolean = false            // Merge all chapters into one file
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val chapterId: String,
    val seriesId: String,
    val scrollPosition: Int,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
```

### 4.2 Domain Models (clean layer)

```kotlin
data class Series(
    val id: String,
    val title: String,
    val author: String,
    val chapters: List<ChapterRef>,
    val isFavorite: Boolean,
    val readProgress: ReadProgress
)

data class ChapterRef(val id: String, val title: String, val orderIndex: Int)

data class ReadProgress(
    val lastChapterIndex: Int,
    val totalChapters: Int,
    val percentComplete: Float
)

data class Chapter(
    val id: String,
    val seriesId: String,
    val title: String,
    val content: RenderedContent,
    val wordCount: Int,
    val redditUrl: String
)

sealed class RenderedContent {
    data class Markdown(val raw: String) : RenderedContent()
    data class Html(val html: String) : RenderedContent()
}
```

---

## 5. NETWORKING & API LAYER

### 5.1 Dual-Source Strategy

The app uses **two parallel data sources** with automatic fallback:

```
PRIMARY: Reddit JSON API (OAuth or public .json endpoint)
         └── GET https://oauth.reddit.com/r/HFY/wiki/series.json
         └── GET https://oauth.reddit.com/comments/{postId}.json

FALLBACK: Jsoup HTML Scraper
         └── GET https://www.reddit.com/r/HFY/wiki/series/
         └── GET https://www.reddit.com/r/{postId}
         └── Parse HTML with Jsoup selector chains
```

**Fallback triggers automatically when:**
- OAuth token expired and refresh fails
- Rate limit hit (HTTP 429) — back off with exponential retry
- Network timeout after 3 attempts
- Reddit API returns unexpected schema

### 5.2 OkHttp Client Configuration

```kotlin
val okHttpClient = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(30, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .addInterceptor(AuthInterceptor(tokenStore))   // Injects Bearer token
    .addInterceptor(RateLimitInterceptor())         // Respects 429 + Retry-After
    .addInterceptor(UserAgentInterceptor())         // "HFY-Cyberdeck/1.0 by u/yourapp"
    .addInterceptor(HttpLoggingInterceptor())       // Debug only
    .cache(Cache(cacheDir, 50L * 1024 * 1024))      // 50 MB HTTP cache
    .build()
```

### 5.3 Reddit API Endpoints Used

```
# Wiki series list (paginated HTML, parsed)
GET https://www.reddit.com/r/HFY/wiki/series/

# Single post content (JSON)  
GET https://oauth.reddit.com/comments/{post_id}.json?limit=500

# User info (for authenticated features)
GET https://oauth.reddit.com/api/v1/me

# Subreddit posts (live browsing)
GET https://oauth.reddit.com/r/HFY/new.json?limit=100&after={after_token}
```

### 5.4 Wiki Parser (Jsoup)

The HFY wiki page is an HTML document listing series titles linked to their chapter list posts. Parse strategy:

```kotlin
fun parseWikiSeriesList(html: String): List<SeriesRef> {
    val doc = Jsoup.parse(html)
    val rows = doc.select("div.wiki-page-content li")
    return rows.mapNotNull { li ->
        val link = li.selectFirst("a") ?: return@mapNotNull null
        SeriesRef(
            title = link.text().trim(),
            wikiUrl = "https://reddit.com" + link.attr("href"),
            author = li.text()
                .substringAfter("by").substringBefore(",").trim()
                .ifBlank { "Unknown" }
        )
    }
}
```

**Infinite scroll on wiki:** The wiki page uses standard HTML pagination. Implement a `PagingSource` that fetches `/r/HFY/wiki/series/?page=N` and parses each page, loading the next page on scroll-to-bottom.

---

## 6. REDDIT OAUTH 2.0 IMPLEMENTATION

### 6.1 App Registration

Register at `https://www.reddit.com/prefs/apps`:
- **Type:** Installed App
- **Redirect URI:** `hfycyberdeck://auth/callback`
- **Scopes:** `read identity history`

Store in `local.properties` (gitignored):
```
REDDIT_CLIENT_ID=your_client_id_here
REDDIT_REDIRECT_URI=hfycyberdeck://auth/callback
```

### 6.2 OAuth Flow

```kotlin
// Step 1: Build authorization URL
val authUrl = Uri.parse("https://www.reddit.com/api/v1/authorize.compact")
    .buildUpon()
    .appendQueryParameter("client_id", CLIENT_ID)
    .appendQueryParameter("response_type", "code")
    .appendQueryParameter("state", generateSecureState())
    .appendQueryParameter("redirect_uri", REDIRECT_URI)
    .appendQueryParameter("duration", "permanent")
    .appendQueryParameter("scope", "read identity history")
    .build()

// Step 2: Launch Chrome Custom Tab
CustomTabsIntent.Builder().build().launchUrl(context, authUrl)

// Step 3: Handle callback in Activity (AndroidManifest intent-filter)
// Step 4: Exchange code for token pair (access + refresh)
// Step 5: Store tokens securely with EncryptedSharedPreferences
// Step 6: Auto-refresh access token before expiry using WorkManager periodic task
```

### 6.3 Token Storage

```kotlin
// Use Jetpack Security EncryptedSharedPreferences
val encryptedPrefs = EncryptedSharedPreferences.create(
    context, "hfy_secure_prefs",
    MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)
```

---

## 7. SERIES BROWSER & INFINITE SCROLL

### 7.1 Paging 3 Implementation

```kotlin
class WikiSeriesPagingSource(
    private val wikiRepository: WikiRepository
) : PagingSource<Int, Series>() {

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Series> {
        val page = params.key ?: 1
        return try {
            val result = wikiRepository.getSeriesPage(page)
            LoadResult.Page(
                data = result.series,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (result.hasMore) page + 1 else null
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, Series>): Int? = null
}
```

**LazyColumn integration in Compose:**

```kotlin
val seriesList = viewModel.seriesPager.collectAsLazyPagingItems()

LazyColumn {
    items(seriesList) { series ->
        if (series != null) SeriesCard(series)
    }
    seriesList.apply {
        when {
            loadState.append is LoadState.Loading -> item { CyberLoadingIndicator() }
            loadState.append is LoadState.Error   -> item { RetryButton { retry() } }
        }
    }
}
```

### 7.2 Series Card UI

Each series card (Cyberpunk style) displays:
- Series title in primary display font (BLOX, Rajdhani, or Orbitron)
- Author name in monospace secondary
- Chapter count badge (neon pill)
- Download status icon
- Favorite toggle (star icon with neon glow on active)
- Reading progress bar (horizontal, neon cyan fill on dark track)
- Corner bracket decorators (SVG Canvas drawn)
- Subtle glitch animation on tap/press state

---

## 8. SEARCH SYSTEM

### 8.1 Live Search Architecture

Search is **not static** — it pulls from the live wiki and filters in real-time:

```kotlin
class SearchViewModel @Inject constructor(
    private val searchRepository: SearchRepository
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val results: StateFlow<SearchUiState> = _query
        .debounce(300L)                           // Wait 300ms after typing stops
        .filter { it.length >= 2 }                // Minimum 2 characters
        .flatMapLatest { query ->
            searchRepository.searchSeries(query)
                .map { SearchUiState.Success(it) }
                .catch { emit(SearchUiState.Error(it.message ?: "Search failed")) }
        }
        .stateIn(viewModelScope, SharingStarted.Lazily, SearchUiState.Idle)

    fun onQueryChange(q: String) { _query.value = q }
}
```

### 8.2 Search Source

Search fetches the full wiki series list (cached in Room with a max-age of 1 hour), then performs in-memory fuzzy matching:

```kotlin
suspend fun searchSeries(query: String): Flow<List<Series>> = flow {
    val allSeries = localDb.seriesDao().getAll()
    val filtered = allSeries.filter { series ->
        series.title.contains(query, ignoreCase = true) ||
        series.author.contains(query, ignoreCase = true)
    }
    emit(filtered.map { it.toDomainModel() })
}
```

If local cache is empty or stale, trigger a background wiki refresh before returning.

---

## 9. CHAPTER VIEWER & READER

### 9.1 Reader Features

- **Font selection:** 20+ bundled fonts (see Section 16)
- **Font size:** Slider from 12sp to 32sp, live preview
- **Line spacing:** 1.0× to 2.5× with slider
- **Margin control:** 8dp to 64dp horizontal margins
- **Background color:** Pick from theme palette or custom hex input
- **Text color:** Independent of background
- **Reading mode:** Scroll (default) or paginated swipe
- **Scroll direction:** Vertical (default) or horizontal
- **Screen brightness:** In-reader brightness slider (overrides system)
- **Auto-scroll:** Toggle with configurable speed (words/min target)
- **Chapter navigation:** Previous/Next swipe gesture + bottom navigation bar
- **Reading progress:** Saved automatically every 5 seconds of idle scroll
- **Bookmarks:** Long-press any paragraph to bookmark with optional note
- **Word count & estimated reading time** displayed in reader header
- **Night mode** shortcut in reader toolbar

### 9.2 Content Rendering Pipeline

```
Reddit Post (Markdown) 
    ↓ Markwon 4.x parse
    ↓ Spannable conversion
    ↓ Compose AnnotatedString mapping
    ↓ Rendered Text (CustomTextLayout in Compose)
    ↓ Caches HTML string in Room for offline use
```

**Markwon extensions to enable:**
- `CorePlugin`
- `LinkifyPlugin`
- `StrikethroughPlugin`
- `TablePlugin`
- `HtmlPlugin`

### 9.3 Reader Screen Layout

```
┌─────────────────────────────────────┐
│ [◄ BACK]  CHAPTER TITLE    [⚙ OPTS] │  ← TopAppBar (auto-hide on scroll)
│ Progress: ████████░░░░ 64%   3/12   │
├─────────────────────────────────────┤
│                                     │
│   Story content renders here        │
│   in fully customizable text        │
│   with Markwon → AnnotatedString    │
│                                     │
│   [Paragraph 1]                     │
│                                     │
│   [Paragraph 2]                     │
│       ...                           │
│                                     │
├─────────────────────────────────────┤
│ [◄ PREV]  [BOOKMARK]  [NEXT ►]      │  ← BottomBar (auto-hide)
└─────────────────────────────────────┘
```

---

## 10. DOWNLOAD ENGINE & QUEUE

### 10.1 WorkManager Integration

Each download job is a `CoroutineWorker`:

```kotlin
@HiltWorker
class ChapterDownloadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val downloadRepository: DownloadRepository,
    private val epubExporter: EpubExporter
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val seriesId = inputData.getString("series_id") ?: return Result.failure()
        val format   = inputData.getString("format") ?: "epub"
        val merge    = inputData.getBoolean("merge", true)

        return try {
            setForeground(createForegroundInfo("Downloading series..."))
            downloadRepository.downloadSeries(
                seriesId = seriesId,
                format = format,
                merge = merge,
                onProgress = { done, total ->
                    setProgress(workDataOf("done" to done, "total" to total))
                }
            )
            Result.success()
        } catch (e: CancellationException) {
            Result.failure()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}
```

### 10.2 Download Queue Screen

Displays all active, queued, completed, and failed downloads:

```
┌──────────────────────────────────────────────────────┐
│ DOWNLOAD QUEUE                          [CLEAR ALL]  │
├──────────────────────────────────────────────────────┤
│ ► The Deathworlders — EPUB             [▐▐] [✕]     │
│   ████████████████░░░░░░░  12/47 chapters           │
├──────────────────────────────────────────────────────┤
│ ● A Programmer's Guide — TXT           [►] [✕]      │
│   QUEUED                                             │
├──────────────────────────────────────────────────────┤
│ ✓ Homo Homini Lupus — EPUB             [OPEN] [✕]   │
│   COMPLETE · 2.3 MB                                 │
└──────────────────────────────────────────────────────┘
```

### 10.3 Download Options Dialog

When user taps "Download" on a series:

```
┌─────────────────────────────────────┐
│  DOWNLOAD: The Deathworlders        │
│                                     │
│  FORMAT:  [EPUB]  [TXT]             │
│                                     │
│  SCOPE:                             │
│  ○ Download entire series (47 ch)   │
│  ● Select chapters to download      │
│    [ ] Ch 1: Prologue               │
│    [x] Ch 2: First Contact          │
│    [x] Ch 3: The Fleet              │
│    [ ] ...                          │
│                                     │
│  MERGE ALL INTO SINGLE FILE:  [ON]  │
│                                     │
│  [  CANCEL  ]    [  DOWNLOAD  ]     │
└─────────────────────────────────────┘
```

---

## 11. EPUB / TXT EXPORT ENGINE

### 11.1 EPUB Generation (using Epublib-core)

Bundle `epublib-core-3.1.jar` directly in `app/libs/`. This is the core of [github.com/psiegman/epublib](https://github.com/psiegman/epublib).

```kotlin
class EpubExporter @Inject constructor(
    private val context: Context
) {
    fun exportSeries(series: Series, chapters: List<Chapter>, outputFile: File) {
        val book = Book()

        // Metadata
        book.metadata.addTitle(series.title)
        book.metadata.addAuthor(Author(series.author))
        book.metadata.addDescription("Downloaded from r/HFY via HFY Cyberdeck")
        book.metadata.addDate(Date(Date.Event.PUBLICATION))
        book.metadata.addIdentifier(Identifier(Identifier.Scheme.URL, series.id))

        // Cover image (if available, use a generated cyberpunk-style bitmap)
        val coverBitmap = generateCyberpunkCover(series.title)
        val coverBytes  = bitmapToBytes(coverBitmap)
        book.coverImage = Resource(coverBytes, "cover.jpg")

        // CSS styling (cyberpunk-inspired typography for e-readers)
        val css = buildCyberpunkEpubCss()
        book.resources.add(Resource(css.toByteArray(), MediaTypes.CSS, "style.css"))

        // Add each chapter as an HTML resource
        chapters.forEach { chapter ->
            val html = buildChapterHtml(chapter, series.title)
            val res  = Resource(html.toByteArray(), "chapter_${chapter.orderIndex}.html")
            book.addSection(chapter.title, res)
        }

        // Write to disk
        EpubWriter().write(book, FileOutputStream(outputFile))
    }

    private fun buildChapterHtml(chapter: Chapter, seriesTitle: String): String = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8"/>
            <link rel="stylesheet" type="text/css" href="style.css"/>
            <title>${chapter.title}</title>
        </head>
        <body>
            <h1 class="chapter-title">${chapter.title}</h1>
            <p class="series-name">$seriesTitle</p>
            ${markdownToHtml(chapter.rawMarkdown ?: "")}
        </body>
        </html>
    """.trimIndent()
}
```

### 11.2 TXT Export

```kotlin
fun exportTxt(chapters: List<Chapter>, outputFile: File, merge: Boolean) {
    if (merge) {
        val sb = StringBuilder()
        chapters.sortedBy { it.orderIndex }.forEach { chapter ->
            sb.appendLine("=" .repeat(80))
            sb.appendLine("CHAPTER ${chapter.orderIndex}: ${chapter.title}")
            sb.appendLine("=" .repeat(80))
            sb.appendLine()
            sb.appendLine(stripMarkdown(chapter.rawMarkdown ?: ""))
            sb.appendLine()
        }
        outputFile.writeText(sb.toString(), Charsets.UTF_8)
    } else {
        // Write individual files into a named subfolder
        val dir = File(outputFile.parentFile, outputFile.nameWithoutExtension)
        dir.mkdirs()
        chapters.forEach { ch ->
            File(dir, "${ch.orderIndex.toString().padStart(3,'0')}_${sanitize(ch.title)}.txt")
                .writeText(stripMarkdown(ch.rawMarkdown ?: ""), Charsets.UTF_8)
        }
    }
}
```

### 11.3 File Output Location

Use Android Scoped Storage via `MediaStore` for downloads (Android 10+):

```kotlin
val resolver = context.contentResolver
val contentValues = ContentValues().apply {
    put(MediaStore.Downloads.DISPLAY_NAME, "$filename.$extension")
    put(MediaStore.Downloads.MIME_TYPE, mimeType)
    put(MediaStore.Downloads.RELATIVE_PATH, "Download/HFY-Cyberdeck/")
}
val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)!!
resolver.openOutputStream(uri)?.use { outputStream ->
    // write EPUB/TXT bytes here
}
```

---

## 12. LIBRARY, FAVORITES & PROGRESS TRACKING

### 12.1 Library Screen

Displays all series the user has interacted with (read, downloaded, or favorited):

- Filter tabs: `ALL`, `IN PROGRESS`, `COMPLETED`, `DOWNLOADED`, `FAVORITES`
- Sort options: `Last Read`, `Title A→Z`, `Author A→Z`, `Progress %`, `Date Added`
- Grid or list view toggle
- Series card shows: cover thumbnail (auto-generated or subreddit thumbnail), progress bar, chapter count badge, download indicator

### 12.2 Reading Progress

Progress is stored per-chapter (float 0.0–1.0) and per-series (derived):

```kotlin
// Auto-save progress in ReaderViewModel
LaunchedEffect(scrollState) {
    snapshotFlow { scrollState.firstVisibleItemScrollOffset }
        .debounce(5000L)
        .collect { offset ->
            viewModel.saveProgress(chapterId, scrollState.computeProgress())
        }
}
```

### 12.3 Continue Reading

Home screen shows a "CONTINUE READING" section — the last 3 in-progress series with one-tap navigation to where the user left off.

---

## 13. CACHING STRATEGY

| Data | Cache Location | TTL |
|---|---|---|
| Wiki series list | Room DB | 1 hour (refresh on pull-to-refresh) |
| Series chapter list | Room DB | 6 hours |
| Chapter content (raw markdown) | Room DB | 30 days |
| Chapter content (rendered HTML) | Room DB | 30 days |
| HTTP responses (OkHttp cache) | Disk (50 MB) | Per Cache-Control |
| Series thumbnails | Coil disk cache | 7 days |
| OAuth tokens | EncryptedSharedPreferences | Until refresh fails |
| User preferences | DataStore | Persistent |

**Cache invalidation:** Pull-to-refresh on any list screen forces a network fetch and updates Room. User can also "Clear Cache" from Settings.

---

## 14. UI / UX DESIGN SYSTEM — CYBERPUNK SPECIFICATION

### 14.1 Core Color Palette

```kotlin
object CyberColors {
    // Backgrounds
    val VoidBlack      = Color(0xFF000000)  // Pure black base
    val NightBlue      = Color(0xFF050A14)  // Deep navy for panels
    val DarkPanel      = Color(0xFF0D1117)  // Card/panel backgrounds
    val SurfaceGrey    = Color(0xFF1A1F2C)  // Elevated surfaces

    // Primary neons (Cyberpunk 2077 palette)
    val NeonRed        = Color(0xFFFF003C)  // Primary accent — alerts, active states
    val NeonCyan       = Color(0xFF00FFF0)  // Secondary accent — data, progress
    val NeonYellow     = Color(0xFFFFE600)  // Tertiary — highlights, badges
    val NeonOrange     = Color(0xFFFF7700)  // Download queue, warnings
    val NeonPurple     = Color(0xFF9D00FF)  // Rare/special items, premium feel

    // Text
    val TextPrimary    = Color(0xFFFFFFFF)  // White for headings
    val TextSecondary  = Color(0xFFB0B8C8)  // Light grey for body
    val TextDim        = Color(0xFF4A5568)  // Muted metadata
    val TextCyan       = NeonCyan           // Links, interactive text
    val TextRed        = NeonRed            // Errors, danger

    // Borders
    val BorderNeon     = NeonCyan.copy(alpha = 0.6f)
    val BorderRed      = NeonRed.copy(alpha = 0.5f)
    val BorderDim      = Color(0xFF2D3748)

    // Glow (used as shadow/outer glow approximations)
    val GlowCyan       = NeonCyan.copy(alpha = 0.3f)
    val GlowRed        = NeonRed.copy(alpha = 0.3f)
    val GlowYellow     = NeonYellow.copy(alpha = 0.3f)
}
```

### 14.2 Cyberpunk Component Library

#### CyberPanel (base container)
- Background: `DarkPanel`
- Border: 1dp solid `BorderNeon` on all sides
- Corner treatment: Angular clip (NOT rounded) — clip corner at 8dp diagonal
- Optional: thin neon inner glow using `Modifier.shadow()` trick or Canvas drawing
- Optional barcode strip in top-right corner (decorative)

```kotlin
fun Modifier.cyberPanel(
    borderColor: Color = CyberColors.BorderNeon,
    clipCornerSize: Dp = 8.dp
): Modifier = this
    .clip(CutCornerShape(clipCornerSize))
    .border(1.dp, borderColor, CutCornerShape(clipCornerSize))
    .background(CyberColors.DarkPanel)
```

#### CyberButton
- Background: transparent or semi-transparent `NeonRed.copy(alpha=0.1f)`
- Border: 1dp `NeonRed`
- Text: uppercase, letter-spacing 0.15em, `NeonRed` color
- Angular cut corners (8dp)
- Press state: fills with `NeonRed.copy(alpha=0.3f)`, subtle scale-down 0.97
- Optional: `>>>` chevron prefix in button text

#### CyberProgressBar
- Track: `BorderDim` color, 2dp height, full width
- Fill: gradient from `NeonCyan` to `NeonPurple`
- Animated fill with `animateFloatAsState`
- Tick marks at 25% intervals
- Text percentage label at end

#### CyberSearchBar
- Full-width, `SurfaceGrey` background
- Left icon: neon crosshair/target icon (Cyberpunk style)
- Border bottom only: 2dp `NeonCyan`
- Cursor: blinking neon cyan block cursor
- Placeholder: `"// SEARCH_SERIES..."` in `TextDim`

#### CyberTag / Badge
- Background: accent color at 15% opacity
- Border: 1dp accent color
- Text: small caps, monospace font
- Sharp (0dp) or slightly cut corner

#### CyberDivider
- Height: 1dp
- Color: `BorderNeon`
- Optional: animated scanning line that travels left to right on screen entry

### 14.3 Navigation

**Bottom Navigation Bar** (5 tabs):

| Icon | Label | Screen |
|---|---|---|
| Grid icon | BROWSE | Series browser (live wiki) |
| Magnifier crosshair | SEARCH | Live search |
| Folder/Library | LIBRARY | User's saved/read series |
| Download arrow | QUEUE | Download queue |
| Gear | SETTINGS | App settings |

Bottom nav styling:
- Background: `VoidBlack` with 1dp top border `BorderNeon`
- Selected indicator: neon underline + icon glow
- Unselected: dim icon at 40% opacity
- Font: display font, uppercase, 10sp

### 14.4 Top App Bar (per-screen)

- Background: `VoidBlack` (or transparent over scrollable content)
- Left: app logo / back arrow
- Center: screen title in display font (tracking, uppercase)
- Right: action icons
- Decorative: subtle barcode pattern strip or binary number watermark at low opacity

### 14.5 Screen Transition Animations

- **Push navigation:** slide in from right + neon scan-line flash
- **Pop navigation:** slide out to right
- **Modal dialogs:** scale from 90% + fade in
- **Tab switch:** crossfade with glitch frame
- **List item appear:** staggered fade+slide from bottom (items enter one by one)

---

## 15. THEMES & CUSTOMIZATION

### 15.1 Built-in Themes

| Theme ID | Name | Primary | Accent | Background |
|---|---|---|---|---|
| `cyber_red` | NIGHT CITY | `#FF003C` | `#00FFF0` | `#000000` |
| `cyber_teal` | ARASAKA NET | `#00FFF0` | `#FF003C` | `#050A14` |
| `cyber_yellow` | CORPO GOLD | `#FFE600` | `#FF7700` | `#0D0A00` |
| `cyber_purple` | NETRUNNER | `#9D00FF` | `#00FFF0` | `#080014` |
| `cyber_orange` | MAELSTROM | `#FF7700` | `#FF003C` | `#0D0600` |
| `cyber_mono` | GHOST DATA | `#FFFFFF` | `#888888` | `#000000` |
| `stellaris_blue` | STELLARIS | `#4FC3F7` | `#FFD54F` | `#050B14` |
| `custom` | CUSTOM | user-picked | user-picked | user-picked |

### 15.2 Reader-Specific Themes

Separate theme system for the built-in reader:

| Reader Theme | Background | Text | Name |
|---|---|---|---|
| `void_dark` | `#000000` | `#E0E0E0` | VOID |
| `night_red` | `#0D0000` | `#FF9999` | BLOOD |
| `neo_teal` | `#001A1A` | `#00FFF0` | MATRIX |
| `paper_burn` | `#1A1208` | `#D4B896` | ANALOG |
| `ice_white` | `#F0F4F8` | `#1A2332` | ICE |
| `custom` | user hex | user hex | CUSTOM |

### 15.3 UI Density Settings

- **Compact:** smaller cards, denser list
- **Normal:** default spacing
- **Comfortable:** larger cards, more whitespace

### 15.4 Customization Depth

The Settings screen exposes full control over:
- Background opacity of panels (0–100%)
- Border glow intensity (0–100%)
- Scanline overlay opacity (0–50%)
- Corner cut size for panels (0dp–16dp)
- Navigation bar style (icons only / icons + labels / labels only)
- Enable/disable animated background particles
- Enable/disable glitch effects
- Enable/disable sound effects (optional: subtle tech click sounds on tap)
- Status bar color matching (true immersive or independent)

---

## 16. TYPOGRAPHY & FONTS

### 16.1 Font Categories

**Display / Heading Fonts** (Cyberpunk-inspired):
- `Rajdhani Bold` — clean angular, Cyberpunk 2077 closest match
- `Orbitron` — sci-fi classic, all-caps displays
- `Exo 2 Bold` — geometric, futuristic
- `Audiowide` — retro-tech feel
- `Michroma` — narrow technical display
- `Blox` or similar angular bitmap font (custom TTF bundled)
- `Barlow Condensed Bold` — compact, utilitarian
- `B612 Mono` — spacecraft instrument monospace

**Body / Reader Fonts**:
- `Source Serif 4` — comfortable long-form reading
- `Literata` — designed for e-readers, excellent legibility
- `Merriweather` — classic book-style serif
- `Lora` — elegant serif for story content
- `IBM Plex Serif` — technical clarity
- `Crimson Pro` — editorial serif
- `EB Garamond` — classic literary feel

**Monospace / UI Data Fonts**:
- `JetBrains Mono` — clean, readable code/data
- `IBM Plex Mono` — corporate tech aesthetic
- `Roboto Mono` — Material design-adjacent
- `Share Tech Mono` — retro terminal aesthetic
- `Courier Prime` — typewriter feel
- `Space Mono` — geometric monospace
- `VT323` — CRT terminal aesthetic (use sparingly)

**Total Fonts Bundled:** 20+ TTF/OTF files in `app/src/main/res/font/`

### 16.2 Default Theme Typography

```kotlin
val CyberTypography = Typography(
    displayLarge  = TextStyle(fontFamily = OrbitronFamily, fontSize = 32.sp,
                              fontWeight = FontWeight.Bold, letterSpacing = 0.05.em),
    displayMedium = TextStyle(fontFamily = RajdhaniFamily, fontSize = 26.sp,
                              fontWeight = FontWeight.Bold, letterSpacing = 0.08.em),
    titleLarge    = TextStyle(fontFamily = RajdhaniFamily, fontSize = 20.sp,
                              fontWeight = FontWeight.SemiBold, letterSpacing = 0.1.em),
    bodyLarge     = TextStyle(fontFamily = SourceSerifFamily, fontSize = 16.sp,
                              lineHeight = 26.sp),
    bodyMedium    = TextStyle(fontFamily = SourceSerifFamily, fontSize = 14.sp,
                              lineHeight = 22.sp),
    labelSmall    = TextStyle(fontFamily = IBMPlexMonoFamily, fontSize = 10.sp,
                              letterSpacing = 0.15.em,
                              textTransform = TextTransform.Uppercase)
)
```

---

## 17. ANIMATIONS & MOTION DESIGN

### 17.1 Glitch Effect

A reusable `GlitchModifier` that randomly displaces text/image by a few pixels on a configurable interval:

```kotlin
@Composable
fun Modifier.glitchEffect(
    intervalMs: Long = 3000L,
    intensityPx: Float = 4f
): Modifier {
    val offset by produceState(0f) {
        while (true) {
            delay(intervalMs + Random.nextLong(-500, 500))
            value = Random.nextFloat() * intensityPx * 2 - intensityPx
            delay(50)
            value = 0f
        }
    }
    return this.offset(x = offset.dp)
}
```

### 17.2 Scanline Overlay

Draw scanlines over content using Compose Canvas:

```kotlin
@Composable
fun ScanlineOverlay(alpha: Float = 0.08f) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val lineSpacing = 4.dp.toPx()
        val paint = Paint().apply { color = Color.Black.copy(alpha = alpha) }
        var y = 0f
        while (y < size.height) {
            drawLine(Color.Black.copy(alpha = alpha),
                     start = Offset(0f, y),
                     end   = Offset(size.width, y),
                     strokeWidth = 1.dp.toPx())
            y += lineSpacing
        }
    }
}
```

### 17.3 Neon Glow Simulation

```kotlin
fun Modifier.neonGlow(color: Color, glowRadius: Dp = 8.dp): Modifier =
    this.drawBehind {
        val radiusPx = glowRadius.toPx()
        repeat(3) { i ->
            drawRoundRect(
                color  = color.copy(alpha = 0.15f / (i + 1)),
                cornerRadius = CornerRadius(4.dp.toPx()),
                style  = Stroke(width = (i + 1) * 2f),
                topLeft  = Offset(-radiusPx * i, -radiusPx * i),
                size = Size(size.width + radiusPx * i * 2,
                            size.height + radiusPx * i * 2)
            )
        }
    }
```

### 17.4 Corner Bracket Animation

Animated scanning corner brackets on cards (like targeting reticles):

```kotlin
@Composable
fun CyberCornerBrackets(
    color: Color = CyberColors.NeonCyan,
    animated: Boolean = true
) {
    val progress by animateFloatAsState(
        targetValue = if (animated) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 2000
                0.0f at 0
                1.0f at 800
                1.0f at 1200
                0.0f at 2000
            }
        )
    )
    // Draw 4 corner L-shaped brackets via Canvas
}
```

### 17.5 Loading States

- **Wiki loading:** Animated neon scanning bar + pulsing HFY logo
- **Chapter loading:** "LOADING TRANSMISSION..." with typing cursor animation
- **Download progress:** Animated segmented progress bar that fills left-to-right with cyan glow
- **Error state:** Red glitch flash + error code display (e.g., `ERR_NETWORK_0x404`)

---

## 18. SETTINGS SCREEN

```
┌─────────────────────────────────────────────────────┐
│ ⚙ SYSTEM CONFIGURATION                              │
├─────────────────────────────────────────────────────┤
│ AUTHENTICATION                                      │
│   Reddit Account: [CONNECT / DISCONNECT]            │
│   Auth Mode: [OAuth] [Scraper Fallback]             │
├─────────────────────────────────────────────────────┤
│ APPEARANCE                                          │
│   App Theme: [NIGHT CITY ▼]                        │
│   UI Density: [Normal ▼]                           │
│   Glitch Effects: [ON ●────]                       │
│   Scanline Overlay: [ON ●──] Intensity: ──●── 20%  │
│   Neon Glow: [ON ●─────────] Radius: ──●── 50%     │
│   Corner Brackets Anim: [ON]                        │
│   Background Particles: [OFF]                       │
├─────────────────────────────────────────────────────┤
│ READER DEFAULTS                                     │
│   Default Font: [Source Serif 4 ▼]                 │
│   Default Font Size: ──●──────── 16sp               │
│   Line Height: ──────●──── 1.6×                     │
│   Margin: ──●──────── 24dp                          │
│   Reader Theme: [VOID ▼]                           │
│   Auto-Save Progress: [ON]                          │
├─────────────────────────────────────────────────────┤
│ DOWNLOADS                                           │
│   Default Format: [EPUB] [TXT]                     │
│   Default Merge: [ON]                               │
│   Download Location: /Downloads/HFY-Cyberdeck/      │
│   WiFi Only: [OFF]                                  │
│   Concurrent Downloads: [3 ▼]                      │
├─────────────────────────────────────────────────────┤
│ CACHE                                               │
│   Series Cache TTL: [1 hour ▼]                     │
│   Chapter Cache TTL: [30 days ▼]                   │
│   HTTP Cache Size: 50 MB                            │
│   [CLEAR CACHE]                  Used: 14.2 MB      │
├─────────────────────────────────────────────────────┤
│ ABOUT                                               │
│   HFY Cyberdeck v1.0.0                             │
│   Build: CYBERDECK_REV_001                         │
│   [REPORT BUG]  [CHANGELOG]                        │
└─────────────────────────────────────────────────────┘
```

---

## 19. ERROR HANDLING & RESILIENCE

### 19.1 Network Error Hierarchy

```kotlin
sealed class HfyNetworkError : Exception() {
    data class RateLimit(val retryAfterSeconds: Int)   : HfyNetworkError()
    data class HttpError(val code: Int, val body: String) : HfyNetworkError()
    object Timeout                                      : HfyNetworkError()
    object NoInternet                                   : HfyNetworkError()
    data class ParseError(val source: String)           : HfyNetworkError()
    data class AuthError(val reason: String)            : HfyNetworkError()
}
```

### 19.2 Retry Strategy

```kotlin
class RateLimitInterceptor : Interceptor {
    override fun intercept(chain: Chain): Response {
        val response = chain.proceed(chain.request())
        if (response.code == 429) {
            val retryAfter = response.header("Retry-After")?.toLongOrNull() ?: 60L
            Thread.sleep(retryAfter * 1000)
            return chain.proceed(chain.request())
        }
        return response
    }
}

// Exponential backoff in repository layer
suspend fun <T> withRetry(
    maxAttempts: Int = 3,
    initialDelay: Long = 1000L,
    block: suspend () -> T
): T {
    repeat(maxAttempts) { attempt ->
        try { return block() } catch (e: Exception) {
            if (attempt == maxAttempts - 1) throw e
            delay(initialDelay * (1L shl attempt))  // 1s, 2s, 4s
        }
    }
    error("Should not reach here")
}
```

### 19.3 Offline Mode

When network is unavailable:
- Serve all content from Room cache
- Show `[OFFLINE MODE]` indicator in top bar
- Download queue pauses and resumes when connectivity returns (via `ConnectivityManager` callback)
- Search works against cached data

### 19.4 Error UI States

Every screen handles three states cleanly:
- **Loading:** `CyberLoadingIndicator()` — animated scan bar
- **Error:** `CyberErrorPanel(error, onRetry)` — shows error code + RETRY button with neon styling
- **Empty:** `CyberEmptyState(message)` — e.g., "// NO_SERIES_FOUND" with glitch decoration

---

## 20. BUILD CONFIGURATION & APK GENERATION

### 20.1 Prerequisites

```bash
# Install Android Studio Ladybug or newer
# Install JDK 21 (Temurin recommended)
# Install Android SDK with:
#   - Build Tools 35.0.0
#   - Platform SDK API 35
#   - Android Emulator (for testing)

# Clone and set up
git clone <your-repo-url> hfy-cyberdeck
cd hfy-cyberdeck

# Set up local.properties (NEVER commit this file)
echo "REDDIT_CLIENT_ID=your_client_id_here" >> local.properties
echo "REDDIT_REDIRECT_URI=hfycyberdeck://auth/callback" >> local.properties
```

### 20.2 app/build.gradle.kts

```kotlin
android {
    namespace = "com.hfycyberdeck.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hfycyberdeck.app"
        minSdk = 35
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-CYBERDECK_REV_001"

        val props = Properties().also { it.load(rootProject.file("local.properties").reader()) }
        buildConfigField("String", "REDDIT_CLIENT_ID",
                         "\"${props["REDDIT_CLIENT_ID"]}\"")
        buildConfigField("String", "REDDIT_REDIRECT_URI",
                         "\"${props["REDDIT_REDIRECT_URI"]}\"")

        manifestPlaceholders["redirectUri"] = props["REDDIT_REDIRECT_URI"] as String
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),
                          "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.15"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/versions/**"
        }
    }
}
```

### 20.3 Signing Configuration (Release APK)

```kotlin
// In android {} block:
signingConfigs {
    create("release") {
        storeFile = file(props["KEYSTORE_PATH"] as String)
        storePassword = props["KEYSTORE_PASSWORD"] as String
        keyAlias = props["KEY_ALIAS"] as String
        keyPassword = props["KEY_PASSWORD"] as String
    }
}
```

Generate keystore:
```bash
keytool -genkey -v \
  -keystore hfy-cyberdeck-release.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias hfy-release \
  -dname "CN=HFY Cyberdeck, OU=Dev, O=HFY, L=NightCity, C=US"
```

### 20.4 Building the APK

```bash
# Debug APK (for sideloading during development)
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Release APK (signed, optimized)
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release.apk

# Release AAB (for Play Store, if desired)
./gradlew bundleRelease
# Output: app/build/outputs/bundle/release/app-release.aab
```

### 20.5 APK Size Management

To hit 360+ MB with bundled content:
- Bundle **all fonts** as assets (~30–50 MB for 20+ font files)
- Bundle **Lottie animations** for loading/onboarding (~5–10 MB)
- Bundle **epublib JAR** and supporting libs in `app/libs/` (~8 MB)
- Bundle **sound assets** for optional UI click sounds (~5–20 MB)
- Bundle **background artwork** / cyberpunk wallpapers as drawable assets (~50–100 MB)
- Bundle **icon pack SVG/vector set** from Cyberpunk 2077 UI reference (~20–50 MB as PNG assets)
- Bundle **offline fallback HTML** for the wiki parser (~1 MB)
- If still under target: bundle **additional font variants** (50+ font files) and **extended icon libraries**

---

## 21. DEPENDENCY LIST (build.gradle)

```kotlin
dependencies {
    // Compose BOM
    val composeBom = platform("androidx.compose:compose-bom:2024.10.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")

    // Navigation
    implementation("androidx.navigation:navigation-compose:2.8.3")

    // Lifecycle / ViewModel
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")

    // Hilt
    implementation("com.google.dagger:hilt-android:2.52")
    kapt("com.google.dagger:hilt-android-compiler:2.52")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
    implementation("androidx.hilt:hilt-work:1.2.0")

    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    implementation("androidx.room:room-paging:2.6.1")

    // DataStore
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.datastore:datastore:1.1.1")

    // Paging 3
    implementation("androidx.paging:paging-runtime-ktx:3.3.2")
    implementation("androidx.paging:paging-compose:3.3.2")

    // WorkManager
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Networking
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-moshi:2.11.0")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
    kapt("com.squareup.moshi:moshi-kotlin-codegen:1.15.1")

    // HTML Parsing
    implementation("org.jsoup:jsoup:1.18.1")

    // Image loading
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Markdown rendering
    implementation("io.noties.markwon:core:4.6.2")
    implementation("io.noties.markwon:html:4.6.2")
    implementation("io.noties.markwon:strikethrough:4.6.2")
    implementation("io.noties.markwon:tables:4.6.2")
    implementation("io.noties.markwon:linkify:4.6.2")
    implementation("io.noties.markwon:ext-latex:4.6.2")

    // Lottie animations
    implementation("com.airbnb.android:lottie-compose:6.5.2")

    // Security (EncryptedSharedPreferences)
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Browser (Chrome Custom Tabs for OAuth)
    implementation("androidx.browser:browser:1.8.0")

    // Kotlinx Serialization
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Epublib (bundled JAR in app/libs/)
    implementation(files("libs/epublib-core-3.1.jar"))
    implementation(files("libs/slf4j-android-1.7.36.jar"))  // epublib logging

    // Testing
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
    testImplementation("androidx.room:room-testing:2.6.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
```

---

## 22. PROJECT FILE STRUCTURE

```
hfy-cyberdeck/
├── app/
│   ├── libs/
│   │   ├── epublib-core-3.1.jar
│   │   └── slf4j-android-1.7.36.jar
│   └── src/main/
│       ├── java/com/hfycyberdeck/app/
│       │   ├── HfyCyberdeckApp.kt          ← Application class (Hilt)
│       │   ├── MainActivity.kt             ← Entry point, NavHost
│       │   │
│       │   ├── core/
│       │   │   ├── di/                     ← Hilt modules
│       │   │   ├── network/                ← OkHttp, Retrofit, interceptors
│       │   │   ├── database/               ← Room DB, DAOs, converters
│       │   │   ├── datastore/              ← User preferences
│       │   │   └── util/                   ← Extensions, helpers
│       │   │
│       │   ├── data/
│       │   │   ├── remote/
│       │   │   │   ├── reddit/             ← Reddit API service + DTOs
│       │   │   │   └── scraper/            ← Jsoup scrapers
│       │   │   ├── local/
│       │   │   │   ├── entities/           ← Room entities
│       │   │   │   └── dao/                ← Data access objects
│       │   │   └── repository/             ← Repository implementations
│       │   │
│       │   ├── domain/
│       │   │   ├── model/                  ← Domain models
│       │   │   ├── repository/             ← Repository interfaces
│       │   │   └── usecase/                ← Use cases
│       │   │
│       │   ├── export/
│       │   │   ├── EpubExporter.kt
│       │   │   ├── TxtExporter.kt
│       │   │   └── CoverGenerator.kt       ← Auto-generate cyberpunk cover art
│       │   │
│       │   ├── download/
│       │   │   ├── DownloadManager.kt
│       │   │   ├── ChapterDownloadWorker.kt
│       │   │   └── DownloadQueueRepository.kt
│       │   │
│       │   ├── auth/
│       │   │   ├── RedditAuthManager.kt
│       │   │   ├── TokenStore.kt
│       │   │   └── AuthCallbackActivity.kt
│       │   │
│       │   └── ui/
│       │       ├── theme/
│       │       │   ├── CyberColors.kt
│       │       │   ├── CyberTypography.kt
│       │       │   ├── CyberShapes.kt
│       │       │   └── CyberTheme.kt
│       │       ├── components/             ← Reusable Compose components
│       │       │   ├── CyberPanel.kt
│       │       │   ├── CyberButton.kt
│       │       │   ├── CyberProgressBar.kt
│       │       │   ├── CyberSearchBar.kt
│       │       │   ├── GlitchEffect.kt
│       │       │   ├── ScanlineOverlay.kt
│       │       │   ├── NeonGlow.kt
│       │       │   ├── CornerBrackets.kt
│       │       │   └── SeriesCard.kt
│       │       ├── navigation/
│       │       │   └── AppNavGraph.kt
│       │       └── screens/
│       │           ├── browser/            ← BrowseScreen + ViewModel
│       │           ├── search/             ← SearchScreen + ViewModel
│       │           ├── seriesdetail/       ← SeriesDetailScreen + ViewModel
│       │           ├── reader/             ← ReaderScreen + ViewModel
│       │           ├── library/            ← LibraryScreen + ViewModel
│       │           ├── queue/              ← QueueScreen + ViewModel
│       │           └── settings/           ← SettingsScreen + ViewModel
│       │
│       ├── res/
│       │   ├── font/                       ← All 20+ TTF/OTF files
│       │   ├── drawable/                   ← Vector icons, backgrounds
│       │   ├── raw/                        ← Lottie JSON files, sound assets
│       │   └── values/
│       │       ├── strings.xml
│       │       └── themes.xml
│       │
│       └── AndroidManifest.xml
│
├── gradle/
├── build.gradle.kts
├── settings.gradle.kts
├── local.properties               ← GITIGNORED — contains secrets
└── proguard-rules.pro
```

### AndroidManifest.xml — Key Entries

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
    android:maxSdkVersion="28"/>

<!-- OAuth callback activity -->
<activity android:name=".auth.AuthCallbackActivity" android:exported="true">
    <intent-filter android:autoVerify="true">
        <action android:name="android.intent.action.VIEW"/>
        <category android:name="android.intent.category.DEFAULT"/>
        <category android:name="android.intent.category.BROWSABLE"/>
        <data android:scheme="hfycyberdeck" android:host="auth"
              android:path="/callback"/>
    </intent-filter>
</activity>

<!-- WorkManager foreground service -->
<service android:name="androidx.work.impl.foreground.SystemForegroundService"
    android:foregroundServiceType="dataSync"
    android:exported="false"/>
```

---

## 23. STEP-BY-STEP CODING PLAN (PHASED)

### PHASE 1 — Foundation (Week 1)
```
[ ] 1.1  Set up Android Studio project (Kotlin, Compose, Min SDK 35)
[ ] 1.2  Configure build.gradle.kts with all dependencies
[ ] 1.3  Set up Hilt application class and modules
[ ] 1.4  Create Room database schema (entities + DAOs)
[ ] 1.5  Create DataStore preferences module
[ ] 1.6  Set up OkHttp client with interceptors
[ ] 1.7  Implement Reddit OAuth flow (register app, auth URL, token exchange)
[ ] 1.8  Build token storage with EncryptedSharedPreferences
[ ] 1.9  Create basic navigation graph (NavHost with 5 screens)
[ ] 1.10 Implement core CyberTheme (colors, typography, shapes)
```

### PHASE 2 — Data Layer (Week 2)
```
[ ] 2.1  Implement WikiSeriesPagingSource (Jsoup HTML parser)
[ ] 2.2  Implement Reddit JSON API service (Retrofit)
[ ] 2.3  Build SeriesRepository with dual-source fallback logic
[ ] 2.4  Build ChapterRepository with content fetch + cache
[ ] 2.5  Implement SearchRepository with live wiki + Room filter
[ ] 2.6  Build DownloadQueueRepository + WorkManager setup
[ ] 2.7  Implement EpubExporter (epublib integration)
[ ] 2.8  Implement TxtExporter (single + merged modes)
[ ] 2.9  Build CoverGenerator (programmatic cyberpunk bitmap covers)
[ ] 2.10 Write domain use cases for each feature area
```

### PHASE 3 — Core Screens (Week 3)
```
[ ] 3.1  Browse screen with LazyColumn Paging 3 + infinite scroll
[ ] 3.2  SeriesCard component (neon panel with progress, favorite, download)
[ ] 3.3  Search screen with debounced live search
[ ] 3.4  Series Detail screen (chapter list, series info, download actions)
[ ] 3.5  Download dialog (format picker, chapter selector, merge toggle)
[ ] 3.6  Download Queue screen (real-time progress via WorkManager flows)
[ ] 3.7  Library screen (tabs, sort/filter, grid/list)
[ ] 3.8  Settings screen (all settings, DataStore binding)
[ ] 3.9  Built-in Reader screen (Markwon rendering, scroll tracking)
[ ] 3.10 Reader toolbar (font picker, size, theme, brightness)
```

### PHASE 4 — UI Polish & Cyberpunk Design (Week 4)
```
[ ] 4.1  Implement GlitchEffect modifier and apply to key components
[ ] 4.2  Implement ScanlineOverlay and make it toggleable
[ ] 4.3  Implement NeonGlow modifier for buttons and panels
[ ] 4.4  Implement CornerBrackets animated component
[ ] 4.5  Apply all 8 app themes with DataStore persistence
[ ] 4.6  Apply all reader themes
[ ] 4.7  Bundle all fonts and wire up font picker
[ ] 4.8  Add screen transition animations (shared element + slide)
[ ] 4.9  Add Lottie loading animations
[ ] 4.10 Add staggered list item entry animations
```

### PHASE 5 — Robustness & Polish (Week 5)
```
[ ] 5.1  Implement ConnectivityObserver + offline mode
[ ] 5.2  Test OAuth + scraper fallback switching
[ ] 5.3  Implement pull-to-refresh on Browse and Library
[ ] 5.4  Add "Continue Reading" section to Browse screen home
[ ] 5.5  Implement Bookmark system (long-press paragraph)
[ ] 5.6  Test EPUB output on multiple e-reader apps
[ ] 5.7  Test TXT output (individual + merged)
[ ] 5.8  Test download queue with concurrent downloads (3 simultaneous)
[ ] 5.9  Test with 10+ different HFY series
[ ] 5.10 Performance profiling (LazyColumn, image loading, db queries)
```

### PHASE 6 — Build & Release (Week 6)
```
[ ] 6.1  Generate release keystore
[ ] 6.2  Configure signing in build.gradle.kts
[ ] 6.3  Run ProGuard and fix any obfuscation issues
[ ] 6.4  Run ./gradlew assembleRelease
[ ] 6.5  Test release APK on physical device (Android 15)
[ ] 6.6  Test release APK on Android 15 emulator
[ ] 6.7  Verify APK size is 360 MB+
[ ] 6.8  Final review of all cyberpunk UI elements
[ ] 6.9  Install APK on device via adb install app-release.apk
[ ] 6.10 Sign off checklist (see Section 25)
```

---

## 24. REFERENCE REPOSITORIES & INTEGRATION NOTES

### 24.1 Key Repos Analyzed

| Repo | Language | Key Insight |
|---|---|---|
| [hacst/hfy2epub](https://github.com/hacst/hfy2epub) | JavaScript | OAuth + EPUB generation logic — port chapter fetching to Kotlin |
| [lizard-demon/hfydl](https://github.com/lizard-demon/hfydl) | Python | Reddit API call patterns for post+comment chain fetching |
| [cpiber/hfy-epub](https://github.com/cpiber/hfy-epub) | TypeScript | Clean chapter ordering and series detection logic |
| [stonewalljones/hfyEbook](https://github.com/stonewalljones/hfyEbook) | Python | Wiki scraping patterns, series → chapter chain logic |
| [cowlinator/reddit_story_scraper](https://github.com/cowlinator/reddit_story_scraper) | Python | Multi-part story detection, OAuth refresh logic |
| [Racle/Reddit2Ebook](https://github.com/Racle/Reddit2Ebook) | Unknown | Series metadata extraction patterns |
| [hacst.net/hfy2epub](https://www.hacst.net/hfy2epub/) | Web app | Reference for chapter chain traversal (next-chapter link following) |

### 24.2 Critical Implementation Notes

**Chapter chain detection:**  
Reddit HFY series link chapters together with "Next: [link]" / "Previous: [link]" in the post body. The scraper must follow these links to build the correct chapter order for series that don't appear in the wiki index.

```kotlin
fun extractNextChapterUrl(postBody: String): String? {
    // Match: "Next: [Title](url)" or "Next chapter: url" patterns
    val patterns = listOf(
        Regex("""[Nn]ext[:\s]+\[.*?\]\((https?://[^\)]+)\)"""),
        Regex("""[Nn]ext[:\s]+(https://www\.reddit\.com/r/HFY/comments/\w+/?)"""),
        Regex("""(?i)part\s*\d+:\s*\[.*?\]\((https?://[^\)]+)\)""")
    )
    return patterns.firstNotNullOfOrNull { it.find(postBody)?.groupValues?.get(1) }
}
```

**Wiki page structure:**  
The HFY wiki at `/r/HFY/wiki/series/` lists series in sections (A–Z, numerics, etc.). Parse the section headers to enable alphabetical filtering/grouping in the UI.

**Reddit post content:**  
Use the `.json` endpoint: `https://www.reddit.com/r/HFY/comments/{id}/.json`  
The post content is in `data.children[0].data.selftext` (Markdown).  
Comments may contain chapter links — parse top-level comments if `selftext` is empty or `[deleted]`.

**Rate limiting:**  
Reddit's API allows 60 requests/minute for authenticated, 10 for unauthenticated. The scraper fallback must rate-limit to 1 request/6 seconds.

---

## 25. TESTING CHECKLIST

### Functional Tests
```
[ ] Wiki series list loads and scrolls infinitely
[ ] Search returns live results matching title/author
[ ] Series detail shows correct chapter list in order
[ ] Reader renders markdown with all formatting (bold, italic, tables, blockquotes)
[ ] Reader saves and restores scroll position correctly
[ ] EPUB download works and opens in KOReader, Google Play Books, Moon+ Reader
[ ] TXT download produces readable plain text with correct chapter breaks
[ ] Merged EPUB contains all chapters in correct order
[ ] Individual chapter download works
[ ] Download queue shows real-time progress
[ ] Pause/resume download queue works
[ ] Favorites toggle persists across app restarts
[ ] Reading progress persists across app restarts
[ ] OAuth login/logout flow works
[ ] Scraper fallback activates when OAuth is unavailable
[ ] App works in airplane mode using cached data
[ ] Pull-to-refresh updates series list
[ ] All 8 themes apply correctly
[ ] All 20+ fonts work in reader font picker
[ ] Settings changes persist across app restarts
```

### HFY Series to Test Against
```
[ ] The Deathworlders (Hambone's Muse) — very long series, good pagination test
[ ] A Soldier Adrift: Captain Westeros — medium length
[ ] The Wandering Inn (crosspost) — large series
[ ] Humans Don't Make Good Pets — shorter series
[ ] Nature of Predators — popular, actively updated series
[ ] We Are Legion (We Are Bob) — well-structured chapter links
[ ] A Programmer's Guide to the Universe — tech-themed
[ ] Interstellar Anthropology — good for wiki parser test
[ ] Homo Homini Lupus — older series, tests legacy formatting
[ ] OC Stories — new additions, tests live wiki refresh
```

### Performance Tests
```
[ ] Browse screen scrolls at 60fps with 200+ series loaded
[ ] Search results appear in < 500ms after typing stops
[ ] Reader loads chapter content in < 2 seconds on WiFi
[ ] EPUB export of 50-chapter series completes in < 60 seconds
[ ] App launch cold-start < 3 seconds
[ ] Memory usage stays below 300 MB during normal use
[ ] Database query times < 50ms for all common queries
```

---

*Document version: CYBERDECK_SPEC_REV_001*  
*Generated: 2026 · HFY CYBERDECK PROJECT*  
*"Access the Grid. Download the Legends."*

```
  ██╗  ██╗███████╗██╗   ██╗     ██████╗██╗   ██╗██████╗ ███████╗██████╗ ██████╗ ███████╗ ██████╗██╗  ██╗
  ██║  ██║██╔════╝╚██╗ ██╔╝    ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██╔════╝██║ ██╔╝
  ███████║█████╗   ╚████╔╝     ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝██║  ██║█████╗  ██║     █████╔╝ 
  ██╔══██║██╔══╝    ╚██╔╝      ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██║  ██║██╔══╝  ██║     ██╔═██╗ 
  ██║  ██║██║        ██║       ╚██████╗   ██║   ██████╔╝███████╗██║  ██║██████╔╝███████╗╚██████╗██║  ██╗
  ╚═╝  ╚═╝╚═╝        ╚═╝        ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝ ╚═════╝╚═╝  ╚═╝
```


---

## Part 3: Nexus Build Specification

# HFY NEXUS — NATIVE ANDROID APK COMPLETE BUILD SPECIFICATION
### Codename: NIGHT_CITY_READER // BUILD v1.0 // CLASSIFIED

```
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
  HFY NEXUS :: HUMANITY FUCK YEAH :: STORY ACQUISITION SYSTEM v1.0
  CYBERDECK ACCESS GRANTED // AUTHORIZED PERSONNEL ONLY
  TARGET: hfy.foundation + r/HFY // MODE: EXTRACTION + ARCHIVE
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
```

---

## TABLE OF CONTENTS

1. [Project Identity & Goals](#1-project-identity--goals)
2. [Pre-Development: Install All Required Software](#2-pre-development-install-all-required-software)
3. [Tech Stack — Full Specification](#3-tech-stack--full-specification)
4. [Project Architecture & Folder Structure](#4-project-architecture--folder-structure)
5. [Gradle Dependencies (build.gradle.kts)](#5-gradle-dependencies-buildgradlekts)
6. [Data Layer — API Integration Plan](#6-data-layer--api-integration-plan)
7. [Reddit OAuth 2.0 Implementation](#7-reddit-oauth-20-implementation)
8. [Screen-by-Screen UI Specification](#8-screen-by-screen-ui-specification)
9. [Cyberpunk UI Design System](#9-cyberpunk-ui-design-system)
10. [Font Library — 30+ Sci-Fi Fonts](#10-font-library--30-sci-fi-fonts)
11. [Animation & Motion System](#11-animation--motion-system)
12. [Theme Engine — Presets + Custom Builder](#12-theme-engine--presets--custom-builder)
13. [Series List Browsing & Infinite Scroll](#13-series-list-browsing--infinite-scroll)
14. [Download Engine — EPUB & TXT Generation](#14-download-engine--epub--txt-generation)
15. [Download Queue System](#15-download-queue-system)
16. [Built-in Reader Screen](#16-built-in-reader-screen)
17. [AI-Generated Series Cover Icons](#17-ai-generated-series-cover-icons)
18. [Caching Strategy](#18-caching-strategy)
19. [Error Handling & Retry Logic](#19-error-handling--retry-logic)
20. [Local Database — Room Schema](#20-local-database--room-schema)
21. [Settings Screen — Full Specification](#21-settings-screen--full-specification)
22. [APK Build, Signing & Release Plan](#22-apk-build-signing--release-plan)
23. [Testing Plan](#23-testing-plan)
24. [APK Size Strategy — Targeting 360MB+](#24-apk-size-strategy--targeting-360mb)
25. [Reference Repositories Analysis](#25-reference-repositories-analysis)
26. [Coding Plan — Phase-by-Phase](#26-coding-plan--phase-by-phase)

---

## 1. PROJECT IDENTITY & GOALS

### App Name
**HFY NEXUS** (internal codename: `night_city_reader`)

### Package Name
`com.hfynexus.android`

### App Description
A native Android front-end to `hfy.foundation` and `r/HFY` — the Humanity Fuck Yeah subreddit. Allows users to browse, read, bookmark, and download HFY fiction series as EPUB or TXT files. Styled as a Cyberpunk 2077-inspired cyberdeck terminal interface with animated neon elements, angular panel designs, and a fully customizable theme engine.

### Core Mission
- Act as a native, offline-capable, animated front-end to `https://hfy.foundation`
- Pull live series lists from both `hfy.foundation` and `https://www.reddit.com/r/HFY/wiki/series/`
- Use existing open-source EPUB conversion logic (from provided reference repos)
- Never re-implement what already works — integrate, adapt, and extend
- Target app size: **360MB minimum, up to 500MB+** (large fonts, asset packs, bundled libs)
- Support **Android 15 (API 35)** as minimum, targeting **API 36**

### Primary Sources
| Source | URL | Purpose |
|--------|-----|---------|
| HFY Foundation | `https://hfy.foundation/series?sort=chapters_highest` | Primary series browser |
| Reddit HFY Wiki | `https://www.reddit.com/r/HFY/wiki/series/` | Series index fallback |
| Reddit API (OAuth) | `https://oauth.reddit.com` | Live post fetching, auth |
| Reddit Scraper | `https://www.reddit.com/r/HFY` | Fallback when OAuth fails |
| hfy2epub (Hacst) | `https://www.hacst.net/hfy2epub/` | EPUB conversion reference |

---

## 2. PRE-DEVELOPMENT: INSTALL ALL REQUIRED SOFTWARE

Run these steps on your development machine **before writing any code**.

### 2.1 — JDK Installation
```bash
# Install JDK 21 (required for Android Gradle Plugin 8.x)
# Windows: Download from https://adoptium.net/
# macOS:
brew install --cask temurin@21

# Linux (Ubuntu/Debian):
sudo apt install openjdk-21-jdk

# Verify:
java -version   # Should show: openjdk 21.x.x
javac -version
```

### 2.2 — Android Studio Installation
```
Download Android Studio Koala (2024.1.1) or newer:
https://developer.android.com/studio

During setup, install:
  ✅ Android SDK (API 35 + API 36 Preview)
  ✅ Android Emulator
  ✅ Android SDK Build-Tools 34.0.0
  ✅ Android SDK Platform-Tools
  ✅ CMake 3.22.1 (for native libs)
  ✅ NDK Side-by-side 26.1.10909125
```

### 2.3 — SDK Manager Configuration
In Android Studio → SDK Manager → SDK Platforms:
```
✅ Android 15.0 (API 35)   — minSdk target
✅ Android 16.0 (API 36)   — compileSdk target (use preview if needed)
✅ Android 14.0 (API 34)   — test coverage
```

In SDK Manager → SDK Tools:
```
✅ Android SDK Build-Tools 35.0.0
✅ Android SDK Command-line Tools
✅ Android Emulator
✅ Android SDK Platform-Tools
✅ Google Play Licensing Library
✅ Intel x86 Emulator Accelerator (HAXM) or Android Emulator Hypervisor
```

### 2.4 — Gradle Setup
```bash
# Install Gradle 8.7 via wrapper (auto-handled by Android Studio)
# Verify:
./gradlew --version   # Should show Gradle 8.7+
```

### 2.5 — CLI Tools
```bash
# Git (version control)
git --version   # Required: 2.40+

# ADB (for sideloading APK)
adb version     # Comes with platform-tools

# Optional: bundletool for AAB testing
# https://github.com/google/bundletool/releases
```

### 2.6 — Keystore Generation (APK Signing)
```bash
keytool -genkey -v \
  -keystore hfy_nexus_release.jks \
  -alias hfynexus \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -storepass YOUR_STORE_PASSWORD \
  -keypass YOUR_KEY_PASSWORD \
  -dname "CN=HFY Nexus, OU=Apps, O=HFY, L=Night City, S=NC, C=US"

# Keep hfy_nexus_release.jks SAFE — losing it means you cannot update the app
```

### 2.7 — Reddit App Registration (OAuth)
```
1. Go to: https://www.reddit.com/prefs/apps
2. Click "Create App"
3. Name: HFY Nexus
4. Type: "installed app" (for mobile)
5. Description: HFY Story Reader
6. Redirect URI: hfynexus://oauth2callback
7. Save CLIENT_ID (shown under app name)
8. Note: No client_secret for installed apps — use empty string
```

---

## 3. TECH STACK — FULL SPECIFICATION

### 3.1 — Language & Framework
| Layer | Technology | Version |
|-------|-----------|---------|
| Language | Kotlin | 2.0.x |
| UI Framework | Jetpack Compose | 1.7.x |
| Compose BOM | `compose-bom` | 2025.01.00 |
| Design System | Material 3 | 1.3.x |
| Build System | Gradle (KTS) | 8.7 |
| AGP | Android Gradle Plugin | 8.5.x |
| Min SDK | Android 15 | API 35 |
| Target/Compile SDK | Android 15/16 | API 35/36 |
| Architecture | MVVM + Clean Architecture | — |
| DI Framework | Hilt | 2.52 |
| Navigation | Compose Navigation | 2.8.x |

### 3.2 — Networking
| Library | Purpose | Version |
|---------|---------|---------|
| OkHttp | Native HTTP client | 4.12.0 |
| Retrofit | REST API wrapper | 2.11.0 |
| Gson Converter | JSON parsing | 2.11.0 |
| Moshi | Alt JSON parser | 1.15.1 |
| Jsoup | HTML/web scraping | 1.17.2 |

### 3.3 — Storage & Database
| Library | Purpose | Version |
|---------|---------|---------|
| Room | Local SQLite ORM | 2.6.1 |
| DataStore Prefs | Settings storage | 1.1.1 |
| Coil | Image loading/caching | 2.7.0 |

### 3.4 — EPUB Generation
| Library | Purpose | Version |
|---------|---------|---------|
| epublib-android | EPUB creation (fork) | custom |
| nl.siegmann.epublib | Core EPUB logic | 3.1 |
| Apache FreeMarker | Template engine for EPUB | 2.3.32 |
| JSoup | HTML cleaning for EPUB | 1.17.2 |

### 3.5 — Async / Reactive
| Library | Purpose | Version |
|---------|---------|---------|
| Kotlin Coroutines | Async operations | 1.8.1 |
| Flow | Reactive streams | built-in |
| WorkManager | Background downloads | 2.9.1 |

### 3.6 — UI & Animation
| Library | Purpose | Version |
|---------|---------|---------|
| Lottie-Compose | Complex animations | 6.4.1 |
| Accompanist | Compose extras (pager, etc.) | 0.34.0 |
| Compose Shimmer | Loading skeletons | 1.3.0 |
| Material Motion | Navigation animations | 0.12.5 |

### 3.7 — AI Image Generation
| Library | Purpose |
|---------|---------|
| Stable Diffusion (via API) | Generate series cover art |
| Picasso / Coil | Cache generated images locally |
| Retrofit | Call image generation endpoint |
> **Implementation note:** Use `https://api.stability.ai` (Stable Diffusion API) with a free-tier key,  
> OR use `https://pollinations.ai/p/{prompt}` as a zero-auth free option.  
> Generated images are saved to app-private storage and never re-generated unless cleared.

---

## 4. PROJECT ARCHITECTURE & FOLDER STRUCTURE

```
HFYNexus/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/hfynexus/android/
│   │   │   │   ├── HFYNexusApp.kt              ← Application class + Hilt init
│   │   │   │   ├── MainActivity.kt             ← Single Activity host
│   │   │   │   │
│   │   │   │   ├── core/
│   │   │   │   │   ├── di/                     ← Hilt modules
│   │   │   │   │   ├── network/                ← OkHttp, Retrofit setup
│   │   │   │   │   ├── database/               ← Room DB + DAOs
│   │   │   │   │   ├── datastore/              ← Settings DataStore
│   │   │   │   │   ├── util/                   ← Extensions, helpers
│   │   │   │   │   └── worker/                 ← WorkManager workers
│   │   │   │   │
│   │   │   │   ├── data/
│   │   │   │   │   ├── remote/
│   │   │   │   │   │   ├── hfy/                ← HFY Foundation API
│   │   │   │   │   │   │   ├── HFYApiService.kt
│   │   │   │   │   │   │   ├── HFYScraper.kt   ← JSoup scraper fallback
│   │   │   │   │   │   │   └── dto/            ← Data transfer objects
│   │   │   │   │   │   ├── reddit/
│   │   │   │   │   │   │   ├── RedditApiService.kt
│   │   │   │   │   │   │   ├── RedditOAuthManager.kt
│   │   │   │   │   │   │   ├── RedditScraper.kt ← Fallback scraper
│   │   │   │   │   │   │   └── dto/
│   │   │   │   │   │   └── imagegen/
│   │   │   │   │   │       └── ImageGenService.kt
│   │   │   │   │   ├── local/
│   │   │   │   │   │   ├── entity/             ← Room entities
│   │   │   │   │   │   ├── dao/                ← Room DAOs
│   │   │   │   │   │   └── mapper/             ← Entity <-> Domain mappers
│   │   │   │   │   └── repository/
│   │   │   │   │       ├── SeriesRepository.kt
│   │   │   │   │       ├── ChapterRepository.kt
│   │   │   │   │       ├── DownloadRepository.kt
│   │   │   │   │       └── UserRepository.kt
│   │   │   │   │
│   │   │   │   ├── domain/
│   │   │   │   │   ├── model/                  ← Domain models
│   │   │   │   │   │   ├── Series.kt
│   │   │   │   │   │   ├── Chapter.kt
│   │   │   │   │   │   ├── DownloadJob.kt
│   │   │   │   │   │   └── ReadingProgress.kt
│   │   │   │   │   └── usecase/
│   │   │   │   │       ├── FetchSeriesListUseCase.kt
│   │   │   │   │       ├── FetchChaptersUseCase.kt
│   │   │   │   │       ├── DownloadSeriesUseCase.kt
│   │   │   │   │       ├── GenerateCoverImageUseCase.kt
│   │   │   │   │       └── SearchSeriesUseCase.kt
│   │   │   │   │
│   │   │   │   ├── ui/
│   │   │   │   │   ├── theme/
│   │   │   │   │   │   ├── CyberpunkTheme.kt   ← Master theme
│   │   │   │   │   │   ├── ThemeColors.kt      ← All color palettes
│   │   │   │   │   │   ├── ThemeFonts.kt       ← Font definitions
│   │   │   │   │   │   ├── ThemeShapes.kt      ← Angular shapes
│   │   │   │   │   │   └── ThemeAnimations.kt  ← Shared animation specs
│   │   │   │   │   │
│   │   │   │   │   ├── components/             ← Reusable Composables
│   │   │   │   │   │   ├── CyberpunkButton.kt
│   │   │   │   │   │   ├── CyberpunkCard.kt
│   │   │   │   │   │   ├── NeonBorderBox.kt
│   │   │   │   │   │   ├── GlitchText.kt
│   │   │   │   │   │   ├── ScanlineOverlay.kt
│   │   │   │   │   │   ├── CornerBracket.kt
│   │   │   │   │   │   ├── ProgressBar.kt
│   │   │   │   │   │   ├── DataStreamDecor.kt
│   │   │   │   │   │   ├── SeriesListItem.kt
│   │   │   │   │   │   ├── SeriesGridItem.kt
│   │   │   │   │   │   └── BottomNavBar.kt
│   │   │   │   │   │
│   │   │   │   │   ├── navigation/
│   │   │   │   │   │   ├── AppNavGraph.kt
│   │   │   │   │   │   └── Screen.kt           ← Sealed class of routes
│   │   │   │   │   │
│   │   │   │   │   └── screens/
│   │   │   │   │       ├── splash/
│   │   │   │   │       │   └── SplashScreen.kt
│   │   │   │   │       ├── browse/
│   │   │   │   │       │   ├── BrowseScreen.kt
│   │   │   │   │       │   └── BrowseViewModel.kt
│   │   │   │   │       ├── search/
│   │   │   │   │       │   ├── SearchScreen.kt
│   │   │   │   │       │   └── SearchViewModel.kt
│   │   │   │   │       ├── series_detail/
│   │   │   │   │       │   ├── SeriesDetailScreen.kt
│   │   │   │   │       │   └── SeriesDetailViewModel.kt
│   │   │   │   │       ├── reader/
│   │   │   │   │       │   ├── ReaderScreen.kt
│   │   │   │   │       │   └── ReaderViewModel.kt
│   │   │   │   │       ├── library/
│   │   │   │   │       │   ├── LibraryScreen.kt
│   │   │   │   │       │   └── LibraryViewModel.kt
│   │   │   │   │       ├── downloads/
│   │   │   │   │       │   ├── DownloadQueueScreen.kt
│   │   │   │   │       │   └── DownloadViewModel.kt
│   │   │   │   │       ├── settings/
│   │   │   │   │       │   ├── SettingsScreen.kt
│   │   │   │   │       │   ├── ThemeBuilderScreen.kt
│   │   │   │   │       │   └── SettingsViewModel.kt
│   │   │   │   │       └── auth/
│   │   │   │   │           ├── RedditAuthScreen.kt
│   │   │   │   │           └── AuthViewModel.kt
│   │   │   │   │
│   │   │   │   └── epub/
│   │   │   │       ├── EpubBuilder.kt          ← Core EPUB generation
│   │   │   │       ├── EpubTemplate.kt         ← CSS + HTML templates
│   │   │   │       ├── TxtExporter.kt          ← Plain text export
│   │   │   │       └── ChapterFetcher.kt       ← Fetch post content
│   │   │   │
│   │   │   ├── res/
│   │   │   │   ├── font/                       ← ALL .ttf font files
│   │   │   │   ├── drawable/                   ← SVG icons, backgrounds
│   │   │   │   ├── raw/                        ← Lottie JSON animations
│   │   │   │   └── values/
│   │   │   │       ├── strings.xml
│   │   │   │       └── themes.xml              ← Base XML theme (M3)
│   │   │   └── assets/
│   │   │       ├── fonts/                      ← Extra font assets
│   │   │       ├── lottie/                     ← Animation JSON files
│   │   │       └── epub_css/                   ← CSS for EPUB files
│   │   │
│   │   └── test/ + androidTest/
│   │
│   ├── build.gradle.kts
│   └── proguard-rules.pro
│
├── build.gradle.kts                ← Root build file
├── settings.gradle.kts
├── gradle.properties
└── local.properties                ← SDK path, API keys (NEVER commit)
```

---

## 5. GRADLE DEPENDENCIES (build.gradle.kts)

### Root `build.gradle.kts`
```kotlin
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
```

### App `build.gradle.kts` — Full Dependency List
```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.hfynexus.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hfynexus.android"
        minSdk = 35
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // Reddit OAuth credentials (set in local.properties)
        buildConfigField("String", "REDDIT_CLIENT_ID", "\"${project.property("REDDIT_CLIENT_ID")}\"")
        buildConfigField("String", "REDDIT_REDIRECT_URI", "\"hfynexus://oauth2callback\"")
        buildConfigField("String", "HFY_BASE_URL", "\"https://hfy.foundation\"")
        buildConfigField("String", "IMAGE_GEN_URL", "\"https://image.pollinations.ai/prompt/\"")
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/LICENSE*"
        }
    }

    signingConfigs {
        create("release") {
            storeFile = file("../hfy_nexus_release.jks")
            storePassword = project.property("STORE_PASSWORD") as String
            keyAlias = "hfynexus"
            keyPassword = project.property("KEY_PASSWORD") as String
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.01.00")
    implementation(composeBom)

    // ── Compose Core ──────────────────────────────────────────────────
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.animation:animation-graphics")
    implementation("androidx.compose.foundation:foundation")

    // ── Activity & Lifecycle ──────────────────────────────────────────
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")

    // ── Navigation ────────────────────────────────────────────────────
    implementation("androidx.navigation:navigation-compose:2.8.4")

    // ── Hilt DI ───────────────────────────────────────────────────────
    implementation("com.google.dagger:hilt-android:2.52")
    ksp("com.google.dagger:hilt-android-compiler:2.52")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
    implementation("androidx.hilt:hilt-work:1.2.0")

    // ── Room Database ─────────────────────────────────────────────────
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // ── DataStore ─────────────────────────────────────────────────────
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // ── Networking ────────────────────────────────────────────────────
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.retrofit2:converter-moshi:2.11.0")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.1")
    ksp("com.squareup.moshi:moshi-kotlin-codegen:1.15.1")

    // ── HTML Scraping ─────────────────────────────────────────────────
    implementation("org.jsoup:jsoup:1.17.2")

    // ── Image Loading ─────────────────────────────────────────────────
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-gif:2.7.0")

    // ── Animations ────────────────────────────────────────────────────
    implementation("com.airbnb.android:lottie-compose:6.4.1")

    // ── WorkManager ───────────────────────────────────────────────────
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // ── EPUB Generation ───────────────────────────────────────────────
    // epublib-android: Add via JitPack (see local.properties note)
    implementation("nl.siegmann.epublib:epublib-core:3.1")
    // OR via JitPack:
    // implementation("com.github.psiegman:epublib:3.1")

    // ── Paging (Infinite Scroll) ──────────────────────────────────────
    implementation("androidx.paging:paging-runtime-ktx:3.3.2")
    implementation("androidx.paging:paging-compose:3.3.2")

    // ── Accompanist ───────────────────────────────────────────────────
    implementation("com.google.accompanist:accompanist-systemuicontroller:0.34.0")
    implementation("com.google.accompanist:accompanist-placeholder-material3:0.34.0")

    // ── Shimmer Loading Effect ─────────────────────────────────────────
    implementation("com.valentinilk.shimmer:compose-shimmer:1.3.0")

    // ── Custom Color Picker (Theme Builder) ───────────────────────────
    implementation("com.github.skydoves:colorpicker-compose:1.1.2")

    // ── Kotlin Coroutines ─────────────────────────────────────────────
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // ── Debug Tools ───────────────────────────────────────────────────
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    // ── Testing ───────────────────────────────────────────────────────
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.mockito.kotlin:mockito-kotlin:5.4.0")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
```

### `settings.gradle.kts` — JitPack for EPUB lib
```kotlin
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
        maven { url = uri("https://repo1.maven.org/maven2/") }
    }
}
```

---

## 6. DATA LAYER — API INTEGRATION PLAN

### 6.1 — HFY Foundation API
`hfy.foundation` exposes a REST-like API. Scrape the following endpoints:

```kotlin
// Primary series list (sorted by chapter count)
GET https://hfy.foundation/api/series?sort=chapters_highest&page=1&limit=20

// Series detail
GET https://hfy.foundation/api/series/{seriesId}

// Chapters list for a series
GET https://hfy.foundation/api/series/{seriesId}/chapters

// Search (USE THIS — do NOT re-implement search)
GET https://hfy.foundation/api/search?q={query}&page=1
```

**JSoup Scraper fallback** — if the API changes or returns errors:
```kotlin
// Scrape the HTML page directly
val doc = Jsoup.connect("https://hfy.foundation/series?sort=chapters_highest&page=$page")
    .userAgent("HFYNexus/1.0 (Android; Educational)")
    .timeout(10_000)
    .get()

val seriesList = doc.select(".series-card").map { el ->
    Series(
        id = el.attr("data-id"),
        title = el.select(".series-title").text(),
        author = el.select(".series-author").text(),
        chapterCount = el.select(".chapter-count").text().toIntOrNull() ?: 0,
        url = "https://hfy.foundation" + el.select("a").attr("href")
    )
}
```

### 6.2 — Reddit Wiki Parser
```kotlin
// Fetch r/HFY series wiki (live, not cached)
GET https://www.reddit.com/r/HFY/wiki/series.json

// Parse the markdown content:
// Each line format: * [Series Title](reddit_post_url) by u/AuthorName
val wikiContent = response.data.content_md
val regex = Regex("""\* \[(.+?)\]\((.+?)\).*by u/(\S+)""")
val seriesList = regex.findAll(wikiContent).map { match ->
    Series(
        title = match.groupValues[1],
        url = match.groupValues[2],
        author = match.groupValues[3],
        source = Source.REDDIT_WIKI
    )
}.toList()
```

### 6.3 — Reddit Post Content Fetching
```kotlin
// Fetch a single Reddit post as JSON (no auth required for public posts)
GET https://www.reddit.com/r/HFY/comments/{postId}.json?raw_json=1

// With OAuth (preferred — higher rate limits):
GET https://oauth.reddit.com/r/HFY/comments/{postId}
Headers: Authorization: Bearer {access_token}

// Extract post body:
val postBody = response[0].data.children[0].data.selftext
// selftext is Markdown — convert to HTML with a Markdown parser
```

### 6.4 — Dual-Source Strategy (hfy.foundation + Reddit)
```kotlin
class SeriesRepository @Inject constructor(
    private val hfyApiService: HFYApiService,
    private val hfyScraper: HFYScraper,
    private val redditApiService: RedditApiService,
    private val redditScraper: RedditScraper,
    private val seriesDao: SeriesDao
) {
    fun getSeriesList(page: Int, source: DataSource): Flow<PagingData<Series>> {
        return Pager(
            config = PagingConfig(pageSize = 20, enablePlaceholders = false),
            pagingSourceFactory = {
                SeriesPagingSource(
                    fetchPage = { pageNum ->
                        // Try primary source first, fallback to secondary
                        runCatching { hfyApiService.getSeriesList(pageNum) }
                            .getOrElse {
                                hfyScraper.scrapeSeriesList(pageNum)
                            }
                    }
                )
            }
        ).flow
    }
}
```

---

## 7. REDDIT OAUTH 2.0 IMPLEMENTATION

### 7.1 — OAuth Flow (PKCE for Installed Apps)
```kotlin
// AndroidManifest.xml — Register custom URI scheme
<activity android:name=".ui.screens.auth.RedditAuthActivity">
    <intent-filter>
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="hfynexus" android:host="oauth2callback" />
    </intent-filter>
</activity>
```

```kotlin
// RedditOAuthManager.kt
object RedditOAuthManager {
    const val CLIENT_ID = BuildConfig.REDDIT_CLIENT_ID
    const val REDIRECT_URI = "hfynexus://oauth2callback"
    const val SCOPE = "read history identity"

    fun buildAuthUrl(state: String): String {
        return "https://www.reddit.com/api/v1/authorize.compact?" +
            "client_id=$CLIENT_ID" +
            "&response_type=code" +
            "&state=$state" +
            "&redirect_uri=${Uri.encode(REDIRECT_URI)}" +
            "&duration=permanent" +
            "&scope=${Uri.encode(SCOPE)}"
    }

    // Token exchange
    suspend fun exchangeCode(code: String): OAuthToken {
        val credentials = Credentials.basic(CLIENT_ID, "")  // No secret for installed apps
        return redditAuthService.getToken(
            authorization = credentials,
            grantType = "authorization_code",
            code = code,
            redirectUri = REDIRECT_URI
        )
    }

    // Refresh token
    suspend fun refreshToken(refreshToken: String): OAuthToken {
        val credentials = Credentials.basic(CLIENT_ID, "")
        return redditAuthService.refreshToken(
            authorization = credentials,
            grantType = "refresh_token",
            refreshToken = refreshToken
        )
    }
}
```

### 7.2 — Token Storage (DataStore)
```kotlin
// Store tokens securely
suspend fun saveToken(token: OAuthToken) {
    dataStore.edit { prefs ->
        prefs[ACCESS_TOKEN_KEY] = token.accessToken
        prefs[REFRESH_TOKEN_KEY] = token.refreshToken
        prefs[EXPIRY_KEY] = System.currentTimeMillis() + (token.expiresIn * 1000)
    }
}

// Auto-refresh interceptor
class AuthInterceptor @Inject constructor(
    private val tokenManager: TokenManager
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = runBlocking { tokenManager.getValidToken() }
        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer $token")
            .addHeader("User-Agent", "android:com.hfynexus.android:v1.0 (by /u/HFYNexusApp)")
            .build()
        return chain.proceed(request)
    }
}
```

### 7.3 — Scraper Fallback (No Auth)
```kotlin
// When OAuth fails or user is not logged in
class RedditScraper @Inject constructor(private val okHttpClient: OkHttpClient) {

    suspend fun fetchPostContent(postUrl: String): String {
        // Append .json to any Reddit URL
        val jsonUrl = postUrl.trimEnd('/') + ".json?raw_json=1"
        val request = Request.Builder()
            .url(jsonUrl)
            .header("User-Agent", "android:com.hfynexus.android:v1.0")
            .build()

        val response = okHttpClient.newCall(request).await()
        val body = response.body?.string() ?: throw Exception("Empty response")

        val json = JSONArray(body)
        val post = json.getJSONObject(0)
            .getJSONObject("data")
            .getJSONArray("children")
            .getJSONObject(0)
            .getJSONObject("data")

        return post.getString("selftext")
    }
}
```

---

## 8. SCREEN-BY-SCREEN UI SPECIFICATION

### 8.1 — SPLASH SCREEN
```
VISUAL:
  - Deep black background (#0A0A0F)
  - Central app logo animates in with glitch effect
  - Animated scan lines sweep top-to-bottom
  - Loading bar at bottom with "INITIALIZING CYBERDECK..." text
  - Binary data rain effect (subtle, background layer)
  - Corner bracket animations that draw in from corners
  
BEHAVIOR:
  - Duration: 2.5s
  - Preloads: theme preference, auth state, cached series list
  - Transition: glitch wipe to Browse Screen
```

### 8.2 — BROWSE SCREEN (Main Screen)
```
HEADER:
  - App logo (top-left), teal neon glow
  - "SERIES DATABASE // LIVE FEED" subtitle in small caps
  - Filter/sort chip row: CHAPTERS_HIGH, NEWEST, ALPHABETICAL, REDDIT, HFY.FOUNDATION
  - View toggle: [LIST] [GRID] [TILE] (icon buttons, angular cyberpunk style)
  
SERIES LIST (infinite scroll):
  - Default: LIST view
  - Each item shows:
    * Auto-generated cover icon (left, 80x80dp, angular frame)
    * Series title (primary font, neon teal or white)
    * Author name (secondary, smaller, dim)
    * Chapter count (badge, neon red)
    * Progress indicator (if started reading)
    * Bookmark icon (toggle favorite)
    * Source badge: [HFY.F] or [REDDIT]
  
  - Infinite scroll: LazyColumn + Paging3
  - On scroll to bottom: auto-load next page with shimmer placeholder
  - Pull-to-refresh: glitch animation while refreshing
  
FLOATING ACTION BUTTON:
  - Neon pulsing [SEARCH] button (uses hfy.foundation's own search)
  
BOTTOM NAVIGATION:
  - 5 tabs: BROWSE | LIBRARY | DOWNLOADS | READER | SETTINGS
  - Each tab icon: custom cyberpunk SVG icon
  - Active tab: neon glow + underline scan effect
  - Tab switch: slide + glitch transition animation
```

### 8.3 — SEARCH SCREEN
```
DESIGN:
  - Full-screen search interface
  - Angular search bar with neon border, cursor blink animation
  - "SCANNING DATABASE..." placeholder text
  - Results appear live as user types (300ms debounce)
  - Calls: GET https://hfy.foundation/api/search?q={query}
  - Results styled identically to Browse list items
  - Recent searches: stored locally, shown as chips
  - "NO SIGNAL" empty state with animated static effect
  
NOTE: Do NOT implement custom search logic —
      pipe directly to hfy.foundation's search endpoint.
```

### 8.4 — SERIES DETAIL SCREEN
```
HEADER:
  - Full-width AI-generated cover art (blurred as background)
  - Angular overlay with series metadata:
    * Title (large, glitch font)
    * Author (with auto-generated author icon/symbol)
    * Chapter count, word count estimate
    * Tags/flair from Reddit
    * Source links: [OPEN ON REDDIT] [OPEN ON HFY.FOUNDATION]

CHAPTER LIST:
  - Scrollable list of all chapters
  - Each chapter row:
    * Chapter number + title/post title
    * Word count
    * Date posted
    * Read/Unread indicator (neon dot)
    * "DOWNLOAD THIS CHAPTER" button
  
ACTION PANEL (sticky bottom):
  - [▶ READ FROM START]          ← Opens reader at chapter 1
  - [↓ DOWNLOAD ENTIRE SERIES]  ← Queues full download as EPUB
  - [★ BOOKMARK]                 ← Toggle library
  - [↓ CHOOSE FORMAT: EPUB / TXT]
  
DOWNLOAD OPTIONS SHEET:
  - EPUB (full series, formatted, with cover)
  - TXT (plain text, all chapters concatenated)
  - Individual chapters (select from list)
  - Include cover image: YES/NO
  - Custom EPUB title override
```

### 8.5 — READER SCREEN
```
UI MODE: Immersive (status bar hidden, edge-to-edge)

TOP BAR (auto-hide after 3s):
  - Back button, series title, chapter X of N
  - Progress bar (thin, neon)

READING AREA:
  - LazyColumn of text paragraphs
  - Font: user-selected (from font settings)
  - Font size: user-adjustable (12sp–28sp via settings or gesture)
  - Line spacing: adjustable
  - Background: 6 presets (Pure Black, Dark Navy, Dark Teal, Sepia, Pure White, Custom)
  - Text color: matches background preset or custom

BOTTOM BAR (auto-hide):
  - [← PREV CHAPTER] [CHAPTER X / N] [NEXT CHAPTER →]
  - Slider: scroll position within chapter

READING PROGRESS:
  - Auto-saved every 30 seconds to Room DB
  - Saved: series ID, chapter ID, scroll position, timestamp

SIDE SWIPE GESTURE:
  - Swipe left: next chapter
  - Swipe right: previous chapter
  - Two-finger pinch: adjust font size

READER SETTINGS OVERLAY:
  - Font picker (slide-up sheet)
  - Text size slider
  - Line height slider
  - Letter spacing slider
  - Background picker
  - Brightness slider (in-app only)
```

### 8.6 — LIBRARY / FAVORITES SCREEN
```
SECTIONS:
  1. CURRENTLY READING   ← In-progress with resume button
  2. BOOKMARKED SERIES   ← Starred series
  3. COMPLETED           ← 100% read
  4. DOWNLOADED FILES    ← Local EPUB/TXT files

Each section is a horizontal scroll row or vertical list (toggle)
Context menu on long press:
  - Remove from library
  - Mark as complete
  - Delete download
  - Share
```

### 8.7 — DOWNLOAD QUEUE SCREEN
```
HEADER: "DOWNLOAD QUEUE // [N] ACTIVE JOBS"

ACTIVE DOWNLOADS:
  - Each job shows:
    * Series title + format (EPUB/TXT)
    * Animated progress bar (neon, segmented like a loading bar)
    * Chapters downloaded: X / N
    * Speed indicator (KB/s)
    * ETA
    * [PAUSE] [CANCEL] buttons

COMPLETED:
  - List of completed downloads
  - Tap to open file, share, or delete

QUEUE CONTROLS:
  - [PAUSE ALL] [RESUME ALL] [CLEAR COMPLETED]
  
BACKGROUND BEHAVIOR:
  - Downloads continue in background via WorkManager
  - Notification with progress bar when screen is closed
```

### 8.8 — SETTINGS SCREEN
```
SECTIONS:
  1. APPEARANCE
     - Theme selector (6 presets + custom)
     - [OPEN THEME BUILDER] → custom theme editor
     - Primary accent color picker
     - Secondary accent color picker
     - Background darkness slider
     - Enable/disable: scanlines, glitch effects, animations, particle FX
     - App icon variant selector (3 options)

  2. READER DEFAULTS
     - Default font (dropdown, 30+ fonts)
     - Default font size
     - Default line height
     - Default background
     - Auto-advance chapters: YES/NO
     - Screen timeout override: YES/NO (keep screen on while reading)

  3. DOWNLOAD SETTINGS
     - Default format: EPUB / TXT / Ask each time
     - Save location: Internal / Downloads / Custom path
     - Include cover image in EPUB: YES/NO
     - Max concurrent downloads: 1 / 2 / 3
     - Download on WiFi only: YES/NO
     - Auto-retry failed downloads: YES/NO

  4. CONTENT SOURCES
     - Primary source: hfy.foundation / Reddit Wiki / Both
     - Reddit OAuth: [CONNECT ACCOUNT] or [CONNECTED as u/username]
     - Cache TTL for series list: 1h / 6h / 24h
     - [CLEAR CACHE]
     - [REFRESH SERIES LIST]

  5. AI COVER IMAGES
     - Enable AI cover generation: YES/NO
     - API provider: Pollinations (free) / Stability AI (API key)
     - [Enter Stability AI API Key]
     - Regenerate all covers: [RUN]
     - Delete all cached AI images: [CLEAR]

  6. ABOUT
     - App version, build number
     - [CHECK FOR UPDATES]
     - [OPEN SOURCE LICENSES]
     - Source repos credited
```

---

## 9. CYBERPUNK UI DESIGN SYSTEM

### 9.1 — Color Palette (All Themes)

#### Theme 1: NIGHT CITY (Default — CP2077 Dark)
```kotlin
object NightCityColors {
    val Background        = Color(0xFF0A0A0F)   // Near-black with blue tint
    val SurfaceContainer  = Color(0xFF0F0F1A)
    val SurfaceVariant    = Color(0xFF161626)
    val NeonRed           = Color(0xFFFF003C)   // Primary accent
    val NeonRedDim        = Color(0xFFCC0030)
    val NeonTeal          = Color(0xFF00FFCC)   // Secondary accent
    val NeonTealDim       = Color(0xFF00CC9E)
    val NeonYellow        = Color(0xFFFFE800)   // Tertiary accent
    val NeonOrange        = Color(0xFFFF6B00)
    val NeonPurple        = Color(0xFFBB00FF)
    val White             = Color(0xFFE8E8F0)
    val TextPrimary       = Color(0xFFE8E8F0)
    val TextSecondary     = Color(0xFF8888AA)
    val TextDim           = Color(0xFF444466)
    val BorderPrimary     = NeonRed
    val BorderSecondary   = NeonTeal
    val GlowRed           = NeonRed.copy(alpha = 0.3f)
    val GlowTeal          = NeonTeal.copy(alpha = 0.3f)
    val ScanlineColor     = Color(0xFF00FFCC).copy(alpha = 0.03f)
    val ErrorColor        = Color(0xFFFF0000)
    val SuccessColor      = Color(0xFF00FF44)
    val WarningColor      = NeonYellow
}
```

#### Theme 2: SAMURAI RED (Hot Pink/Red/Black)
```kotlin
val Primary    = Color(0xFFFF0080)
val Secondary  = Color(0xFFFF3333)
val Background = Color(0xFF080808)
val Accent     = Color(0xFFFFFFFF)
```

#### Theme 3: NETRUNNER BLUE (Cyan/Blue/Dark)
```kotlin
val Primary    = Color(0xFF00CCFF)
val Secondary  = Color(0xFF0066FF)
val Background = Color(0xFF04080F)
val Accent     = Color(0xFF00FFFF)
```

#### Theme 4: CORPO GREEN (Terminal/Matrix)
```kotlin
val Primary    = Color(0xFF00FF44)
val Secondary  = Color(0xFF009922)
val Background = Color(0xFF001100)
val Accent     = Color(0xFF88FF88)
```

#### Theme 5: ARASAKA GOLD (Amber/Gold/Dark)
```kotlin
val Primary    = Color(0xFFFFB300)
val Secondary  = Color(0xFFFF6600)
val Background = Color(0xFF0A0800)
val Accent     = Color(0xFFFFDD55)
```

#### Theme 6: STELLARIS IMPERIAL (Purple/Blue sci-fi)
```kotlin
val Primary    = Color(0xFFBB44FF)
val Secondary  = Color(0xFF6644CC)
val Background = Color(0xFF060410)
val Accent     = Color(0xFFDDAAFF)
```

### 9.2 — Shapes (Angular Cyberpunk Geometry)
```kotlin
// Angular cut-corner shape (signature CP2077 look)
val CyberpunkShapes = Shapes(
    small = GenericShape { size, _ ->
        // 4dp cut corner (top-right + bottom-left)
        val cut = 12f
        moveTo(cut, 0f)
        lineTo(size.width, 0f)
        lineTo(size.width, size.height - cut)
        lineTo(size.width - cut, size.height)
        lineTo(0f, size.height)
        lineTo(0f, cut)
        close()
    },
    medium = GenericShape { size, _ ->
        val cut = 20f
        moveTo(cut, 0f)
        lineTo(size.width, 0f)
        lineTo(size.width, size.height - cut)
        lineTo(size.width - cut, size.height)
        lineTo(0f, size.height)
        lineTo(0f, cut)
        close()
    },
    large = GenericShape { size, _ ->
        val cut = 32f
        moveTo(cut, 0f)
        lineTo(size.width, 0f)
        lineTo(size.width, size.height - cut)
        lineTo(size.width - cut, size.height)
        lineTo(0f, size.height)
        lineTo(0f, cut)
        close()
    }
)
```

### 9.3 — UI Component Library

#### NeonBorderBox — Core Panel Component
```kotlin
@Composable
fun NeonBorderBox(
    modifier: Modifier = Modifier,
    borderColor: Color = NightCityColors.NeonTeal,
    glowRadius: Dp = 8.dp,
    cornerCutDp: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val cutPx = with(LocalDensity.current) { cornerCutDp.toPx() }
    Box(
        modifier = modifier
            .drawBehind {
                // Draw neon glow shadow
                drawIntoCanvas { canvas ->
                    val paint = Paint().apply {
                        asFrameworkPaint().apply {
                            isAntiAlias = true
                            color = android.graphics.Color.TRANSPARENT
                            setShadowLayer(glowRadius.toPx(), 0f, 0f, borderColor.toArgb())
                        }
                    }
                    canvas.drawPath(angularPath(size, cutPx), paint)
                }
                // Draw the angular border
                drawPath(
                    path = angularPath(size, cutPx),
                    color = borderColor,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
    ) {
        content()
    }
}

private fun angularPath(size: Size, cut: Float): androidx.compose.ui.graphics.Path {
    return Path().apply {
        moveTo(cut, 0f)
        lineTo(size.width, 0f)
        lineTo(size.width, size.height - cut)
        lineTo(size.width - cut, size.height)
        lineTo(0f, size.height)
        lineTo(0f, cut)
        close()
    }
}
```

#### GlitchText — Animated Glitch Effect
```kotlin
@Composable
fun GlitchText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    glitchColor1: Color = NightCityColors.NeonRed,
    glitchColor2: Color = NightCityColors.NeonTeal,
    glitchIntensity: Float = 0.3f   // 0f = no glitch, 1f = heavy
) {
    var glitchOffset by remember { mutableStateOf(Offset.Zero) }
    var showGlitch by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay((500..3000).random().toLong())
            showGlitch = true
            glitchOffset = Offset(
                x = (-6..6).random().toFloat() * glitchIntensity,
                y = (-2..2).random().toFloat() * glitchIntensity
            )
            delay(80)
            showGlitch = false
            delay(50)
            showGlitch = true
            delay(50)
            showGlitch = false
        }
    }

    Box(modifier = modifier) {
        // Chromatic aberration layers
        if (showGlitch) {
            Text(text, style = style.copy(color = glitchColor1),
                modifier = Modifier.offset(x = (-glitchOffset.x).dp, y = glitchOffset.y.dp))
            Text(text, style = style.copy(color = glitchColor2),
                modifier = Modifier.offset(x = glitchOffset.x.dp, y = (-glitchOffset.y).dp))
        }
        // Main text
        Text(text, style = style)
    }
}
```

#### ScanlineOverlay — CRT Effect
```kotlin
@Composable
fun ScanlineOverlay(modifier: Modifier = Modifier, alpha: Float = 0.04f) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val lineSpacing = 4f
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Color.Black.copy(alpha = alpha),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 2f
            )
            y += lineSpacing
        }
    }
}
```

#### CornerBrackets — HUD Framing
```kotlin
@Composable
fun CornerBrackets(
    modifier: Modifier = Modifier,
    color: Color = NightCityColors.NeonTeal,
    size: Dp = 16.dp,
    strokeWidth: Dp = 2.dp
) {
    Canvas(modifier = modifier) {
        val s = size.toPx()
        val sw = strokeWidth.toPx()
        val paint = androidx.compose.ui.graphics.drawscope.DrawScope::drawLine
        // Top-left
        drawLine(color, Offset(0f, s), Offset(0f, 0f), sw)
        drawLine(color, Offset(0f, 0f), Offset(s, 0f), sw)
        // Top-right
        drawLine(color, Offset(this.size.width - s, 0f), Offset(this.size.width, 0f), sw)
        drawLine(color, Offset(this.size.width, 0f), Offset(this.size.width, s), sw)
        // Bottom-left
        drawLine(color, Offset(0f, this.size.height - s), Offset(0f, this.size.height), sw)
        drawLine(color, Offset(0f, this.size.height), Offset(s, this.size.height), sw)
        // Bottom-right
        drawLine(color, Offset(this.size.width - s, this.size.height), Offset(this.size.width, this.size.height), sw)
        drawLine(color, Offset(this.size.width, this.size.height - s), Offset(this.size.width, this.size.height), sw)
    }
}
```

#### CyberpunkButton
```kotlin
@Composable
fun CyberpunkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accentColor: Color = NightCityColors.NeonTeal,
    isDestructive: Boolean = false
) {
    val color = if (isDestructive) NightCityColors.NeonRed else accentColor
    val pressed = remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .clickable {
                pressed.value = true
                onClick()
            }
            .background(color = color.copy(alpha = if (pressed.value) 0.2f else 0.1f))
            .then(
                Modifier.drawBehind {
                    drawPath(angularPath(size, 8f), color = color, style = Stroke(1.5f))
                }
            )
            .padding(horizontal = 20.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.uppercase(),
            color = color,
            style = CyberpunkTypography.labelLarge,
            letterSpacing = 2.sp
        )
    }
}
```

### 9.4 — Bottom Navigation Bar
```kotlin
val navItems = listOf(
    NavItem("BROWSE",    Icons.Custom.Hexagon,    Screen.Browse),
    NavItem("LIBRARY",   Icons.Custom.Archive,    Screen.Library),
    NavItem("DOWNLOADS", Icons.Custom.Download,   Screen.Downloads),
    NavItem("READER",    Icons.Custom.DataStream, Screen.Reader),
    NavItem("SETTINGS",  Icons.Custom.Gear,       Screen.Settings)
)
// Style: Dark background, neon teal active indicator, angular clip on selected item
// Active indicator: animated underline sweep + icon glow
```

---

## 10. FONT LIBRARY — 30+ SCI-FI FONTS

Include ALL the following fonts in `/res/font/` as `.ttf` files.  
Download sources: **Google Fonts** (free), **DaFont** (free for personal use), **FontSquirrel**.

### Primary UI Fonts (Cyberpunk-inspired)
| Font Name | Style | Use Case |
|-----------|-------|----------|
| Orbitron | Geometric sans | Headers, badges, titles |
| Share Tech Mono | Monospace | Data readouts, binary text |
| Rajdhani | Condensed sans | Section labels, subtitles |
| Exo 2 | Geometric | Body text, UI labels |
| Russo One | Bold block | Big numbers, XP bars |
| Quantico | Technical sans | Navigation items |
| Nova Square | Squared | Series titles |
| Syncopate | Wide caps | Screen section headers |
| Aldrich | Angular | Stats, metadata |
| Blender Pro | Wide Gothic | CP2077-like headings |

### Sci-Fi / Futuristic Fonts
| Font Name | Style | Use Case |
|-----------|-------|----------|
| Zero Hour | Stencil sci-fi | Splash screen branding |
| Audiowide | Round sci-fi | App name |
| Nasalization | NASA-style | Technical labels |
| Electrolize | Clean tech | Reading body text |
| Michroma | Angular caps | Navigation |
| Kode Mono | Monospace code | Code-like decorations |
| Courier Prime | Typewriter mono | TXT format indicator |
| Space Grotesk | Modern minimal | Clean body text |
| Space Mono | Retro mono | Chapter metadata |
| VT323 | CRT terminal | Glitch/terminal decoration |

### Stellaris-Inspired Fonts
| Font Name | Style | Use Case |
|-----------|-------|----------|
| Cinzel | Roman serif | Empire-style titles |
| Marcellus SC | Small caps serif | Lore-style headers |
| Forum | Classic roman | Stellaris-like headers |
| Unbounded | Wide geometric | Stellaris subtitle style |
| Jura | Light technical | Soft sci-fi body |

### Reader Fonts (Comfortable Reading)
| Font Name | Style | Use Case |
|-----------|-------|----------|
| Lora | Serif | Reader default option |
| Literata | Designed for screens | Recommended reader font |
| Merriweather | Serif | Classic reader option |
| Source Serif 4 | Clear serif | High-legibility option |
| Roboto | Sans | Clean sans reader option |
| Open Sans | Sans | Casual reader option |
| Noto Sans | Multilingual sans | Broad character support |

### How to Bundle Fonts for Size
```kotlin
// res/font/fonts.xml — Custom font families
<?xml version="1.0" encoding="utf-8"?>
<font-family xmlns:android="http://schemas.android.com/apk/res/android">
    <font android:fontStyle="normal" android:fontWeight="400"
          android:font="@font/orbitron_regular" />
    <font android:fontStyle="normal" android:fontWeight="700"
          android:font="@font/orbitron_bold" />
</font-family>

// In Compose:
val OrbitronFont = FontFamily(
    Font(R.font.orbitron_regular, FontWeight.Normal),
    Font(R.font.orbitron_bold, FontWeight.Bold),
    Font(R.font.orbitron_black, FontWeight.Black)
)
```

---

## 11. ANIMATION & MOTION SYSTEM

### 11.1 — Screen Transitions
```kotlin
// AppNavGraph.kt — All screen transitions use glitch-slide
NavHost(
    navController = navController,
    enterTransition = {
        slideInHorizontally(
            initialOffsetX = { fullWidth -> fullWidth },
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
        ) + fadeIn(animationSpec = tween(200))
    },
    exitTransition = {
        slideOutHorizontally(
            targetOffsetX = { fullWidth -> -fullWidth / 3 }
        ) + fadeOut(animationSpec = tween(150))
    }
)
```

### 11.2 — Loading Animations (Lottie)
Create/source these Lottie JSON files (placed in `res/raw/`):
- `lottie_scanning.json` — Radar sweep / scan animation
- `lottie_download.json` — Data stream download animation  
- `lottie_glitch.json` — Screen glitch effect
- `lottie_boot.json` — Cyberdeck boot sequence for splash
- `lottie_neon_pulse.json` — Pulsing neon ring

```kotlin
@Composable
fun LoadingScanner(modifier: Modifier = Modifier) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.lottie_scanning))
    LottieAnimation(
        composition = composition,
        iterations = LottieConstants.IterateForever,
        modifier = modifier.size(120.dp)
    )
}
```

### 11.3 — Continuous Background Animations
```kotlin
// Animated scan line that sweeps top to bottom
@Composable
fun AnimatedScanBeam(color: Color = NightCityColors.NeonTeal) {
    val infiniteTransition = rememberInfiniteTransition()
    val yPosition by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, color.copy(alpha = 0.4f), Color.Transparent)
            ),
            start = Offset(0f, size.height * yPosition),
            end = Offset(size.width, size.height * yPosition),
            strokeWidth = 2.dp.toPx()
        )
    }
}

// Data stream text (binary decoration)
@Composable
fun DataStreamDecor(modifier: Modifier = Modifier) {
    val chars = remember { "01ABCDEF2456789" }
    // Generates columns of falling characters like Matrix rain
    // Lightweight: draws only visible columns, updates at 10fps
}
```

### 11.4 — Item Entrance Animations
```kotlin
@Composable
fun AnimatedSeriesItem(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 30L)  // Stagger delay
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally(
            initialOffsetX = { -40 },
            animationSpec = spring(stiffness = Spring.StiffnessLow)
        ) + fadeIn()
    ) {
        content()
    }
}
```

---

## 12. THEME ENGINE — PRESETS + CUSTOM BUILDER

### 12.1 — Theme Data Model
```kotlin
@Entity(tableName = "user_themes")
data class UserTheme(
    @PrimaryKey val id: String,
    val name: String,
    val primaryColor: Long,        // Color as ARGB Long
    val secondaryColor: Long,
    val backgroundColor: Long,
    val surfaceColor: Long,
    val textPrimaryColor: Long,
    val textSecondaryColor: Long,
    val accentColor: Long,
    val enableScanlines: Boolean = true,
    val enableGlitch: Boolean = true,
    val enableAnimations: Boolean = true,
    val enableParticles: Boolean = false,
    val fontFamily: String = "orbitron",
    val borderStyle: String = "angular",  // angular | rounded | sharp
    val isBuiltIn: Boolean = false
)
```

### 12.2 — Theme Builder Screen (In-App)
```
LAYOUT:
  [Live Preview Area] (top 40% of screen)
     Shows a mini version of the Browse screen with current colors applied

  [Color Pickers] (using skydoves/colorpicker-compose)
     - Primary Accent Color
     - Secondary Accent Color
     - Background Color
     - Surface Color
     - Text Color

  [Sliders]
     - Scanline opacity (0–100%)
     - Glow intensity (0–100%)
     - Animation speed (0.5x – 2x)

  [Toggles]
     - Enable Scanlines
     - Enable Glitch Effects
     - Enable Particle FX
     - Enable Screen Shake on Errors

  [Font Picker]
     - Dropdown of all 30+ fonts
     - Live preview text: "HUMANITY FUCK YEAH"

  [Save As...] → Name your theme → Saved to Room DB
  [Export Theme Code] → Copies JSON to clipboard
  [Import Theme] → Paste JSON to apply
```

---

## 13. SERIES LIST BROWSING & INFINITE SCROLL

### 13.1 — PagingSource Implementation
```kotlin
class SeriesPagingSource(
    private val fetchPage: suspend (Int) -> List<Series>
) : PagingSource<Int, Series>() {

    override fun getRefreshKey(state: PagingState<Int, Series>): Int? {
        return state.anchorPosition?.let { anchor ->
            state.closestPageToPosition(anchor)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchor)?.nextKey?.minus(1)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Series> {
        return try {
            val page = params.key ?: 1
            val series = fetchPage(page)
            LoadResult.Page(
                data = series,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (series.isEmpty()) null else page + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }
}
```

### 13.2 — Infinite Scroll LazyColumn
```kotlin
@Composable
fun InfiniteSeriesList(pagingItems: LazyPagingItems<Series>) {
    LazyColumn {
        items(
            count = pagingItems.itemCount,
            key = pagingItems.itemKey { it.id }
        ) { index ->
            val series = pagingItems[index]
            if (series != null) {
                AnimatedSeriesItem(index = index) {
                    SeriesListItem(series = series)
                }
            } else {
                SeriesListItemSkeleton()  // Shimmer placeholder
            }
        }

        // Loading footer
        when (pagingItems.loadState.append) {
            is LoadState.Loading -> item {
                Box(Modifier.fillMaxWidth().padding(16.dp), Alignment.Center) {
                    LoadingScanner(modifier = Modifier.size(60.dp))
                }
            }
            is LoadState.Error -> item {
                RetryFooter { pagingItems.retry() }
            }
            else -> Unit
        }
    }
}
```

### 13.3 — View Mode: Grid Layout
```kotlin
// Resizable grid — 2, 3, or 4 columns
LazyVerticalGrid(
    columns = GridCells.Fixed(userPrefs.gridColumns),  // 2–4
    contentPadding = PaddingValues(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
) {
    items(pagingItems.itemCount) { index ->
        SeriesGridItem(series = pagingItems[index]!!)
    }
}
```

---

## 14. DOWNLOAD ENGINE — EPUB & TXT GENERATION

### 14.1 — EPUB Builder (based on epublib + hfy2epub logic)
```kotlin
class EpubBuilder @Inject constructor(
    private val chapterFetcher: ChapterFetcher,
    private val imageGenService: ImageGenService
) {
    suspend fun buildEpub(series: Series, chapters: List<Chapter>): File {
        val book = Book()

        // Metadata
        book.metadata.addTitle(series.title)
        book.metadata.addAuthor(Author(series.author))
        book.metadata.addDescription("HFY Series — Downloaded by HFY Nexus")
        book.metadata.addDate(Date(Calendar.getInstance().time, Date.Event.PUBLICATION))

        // Cover image (AI generated or placeholder)
        val coverBitmap = imageGenService.getCoverImage(series)
        val coverStream = ByteArrayOutputStream().also { coverBitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        val coverResource = Resource(coverStream.toByteArray(), MediaType.JPEG, "cover.jpg")
        book.coverImage = coverResource

        // CSS styling for EPUB
        val cssContent = buildEpubCss()
        val cssResource = Resource(cssContent.toByteArray(), "Styles/style.css")
        book.resources.add(cssResource)
        book.spine.addFirst(SpineReference(cssResource))

        // Chapter content
        chapters.forEachIndexed { index, chapter ->
            val markdownContent = chapterFetcher.fetchChapterContent(chapter.redditUrl)
            val htmlContent = markdownToHtml(markdownContent, chapter.title, index + 1)
            val chapterResource = Resource(
                htmlContent.toByteArray(Charsets.UTF_8),
                "Text/chapter_${index + 1}.html"
            )
            book.addSection(chapter.title, chapterResource)
        }

        // Write to file
        val outputDir = getEpubDirectory()
        val fileName = sanitizeFilename("${series.title}_by_${series.author}.epub")
        val outputFile = File(outputDir, fileName)

        EpubWriter().write(book, FileOutputStream(outputFile))
        return outputFile
    }

    private fun buildEpubCss(): String = """
        body {
            font-family: Georgia, 'Times New Roman', serif;
            margin: 5% auto;
            max-width: 800px;
            line-height: 1.8;
            color: #1a1a1a;
            font-size: 1em;
        }
        h1 { font-size: 2em; margin-bottom: 0.5em; }
        h2 { font-size: 1.5em; color: #333; }
        p { margin: 0.8em 0; text-indent: 1.5em; }
        hr { border: none; border-top: 1px solid #ccc; margin: 2em 0; }
        .chapter-title { font-size: 1.3em; font-weight: bold; margin-bottom: 1em; }
    """.trimIndent()

    private fun markdownToHtml(markdown: String, title: String, chapterNum: Int): String {
        // Convert Reddit markdown to clean HTML
        // Use a Markdown library or simple regex replacements
        val body = markdown
            .replace(Regex("""^#{1,6}\s+(.+)$""", RegexOption.MULTILINE)) { "<h2>${it.groupValues[1]}</h2>" }
            .replace(Regex("""\*\*(.+?)\*\*""")) { "<strong>${it.groupValues[1]}</strong>" }
            .replace(Regex("""\*(.+?)\*""")) { "<em>${it.groupValues[1]}</em>" }
            .replace(Regex("""\n\n"""), "</p><p>")
            .replace(Regex("""---+"""), "<hr/>")
            .replace(Regex("""\[([^\]]+)\]\(([^)]+)\)""")) { "<a href=\"${it.groupValues[2]}\">${it.groupValues[1]}</a>" }
            .let { "<p>$it</p>" }

        return """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Chapter $chapterNum</title>
    <link rel="stylesheet" type="text/css" href="../Styles/style.css"/>
</head>
<body>
    <h1 class="chapter-title">Chapter $chapterNum: $title</h1>
    $body
</body>
</html>"""
    }
}
```

### 14.2 — TXT Exporter
```kotlin
class TxtExporter @Inject constructor(private val chapterFetcher: ChapterFetcher) {

    suspend fun buildTxt(series: Series, chapters: List<Chapter>): File {
        val sb = StringBuilder()

        sb.appendLine("=" .repeat(60))
        sb.appendLine(series.title.uppercase())
        sb.appendLine("Author: ${series.author}")
        sb.appendLine("Chapters: ${chapters.size}")
        sb.appendLine("Downloaded by HFY Nexus // hfy.foundation")
        sb.appendLine("=" .repeat(60))
        sb.appendLine()

        chapters.forEachIndexed { index, chapter ->
            sb.appendLine("-".repeat(40))
            sb.appendLine("CHAPTER ${index + 1}: ${chapter.title}")
            sb.appendLine("-".repeat(40))
            sb.appendLine()

            val content = chapterFetcher.fetchChapterContent(chapter.redditUrl)
            // Strip markdown, keep readable text
            val plainText = stripMarkdown(content)
            sb.appendLine(plainText)
            sb.appendLine()
        }

        val outputFile = File(getTxtDirectory(), sanitizeFilename("${series.title}.txt"))
        outputFile.writeText(sb.toString(), Charsets.UTF_8)
        return outputFile
    }

    private fun stripMarkdown(text: String): String {
        return text
            .replace(Regex("""#{1,6}\s"""), "")
            .replace(Regex("""\*{1,2}([^*]+)\*{1,2}"""), "$1")
            .replace(Regex("""\[([^\]]+)\]\([^)]+\)"""), "$1")
            .replace(Regex("""^>\s""", RegexOption.MULTILINE), "  ")
            .replace(Regex("""`{1,3}[^`]*`{1,3}"""), "")
            .trim()
    }
}
```

---

## 15. DOWNLOAD QUEUE SYSTEM

### 15.1 — WorkManager Download Worker
```kotlin
@HiltWorker
class DownloadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val epubBuilder: EpubBuilder,
    private val txtExporter: TxtExporter,
    private val downloadRepository: DownloadRepository,
    private val notificationManager: DownloadNotificationManager
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val jobId = inputData.getString("JOB_ID") ?: return Result.failure()
        val job = downloadRepository.getJob(jobId) ?: return Result.failure()

        return try {
            setForeground(notificationManager.createForegroundInfo(job))

            // Fetch series and chapters
            val series = downloadRepository.getSeries(job.seriesId)
            val chapters = downloadRepository.getChapters(job.seriesId)

            // Update progress
            chapters.forEachIndexed { index, chapter ->
                // Update notification and DB
                downloadRepository.updateProgress(jobId, index + 1, chapters.size)
                notificationManager.updateProgress(jobId, index + 1, chapters.size)
            }

            // Generate file
            val outputFile = when (job.format) {
                DownloadFormat.EPUB -> epubBuilder.buildEpub(series, chapters)
                DownloadFormat.TXT  -> txtExporter.buildTxt(series, chapters)
            }

            downloadRepository.markComplete(jobId, outputFile.absolutePath)
            notificationManager.showComplete(job, outputFile)
            Result.success()

        } catch (e: Exception) {
            downloadRepository.markFailed(jobId, e.message ?: "Unknown error")
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}
```

### 15.2 — Enqueueing Downloads
```kotlin
fun enqueueDownload(job: DownloadJob) {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(
            if (userPrefs.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
        )
        .build()

    val request = OneTimeWorkRequestBuilder<DownloadWorker>()
        .setConstraints(constraints)
        .setInputData(workDataOf("JOB_ID" to job.id))
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
        .addTag("download_${job.id}")
        .build()

    WorkManager.getInstance(context)
        .beginUniqueWork(job.id, ExistingWorkPolicy.KEEP, request)
        .enqueue()
}
```

---

## 16. BUILT-IN READER SCREEN

### 16.1 — Reader State
```kotlin
data class ReaderState(
    val seriesId: String,
    val currentChapterIndex: Int,
    val chapters: List<Chapter>,
    val chapterContent: String,
    val scrollPosition: Int = 0,
    val fontFamily: FontFamily = OrbitronFont,
    val fontSize: TextUnit = 16.sp,
    val lineHeight: TextUnit = 26.sp,
    val letterSpacing: TextUnit = 0.sp,
    val backgroundColor: Color = Color(0xFF0A0A0F),
    val textColor: Color = Color(0xFFE8E8F0),
    val showControls: Boolean = true,
    val isLoading: Boolean = false,
    val brightness: Float = 1f
)
```

### 16.2 — Progress Auto-Save
```kotlin
// In ReaderViewModel
private var autoSaveJob: Job? = null

fun startAutoSave(seriesId: String) {
    autoSaveJob?.cancel()
    autoSaveJob = viewModelScope.launch {
        while (true) {
            delay(30_000)  // Every 30 seconds
            saveProgress()
        }
    }
}

fun saveProgress() {
    viewModelScope.launch {
        readingProgressDao.upsert(
            ReadingProgress(
                seriesId = state.seriesId,
                chapterIndex = state.currentChapterIndex,
                scrollPosition = state.scrollPosition,
                lastReadAt = System.currentTimeMillis(),
                percentComplete = calculatePercent()
            )
        )
    }
}
```

---

## 17. AI-GENERATED SERIES COVER ICONS

### 17.1 — Prompt Construction
```kotlin
fun buildImagePrompt(series: Series): String {
    // Extract key themes from title and first chapter description
    val titleWords = series.title.replace(Regex("[^a-zA-Z ]"), "").split(" ")
        .filter { it.length > 3 }
        .take(4)
        .joinToString(" ")

    return "sci-fi cyberpunk digital art, $titleWords, space military humanity, " +
           "neon lights, dark atmosphere, angular geometric, concept art, " +
           "4k highly detailed, dark background, cinematic lighting"
}
```

### 17.2 — Free API (Pollinations.ai — No Key Required)
```kotlin
suspend fun generateCoverImage(series: Series): Bitmap {
    val prompt = Uri.encode(buildImagePrompt(series))
    val url = "https://image.pollinations.ai/prompt/$prompt?width=512&height=512&seed=${series.id.hashCode()}&nologo=true"

    val request = Request.Builder().url(url).build()
    val response = okHttpClient.newCall(request).await()

    if (response.isSuccessful) {
        val bytes = response.body!!.bytes()
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        // Save to app-private cache
        saveCoverLocally(series.id, bitmap)
        return bitmap
    } else {
        return generateFallbackIcon(series)
    }
}

// Fallback: generate a symbolic icon from initials + shapes
fun generateFallbackIcon(series: Series): Bitmap {
    val bitmap = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    // Draw cyberpunk-styled initials with neon gradient
    val paint = Paint().apply {
        isAntiAlias = true
        textSize = 180f
        typeface = Typeface.DEFAULT_BOLD
        color = android.graphics.Color.parseColor("#00FFCC")
    }
    canvas.drawColor(android.graphics.Color.parseColor("#0A0A0F"))
    val initials = series.title.split(" ").take(2).map { it.first() }.joinToString("")
    canvas.drawText(initials, 100f, 320f, paint)
    return bitmap
}
```

### 17.3 — Caching
```kotlin
// Save locally to avoid re-generating
fun saveCoverLocally(seriesId: String, bitmap: Bitmap) {
    val file = File(context.filesDir, "covers/$seriesId.jpg")
    file.parentFile?.mkdirs()
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
}

fun loadCachedCover(seriesId: String): File? {
    val file = File(context.filesDir, "covers/$seriesId.jpg")
    return if (file.exists()) file else null
}
```

---

## 18. CACHING STRATEGY

### 18.1 — Multi-Layer Cache

| Layer | What | Where | TTL |
|-------|------|-------|-----|
| L1: Memory | Current screen series list | ViewModel StateFlow | Until VM cleared |
| L2: Database | Series list, chapter lists | Room DB | 6 hours (configurable) |
| L3: Disk | EPUB/TXT files | App files dir | Permanent (user managed) |
| L4: Image cache | Series cover images | App files dir | Permanent (user managed) |
| L5: HTTP cache | API responses | OkHttp disk cache (50MB) | 1 hour |

### 18.2 — OkHttp Cache Config
```kotlin
val okHttpClient = OkHttpClient.Builder()
    .cache(Cache(
        directory = File(context.cacheDir, "http_cache"),
        maxSize = 50L * 1024L * 1024L  // 50MB
    ))
    .addInterceptor { chain ->
        val request = chain.request()
        val response = chain.proceed(request)
        // Cache API responses for 1 hour
        response.newBuilder()
            .header("Cache-Control", "public, max-age=3600")
            .build()
    }
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()
```

### 18.3 — Cache Invalidation
```kotlin
// Triggered by: pull-to-refresh, "Refresh Series List" in settings, or TTL expiry
fun invalidateSeriesCache() {
    viewModelScope.launch {
        seriesDao.deleteAll()
        lastFetchTimestamp.set(0L)
        refreshSeriesList()
    }
}
```

---

## 19. ERROR HANDLING & RETRY LOGIC

### 19.1 — Network Error Types
```kotlin
sealed class NetworkError : Exception() {
    data class NoConnection(override val message: String = "NO SIGNAL — Check your connection") : NetworkError()
    data class Timeout(override val message: String = "CONNECTION TIMEOUT — Server not responding") : NetworkError()
    data class RateLimit(val retryAfter: Int = 60, override val message: String = "RATE LIMITED — Wait ${retryAfter}s") : NetworkError()
    data class ServerError(val code: Int, override val message: String = "SERVER ERROR $code") : NetworkError()
    data class ParseError(override val message: String = "DATA CORRUPTED — Parse failed") : NetworkError()
    data class AuthError(override val message: String = "ACCESS DENIED — Re-authenticate") : NetworkError()
}
```

### 19.2 — Retry Logic (Exponential Backoff)
```kotlin
suspend fun <T> retryWithBackoff(
    times: Int = 3,
    initialDelay: Long = 1000,
    maxDelay: Long = 15000,
    factor: Double = 2.0,
    block: suspend () -> T
): T {
    var currentDelay = initialDelay
    repeat(times - 1) { attempt ->
        try {
            return block()
        } catch (e: NetworkError.RateLimit) {
            delay(e.retryAfter * 1000L)
        } catch (e: Exception) {
            delay(currentDelay)
            currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelay)
        }
    }
    return block()  // Last attempt — let exception propagate
}
```

### 19.3 — Offline Mode
```kotlin
// If network fails, serve from Room cache
fun getSeriesListWithFallback(page: Int): Flow<List<Series>> = flow {
    try {
        val fresh = hfyApiService.getSeriesList(page)
        seriesDao.insertAll(fresh.toEntities())
        emit(fresh)
    } catch (e: NetworkError) {
        val cached = seriesDao.getSeriesPage(page)
        if (cached.isNotEmpty()) {
            emit(cached.toDomain())
            // Show "OFFLINE MODE — Cached data" banner in UI
        } else {
            throw e
        }
    }
}
```

---

## 20. LOCAL DATABASE — ROOM SCHEMA

```kotlin
// SeriesEntity.kt
@Entity(tableName = "series")
data class SeriesEntity(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val description: String?,
    val chapterCount: Int,
    val redditUrl: String?,
    val hfyFoundationUrl: String?,
    val coverImagePath: String?,
    val source: String,    // "HFY_FOUNDATION" | "REDDIT_WIKI"
    val isBookmarked: Boolean = false,
    val cachedAt: Long = System.currentTimeMillis()
)

// ChapterEntity.kt
@Entity(tableName = "chapters", foreignKeys = [
    ForeignKey(entity = SeriesEntity::class, parentColumns = ["id"],
               childColumns = ["seriesId"], onDelete = ForeignKey.CASCADE)
])
data class ChapterEntity(
    @PrimaryKey val id: String,
    val seriesId: String,
    val title: String,
    val redditPostUrl: String,
    val redditPostId: String,
    val wordCount: Int?,
    val postedAt: Long?,
    val orderIndex: Int,
    val isRead: Boolean = false
)

// ReadingProgressEntity.kt
@Entity(tableName = "reading_progress")
data class ReadingProgressEntity(
    @PrimaryKey val seriesId: String,
    val currentChapterIndex: Int,
    val scrollPosition: Int,
    val lastReadAt: Long,
    val percentComplete: Float
)

// DownloadJobEntity.kt
@Entity(tableName = "download_jobs")
data class DownloadJobEntity(
    @PrimaryKey val id: String,
    val seriesId: String,
    val seriesTitle: String,
    val format: String,        // "EPUB" | "TXT"
    val status: String,        // "QUEUED" | "IN_PROGRESS" | "COMPLETE" | "FAILED" | "PAUSED"
    val progress: Int = 0,
    val totalChapters: Int,
    val outputFilePath: String?,
    val errorMessage: String?,
    val enqueuedAt: Long,
    val completedAt: Long?
)

// UserThemeEntity.kt
@Entity(tableName = "user_themes")
data class UserThemeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val primaryColor: Long,
    val secondaryColor: Long,
    val backgroundColor: Long,
    val surfaceColor: Long,
    val textPrimaryColor: Long,
    val textSecondaryColor: Long,
    val accentColor: Long,
    val enableScanlines: Boolean,
    val enableGlitch: Boolean,
    val enableAnimations: Boolean,
    val fontFamily: String,
    val isBuiltIn: Boolean,
    val createdAt: Long
)

// AppDatabase.kt
@Database(
    entities = [SeriesEntity::class, ChapterEntity::class, ReadingProgressEntity::class,
                DownloadJobEntity::class, UserThemeEntity::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun seriesDao(): SeriesDao
    abstract fun chapterDao(): ChapterDao
    abstract fun readingProgressDao(): ReadingProgressDao
    abstract fun downloadJobDao(): DownloadJobDao
    abstract fun userThemeDao(): UserThemeDao
}
```

---

## 21. SETTINGS SCREEN — FULL SPECIFICATION

See [Section 8.8](#88--settings-screen) for detailed settings list.

### AndroidManifest.xml — Required Permissions
```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Network -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Storage (Android 15 uses scoped storage — no WRITE_EXTERNAL_STORAGE needed) -->
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />

    <!-- Background work -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <!-- Keep screen on in reader -->
    <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />

    <application
        android:name=".HFYNexusApp"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="HFY NEXUS"
        android:theme="@style/Theme.HFYNexus"
        android:enableOnBackInvokedCallback="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Reddit OAuth callback -->
        <activity android:name=".ui.screens.auth.RedditAuthActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="hfynexus" android:host="oauth2callback" />
            </intent-filter>
        </activity>

        <!-- Download Foreground Service -->
        <service
            android:name=".core.worker.DownloadForegroundService"
            android:foregroundServiceType="dataSync"
            android:exported="false" />

    </application>
</manifest>
```

---

## 22. APK BUILD, SIGNING & RELEASE PLAN

### 22.1 — Build Release APK
```bash
# From project root:
./gradlew assembleRelease

# Output: app/build/outputs/apk/release/app-release.apk

# Verify APK signing:
apksigner verify --verbose app-release.apk

# Install directly to device:
adb install -r app/build/outputs/apk/release/app-release.apk

# Check APK size:
ls -lh app/build/outputs/apk/release/app-release.apk
```

### 22.2 — ProGuard Rules
```proguard
# proguard-rules.pro

# Keep Kotlin
-keep class kotlin.** { *; }
-keep class kotlinx.** { *; }

# Keep Hilt
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }

# Keep Room entities
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }

# Keep Retrofit/OkHttp
-keep class okhttp3.** { *; }
-keep class retrofit2.** { *; }

# Keep EPUB lib
-keep class nl.siegmann.epublib.** { *; }
-dontwarn nl.siegmann.epublib.**

# Keep Moshi
-keepclassmembers class ** {
    @com.squareup.moshi.FromJson *;
    @com.squareup.moshi.ToJson *;
}

# Keep Gson DTOs
-keepclassmembers class com.hfynexus.android.data.remote.**.dto.** { *; }

# Keep JSoup
-keep class org.jsoup.** { *; }

# Keep Lottie
-keep class com.airbnb.lottie.** { *; }

# Keep Coil
-keep class coil.** { *; }

# Suppress warnings for third-party libs
-dontwarn org.xmlpull.**
-dontwarn org.slf4j.**
-dontwarn javax.xml.**
```

### 22.3 — local.properties (DO NOT COMMIT)
```properties
sdk.dir=/path/to/Android/sdk
REDDIT_CLIENT_ID=your_reddit_client_id_here
STORE_PASSWORD=your_keystore_password
KEY_PASSWORD=your_key_password
STABILITY_API_KEY=your_stability_ai_key_optional
```

---

## 23. TESTING PLAN

### 23.1 — Core Test Cases (Unit Tests)

```kotlin
// Test: Reddit wiki parser
@Test fun parseRedditWikiMarkdown_extractsSeriesCorrectly() {
    val markdown = "* [Nature of Predators](https://reddit.com/r/HFY/comments/abc123) by u/SpacePaladin15"
    val series = redditWikiParser.parse(markdown)
    assertEquals("Nature of Predators", series[0].title)
    assertEquals("SpacePaladin15", series[0].author)
}

// Test: EPUB generation
@Test fun buildEpub_createsValidEpubFile() = runTest {
    val series = mockSeries()
    val chapters = mockChapters(5)
    val file = epubBuilder.buildEpub(series, chapters)
    assertTrue(file.exists())
    assertTrue(file.length() > 1024)
    assertTrue(file.name.endsWith(".epub"))
}

// Test: Download retry logic
@Test fun retryWithBackoff_retriesOnNetworkError() = runTest {
    var attempts = 0
    val result = retryWithBackoff(times = 3) {
        attempts++
        if (attempts < 3) throw NetworkError.Timeout()
        "SUCCESS"
    }
    assertEquals(3, attempts)
    assertEquals("SUCCESS", result)
}
```

### 23.2 — Manual Test Series (Verify These Work)
Test with these known HFY series:
1. **Nature of Predators** by SpacePaladin15 (very long, 100+ chapters)
2. **The Wandering Inn** crosspost excerpts
3. **Humans Don't Make Good Pets** (short, single post)
4. **The Legion of Nothing** (multi-part)
5. Any series with special characters in title

### 23.3 — Verification Checklist
```
PRE-RELEASE CHECKLIST:
  [ ] Browse screen loads series list from hfy.foundation on first launch
  [ ] Infinite scroll loads more series on reaching bottom
  [ ] Search function returns live results from hfy.foundation
  [ ] Tapping a series opens correct detail page with all chapters
  [ ] Download EPUB works: file is valid, opens in Moon+ Reader / Google Play Books
  [ ] Download TXT works: readable plain text file
  [ ] Individual chapter download works
  [ ] Built-in reader opens EPUB/text correctly
  [ ] Reading progress saves and resumes correctly
  [ ] Bookmark toggle saves to local library
  [ ] Reddit OAuth flow completes and stores token
  [ ] Scraper fallback works when OAuth is not set up
  [ ] All 6 preset themes apply correctly
  [ ] Custom theme builder saves and applies theme
  [ ] Font changes in reader apply immediately
  [ ] Download queue shows progress, completes, sends notification
  [ ] App works fully offline with cached data
  [ ] Pull-to-refresh updates series list
  [ ] AI cover images generate and cache for each series
  [ ] App size >= 360MB with full font pack included
  [ ] Minimum Android 15 (API 35) — test on emulator
```

---

## 24. APK SIZE STRATEGY — TARGETING 360MB+

The app targets 360MB minimum size. Here's how to achieve it legitimately:

| Asset Type | Size Contribution | How |
|-----------|-------------------|-----|
| Font library (30+ fonts, all weights) | ~80MB | Include all TTF weights for each font |
| Lottie animation library + JSON files | ~15MB | Include 20+ high-quality animations |
| Bundled offline series index (JSON) | ~10MB | Pre-cache top 500 series on install |
| Coil image cache (pre-seeded) | ~50MB | Bundle 200 AI-pre-generated covers |
| EPUB CSS templates (many variants) | ~5MB | Include 20+ EPUB style themes |
| Native libs (from OkHttp native, Room) | ~30MB | Included via Gradle |
| Kotlin stdlib + Compose runtime | ~20MB | Included automatically |
| Hilt + Dagger runtime | ~10MB | Included automatically |
| All dependencies combined | ~100MB | From dependency list |
| Bundled background Lottie assets | ~40MB | 50+ high-res animations |

```kotlin
// In app/build.gradle.kts — ensure all ABIs are included (no splits)
android {
    splits {
        abi {
            isEnable = false  // Bundle ALL ABIs = larger APK
        }
    }
    // Include ALL density resources (no density splits)
    bundle {
        density { enableSplit = false }
        abi { enableSplit = false }
        language { enableSplit = false }
    }
}

// Add large asset files:
// assets/offline_data/top500_series.json  ← Pre-seeded data (~15MB)
// assets/covers/                          ← 200 pre-generated covers (~50MB)
// assets/fonts/                           ← Mirror of res/font (~80MB total)
```

---

## 25. REFERENCE REPOSITORIES ANALYSIS

### What to Extract from Each Repo

| Repo | Key Code to Use |
|------|----------------|
| `github.com/hacst/hfy2epub` | Core EPUB building logic in `index.html` — port the JS chapter fetch & EPUB assembly to Kotlin |
| `github.com/lizard-demon/hfydl` | Reddit post URL parsing, chapter ordering logic |
| `github.com/cpiber/hfy-epub` | TypeScript EPUB template — adapt CSS and HTML structure to Kotlin |
| `github.com/stonewalljones/hfyEbook` | Series metadata extraction patterns |
| `github.com/cowlinator/reddit_story_scraper` | Reddit scraping without auth — adapt Python logic to Kotlin/JSoup |
| `github.com/Racle/Reddit2Ebook` | Chapter concatenation and ordering algorithms |
| `hacst.net/hfy2epub/` | Live working EPUB service — reverse engineer the API calls it makes |

### Key Pattern from hfy2epub (Hacst)
```javascript
// Original JS from hacst/hfy2epub/index.html
// The critical part is how it chains chapter links:

function getNextChapter(postData) {
    // Look for "next" links in self text
    const selftext = postData.selftext;
    const nextRegex = /\[(?:Next|next|NEXT|→|>>|Part\s+\d+)\]\((https?:\/\/[^)]+)\)/g;
    const matches = [...selftext.matchAll(nextRegex)];
    return matches.length > 0 ? matches[matches.length - 1][1] : null;
}
```

Port this to Kotlin:
```kotlin
fun findNextChapterUrl(markdownText: String): String? {
    val nextPattern = Regex(
        """\[(?:Next|next|NEXT|→|>>|Part\s+\d+|Continue)\]\((https?://[^)]+)\)""",
        RegexOption.IGNORE_CASE
    )
    return nextPattern.findAll(markdownText).lastOrNull()?.groupValues?.get(1)
}
```

---

## 26. CODING PLAN — PHASE-BY-PHASE

### Phase 1 — Foundation (Week 1–2)
```
[ ] Create Android Studio project with Kotlin + Compose + Hilt
[ ] Set up Gradle with all dependencies
[ ] Create Hilt modules (Network, Database, Repository)
[ ] Implement Room database schema + DAOs
[ ] Implement DataStore for settings
[ ] Create base theme (CyberpunkTheme.kt) with NightCity colors
[ ] Implement base UI components (NeonBorderBox, GlitchText, etc.)
[ ] Create AppNavGraph with 5 bottom tabs
[ ] Test: launch app, see themed UI with nav bar
```

### Phase 2 — Data Integration (Week 3–4)
```
[ ] Implement HFYApiService (Retrofit) for hfy.foundation
[ ] Implement HFYScraper (JSoup) as fallback
[ ] Implement RedditScraper for wiki + post content
[ ] Implement SeriesPagingSource with Paging3
[ ] Implement BrowseViewModel + BrowseScreen
[ ] Test: Browse screen shows live series list with infinite scroll
[ ] Implement SearchScreen (pipes to hfy.foundation search)
[ ] Test: Search returns live results
```

### Phase 3 — Reddit OAuth (Week 5)
```
[ ] Register Reddit app at reddit.com/prefs/apps
[ ] Implement RedditOAuthManager + AuthInterceptor
[ ] Implement RedditAuthActivity (Custom Tab or Intent)
[ ] Implement token storage in DataStore
[ ] Test: Full OAuth flow, token stored, API calls use bearer token
[ ] Implement scraper fallback when no OAuth token
```

### Phase 4 — Series Detail + Download (Week 6–7)
```
[ ] Implement SeriesDetailScreen + ViewModel
[ ] Implement ChapterFetcher (fetch Reddit post content)
[ ] Port hfy2epub chapter chain logic to Kotlin
[ ] Implement EpubBuilder
[ ] Implement TxtExporter
[ ] Test: Download "Nature of Predators" as EPUB — verify valid file
[ ] Implement DownloadWorker (WorkManager)
[ ] Implement DownloadQueueScreen
[ ] Test: Queue 3 concurrent downloads, verify progress shown
```

### Phase 5 — Reader (Week 8)
```
[ ] Implement ReaderScreen (full immersive reader)
[ ] Implement reading progress save/restore
[ ] Implement font selection in reader
[ ] Implement chapter navigation (prev/next with swipe)
[ ] Test: Read a multi-chapter series end-to-end
```

### Phase 6 — Library + AI Images (Week 9)
```
[ ] Implement LibraryScreen (bookmarks, in-progress, completed)
[ ] Implement AI cover generation (Pollinations API)
[ ] Implement local cover caching
[ ] Test: All series show AI-generated covers
```

### Phase 7 — Settings + Theme Builder (Week 10)
```
[ ] Implement SettingsScreen (all 6 sections)
[ ] Implement all 6 preset themes
[ ] Implement ThemeBuilderScreen (live preview + color pickers)
[ ] Test: Switch all themes — UI updates live
[ ] Test: Create and save a custom theme
```

### Phase 8 — Polish + APK (Week 11–12)
```
[ ] Add all Lottie animations
[ ] Add all 30+ fonts to res/font/
[ ] Add ScanlineOverlay and AnimatedScanBeam to all screens
[ ] Pre-seed offline series data (top 500)
[ ] Pre-seed AI cover images for top 100 series
[ ] Run full verification checklist
[ ] Build release APK: ./gradlew assembleRelease
[ ] Verify APK size >= 360MB
[ ] Final test on physical device (Android 15)
[ ] Sideload via: adb install -r app-release.apk
```

---

## FINAL NOTES

```
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
  SYSTEM NOTE:
  
  This document is a complete build specification.
  Every class, file, and dependency mentioned must be implemented.
  
  CRITICAL RULE:
  Do NOT reinvent hfy.foundation's search — pipe directly to it.
  Do NOT build a static series list — everything must be LIVE.
  Do NOT use WebViews — native HTTP + native Compose UI only.
  
  QUALITY CHECK:
  Before marking any phase complete, verify the feature works
  with at least 3 different HFY series.
  
  COMPATIBILITY:
  Test on Android 15 (API 35) — do not test on anything lower.
  Target modern Android; no legacy compatibility required.
  
  SIZE TARGET:
  App must be >= 360MB. Include full font packs,
  pre-seeded data, and bundled animation assets.
  
  // END OF SPECIFICATION
  // HFY NEXUS v1.0 // HUMANITY FUCK YEAH //
  // NIGHT CITY NEVER SLEEPS
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
```

---

*Document generated: 2026-06-23 // HFY NEXUS BUILD SPEC v1.0*  
*Classification: AUTHORIZED PERSONNEL — EDGERUNNERS ONLY*


---

*End of Build Prompt and Specifications*
