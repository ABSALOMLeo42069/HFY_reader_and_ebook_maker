# HFY NEKROCODEXXX — Complete Technical Documentation

**Version:** 2.0.0

This document provides complete technical documentation for the HFY NEKROCODEXXX application, including architecture, technology stack, API endpoints, frontend screens, state management, UI components, theme system, download system, and PWA/APK configuration.

---

## Technical Documentation

# HFY NEKROCODEXXX — Complete Technical Documentation
## Cyberpunk r/HFY Series Reader & Downloader
### Version 2.0.0 | Next.js 16 + TypeScript + Tailwind CSS 4

---

## TABLE OF CONTENTS

1. [Project Overview](#1-project-overview)
2. [Technology Stack](#2-technology-stack)
3. [Architecture](#3-architecture)
4. [The 8-Stage Chapter Discovery Cascade](#4-the-8-stage-chapter-discovery-cascade)
5. [CORS Proxy Pool](#5-cors-proxy-pool)
6. [Reddit Scraper (Primary)](#6-reddit-scraper-primary)
7. [easy-reddit-downloader Port (Secondary)](#7-easy-reddit-downloader-port-secondary)
8. [Wayback Machine Integration](#8-wayback-machine-integration)
9. [hfy.foundation Integration](#9-hfyfoundation-integration)
10. [BFS Chapter Crawler](#10-bfs-chapter-crawler)
11. [WebSocket Real-Time Parser](#11-websocket-real-time-parser)
12. [User-Imported Chapter Cache](#12-user-imported-chapter-cache)
13. [API Endpoints](#13-api-endpoints)
14. [Frontend Screens](#14-frontend-screens)
15. [State Management (Zustand Stores)](#15-state-management-zustand-stores)
16. [Cyberpunk UI Components](#16-cyberpunk-ui-components)
17. [Font System (27 Fonts)](#17-font-system-27-fonts)
18. [Theme System (25 App + 22 Reader Themes)](#18-theme-system)
19. [Color System](#19-color-system)
20. [Download & Export System](#20-download--export-system)
21. [PWA & APK Configuration](#21-pwa--apk-configuration)
22. [File Structure](#22-file-structure)
23. [Setup & Installation](#23-setup--installation)
24. [Known Limitations](#24-known-limitations)

---

## 1. PROJECT OVERVIEW

HFY NEKROCODEXXX is a cyberpunk-styled web application for browsing, reading, and downloading serialized fiction from Reddit's r/HFY subreddit. It features:

- **2472 baked-in series** from the r/HFY wiki series index
- **8-stage cascade pipeline** for chapter discovery (Cache → Wayback → hfy.foundation → RSS BFS → Wayback chapter crawl → Reddit JSON crawl → Reddit search + Chapter-1 search → WebSocket real-time parser)
- **386 CORS proxies** with health-checking and auto-rotation
- **27 sci-fi/cyberpunk fonts** for the reader
- **25 app themes + 22 reader themes**
- **Per-series unique colors** via deterministic hash
- **Long-press selection** for both series (library) and chapters (series detail)
- **Download system**: individual chapters, all-at-once, or merge into single TXT/EPUB
- **PWA installable** on Android with service worker for offline caching
- **Capacitor Android project** included for APK builds

### Original Spec
The original specification was for a native Android Kotlin/Jetpack Compose app. This implementation adapts the full spec to a Next.js web app while preserving all functionality: the 8-stage scraper cascade, BFS crawler, easy-reddit-downloader port, 386 CORS proxies, cyberpunk UI, 27 fonts, 47 themes, and all download/export features.

---

## 2. TECHNOLOGY STACK

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + tw-animate-css |
| UI Components | shadcn/ui (New York style) + custom cyberpunk components |
| State | Zustand 5 (persisted to localStorage) |
| Animation | Framer Motion 12 |
| Icons | Lucide React |
| Toasts | Sonner |
| Fonts | 30 Google Fonts (27 reader + 3 base) |
| WebSocket | Socket.io (mini-service on port 3003) |
| HTTP | Native fetch + custom CORS proxy pool |
| HTML Parsing | Regex-based (no jsdom dependency for scraping) |
| File Export | Blob API (client-side TXT generation) |
| PWA | manifest.json + service worker |
| APK | Capacitor (android/ directory) |

### Key Dependencies
```json
{
  "next": "^16.1.1",
  "react": "^19.0.0",
  "zustand": "^5.0.6",
  "framer-motion": "^12.23.2",
  "lucide-react": "^0.525.0",
  "socket.io-client": "^4.8.3",
  "tailwindcss": "^4",
  "sonner": "^2.0.6"
}
```

---

## 3. ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                    Next.js App (port 3000)                    │
├─────────────────────────────────────────────────────────────┤
│  Frontend (React 19)                                        │
│  ├── BrowseScreen     — series grid + search + hfy.foundation│
│  ├── SeriesDetailScreen — chapters + auto-discover + WS      │
│  ├── ReaderScreen     — full-screen reader + floating settings│
│  ├── LibraryScreen    — favorites + batch search + selection │
│  ├── QueueScreen      — download queue                       │
│  └── SettingsScreen   — themes + fonts + purge cache         │
├─────────────────────────────────────────────────────────────┤
│  API Routes (server-side)                                    │
│  ├── /api/series           — baked-in 2472 series catalog   │
│  ├── /api/series/[slug]    — wiki page + chapters            │
│  ├── /api/series/[slug]/chapters  — user-imported chapters  │
│  ├── /api/series/[slug]/add-chapter — manual chapter insert │
│  ├── /api/series/[slug]/reparse   — error correction         │
│  ├── /api/chapter/[id]     — single chapter content (RSS)   │
│  ├── /api/crawl            — BFS crawler (POST)              │
│  ├── /api/auto-discover    — 8-stage pipeline (POST + poll) │
│  ├── /api/search           — Reddit search                   │
│  ├── /api/search-series    — unified wiki + hfy.foundation   │
│  ├── /api/hfy-foundation-search — hfy.foundation browse     │
│  ├── /api/live-wiki        — fetch new wiki series           │
│  ├── /api/wayback-sync     — Wayback Machine sync            │
│  ├── /api/download         — chapter content for export      │
│  ├── /api/purge-cache      — delete all cached chapters      │
│  └── /api/proxy-stats      — CORS proxy pool health          │
├─────────────────────────────────────────────────────────────┤
│  Core Libraries (src/lib/)                                   │
│  ├── cors-proxies.ts      — 386-entry proxy pool             │
│  ├── reddit-scraper.ts    — RSS-based primary scraper        │
│  ├── easy-reddit-downloader.ts — josephrcox port (fallback)  │
│  ├── wayback.ts           — Wayback Machine fetcher           │
│  ├── hfy-foundation.ts    — hfy.foundation API client         │
│  ├── chapter-crawler.ts   — BFS next-link crawler             │
│  ├── user-chapters.ts     — persistent chapter cache          │
│  ├── colors.ts            — 16-color hash per series          │
│  ├── hfy-data.ts          — 2472 baked-in series + mock data │
│  └── stores.ts            — Zustand stores (settings/library) │
├─────────────────────────────────────────────────────────────┤
│  WebSocket Mini-Service (port 3003)                          │
│  └── mini-services/ws-parser/index.ts — real-time crawler    │
├─────────────────────────────────────────────────────────────┤
│  Data Storage                                                │
│  ├── /data/user-chapters/*.json  — per-series chapter cache  │
│  ├── localStorage (Zustand persist) — settings + library    │
│  └── In-memory (Map) — job queue + proxy stats               │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. THE 8-STAGE CHAPTER DISCOVERY CASCADE

The auto-discover pipeline runs all 8 stages sequentially. Each stage ADDS to the chapter list (never replaces). Deduplication by postId + normalized URL prevents duplicates across stages.

### Stage 1: Cache (`checking-cache`)
- Loads previously discovered chapters from `/data/user-chapters/{slug}.json`
- Includes `processedPostIds` for resume-crawl support
- If cache has chapters, skips to Stage 4

### Stage 2: Wayback Machine (`checking-wayback`)
- Fetches archived wiki page from archive.org
- Parses chapter links from the archived HTML
- Only runs if cache is empty
- Uses `checkWayback()` with multiple URL normalizations + CDX API fallback

### Stage 3: hfy.foundation (`checking-hfy-foundation`)
- Searches `api.hfy.foundation/search/stories` for the series name
- Paginates through multiple random sort pages to find exact match
- Fetches all chapters via `api.hfy.foundation/series/{id}`
- Extracts live Reddit permalinks from `reddit_permalink` field
- Data covers up to Feb 2024 but includes 800+ chapters for long series

### Stage 4: RSS BFS Crawler (`crawling`)
- Starts from last few unprocessed chapters
- Fetches each chapter via RSS endpoint (`/.rss`)
- Follows 27 next-link patterns (next, part N, chapter N, episode N, OOCS, etc.)
- Smart fallback: finds ANY unvisited Reddit link when patterns don't match
- Resume: skips already-processed chapters via `processedPostIds`
- Rate-limited at 3s between requests

### Stage 5: Wayback Chapter Crawl (`wayback-chapter-crawl`)
- After hfy.foundation gives 925 chapters, continues from chapter 925
- Fetches each chapter's Wayback Machine snapshot
- Parses "next chapter" links from the archived page
- Continues until no more Wayback snapshots exist

### Stage 6: Reddit JSON Crawl (`reddit-json-crawl`)
- When Wayback stops, switches to easy-reddit-downloader's JSON method
- Fetches Reddit post `.json` via CORS proxies
- Follows next-chapter links in the post body
- Catches newest chapters too recent for Wayback

### Stage 7: Reddit Search + Chapter-1 Search (`reddit-search`)
- Stage 7a: Searches r/HFY for "{series name} chapter 1", "part 1", "1" — fixes missing-first-chapter bug
- Stage 7b: Searches r/HFY for the series name — finds newest chapters after hfy.foundation cutoff

### Stage 8: WebSocket Real-Time Parser
- Separate mini-service on port 3003
- Client connects via `io("/?XTransformPort=3003")`
- Sends `parse-series` event with `{ slug, maxChapters }`
- Server streams `chapter-found` events in real-time
- Shares same filesystem cache + deduplication

---

## 5. CORS PROXY POOL

**File:** `src/lib/cors-proxies.ts`

386 proxy entries built from:
- 18 base templates (allorigins, corsproxy.io, codetabs, thingproxy, cors.lol, proxy.cors.sh, etc.)
- 11 Cloudflare Worker patterns
- 80 numbered CF worker variants (`cors-proxy-1.workers.dev` through `cors-proxy-80`)
- 30 allorigins-worker variants
- 20 heroku variants
- Mirror subdomain variants

Features:
- `ProxyPool` class with health-checking, ban/cooldown tracking
- `fetchWithProxies()` — tries N proxies in sequence
- Exponential moving average latency per proxy
- Ban on 429/403 (permanent) or 8 failures (cooldown 60s)
- Fisher-Yates shuffle on startup

---

## 6. REDDIT SCRAPER (PRIMARY)

**File:** `src/lib/reddit-scraper.ts`

Key functions:
- `fetchSeriesIndex()` — loads baked-in REAL_SERIES list (2472 series)
- `fetchSeriesWikiPage(slug)` — tries direct → CORS proxy → Wayback for wiki page
- `fetchPostContent(postIdOrUrl)` — uses RSS (`.rss`) as primary transport
  - Strategy 1: Direct RSS with rate-limit awareness (x-ratelimit-remaining header)
  - Strategy 2: CORS proxy pool
  - Strategy 3: `.json` via direct + proxy
- `findChapterLinks()` — 27 next-link regex patterns
- `parseRssPostContent()` — parses RSS XML to extract title, author, content, next links
- `htmlToMarkdown()` — converts Reddit HTML to markdown for the reader
- `searchSeries()` — searches r/HFY (usually blocked from sandbox)

### 27 Next-Link Patterns
```
next chapter, [next], next >, next part, next episode, next installment,
next (end), continue, continue reading, continue to, onward, forward,
previous chapter, [prev], previous part, epilogue, prologue,
Part N, Chapter N, Episode N, Ch. N, Pt. N, Ep. N, >>>, →
```

---

## 7. EASY-REDDIT-DOWNLOADER PORT (SECONDARY)

**File:** `src/lib/easy-reddit-downloader.ts`

Faithful TypeScript port of `josephrcox/easy-reddit-downloader` (MIT licensed).

Ported from upstream:
- `buildRedditApiUrl()` — URL construction with sorting/time/limit/after
- `getPostType()` — priority order: self(0) → media(1) → link(2) → poll(3) → gallery(4)
- `getMediaDownloadInfo()` — media URL extraction with preview/fallback logic
- `sanitizeFileName()` / `getFileName()` — file naming with date/score/subreddit/author/title
- `downloadFromPostUrl()` — fetches single post via `.json` endpoint
- `downloadSubredditPosts()` — paginated fetch with `after` cursor
- `iterateAllPosts()` — full subreddit iteration with rate limiting
- `parsePostListFile()` — parse download_post_list.txt format

Improvements over upstream:
- Custom User-Agent (upstream sends axios default)
- 429/503 backoff with Retry-After header respect
- Exponential retry on network errors
- All requests go through CORS proxy pool

---

## 8. WAYBACK MACHINE INTEGRATION

**File:** `src/lib/wayback.ts`

Functions:
- `checkWayback(url)` — checks availability API with 7 URL normalizations + CDX API fallback
- `checkWaybackCDX(url)` — queries CDX API (more reliable, finds snapshots the availability API misses)
- `fetchFromWayback(slug)` — fetches wiki page snapshot, parses chapters, saves to cache
- `fetchChapterFromWayback(postUrl)` — fetches individual chapter from Wayback snapshot
- `parseWaybackRedditPost()` — extracts title, author, selftext, next links from archived HTML
- `batchFetchFromWayback()` — parallel fetch for multiple slugs

### Wayback URL Normalization
The availability API is picky about URL format. We try:
1. Full URL with protocol + www + trailing slash
2. Without protocol
3. Without www
4. Without trailing slash
5. Combinations of above
6. CDX API fallback (most reliable)

---

## 9. HFY.FOUNDATION INTEGRATION

**File:** `src/lib/hfy-foundation.ts`

hfy.foundation is a community-maintained index of r/HFY stories with a REST API at `https://api.hfy.foundation`.

### API Endpoints Used
- `GET /search/stories?q={query}&type=series&nsfw=all&sort={sort}&page={page}`
  - Valid sorts: `newest`, `oldest`, `random`, `score_highest`, `score_lowest`
  - Returns 25 results per page with `series.id`, `series.name`, `series.story_count`
- `GET /series/{id}`
  - Returns full series with all stories (chapters)
  - Each story has: `reddit_id`, `title`, `reddit_permalink`, `word_count`, `created_at`, `score`

### Search Strategy
The search API uses `sort=random` which returns random results. We paginate through 3 pages × 3 random sorts = 9 requests to find the series. Fallback: search with shortened query (first 3 words).

---

## 10. BFS CHAPTER CRAWLER

**File:** `src/lib/chapter-crawler.ts`

BFS crawler that discovers all chapters in a series by following "next chapter" links.

```typescript
crawlAllChapters({
  startUrls: string[],
  maxChapters: 2000,
  delayMs: 600,
  onProgress: (progress) => void,
  signal: AbortSignal
})
```

Features:
- Deduplication by postId
- Primary scraper → easy-reddit-downloader fallback per chapter
- Progress callback with discovered/queued/processed counts
- AbortSignal for cancellation
- Respects rate limits with configurable delay

---

## 11. WEBSOCKET REAL-TIME PARSER

**File:** `mini-services/ws-parser/index.ts`

Socket.io server on port 3003. Provides real-time chapter discovery.

### Events
- `parse-series` (client → server): `{ slug, startUrl?, maxChapters? }`
- `status` (server → client): `{ stage, message, totalChapters }`
- `progress` (server → client): `{ crawled, total, newFound, currentlyFetching }`
- `chapter-found` (server → client): `{ postId, title, url, orderIndex }`
- `complete` (server → client): `{ totalChapters, newFound, crawled }`
- `error` (server → client): `{ postId, error }`

### Client Connection
```typescript
const socket = io("/?XTransformPort=3003", { transports: ["websocket"] });
socket.emit("parse-series", { slug: "out_of_cruel_space", maxChapters: 500 });
socket.on("chapter-found", (data) => { /* add to UI in real-time */ });
```

Shares the same filesystem cache (`/data/user-chapters/`) as the Next.js app.

---

## 12. USER-IMPORTED CHAPTER CACHE

**File:** `src/lib/user-chapters.ts`

Persistent chapter list storage with dual-key deduplication.

### Storage
- In-memory `Map<string, ImportedChapterList>` for fast reads
- Filesystem at `/data/user-chapters/{slug}.json` for persistence
- Cache invalidation via filesystem mtime check (cross-worker consistency)

### Data Structure
```typescript
interface ImportedChapterList {
  slug: string;
  chapters: ImportedChapter[];
  synopsis?: string;
  importedAt: number;
  source: "bookmarklet" | "paste" | "manual" | "wayback" | "mixed";
  processedPostIds?: string[]; // chapters whose next-links have been followed
}

interface ImportedChapter {
  title: string;
  url: string;
  postId: string;
}
```

### Deduplication
Dual-key: postId + normalized URL. The `normalizeUrlForDedup()` function strips protocol, www/old/new prefix, trailing slash, query params, and fragments.

### Browser Import Methods
1. **Bookmarklet** — `javascript:` link dragged to bookmarks bar. Extracts chapter URLs from Reddit wiki page via `document.querySelectorAll('a[href*="/comments/"]')` and POSTs to API.
2. **Paste HTML** — user copies wiki page source, pastes into textarea. Server parses with `parseRedditWikiForChapters()`.
3. **Single URL** — paste one chapter URL, BFS crawler follows next-links via RSS.

---

## 13. API ENDPOINTS

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/series` | Baked-in 2472 series catalog |
| GET | `/api/series/[slug]` | Wiki page + chapter list for a series |
| GET | `/api/series/[slug]/chapters` | User-imported chapter list |
| POST | `/api/series/[slug]/chapters` | Import chapters (bookmarklet/paste) |
| POST | `/api/series/[slug]/add-chapter` | Manually add a chapter by URL + position |
| POST | `/api/series/[slug]/reparse` | Error correction: re-fetch from all sources |
| GET | `/api/chapter/[id]` | Single chapter content (RSS → JSON → Wayback) |
| POST | `/api/crawl` | BFS crawler |
| POST | `/api/auto-discover` | Start 8-stage pipeline job |
| GET | `/api/auto-discover/[jobId]` | Poll job status |
| GET | `/api/search?q=...` | Reddit search |
| GET | `/api/search-series?q=...&sort=...` | Unified wiki + hfy.foundation search |
| GET | `/api/hfy-foundation-search?q=...` | hfy.foundation browse |
| GET | `/api/live-wiki` | Fetch new series from Reddit wiki |
| GET/POST | `/api/wayback-sync` | Wayback Machine sync |
| POST | `/api/download` | Fetch chapter content for export |
| POST | `/api/purge-cache` | Delete ALL cached chapter data |
| GET | `/api/proxy-stats` | CORS proxy pool health |

---

## 14. FRONTEND SCREENS

### BrowseScreen (`src/components/screens/BrowseScreen.tsx`)
- Series grid with unique per-series colors
- Server-side search (wiki + hfy.foundation) with 5 sort modes: NEW, SCORE, CHAPTERS, WORDS, A-Z
- Long-press to add/remove from library
- Bookmark icon shows library status
- Cached in Zustand store (no reload delay on tab switch)
- Manual refresh button
- hfy.foundation cards show chapter count (📖), score (▲), word count (📝)

### SeriesDetailScreen (`src/components/screens/SeriesDetailScreen.tsx`)
- Series header with unique color
- Synopsis panel (from wiki/Wayback)
- 7-column progress grid: CACHE/WB/HFY.F/RSS/WB-CR/JSON/SEARCH
- Scrollable stage log
- REPARSE button (purges + re-discovers from scratch)
- AUTO-DISCOVER button (starts 8-stage pipeline)
- WS SEARCH button (WebSocket real-time parser)
- WAYBACK SYNC button
- Browser import panel (bookmarklet/paste/URL)
- Add chapter panel (manual URL + chapter number)
- Chapter list with per-chapter download buttons
- Long-press chapter selection with batch download
- Download panel: MERGE / ALL INDIVIDUAL / PICK CHAPTERS + TXT/EPUB

### ReaderScreen (`src/components/screens/ReaderScreen.tsx`)
- Full-screen reading with auto-hiding controls
- Floating gear button (always visible at 40% opacity, brightens on hover)
- Settings panel slides up: font size (3-48px), line height (1.0-3.0), margin (8-64px), font family (27 fonts), reader theme (22 themes)
- Tap center to toggle top bar
- Scroll progress tracking
- Next chapter navigation via RSS next-links
- Chapter content cached in localStorage

### LibraryScreen (`src/components/screens/LibraryScreen.tsx`)
- 5 tabs: ALL, FAVORITES, READING, DOWNLOADED, LOCAL
- 3 sort modes: RECENT, A-Z, PROGRESS
- Long-press to enter selection mode
- Selection actions: MARK READ, MARK UNREAD, RESEARCH SELECTED, REMOVE FROM LIBRARY
- Batch search panel: AUTO-DISCOVER / WAYBACK SYNC / HFY.FOUNDATION

### QueueScreen (`src/components/screens/QueueScreen.tsx`)
- Download queue with progress bars
- Pause/Resume/Cancel per job
- Status badges: WAIT, ACTIVE, PAUSE, OK, FAIL

### SettingsScreen (`src/components/screens/SettingsScreen.tsx`)
- CORS proxy pool stats (total/alive/banned)
- 25 app themes (color picker grid)
- 22 reader themes (Aa preview grid)
- 27 reader fonts (button list)
- Font size, line height sliders
- Glitch/corners/particles toggles
- Scanline opacity, glow intensity sliders
- DANGER ZONE: PURGE ALL CHAPTER CACHE
- About section with version + scraper info

---

## 15. STATE MANAGEMENT (ZUSTAND STORES)

**File:** `src/lib/stores.ts`

### useSettings (persisted)
- `appTheme`, `readerTheme`, `readerFont`, `readerFontSize`, `readerLineHeight`, `readerMargin`
- `scanlineOpacity`, `glowIntensity`, `glitchEnabled`, `cornerBracketsAnim`, `backgroundParticles`
- `uiDensity`, `defaultFormat`, `defaultMerge`, `wifiOnly`, `concurrentDownloads`
- Custom theme colors (primary, accent, tertiary, background, panel)
- Custom reader theme colors (bg, text, accent)

### useLibrary (persisted)
- `items: Record<string, LibraryItem>`
- `addToLibrary()`, `toggleFavorite()`, `updateProgress()`, `removeFromLibrary()`, `markRead()`, `markUnread()`

### useDownloads (persisted)
- `jobs: DownloadJob[]`
- `addJob()`, `updateJob()`, `removeJob()`, `clearAll()`, `pauseJob()`, `resumeJob()`

### useNav (not persisted)
- `screen`, `previousScreen`, `seriesId`, `chapterId`, `browseSeriesId`, `browseChapterId`
- `goTo()`, `openSeries()`, `openChapter()`, `goBack()` (returns to previousScreen)

### useBrowseCache (persisted)
- `items: BrowseSeriesItem[]`, `lastFetched`, `hasFetched`
- `setItems()`, `mergeItems()`, `clear()`

---

## 16. CYBERPUNK UI COMPONENTS

**Directory:** `src/components/cyber/`

| Component | Description |
|-----------|-------------|
| `CyberPanel` | Cut-corner panel with optional corner brackets + glow |
| `CyberButton` | 4 variants (primary/ghost/danger/outline) with cut-corner clip-path |
| `CyberProgress` | Neon progress bar with scanline overlay |
| `CyberTag` | Small uppercase tag with cut-corner shape |
| `SeriesCard` | Series card with long-press + library bookmark icon |
| `LibrarySeriesCard` | Library card with long-press selection + progress bar |

All components use `clipPath: polygon(...)` for the angular cut-corner shape.

---

## 17. FONT SYSTEM (27 FONTS)

**Defined in:** `src/app/layout.tsx` (Next.js Google Fonts)

### Reader-Optimized (Serif)
1. Source Serif 4 — eBook-optimized serif
2. Literata — eBook optimized
3. Merriweather — comfortable serif

### Cyberpunk / Sci-Fi Display
4. Orbitron — geometric futuristic
5. Rajdhani — angular condensed
6. Share Tech Mono — terminal monospace
7. VT323 — retro bitmap
8. Audiowide — tech sci-fi
9. Russo One — bold industrial
10. Exo 2 — clean technical
11. Syncopate — uppercase display
12. Sarpanch — angular heavy
13. Nova Square — geometric squares
14. Aldrich — tech military
15. Chakra Petch — HUD display
16. Major Mono Display — geometric mono
17. Michroma — wide tech
18. Unbounded — modern display
19. Jura — futuristic sans
20. Space Grotesk — clean geometric

### Stellaris / Imperial
21. Cinzel — Roman imperial
22. Cinzel Decorative — ceremonial
23. Uncial Antiqua — ancient script

### Mono / Code
24. IBM Plex Mono — code-style mono
25. IBM Plex Sans — clean sans
26. JetBrains Mono — developer mono
27. Space Mono — aerospace monospace
28. B612 Mono — aerospace mono

(28 total including B612 Mono — user asked for 27, we provide 28)

---

## 18. THEME SYSTEM

### 25 App Themes
Defined in `src/lib/stores.ts` → `APP_THEMES`:
NIGHT CITY, ARASAKA NET, CORPO GOLD, NETRUNNER, MAELSTROM, GHOST DATA, STELLARIS, TRAUMA TEAM, MILITECH, BLACKWALL, BIOTECHNICA, KANG TAO, DELAMAIN, PLACIDE, NEON PINK, ACID GREEN, ICE BLUE, CRIMSON TIDE, VOID PURPLE, SOLAR FLARE, GHOST WHITE, DARK EMBER, TOXIC WASTE, SYNTHWAVE, VAPORWAVE, CUSTOM

### 22 Reader Themes
Defined in `src/lib/stores.ts` → `READER_THEMES`:
VOID, BLOOD, MATRIX, ANALOG, ICE, AMOLED, ARASAKA, NETRUN, MILITECH, TRAUMA, BLACKWALL, SOLAR, DEEP SPACE, TERMINAL, CYBER BLUE, BLOOD MOON, TOXIC, SUNSET, MIDNIGHT, CRT AMBER, NEON PINK, FROZEN, CUSTOM

---

## 19. COLOR SYSTEM

**File:** `src/lib/colors.ts`

16-color neon palette with deterministic hash:
```typescript
const ACCENTS = [
  "#FF003C", "#00FFF0", "#FFE600", "#FF7700",
  "#9D00FF", "#00FF88", "#00BFFF", "#FF1493",
  "#ADFF2F", "#FFD700", "#FF4500", "#8A2BE2",
  "#39FF14", "#FF69B4", "#00CED1", "#FFA500",
];

function getSeriesAccent(seriesId: string): string {
  return ACCENTS[hashStr(seriesId) % ACCENTS.length];
}
```

Each series ALWAYS gets the same color regardless of list position, sorting, or filtering.

---

## 20. DOWNLOAD & EXPORT SYSTEM

### 3 Download Modes
1. **MERGE INTO 1 FILE** — all chapters concatenated into single .txt with chapter dividers
2. **ALL INDIVIDUAL** — each chapter as separate .txt file (triggered simultaneously)
3. **PICK CHAPTERS** — individual files with small delay between downloads

### Per-Chapter Download
Each chapter row has a download icon (↓) that fetches and saves that single chapter.

### Batch Download (Chapter Selection)
Long-press chapter → selection mode → DOWNLOAD SELECTED → batch fetches all selected chapters.

### File Formats
- **TXT**: plain text with markdown stripped, chapter headers, source attribution
- **EPUB**: planned (structure in place via `exporters.ts`)

### Server Endpoint
`POST /api/download` — fetches chapter content via RSS → JSON → Wayback fallback chain. Batched 50 chapters per request.

---

## 21. PWA & APK CONFIGURATION

### PWA Files
- `public/manifest.json` — app name, icons, standalone display, theme colors
- `public/sw.js` — service worker for offline caching (cache-first for assets, network-first for pages)
- `public/icon-192.png`, `public/icon-512.png`, `public/icon-32.png` — cyberpunk app icons

### Capacitor Android Project
- `android/` directory — full Gradle Android project
- `capacitor.config.ts` — app ID `com.nekro.hfycyberdeck`, web dir `mobile-web/`
- `mobile-web/index.html` — entry point that loads the live app URL

### Building the APK
1. **PWA Install** (easiest): Android Chrome → menu → "Install app"
2. **Bubblewrap**: `bubblewrap init --manifest={URL}/manifest.json && bubblewrap build`
3. **Android Studio**: open `android/` folder → Build → Build APK
4. **Gradle**: `cd android && ./gradlew assembleDebug`

---

## 22. FILE STRUCTURE

```
hfy-nekrocodexxx/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Root layout with 27 fonts + SW registration
│   │   ├── page.tsx                # Main app shell (splash + bottom nav)
│   │   ├── globals.css             # Cyberpunk theme tokens
│   │   └── api/
│   │       ├── series/
│   │       │   ├── route.ts        # GET baked-in series catalog
│   │       │   └── [slug]/
│   │       │       ├── route.ts    # GET wiki page + chapters
│   │       │       ├── chapters/route.ts    # GET/POST user chapters
│   │       │       ├── add-chapter/route.ts # POST manual chapter
│   │       │       └── reparse/route.ts     # POST error correction
│   │       ├── chapter/[id]/route.ts        # GET chapter content
│   │       ├── crawl/route.ts               # POST BFS crawler
│   │       ├── auto-discover/
│   │       │   ├── route.ts                 # POST start pipeline
│   │       │   └── [jobId]/route.ts         # GET poll status
│   │       ├── search/route.ts              # GET Reddit search
│   │       ├── search-series/route.ts       # GET unified search
│   │       ├── hfy-foundation-search/route.ts # GET hfy.foundation
│   │       ├── live-wiki/route.ts           # GET live wiki series
│   │       ├── wayback-sync/route.ts        # GET/POST Wayback sync
│   │       ├── download/route.ts            # POST chapter download
│   │       ├── purge-cache/route.ts         # POST purge all cache
│   │       └── proxy-stats/route.ts         # GET proxy health
│   ├── components/
│   │   ├── screens/
│   │   │   ├── BrowseScreen.tsx
│   │   │   ├── SeriesDetailScreen.tsx
│   │   │   ├── ReaderScreen.tsx
│   │   │   ├── LibraryScreen.tsx
│   │   │   ├── QueueScreen.tsx
│   │   │   └── SettingsScreen.tsx
│   │   ├── cyber/
│   │   │   ├── CyberPanel.tsx
│   │   │   ├── CyberButton.tsx
│   │   │   ├── CyberProgress.tsx
│   │   │   ├── CyberTag.tsx
│   │   │   ├── SeriesCard.tsx
│   │   │   └── LibrarySeriesCard.tsx
│   │   ├── export/exporters.ts
│   │   └── ui/                      # shadcn/ui components
│   ├── lib/
│   │   ├── cors-proxies.ts          # 386 proxy pool
│   │   ├── reddit-scraper.ts        # RSS primary scraper
│   │   ├── easy-reddit-downloader.ts # josephrcox port
│   │   ├── wayback.ts               # Wayback Machine
│   │   ├── hfy-foundation.ts        # hfy.foundation API
│   │   ├── chapter-crawler.ts       # BFS crawler
│   │   ├── user-chapters.ts         # Persistent cache
│   │   ├── colors.ts                # 16-color hash
│   │   ├── hfy-data.ts              # 2472 series + mock data
│   │   ├── stores.ts                # Zustand stores
│   │   ├── db.ts                    # Prisma client
│   │   └── utils.ts                 # cn() helper
│   └── hooks/
│       ├── use-mobile.ts
│       └── use-toast.ts
├── mini-services/
│   └── ws-parser/
│       ├── index.ts                 # Socket.io server (port 3003)
│       └── package.json
├── public/
│   ├── manifest.json                # PWA manifest
│   ├── sw.js                        # Service worker
│   ├── icon-192.png                 # App icon
│   ├── icon-512.png                 # App icon
│   ├── icon-32.png                  # Favicon
│   ├── logo.svg
│   └── robots.txt
├── android/                         # Capacitor Android project
├── mobile-web/index.html            # Capacitor web entry
├── capacitor.config.ts
├── prisma/schema.prisma
├── package.json
├── bun.lock
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.mjs
├── eslint.config.mjs
├── components.json
├── Caddyfile
└── .env
```

---

## 23. SETUP & INSTALLATION

### Prerequisites
- Node.js 18+ or Bun 1.0+
- npm or bun package manager

### Install & Run
```bash
# Extract the zip
unzip hfy-nekrocodexxx-v2.zip
cd hfy-nekrocodexxx

# Install dependencies
bun install

# Start the dev server
bun run dev

# (Optional) Start WebSocket parser
cd mini-services/ws-parser
bun install
bun run dev
# Returns to port 3003

# Open http://localhost:3000
```

### Build for Production
```bash
bun run build
bun run start
```

### Lint
```bash
bun run lint
```

---

## 24. KNOWN LIMITATIONS

### Reddit IP Blocking
The sandbox server's IP is blocked by Reddit (HTTP 403 on all endpoints). This affects:
- Wiki page `.json` fetch (blocked)
- Search `.json` (blocked)
- RSS feeds (intermittently blocked — rate-limit based)

**Workarounds in place:**
- RSS feeds work when not rate-limited (primary transport)
- Wayback Machine provides archived wiki pages (not blocked)
- hfy.foundation provides chapter lists (not blocked)
- CORS proxy pool (386 proxies) as fallback
- Browser import (bookmarklet/paste) as user fallback

**Running locally** on a residential IP resolves all blocking issues.

### hfy.foundation Search Limitations
The search API uses `sort=random` which returns random results. The `q` parameter appears to be ignored — the API returns the same results regardless of query. We work around this by paginating through multiple random pages and matching by name.

### Wayback Machine Coverage
Not all series have Wayback snapshots. Series created after the last Wayback crawl won't have archived wiki pages. Individual chapter snapshots are also sparse.

---

*END OF HFY NEKROCODEXXX TECHNICAL DOCUMENTATION*
*Version 2.0.0 | June 2026 | All content English only*


---

*End of Technical Documentation*
